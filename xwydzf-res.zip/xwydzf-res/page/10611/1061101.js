var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Layer.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#black_w",App.toshow);
		App.pageA.on("click","#ckjl",App.toYQJL);
		App.pageA.on("click","#wc",App.toCheck);
		App.pageA.on("click", "#yzm", App.toYZM);
		App.pageA.on("click","#gzhgg",App.togoGZ);
		App.pageA.on("focus", "#frxm", App.toFocus);
		App.pageA.on("blur", "#frxm", App.toBlur);
		App.pageA.on("focus", "#sjhm", App.toFocus);
		App.pageA.on("blur", "#sjhm", App.toBlur);
		App.pageA.on("focus", "#jgh", App.toFocus);
		App.pageA.on("blur", "#jgh", App.toBlur);
		App.pageA.on("click", "#iknow", App.toIknow);
		App.pageA.on("click", "#back", App.goBackHomeApp);
		if (App.data) {
			App.pageA.append(App.data.html);
		}
	},
	toshow:function(){
		App.pageA.unbind("touchmove");
	},
	//改变输入框样式
	toBlur:function(){
		var id=$(this).attr("id")+"f";
		$("#"+id).removeClass("yui-ldx-yy");
	},
	toFocus:function(){
		var id=$(this).attr("id")+"f";
		$("#"+id).addClass("yui-ldx-yy");
	},
	//弹窗
	toIknow:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	/**
	 * 表单提交
	 */
	toSubmit:function(){
		var artifName =$("#frxm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var tel =  /^(1)[0-9]{10}$/;
		if (artifName == null || artifName == "") {
			Fw.Form.showPinLabel($(this), "请输入姓名", true);
			return;
		}
			if (!tel.test(mobile)||mobile.length != '11') {
				Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
				return;
			}
		var url= YT.dataUrlWeb("private/inviteCodePush");
		var params={
				inviteName:artifName,
				org:$("#jgh").val(),
				mobile:mobile
		}
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url,params,function(data){
			if(data.STATUS=="1"){
				App.inviteName=data.inviteName;
				App.inviteCode=data.inviteCode;
				var height=document.body.clientHeight+500;
				var top=document.body.scrollTop+$(window).height()/4;
				$("#white_b").attr("style","top:"+top+"px;");
				$("#black").attr("style","height:"+height+"px;");
				$("#ts").attr("style","padding-top:"+top+"px;");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				var json={
						title:'邀请有礼',
						description:App.inviteName+" 邀请您签约兴业管家，好礼相送！",
						url:basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.inviteName)+"&inviteCode="+App.inviteCode,
						picUrl:basePath+"/css/img/xygj.png",
				}
				cibApp.doShare(json);
				Fw.Layer.hideWaitPanel();
			}
		},function(data){
			$("#content").html(data.MSG);
			$("#white_b").removeClass("hidden");
			$("#black").removeClass("hidden");
			//静止滑动
			App.pageA.bind("touchmove",function(e){
				e.preventDefault();
			});
			Fw.Layer.hideWaitPanel();}
		);
	},
	//立即邀请
	toYQJL:function(){
		Fw.redirect("1061102.html?data="+App.func("data")+"&mac="+App.func("mac"),App.data);
	},
	//活动规则
	togoGZ:function(){
		Fw.redirect("1061103.html?page=1061101&data="+App.func("data")+"&mac="+App.func("mac"),App.data);
	},
	goBackHomeApp:function(){
		Fw.redirect("1061100.html?data="+App.func("data")+"&mac="+App.func("mac"));
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);