/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#dj", App.toDG);
		App.pageA.on("click", "#ckgd", App.toCKGD);
		App.pageA.on("click", "#sqgd", App.toSQGD);
		App.pageA.on("click", "#ljyq", App.toLJYQ);
		App.pageA.on("click", "#back", App.goBack);
		var width=document.body.clientWidth-30-115-2;
		var splitWidth=width/3;
		var height=document.body.clientHeight*0.75;
		$("#yqjl").attr("style","width: 100%;height: "+height+"px;");
		$("#all").attr("style","width:"+width+";");
		$("#one").attr("style","width:"+splitWidth+";");
		$("#two").attr("style","width:"+splitWidth+";");
		$("#three").attr("style","width:"+splitWidth+";");
		$("#count").html(App.data.inviteCount);
		$("#primaryStandard").html(App.data.primaryNum);
		$("#intermediateStandard").html(App.data.intermediateNum);
		$("#advancedStandard").html(App.data.advancedNum);
		if (App.data) {
			App.pageA.append(App.data.html);
		}
	},
	//关闭提示
	toshow:function(){
		App.pageA.unbind("touchmove");
	},
	//立即邀请
	toLJYQ:function(){
		var json={
				title:'邀请有礼',
				description:App.data.inviteName+" 邀请您签约兴业管家，好礼相送！",
				url:basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.data.inviteName)+"&inviteCode="+App.data.inviteCode,
				picUrl:basePath+"/css/img/xygj.png",
		}
		cibApp.doShare(json);
	},
	//查看更多规则
	toCKGD:function(){
		$("#gzmx").removeClass("hidden");
		$("#ckgd").addClass("hidden");
		$("#sqgd").removeClass("hidden");
	},
	//收起更多规则
	toSQGD:function(){
		$("#gzmx").addClass("hidden");
		$("#ckgd").removeClass("hidden");
		$("#sqgd").addClass("hidden");
	},
	//去礼品信息登记界面
	toDG:function(){
		Fw.redirect("1061105.html?data="+App.func("data")+"&mac="+App.func("mac"),App.data);
	},
	goBack:function(){
		Fw.redirect("1061102.html?data="+App.func("data")+"&mac="+App.func("mac"),App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);