/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.flag=false;
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#iknow", App.toIknow);
		App.pageA.on("click", "#submitc", App.toSubmitC);
		App.pageA.on("click", "#back", App.goBack);
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black").attr("style","height:"+height+"px;");
		 var url= YT.dataUrlWeb("private/inviteeManageMail");
		 Fw.Layer.openWaitPanel();
			var params={
					mobile:App.data.mobile,
					queryFlag:"1"
			}
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					$("#xm").val(data.addressName);
					$("#sfz").val(data.idNo);
					$("#lpdz").val(data.mailingAddr);
					$("#yb").val(data.zipCode);
					Fw.Layer.hideWaitPanel();
				}else{
					$("#content").html(data.MSG);
					$("#white_b").removeClass("hidden");
					$("#black").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				$("#content").html(data.MSG);
				$("#white_b").removeClass("hidden");
				$("#black").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Layer.hideWaitPanel();
			});
	},
	toIknow:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	//保存收货地址
	toSubmitC:function(){
		var name =$("#xm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var idNo=$("#sfz").val();
		var tel =  /^(1)[0-9]{10}$/;
		var yb = $("#yb").val();
		var addr=$("#lpdz").val();
		var num=/[0-9]/;
		if (name == null || name == "") {
			Fw.Form.showPinLabel($(this), "请输入姓名", true);
			return;
			}
			if (idNo == "") {
				Fw.Form.showPinLabel($(this), "请输入身份证", true);
				return;
			}
			if (!num.test(idNo)||idNo.length != 18) {
				Fw.Form.showPinLabel($(this), "请输入正确身份证!", true);
				return;
			}
			if (yb == "") {
				Fw.Form.showPinLabel($(this), "请输入邮编", true);
				return;
			}
			if (!num.test(yb)||yb.length != 6) {
				Fw.Form.showPinLabel($(this), "请输入正确邮编!", true);
				return;
			}
			if (addr == "") {
				Fw.Form.showPinLabel($(this), "请输入礼品寄送地址", true);
				return;
			}
			 var url= YT.dataUrlWeb("private/inviteeManageMail");
			 Fw.Layer.openWaitPanel();
				var params={
						mobile:App.data.mobile,
						queryFlag:"2",
						addressName:name,
						mailingAddr:addr,
						zipCode:yb,
						idNo:idNo
				}
				YT.ajaxDataWeb(url,params,function(data){
					if(data.STATUS=="1"){
						$("#content").html("保存成功");
						$("#white_b").removeClass("hidden");
						$("#black").removeClass("hidden");
						Fw.Layer.hideWaitPanel();
					}else{
						$("#content").html(data.MSG);
						$("#white_b").removeClass("hidden");
						$("#black").removeClass("hidden");
						//静止滑动
						App.pageA.bind("touchmove",function(e){
							e.preventDefault();
						});
						Fw.Layer.hideWaitPanel();
					}
				},function(data){
					$("#content").html(data.MSG);
					$("#white_b").removeClass("hidden");
					$("#black").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					Fw.Layer.hideWaitPanel();
					}
				);
		},
		goBack:function(){
			Fw.redirect("1061104.html?data="+App.func("data")+"&mac="+App.func("mac"),App.data);
		}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);