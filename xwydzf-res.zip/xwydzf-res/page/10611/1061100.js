/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.initEvent();
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#btns", App.gotoOpen);
		App.pageA.on("click", "#cancel", App.gotoCancel);
		App.pageA.on("click", "#download", App.doOpenBrowser);
		App.pageA.on("click", "#open", App.doOpenApp);
		App.pageA.on("click", "#back", App.goBackHomeApp);
		var height=document.body.clientHeight;
		var width=document.body.clientWidth*0.15+10;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#black").css("height","3681px");
		if (App.func("data")&&App.func("mac")) {
			var url= YT.dataUrlWeb("private/dataDecrypt");
			var params={
					data:App.func("data"),
					mac:App.func("mac")
			}
			Fw.Layer.openWaitPanel();
			YT.ajaxDataWeb(url,params,function(data){
				App.decryptedData=data.decryptedData;
				var datas=YT.JsonEval(data.decryptedData);
				if(data.STATUS=="1"){
					var html='<script type="text/javascript" src="'+AppJs.fmtAppJs(""+datas.app)+'"></script>';
					App.html=html;
					App.pageA.append(html);
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Layer.hideWaitPanel();}
			);
		}
		
		$("#kehuduan").html("立即前往");
		
		window.onload=function(){
			setTimeout(function(){
				App.arr=[
				         "./css/0.png" ,
				         "./css/1.png" ,
				         "./css/2.png",
				         "./css/3.png",
				         "./css/4.png",
				         "./css/5.png",
				         "./css/6.png",
				         "./css/7.png"
				         ];
				App.i=0;
				App.Loadimg(App.i);
			},10)
		}
	},
	Loadimg:function(i){
		if(i<App.arr.length){
			var img=new Image();
			img.src="./css/"+i+".png";
			img.id="img"+i;
			$("#bg-tip2").append(img)
			App.Loadimg(App.i++);
		}else{
			$("#bg-tip2").find("img").addClass("imgStyle");
			App.pageA.on("click", "#img7", App.gotoOpen);
			setTimeout(function(){
				var height=document.body.scrollHeight>6381?document.body.scrollHeight:3681;
				$("#black").css("height",height)},1000)
			return;
		}
	},
	gotoOpen:function(){
		$("#white_b").removeClass("hidden");
		$("#black").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
		
	},
	//打开app
	doOpenApp:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
		var json = {};
		
		if (navigator.userAgent.indexOf('Android') > 0) {
			if(navigator.userAgent.indexOf('MicroMessenger') > 0){
				//weixin 打开应用宝
				window.location.href = "http://a.app.qq.com/o/simple.jsp?pkgname=com.yitong.mbank.xy&from=singlemessage";
			}else{
				 json={
						iOSScheme:"xingyeguanjia",
						AndroidPackageName:"com.yitong.mbank.xy",
						AndroidClassName:"com.yitong.mbank.xy.android.activity.SplashActivity",
						callbackName:"openFailBack"
				}
			}
		}else{
			if(navigator.userAgent.indexOf('MicroMessenger') > 0){
				//weixin 打开app store
				window.location.href = "https://itunes.apple.com/cn/app/id1085041167?mt=8";
			}else{
				json={
						iOSScheme:"xingyeguanjia",
						AndroidPackageName:"com.yitong.mbank.xy",
						AndroidClassName:"com.yitong.mbank.xy.android.activity.SplashActivity",
						callbackName:"openFailBack"
				}
			}
			 
		}
		cibApp.doOpenApp(json); 
	},
	//下载app
	doOpenBrowser:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
		var url="";
		
		if (navigator.userAgent.indexOf('Android') > 0) {
			if(navigator.userAgent.indexOf('MicroMessenger') > 0){
				//weixin
				window.location.href = "http://a.app.qq.com/o/simple.jsp?pkgname=com.yitong.mbank.xy&from=singlemessage";
			}else{
				//android
				url="http://download.cib.com.cn/netbank/download/cn/DGYDZF/download.html";
			}
		}else{
			if(navigator.userAgent.indexOf('MicroMessenger') > 0){
				//weixin
				window.location.href = "https://itunes.apple.com/cn/app/id1085041167?mt=8";
			}else{
				//ios
				url="https://itunes.apple.com/cn/app/id1085041167?mt=8";
			}
			
		}
		
		var json={
				url:url
		}
		cibApp.doOpenBrowser(json); 
	},
	gotoCancel:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	//返回App
	goBackHomeApp:function(){
		var data=YT.JsonEval(App.decryptedData);
		var time=new Date().getTime();
		var json={
						sn:"A04",
						from:"09",
						time:time
				}
		var params={
				data:YT.JsonToStr(json)
		}
		var url= YT.dataUrlWeb("private/dataEncrypt");
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url,params,function(data){
			if(data.STATUS=="1"){
				window.location.href = AppJs.portalUrl()+"?from=09&data="+data.encryptedData+"&mac="+data.mac;
			}
		},function(data){
			Fw.Form.showPinLabel($(this), data.MSG, true);
			Fw.Layer.hideWaitPanel();}
		);
	
	}
};
function openFailBack(){
	Fw.Form.showPinLabel($(this), "未安装兴业管家App，请点击下载", true);
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);