/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.next=0;
		App.beginTime ='';
		App.endTime = '';
		App.initEvent();
		App.queryDetail();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
	},
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		App.queryDetail();
	},
	queryDetail:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findRepayment");
		var params={
				toAcctNo:App.data.toAcctNo,
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				NEXT_KEY:App.next+"",
        		PAGE_SIZE:"10"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.list&&data.list.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
		try{
		if(data && data.list){
			var list=App.list=data.list;
			var html='';
			for(var i=0;i<list.length;i++){
				
				html+='<div class="list_item" onClick="App.gotoDetail('+i+')">'+
							'<div class="item_head"><label>还款申请编号:'+Fw.util.Format.subTrsNo(list[i].trsNo)+'</label></div>'+
							'<div class="item_content"><p>还款金额</p><div><span >'+Fw.util.Format.fmtAmt(list[i].amount+'')+'</span>元</div></div>'+
							'<div class="item_footer">'+
								'<div>还款账户<span>'+Fw.util.Format.account(list[i].fromAcctNo)+'</span></div>'+
								'<div>还款日期<span>'+Fw.util.Format.fmtTrsCreDate(list[i].creTime,'yyyy-MM-dd')+'</span></div>'+
							'</div>'+
					   '</div>';
				if(App.next=='0'){
					$("#repay_list").html(html);
				}else{
					$("#repay_list").append(html);
				}
			}
		}else{
			$("#more").hide()
			$("#end").hide();
			$("#repay_list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无还款记录~</div>');
		}
		if(data.NEXT_PAGE){
			$("#more").show();
			$("#end").hide();
			App.next=data.NEXT_KEY/1+10;
		}else{
			if (App.next>0) {
				$("#more").hide();
				$("#end").show();
			}else{
				$("#more").hide();
				$("#end").hide();
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
		}catch(e){
			alert(e)
		}
	},
	gotoDetail:function(i){
		App.data.trsNo=App.list[i].trsNo;
		Fw.redirect("1061842.html",App.data);
	},
	//返回
	goBack:function(){
		Fw.redirect("1061840.html",App.data);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);