/**
 * 创建应用
 * @author 
 */
var App = {
	requires : ['Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
			App.func = window['_getParameter'];
			App.pageA = $("#pageA");
			App.data = Fw.getParameters();
			App.flag = false;
			App.amountRange="0"//0正常 1本金小于最低还款  2 本金为零 存在利息  3逾期
			App.initEvent();
			App.initCY();
			App.queryDetail();
			App.idata={};
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#btnSubmit", App.onNext);
		App.pageA.on("click", "#fromAcctNo", App.initZH);
		App.pageA.on("click","#iconAmount",App.showMoneyPicker);
		App.pageA.on("click", "#cy", App.initZH);
		// 调用金额键盘
		App.pageA.on("click", "#amount", App.showMoneyPicker);
		App.pageA.on("click","#radio1",App.toRadio1);
		App.pageA.on("click","#radio2",App.toRadio2);
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker : function() {
		Fw.Client.showMoneyPicker($("#amount"),true);
	},
	queryDetail:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryDataForRePay");
		var params={
				loanAcctNo :App.data.loanAcctNo,
				productCode :App.data.financingApply.productCode,
				productVersion:App.data.financingApply.productVersion
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data){
					App.idata=data;
					App.loadData(data);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Client.alertinfo(data.MSG,"消息提示","App.gotoBackTest()");
			}
		})
	},
	toRadio1:function() {
		$("#radio2").prop("checked","");
		if (App.amountRange=="1") {
			$("#amount").val(Fw.util.Format.fmtAmt(App.idata.amount+""));
			$("#amount").attr("data-value",App.idata.amount);
			$("#writeAmount").html(Fw.util.Format.fmtAmt(App.idata.amount+""));
		}
		App.onKeypress();
	},
	toRadio2:function() {
		$("#radio1").prop("checked","");
		$("#amount").val("");
		$("#writeAmount").html("请输入");
		$("#capsAmount").html("零");
		$("#amount").attr("data-value","");
		App.onKeypress();
	},
	toCheckAmount:function(){
		$("#radio2").prop("checked","");
        $("#radio1").prop("checked","checked");
		var amount=$("#amount").attr("data-value");
		if (amount && amount !="0") {
			$("#capsAmount").html(Fw.util.Format.fmtNumber2Chinese(amount+""));
		}else{
			$("#capsAmount").html("零");
		}
		if ($("#amount").val()) {
			$("#writeAmount").html($("#amount").val())
		}else{
			$("#writeAmount").html("请输入");
		}
	},
	loadData:function(data){
		if (data && data.product) {
			$("#capsAmountAll").html(Fw.util.Format.fmtNumber2Chinese(data.hjje.toString()));
			$("#capsAmountAll").attr("data-value",data.hjje);
			$("#minacount").html(Fw.util.Format.fmtAmt(data.product.minRepaymentAmount+""));
			$("#minacount").attr("data-value",data.product.minRepaymentAmount);
			$("#allAmount").val(Fw.util.Format.fmtAmt(data.hjje+""));
			$("#allAmount").attr("data-value",data.hjje);
			$("#dkzh").html(Fw.util.Format.account(App.data.loanAcctNo));
			$("#loanContractNo").html(App.data.loanContractNo);
			$("#bxhj").html(Fw.util.Format.fmtAmt(data.hjje+""))
			$("#lx").html(Fw.util.Format.fmtAmt((data.hjje*1-data.amount*1)+""))
			//金额显示控制
			if(App.data.loanType=="3"){
				App.amountRange="3";
				$("#yqedxs").addClass("hidden");
			}else{
				if (data.product.minRepaymentAmount>data.amount) {
					//最低还款金额大于剩余还款金额
					if (data.amount==0 && data.hjje>0) {
						//本金为0存在利息
						App.amountRange="2";
				        $("#radio2").prop("checked","checked");
						$("#radio1").prop("checked","");
						$("#radio1").attr("disabled","disabled");
						App.pageA.off("click", "#amount", App.showMoneyPicker);
						App.pageA.off("click", "#iconAmount", App.showMoneyPicker);
						App.pageA.off("click","#radio1",App.toRadio1);
					}else{
						//存在本金
						App.amountRange="1";
						$("#amount").val(Fw.util.Format.fmtAmt(data.amount+""));
						$("#amount").attr("data-value",data.amount);
						$("#writeAmount").html(Fw.util.Format.fmtAmt(data.amount+""));
						App.pageA.off("click", "#amount", App.showMoneyPicker);
						App.pageA.off("click", "#iconAmount", App.showMoneyPicker);
					}
				}
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 汇款账户
	 */
	initCY : function() {
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findAcctList");
		YT.ajaxData(url, {}, function(data) {
			if (data.STATUS == "1") {
				App.datas = new Array();
				for ( var i = 0; i < data.datels.length; i++) {
					App.datas.push({
						account : data.datels[i].account.acctNo,
						balance : data.datels[i].response.kyye,
						accountName:data.datels[i].response.khmc
					});
				}
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});
	},
	/**
	 * 显示账户
	 */
	initZH : function() {
		var json = {
				jsonArray : App.datas,
				"func" : "App.showCommonlyUsedAccount"
			};
		Fw.Client.hideWaitPanel();
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	/**
	 * 账户回显
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		App.flag = false;
		var balance = parseFloat(balances);
		$("#fromAcctNo").val(account);
		$("#fromAcctName").html(name);
		Fw.Client.hideWaitPanel();
		App.onKeypress();
	},
	/**
	 * 判断是否信息都填写完整
	 */
	onKeypress : function() {
		var SKZH = $("#fromAcctNo").val().trim();
		var SKR = $("#fromAcctName").val().trim();
		var amount=$("#amount").val();
		if ($("#radio1:checked").val()) {
			if (SKZH && SKR && amount) {
				$("#btnSubmit").removeAttr("disabled");
			}else{
				$("#btnSubmit").attr("disabled", "disabled");
			}
		}else{
			if (SKZH && SKR) {
				$("#btnSubmit").removeAttr("disabled");
			}else{
				$("#btnSubmit").attr("disabled", "disabled");
			}
		}
	},
	showBJ:function(data){
		if (data.STATUS=="1") {
			App.trsNo=data.trsNo;
			var amount=$("#amount").attr("data-value");
			if ($("#radio2:checked").val()){
				amount=$("#allAmount").attr("data-value");
			}
			var xml='<M><k>合同编号</k><v>'+App.data.loanContractNo+'</v></M><M><k>贷款账号</k><v>'+App.data.loanAcctNo+'</v></M><M><k>还款账号</k><v>'+$("#fromAcctNo").val()+'</v></M><M><k>还款人</k><v>'+$("#fromAcctName").val()+'</v></M><M><k>还款金额</k><v>'+amount+'</v></M>';
			var json = {
					type : "4",
					func : "App.initComplete",
					funcAndroid:"App.initCompleteAndroid",
					XML : '<?xml version="1.0" encoding="utf-8"?><T><D>'+xml+'</D></T>'
			};
			Fw.Client.showBB(json);
			Fw.Client.hideWaitPanel();
		}else{
			App.callback(data);
		}
		
	},
	/**
	 * 提交
	 */
	onNext : function() {
		var amount=$("#amount").attr("data-value")*1;
		var minacount=$("#minacount").attr("data-value")*1;
		var allAmount=$("#allAmount").attr("data-value")*1;
		var fromAcctNo=$("#fromAcctNo").val();
		var fromAcctName=$("#fromAcctName").val();
		var bj=App.idata.amount*1;//本金
		if ($("#radio2:checked").val()){
			amount=$("#allAmount").attr("data-value");
		}
		if (!amount) {
			Fw.Form.showPinLabel($(this), "请输入还款金额", true);
			return;
		}
		if (amount<minacount && bj>=minacount && App.amountRange=="0") {
			Fw.Form.showPinLabel($(this), "还款金额不得小于单次还款最小金额", true);
			return;
		}
		if (allAmount<amount) {
			Fw.Form.showPinLabel($(this),"还款金额已超出剩余还款金额",true);
			return;
		}
		if (!fromAcctNo) {
			Fw.Form.showPinLabel($(this),"请选择还款账户",true);
			return;
		}
		if (!fromAcctName) {
			Fw.Form.showPinLabel($(this),"请选择还款人",true);
			return;
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag=true;
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("public/getRandomNum");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				url = "private/finaRePaymentTask.json";
				var params ={
						type:"1",
						trsType:"A",
						loanAcctNo:App.data.loanAcctNo,
						loanContractNo:App.data.loanContractNo,
						amount:amount+"",
						fromAcctNo:fromAcctNo,
						fromAcctName:fromAcctName,
						rePayType:$("#radio2:checked").val()?"0":"1",
						isComplete:"1",
						TOKEN:data.randomNum
				};
				Fw.Client.post(url, params, "App.showBJ", "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),data.MSG,true);
				return;
			}
		},function(data){
			App.failuri(data);
		});
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.flag = false;
		App.initBJ(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
	    App.flag = false;
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	/**
	 * 直接办结
	 */
	initBJ:function(a,b,fromAcctNo,fromAcctName,purpose){
			var params = {
					type:"2",
					trsType:"A",
					trsNo:App.trsNo,
					signData:a,
					signSrc:b
			};
			
			Fw.Client.openWaitPanel();
			var url = "private/finaRePaymentTask.json";
			Fw.Client.post(url,params,"App.success","App.failuri");
			
	},
	/**
	 * 直接办结成功回调函数
	 */
	success:function(data){
			if (data.STATUS == "1") {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.successBack()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示","App.initFail()");
			}
	},
	/**
	 * 办结成功返回
	 */
	successBack:function(){
		Fw.redirect("1061844.html", App.data);
	},
	sumMoney:function(){
		App.toCheckAmount();
		App.onKeypress();
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(data.MSG,"消息提示");
	},
	toShowAmount:function(){
		App.showMoneyPicker();
	},
	/**
	 * 返回待办列表
	 */
	gotoBackTest:function(){
		Fw.redirect("1061847.html", App.data);
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
