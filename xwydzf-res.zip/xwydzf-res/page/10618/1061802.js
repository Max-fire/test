/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);

	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toNext);
		App.pageA.on("click","#qkmm",App.showPwdPicker);
		App.pageA.on("porpertychanger","#cardNo",App.checkAll);
		App.pageA.on("input","#cardNo",App.checkAll);
		App.pageA.on("porpertychanger","#msgCode",App.checkAll);
		App.pageA.on("input","#msgCode",App.checkAll);
		var params = {
				"type":"15",
				"mobile":App.data.financingList.firmOwnerPhone,
		};
		sendUtil.openTimerListener("yzm",params);
		
	},
	checkAll:function(){
		var cardNo=$("#cardNo").val();
		var password=$("#qkmm").val();
		var msgCode=$("#msgCode").val();
		if (cardNo && password && msgCode) {
			$("#btnSubmit").removeAttr("disabled", "");
		}else{
			$("#btnSubmit").attr("disabled", "disabled");
		}
	},
	toNext:function(){
		var cardNo=$("#cardNo").val();
		var password=$("#qkmm").attr("data-value");
		var msgCode=$("#msgCode").val();
		if (!cardNo) {
			Fw.Form.showPinLabel($(this), "请输入本行银行卡号!", true);
			return;
		}
		if (!password) {
			Fw.Form.showPinLabel($(this), "请输入取款密码!", true);
			return;
		}
		if (!msgCode) {
			Fw.Form.showPinLabel($(this), "请输入验证码!", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/finacFirmownerAuth");
		var params={
				cardNo:cardNo,
				password:password,
				mobile:App.data.financingList.firmOwnerPhone,
				productCode:App.data.List.productCode,
				productVersion:App.data.List.productVersion,
				MSG:msgCode
		}
		YT.ajaxData(url, params, function(data) {
			if (data.STATUS == "1") {
				App.toQM();
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
				
			})
	},
	toQM:function(){
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/financingES001");
		var params={
				contractType:"y7",
				financingApplyNo:App.data.financingApply.financingApplyNo,
				productCode:App.data.financingList.productCode,
				productVersion:App.data.financingList.productVersion
	
		}
		YT.ajaxData(url, params, function(datas) {
			if (datas.STATUS == "1") {
				var esignNo=datas.result.esignNo;
				params.contractType="y2";
				App.data.y7=datas.downFilePath;
				YT.ajaxData(url, params, function(data) {
					if (data.STATUS == "1") {
						esignNo=esignNo+","+data.result.esignNo;
						App.data.esignNo=esignNo;
						App.data.y2=data.downFilePath;
						Fw.redirect("1061803.html",App.data);
					}else{
						Fw.Client.alertinfo(data.MSG,"系统提示");
					}
					Fw.Client.hideWaitPanel();
					},function(data){
						Fw.Client.alertinfo(data.MSG,"系统提示");
						Fw.Client.hideWaitPanel();
						
					})
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
				
			})
	},
	/**
	 * 密码键盘
	 */
	showPwdPicker:function(){
		Fw.Client.showPwdPicker($("#qkmm"));
	},
	ownerInfo:function(){
		Fw.Client.alertinfo("企业主是指企业持股比例50%以上的自然人控股、占有企业股份的企业法定代表人或企业实际控制人","消息提示");
	},
	//返回
	gotoMsg:function(){
		Fw.redirect("1061801.html",App.data);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);