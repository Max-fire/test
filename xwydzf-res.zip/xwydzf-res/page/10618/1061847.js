/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.next=0;
		App.i=0;
		App.type="";
		App.json=new Array();
		App.arr=[{name:'所有状态',value:''},{name:'删除',value:'0'},{name:'有效',value:'1'},{name:'销户',value:'2'},{name:'挂失',value:'3'},{name:'冻结',value:'4'},{name:'不动户',value:'5'},{name:'已收账',value:'7'},{name:'结清',value:'A'}];
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#more", App.queryList);
		App.pageA.on("click", "#syzt", App.showSel);
		App.pageA.on("click", "#black_b", App.hideSelinfo);
		App.queryList();
	},
	showSel:function(){
		App.type=$(this).attr("id");
		var name=$("#"+App.type).val();
		var value=$("#"+App.type).attr("data-value");
		var arr=App.arr,html='',arrow='',selIndex='',labelSel='';
		for(var i=0;i<arr.length;i++){
			if(value==arr[i].value){
				selIndex=i;
				break;
			}
		}
		for(var i=0;i<arr.length;i++){
			arrow=i==0?'<i></i>':'';
			selSpan=i==selIndex?'':'hidden';
			labelSel=i==selIndex?'labelSel':'';
			html+='<div id="selinfo'+i+'" onClick="App.hideSelinfo('+i+')"><label class="'+labelSel+'">'+arr[i].name+arrow+'</label><span class="'+selSpan+'"></span></div>';
		}
		$("#white_b").html(html);
		$("#white_b").removeClass("hidden");
		$("#black_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
		e.preventDefault();
		});
	},
	hideSelinfo:function(i){
		$("#white_b").addClass("hidden");
		$("#black_b").addClass("hidden");
		if(i>=0){
			var arr=App.arr;
			$("#selinfo"+i).find("span").removeClass("hidden");
			$("#selinfo"+i).find("label").addClass("labelSel")
			
			$("#selinfo"+i).siblings().find("span").addClass("hidden");
			$("#selinfo"+i).siblings().find("label").removeClass("labelSel");
			
			$("#"+App.type).val(arr[i].name);
			$("#"+App.type).attr("data-value",arr[i].value)
			App.next=0;
			App.queryList();
		}
		
		App.pageA.unbind("touchmove");
		
	},
	/**
	 * 查询记录
	 */
	queryList:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/finaRepayList");
		var params={
				loanContractNo:App.data.financingApply.loanContractNo,
//				loanContractNo:"xd201812110016",
				NEXT_KEY:App.next+"",
				status:$("#syzt").attr("data-value"),
        		PAGE_SIZE:"5"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.list&&data.list.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			}else{
				$("#more").hide()
				$("#end").hide();
				$("#list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无还款清单~</div>');
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				//Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
		if(data && data.list){
			var list=data.list;
			var html='';
			if (App.next=="0") {
				App.json=[];
				App.i=0;	
			}
			App.json.push(data.list);
			for(var i=0;i<list.length;i++){
				html+='<div class="list_item">'+
				'<div onClick="App.gotoPage('+1+','+i+','+App.i+')">'+
				'<div class="yui-info-border">'+
					'<div class="pro_num"><span style="color:#8F9DAD;flex:1;">贷款账号：'+Fw.util.Format.fmtAcct(list[i].loanAcctNo+"")+'</span><span style="min-width: 83px;text-align: right;color:'+(list[i].status=="A"?"#00A74C":"#2574D2")+';">'+Fw.util.Format.recordStatusFmt(list[i].status)+'<span style="padding-left:5px;'+(list[i].status=="A"?"border-right:4px solid #00A74C":"border-right:4px solid #2574D2")+';"></span></span></div>'+
					'<div class="yui-amount-info">'+
						'<div class="pro_name">发放金额</div>'+
						'<div class="yui-amount-font"><span style="font-size:16px;">'+Fw.util.Format.fmtAmt(list[i].payAmount+"")+'</span>元</div>'+
					'</div>'+
				'</div>'+
				'<div class="pro_detail">'+
					'<div><label>账户金额</label><span>'+Fw.util.Format.fmtAmt(list[i].remainAmount+"")+'</span></div>'+
					'<div><label>起始日期</label><span>'+Fw.util.Format.fmtTrsCreDate(list[i].beginDate,"yyyy-MM-dd")+'</span></div>'+
					'<div><label>到期日期</label><span>'+Fw.util.Format.fmtTrsCreDate(list[i].endDate,"yyyy-MM-dd")+'</span></div>'+
				'</div>'+
				'</div>'+
				'<div class="pro_btm" style="padding-top: 0px;">'+			
						'<div onClick="App.gotoPage('+2+','+i+','+App.i+')">还款记录</div>';
						if(list[i].remainAmount*1>0){
							html+='<div onClick="App.gotoPage('+3+','+i+','+App.i+')">立即还款</div>';	
						}else{
							html+='<div>立即还款</div>';	
						}											
				html+='</div></div>';
			}
			App.i++;
			if(App.next=='0'){
				$("#list").html(html);
			}else{
				$("#list").append(html);
			}
		}else{
			$("#more").hide()
			$("#end").hide();
			$("#list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无还款清单~</div>');
		}
		if(data.NEXT_PAGE){
			$("#more").show();
			$("#end").hide();
			App.next=data.NEXT_KEY/1+5;
		}else{
			if (App.next>0) {
				$("#more").hide();
				$("#end").show();
			}else{
				$("#more").hide();
				$("#end").hide();
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
		
	},
	gotoPage:function(flag,i,j){
			Fw.Client.openWaitPanel();
			var json=App.json[j][i];
			json.loanContractNo=App.data.financingApply.loanContractNo,
			json.financingApply=App.data.financingApply;
			if(flag==1){
				//还款清单详情
				Fw.redirect("1061845.html",json);
			}else if(flag==2){
				Fw.redirect("1061848.html",json);
			}else if(flag==3){
				Fw.redirect("1061849.html",json);
			}
	},
	//返回
	goBack:function(){
		Fw.redirect("1061800.html");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);