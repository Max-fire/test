/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.y6=false;
		YT.showPageArea(App.pageA, [], true);
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#rz",App.toLook);
		App.pageA.on("porpertychanger","#userName",App.toCheck);
		App.pageA.on("input","#userName",App.toCheck);
		App.pageA.on("porpertychanger","#idCard",App.toCheck);
		App.pageA.on("input","#idCard",App.toCheck);
		App.pageA.on("click","#swmm",App.showPwdPicker);
		$("#swNo").val(App.data.financingList.firmIdNo)
		if (App.data && App.data.sqDetail) {
			$("#swmm").val(App.data.sqDetail.swmm);
			$("#swmm").attr("data-value",App.data.sqDetail.reswmm);
			$("#userName").val(App.data.sqDetail.userName);
			$("#idCard").val(App.data.sqDetail.idCard);
		}
	},
	toLook:function(){
		if (!App.y6) {
			Fw.Form.showPinLabel($(this), "请您认真阅读《涉税数据查询授权书》", true);
			$("#rz").prop("checked","")
			return;
		}else{
			App.toCheck();
		}
	},
	toCheck:function(){
		var swmm=$("#swmm").val();
		var userName=$("#userName").val();
		var idCard=$("#idCard").val();
		if (swmm && userName && idCard && $("#rz:checked").val()) {
			$("#btnSubmit").removeAttr("disabled", "");
		}else{
			$("#btnSubmit").attr("disabled", "disabled");
		}
	},
	toSubmit:function(){
		var swmm=$("#swmm").val();
		var reswmm=$("#swmm").attr("data-value");
		var userName=$("#userName").val();
		var idCard=$("#idCard").val();
		if (!swmm) {
			Fw.Form.showPinLabel($(this), "请输入税务密码!", true);
			return;
		}
		if (!userName) {
			Fw.Form.showPinLabel($(this), "请输入用户姓名!", true);
			return;
		}
		if (!idCard) {
			Fw.Form.showPinLabel($(this), "请输入身份证号码!", true);
			return;
		}
		if (!$("#rz:checked").val()) {
			Fw.Form.showPinLabel($(this), "请勾选涉税数据查询授权书!", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/financingTaxInfoQuery");
		var json={
				firmOwerId:idCard,
				taxRegistNo:App.data.financingList.firmIdNo+"",
				bankName:"兴业银行",
				netPassWord:reswmm,
				financingApplyNo:App.data.financingApply.financingApplyNo
		}
	    YT.ajaxData(url,json,function(data){
	    	if (data.STATUS=="1") {
	    		App.toShowBB();
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			}
	    },App.fail);
	},
	/**
	 * 密码键盘
	 */
	showPwdPicker:function(){
		Fw.Client.showTPwdPicker($("#swmm"),"","1");
	},
	fail:function(data){
		Fw.Client.alertinfo(data.MSG,"系统提示");
		Fw.Client.hideWaitPanel();
	},
	gotoQuery:function(){
		Fw.redirect("1061820.html");
	},
	/**
	 * 验签
	 */
	toShowBB:function(){
		Fw.Client.openWaitPanel();
		var xml='<M><k>'+App.data.financingList.firmName+'</k><v>同意签署《涉税信息查询授权书》并授权兴业银行按照国家相关规定获取本公司相关涉税信息</v></M>'
		var json = {
				type : "4",
				func : "App.initComplete",
				funcAndroid:"App.initCompleteAndroid",
				XML : '<?xml version="1.0" encoding="utf-8"?><T><D>'+xml+'</D><E><M><k>md5</k><v>'+App.data.md5+'</v></M></E></T>'
			};
		Fw.Client.showBB(json);
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * 支付棒确认提交
	 */
	initSubmit:function(a,b){	
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/financingTaxAuth");
		var json = {
				signData:a,
				signSrc:b,
				contractType:"y6",
				financingApplyNo:App.data.financingApply.financingApplyNo
		};
		YT.ajaxData(url, json, function(data) {
			if (data.STATUS == "1") {
				Fw.redirect("1061802.html",App.data)
				Fw.Client.hideWaitPanel();
            } else {
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			App.callback(data);
		});
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
        Fw.Client.alertinfo(data.MSG,"消息提示");
	},
	/**
	 * 涉税信息查询授权书
	 */
	gotoSQ:function(){
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host
		var url=path+App.data.y6;
		App.y6=true;
		url=basePath+"/page/10618/css/pdf/web/viewer.html?url="+url;
		Fw.Client.changeWeb(url,false,pageB);
	},
	//返回
	gotoMsg:function(){
		Fw.redirect("1061801.html",App.data)
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);