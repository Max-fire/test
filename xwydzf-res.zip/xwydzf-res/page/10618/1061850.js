/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.tabValue='';
		App.tabStat='-1';//判断与App.tabValue是否相同 刷新sel数据
		App.next=0;
		App.i=0;
		App.json=new Array();
		App.beginTime ='';
		App.endTime = '';
		Fw.Client.openWaitPanel();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		App.arr=[{name:'所有状态',value:''},{name:'银行处理中',value:'2'},{name:'提款成功',value:'3'},{name:'交易失败',value:'1'}];
		
		App.pageA.on("click", ".tabClick", App.changeTab);
		App.pageA.on("click", ".syzt", App.showSel);
		App.pageA.on("click", "#black_b", App.hideSelinfo);
		App.pageA.on("click", "#more", App.queryList);
		if(App.data.financingApply.productCode&&App.data.financingApply.productCode=="CP0000002"){
		//if(App.data.financingApply.productCode&&App.data.financingApply.productCode=="CP0000001"){
			$("#head").addClass("hidden");
			App.arr[1].name="申请已提交";
			$("#white_b").css("top","0");
		}
		if(App.data.tabValue){
			if(App.data.tabValue=="2"){
				$("#yzf").find("span").addClass("tab_spansel");
				$("#yzf").siblings().find("span").removeClass("tab_spansel");
				App.tabValue="2"
				$("#choose").addClass("hidden");
			}else{
				$("#sysq").find("span").addClass("tab_spansel");
				$("#sysq").siblings().find("span").removeClass("tab_spansel");
				App.tabValue=""
			}
			if(!App.data.queryStatus){
				App.queryList();
			}else{
				App.hideSelinfo(App.data.queryStatus);
			}
			
		}else{
			App.queryList();
		}
		
	},
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		App.hideSelinfo(-1);
		App.next=0;
		App.queryList();
	},
	changeTab:function(){
		if(App.tabValue!=$(this).attr("data-value")){
			if ($(this).attr("data-value")) {
				$("#choose").addClass("hidden");
			}else{
				$("#choose").removeClass("hidden")
			}
			$(this).find("span").addClass("tab_spansel");
			$(this).siblings().find("span").removeClass("tab_spansel");
			$("#syzt").val("所有状态");
			$("#syzt").attr("data-value","");
			App.tabValue=$(this).attr("data-value");
			App.hideSelinfo(-1);
			App.next=0;
			App.beginTime ='';
			App.endTime = '';
			App.queryList();
		}
	},
	showSel:function(){
//		if(App.tabStat!=App.tabValue){
			App.tabStat=App.tabValue;
			var name=$("#syzt").val();
			var arr=App.arr;
			var html='',arrow='',selIndex='',labelSel='';
			for(var i=0;i<arr.length;i++){
				if(name==arr[i].name){
					selIndex=i;
					break;
				}
			}
			for(var i=0;i<arr.length;i++){
				arrow=i==0?'<i></i>':'';
				selSpan=i==selIndex?'':'hidden';
				labelSel=i==selIndex?'labelSel':'';
				html+='<div id="selinfo'+i+'" onClick="App.hideSelinfo('+i+')"><label class="'+labelSel+'">'+arr[i].name+arrow+'</label><span class="'+selSpan+'"></span></div>';
			}
			$("#white_b").html(html);
//		}
		$("#white_b").removeClass("hidden");
		$("#black_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	hideSelinfo:function(i){
		
		$("#white_b").addClass("hidden");
		$("#black_b").addClass("hidden");
		
		if(i>=0){
			var arr=App.arr;
			if(arr[i].name==$("#syzt").val()){//选择的input内相同 不刷新
				App.pageA.unbind("touchmove");
				return false;
			}
			$("#selinfo"+i).find("span").removeClass("hidden");
			$("#selinfo"+i).find("label").addClass("labelSel")
			
			$("#selinfo"+i).siblings().find("span").addClass("hidden");
			$("#selinfo"+i).siblings().find("label").removeClass("labelSel");
			
			$("#syzt").val(arr[i].name);
			$("#syzt").attr("data-value",arr[i].value)
			App.next=0;
			App.j=i;
			App.queryList();
		}else{
			App.j="";
		}
		App.pageA.unbind("touchmove");
		
	},
	/**
	 * 查询提款列标
	 */
	queryList:function(){
		Fw.Client.openWaitPanel();
		var value=$("#syzt").attr("data-value");
		if(value==''){//全部
			if(App.tabValue!=''){//tab已支付
				value='3';
			}
		}
		var url = YT.dataUrl("private/queryFinacWithdrawRecord");
		var params={
				loanContractNo:App.data.financingApply.loanContractNo,
				status:value,
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				NEXT_KEY:App.next+"",
        		PAGE_SIZE:"5"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.datas&&data.datas.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			}else{
				$("#list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无提款记录~</div>');
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
		try{
			if(data && data.datas){
				var list=App.list=data.datas;
				App.financingApply=data.financingApply;
				if (App.next=="0") {
					App.json=[];
					App.i=0;	
				}
				App.json.push(data.datas);
				var html='';
				for(var i=0;i<list.length;i++){
					if(App.tabValue==''){
						var statusColor=App.fmtPayStatusCor(i);
						html+='<div class="list_item" onClick="App.gotoDetail('+i+','+App.i+')">'+
									'<div class="item_head"><div class="list_flex">提款申请编号：'+list[i].financingPayment.withdrawApplyNo+'</div><span style="color:'+statusColor+';border-right: 4px solid '+statusColor+'">'+(App.fmtPayStatus(i)=="重新支付失败"?"支付失败":App.fmtPayStatus(i))+'</span></div>'+
									'<div class="item_content"><div class="list_flex" style="color:#365169;">提款金额</div><span style="color:#FF7F00">'+Fw.util.Format.fmtAmt(list[i].trsTrsfr.amount+'')+'元</span></div>'+
									'<div class="item_footer"><div class="list_flex">申请日期</div><span>'+Fw.util.Format.fmtTrsCreDate(list[i].financingPayment.creTime,"yyyy-MM-dd")+'</span></div>';
									if(App.fmtPayStatus(i)=='支付失败'){
										html+='<div style="padding:8px 15px 12px 15px;font-size: 14px;display: block;text-align:right"><button class="item_btn" onClick="App.payAgain('+i+','+App.i+')">重新发起支付</button></div>';
									}
						html+='</div>';
					}else{
						var withdrawApplyNo=list[i].financingPayment.withdrawApplyNo;
						var amount=Fw.util.Format.fmtAmt(list[i].trsTrsfr.amount+'');
						var dateMonth=App.dateMonth(list[i].financingPayment.creTime,list[i].financingPayment.expiringDate);
						var expiringDate=Fw.util.Format.fmtTrsCreDate(list[i].financingPayment.expiringDate);
						var toAcctNo=Fw.util.Format.account(list[i].trsTrsfr.toAcctNo);
						html+='<div class="list_item" onClick="App.gotoDetail('+i+','+App.i+')">'+
									'<div class="yzf_head">提款申请编号：'+withdrawApplyNo+'</div>'+
									'<div class="yzf_content">支付金额</div>'+
									'<div class="yzf_content" style="font-size:36px;color: #FF7F00;justify-content: center;-webkit-justify-content: center;-webkit-box-pack: center;align-items: baseline;text-align: center;">'+amount+'<span>元</span></div>'+
									'<div class="yzf_footer"><div class="list_flex">收款方账户</div><span>'+toAcctNo+'</span></div>'+
									'<div class="yzf_footer"><div class="list_flex">最后还款日</div><span>'+expiringDate+'</span></div>'+
									'<div class="yzf_footer" style="padding-bottom:12px;"><div class="list_flex">贷款额度期限</div><span>'+dateMonth+'个月</span></div>'+
								'</div>';
					}
				}
				App.i++;
				if(App.next=='0'){
					$("#list").html(html);
				}else{
					$("#list").append(html);
				}
			}else{
				$("#more").hide()
				$("#end").hide();
				$("#list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无提款记录~</div>');
			}
			
			if(data.NEXT_PAGE){
				$("#more").show();
				$("#end").hide();
				App.next=data.NEXT_KEY/1+5;
			}else{
				if (App.next>0) {
					$("#more").hide();
					$("#end").show();
				}else{
					$("#more").hide();
					$("#end").hide();
				}
			}
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA, [], true);
			}catch(e){
				alert(e);
				Fw.Client.hideWaitPanel();
			}
	},
	/**
	 * 格式化提款状态
	 */
	fmtPayStatus:function(i){
		var fpment=App.list[i].financingPayment,fpstatus='--';
		var trs=App.list[i].trsTrsfr;
		var status=fpment.status;
		var fpstatus="";
		if (status=="1") {
				if(fpment.withdrawStatus=='2' && fpment.paymentStatus=='3' && trs.trsferType !="PAY_AGAIN_TRANSFER"){
					fpstatus="支付失败";
				}else if(fpment.withdrawStatus=='2' && fpment.paymentStatus=='3' && trs.trsferType =="PAY_AGAIN_TRANSFER"){
					fpstatus="重新支付失败";
				}else if(fpment.withdrawStatus=='3'){
					fpstatus="提款失败";
				}else{
					fpstatus="--";
				}
		}else if(status=="2"){
			if(App.data.financingApply.productCode=="CP0000002"){//快押贷
			//if(App.data.financingApply.productCode=="CP0000001"){
				fpstatus="申请已提交"
			}else{
				fpstatus="银行处理中"
			}
		}else if(status=="3"){
			fpstatus="提款成功";
		}
		return fpstatus;
	},
	fmtPayStatusCor:function(i){
		var fpment=App.list[i].financingPayment,fpcolor='#5D6574';
		if(fpment.status=="2"){
			fpcolor="#2574D2"//"银行处理中";
		}else if(fpment.status=="3"){
			fpcolor="#00A74C"//"提款成功";
		}else if(fpment.status=="1"){
			fpcolor="#FF3B30"//"支付失败";
		}
		return fpcolor;
	},
	dateMonth:function(date1,date2){
		if(date1 && date2){
			date1=Fw.util.Format.fmtTrsCreDate(date1,"yyyy-MM-dd");
			date1=date1.split('-');
			var num1=date1[2];
			date1=parseInt(date1[0])*12+parseInt(date1[1]);
			
			date2=Fw.util.Format.fmtTrsCreDate(date2,"yyyy-MM-dd");
			date2=date2.split('-');
			var num2=date2[2];
			date2=parseInt(date2[0])*12+parseInt(date2[1]);
			if(num2-num1>0){//date2 日 大于 date1 日
				date2+=1;	
			}
			return Math.abs(date2-date1);
		}else{
			return '--';
		}
	},
	/**
	 * 提款详情
	 */
	gotoDetail:function(i,j){
		try{
			App.data.financingPayment=App.json[j][i].financingPayment;
			App.data.trsTrsfr=App.json[j][i].trsTrsfr;
			App.data.tabValue=App.tabValue?App.tabValue:"1";
			App.data.queryStatus=App.j;
			Fw.redirect("1061851.html",App.data);
		}catch(e){
			alert(e)
		}
		
	},
	/**
	 * 重新发起支付
	 */
	payAgain:function(i,j){
		event.stopPropagation();
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryFinacWithdrawSeria");
		var params={
				withdrawApplyNo:App.json[j][i].financingPayment.withdrawApplyNo,
				trs_no:App.json[j][i].financingPayment.trsNo
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				App.data.financingApply=App.financingApply;
				App.data.financingPayment=App.json[j][i].financingPayment;
				App.data.trsTrsfr=App.json[j][i].trsTrsfr;
				App.data.tabValue=App.tabValue?App.tabValue:"1";
				App.data.queryStatus=App.j;
				Fw.redirect("1061830.html",App.data)
				Fw.Client.hideWaitPanel();
			}else{
				App.callback(data);
			}
		},function(data){
			App.callback(data);
		})
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(data.MSG,"消息提示","App.success()");
	},
	//返回
	goBack:function(){
		var json={}
		json.financingApply=App.data.financingApply;
		Fw.redirect('1061821.html',json);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);