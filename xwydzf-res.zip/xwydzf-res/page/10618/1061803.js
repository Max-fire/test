/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.result={};
		App.y2=false;
		App.y7=false;
		App.initEvent();
		YT.showPageArea(App.pageA, [], true);

	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#grsq",App.toGRSQ);
		App.pageA.on("click","#dbht",App.toDBHT);
		App.pageA.on("porpertychanger","#msgCode",App.toCheck);
		App.pageA.on("click","#rz",App.toCheckXY);
		App.pageA.on("input","#msgCode",App.toCheck);
		$("#firmName").html(App.data.financingList.firmName);
		$("#productName").html(App.data.financingList.productName);
		$("#amount").html(App.data.financingApply.applyAmount);
		$("#loanTerm").html(App.data.financingApply.loanTerm);
		$("#financingApplyNo").html(App.data.financingApply.financingApplyNo);
		var params = {
				type:"15",
				mobile:App.data.financingList.firmOwnerPhone,
				esignNo:App.data.esignNo
		};
		sendUtil.openTimerListener("yzm",params, true);
		Fw.Client.hideWaitPanel();
	},
	toSubmit:function(){
		if($("#rz:checked").val()==null){
			Fw.Form.showPinLabel($(this), "请勾选授权协议", true);
			return;
		}
		if(!$("#msgCode").val()){
			Fw.Form.showPinLabel($(this), "请输入验证码", true);
			return;
		}
		if(App.result.result && App.result.result.id){
		}else{
			Fw.Form.showPinLabel($(this), "请获取数字认证码", true);
			return;
		}
		Fw.Client.openWaitPanel();
		App.toFinancingAuthorize();
	},
	toCheckXY:function(){
		if (!App.y2 || !App.y7) {
			Fw.Form.showPinLabel($(this), "请您认真阅读相关协议", true);
			$("#rz").prop("checked","")
			return;
		}
		App.toCheck();
	},
	toCheck:function(){
		if ($("#rz:checked").val() && $("#msgCode").val()) {
			$("#btnSubmit").removeAttr("disabled", "");
		}else{
			$("#btnSubmit").attr("disabled", "disabled");
		}
	},
	toFinancingAuthorize:function(){
		//两次002
		var url= YT.dataUrl("private/financingAuthorize");
		var params={
				id:App.result.result.id,
//				id:"123456",
				financingApplyNo:App.data.financingApply.financingApplyNo,
				smsCode:$("#msgCode").val(),
				eSignNo:App.data.esignNo
	
		}
		YT.ajaxData(url, params, function(data) {
			if (data.STATUS == "1") {
				App.toSave();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			})
	},
	toSave:function(){
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/submitFinancingApply");
		var params={
				financingApplyNo:App.data.financingApply.financingApplyNo,
		}
		YT.ajaxData(url, params, function(data) {
			if (data.STATUS == "1") {
				Fw.redirect("1061804.html",App.data);
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}
			Fw.Client.hideWaitPanel();
			},function(data){
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
				
			})
	},
	/**
	 * 查看个人征信授权书
	 */
	toGRSQ:function(){
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host
		var url=path+App.data.y7;
		App.y7=true;
		url=basePath+"/page/10618/css/pdf/web/viewer.html?url="+url;
		$("#pageB").attr("title","个人征信授权书")
		Fw.Client.changeWeb(url,false,pageB);
	},
	/**
	 * 查看最高额保证担保合同
	 */
	toDBHT:function(){
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host
		var url=path+App.data.y2;
		App.y2=true;
		url=basePath+"/page/10618/css/pdf/web/viewer.html?url="+url;
		$("#pageB").attr("title","最高额保证合同")
		Fw.Client.changeWeb(url,false,pageB);
	},
	showCallBack:function(data){
		//007返回
		App.result=data;
	},
	//返回
	gotoMsg:function(){
		Fw.redirect("1061802.html",App.data);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);