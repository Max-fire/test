﻿/**
 * 创建应用
 * 
 * @author zhy
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.tabStatus='';// ''所有   3带签   5生效
		App.next=0;
		App.id="sysq";
		App.json=new Array();
		App.i=0;
		App.type='';
		App.productArr=[{name:'所有产品',value:''}];
		App.statusArr=[{name:'所有状态',value:''},{name:'银行审核中',value:'2'},{name:'待签合同',value:'3'},{name:'已确认',value:'4'},{name:'已发放',value:'5'},{name:'已终止',value:'6'},{name:'已结清',value:'7'},{name:'失效',value:'08'}];;
		App.beginTime ='';
		App.endTime = '';
		//查询产品
		App.initEvent();
		App.queryProduct();
		if (App.func("queryType")) {
			App.changeTab(App.func("queryType"));
		}else{
			if(App.data&&App.data.queryType){
				App.changeTab(App.data.queryType);
			}else{
				App.queryList();
			}
		}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		App.pageA.on("click", ".tabClick", App.tabClick);
		App.pageA.on("click", ".selClick", App.showSel);
		
		App.pageA.on("click", "#black_b", App.hideSelinfo);
		App.pageA.on("click", "#more", App.queryList);
		
	},
	/**
	 * tab切换
	 */
	tabClick:function(){
		
		$("#white_b").addClass("hidden");
		$("#black_b").addClass("hidden");
		
		var id=$(this).attr("id");
		if(App.id==id){//点击的tab没切换 不刷新
			return false;
		}else{
			App.changeTab(id);
		}
		
	},
	changeTab:function(id){
		App.id=id;
		$("#"+id).addClass("tab_sel");
		$("#"+id).siblings().removeClass("tab_sel");
		
		$("#"+id+"_i").addClass("tab_line_i");
		$("#"+id+"_i").siblings().removeClass("tab_line_i");
		
		var arr=[];
		if(id=="ysx"){
			App.tabStatus='5';
			arr=[{name:'所有状态',value:''},{name:'已确认',value:'4'},{name:'已发放',value:'5'},{name:'已终止',value:'6'},{name:'已结清',value:'7'},{name:'失效',value:'08'}];
		}else if(id=="dqht"){
			App.tabStatus='3';
			arr=[{name:'所有状态',value:''},{name:'待签合同',value:'3'},{name:'失效',value:'08'}];
		}else if(id=="sysq"){
			App.tabStatus='';
			arr=[{name:'所有状态',value:''},{name:'银行审核中',value:'2'},{name:'待签合同',value:'3'},{name:'已确认',value:'4'},{name:'已发放',value:'5'},{name:'已终止',value:'6'},{name:'已结清',value:'7'},{name:'失效',value:'08'}];
		}
		App.next=0;
		App.statusArr=arr;
		$("#syzt").val("所有状态");$("#syzt").attr("data-value","");
		$("#sycp").val("所有产品");$("#sycp").attr("data-value","");
		
		App.beginTime ='';
		App.endTime = '';
		App.queryList();
	},
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		App.hideSelinfo(-1);
		App.queryList();
	},
	/**
	 * select选择
	 */
	showSel:function(){
//		if(App.type!=$(this).attr("id")){
			App.type=$(this).attr("id");
			var name=$("#"+App.type).val();
			var value=$("#"+App.type).attr("data-value");
			var arr=[],html='',arrow='',selIndex='',labelSel='';
			if(App.type=="sycp"){//产品
				arr=App.productArr;
			}else{//状态
				arr=App.statusArr;
			}
			for(var i=0;i<arr.length;i++){
				
				if(value==arr[i].value){
					selIndex=i;
					break;
				}
			}
			for(var i=0;i<arr.length;i++){
				arrow=i==0?'<i></i>':'';
				selSpan=i==selIndex?'':'hidden';
				labelSel=i==selIndex?'labelSel':'';
				html+='<div id="selinfo'+i+'" onClick="App.hideSelinfo('+i+')"><label class="'+labelSel+'">'+arr[i].name+arrow+'</label><span class="'+selSpan+'"></span></div>';
			}
			$("#white_b").html(html);
//		}
		
		$("#white_b").removeClass("hidden");
		$("#black_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
		
	},
	hideSelinfo:function(i){
		
		$("#white_b").addClass("hidden");
		$("#black_b").addClass("hidden");
		if(i>=0){
			var arr=[];
			if(App.type=="syzt"){
				arr=App.statusArr;
			}else{
				arr=App.productArr;
			}
//			if(arr[i].value==$("#"+App.type).atrr("data-value")){//选择的input内相同 不刷新
//				return false;
//			}
			$("#selinfo"+i).find("span").removeClass("hidden");
			$("#selinfo"+i).find("label").addClass("labelSel")
			
			$("#selinfo"+i).siblings().find("span").addClass("hidden");
			$("#selinfo"+i).siblings().find("label").removeClass("labelSel");
			
			$("#"+App.type).val(arr[i].name);
			$("#"+App.type).attr("data-value",arr[i].value)
			App.next=0;
			App.queryList();
		}
		
		App.pageA.unbind("touchmove");
		
	},
	/**
	 * 查询产品列表
	 */
	queryProduct:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryFinancingProduct");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS=="1"){
				if(data.List&&data.List.length>0){
					App.productArr=[{name:'所有产品',value:''}];
					for(var i=0;i<data.List.length;i++){
						App.productArr.push({name:data.List[i].productName,value:data.List[i].productCode});
					}
					Fw.Client.hideWaitPanel();
				}else{
					Fw.Client.hideWaitPanel();
					YT.showPageArea(App.pageA, [], true);
					Fw.Form.showPinLabel($(this), "暂无产品信息", true);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	/**
	 * 查询申请记录
	 */
	queryList:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findFinancingApplyList");
		var params={
				ancillaryStatus:$("#syzt").attr("data-value").replace(/\s/g,""),
				applyStatus:App.tabStatus,
				productCode:$("#sycp").attr("data-value").replace(/\s/g,""),
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				NEXT_KEY:App.next+"",
        		PAGE_SIZE:"10"        		
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.list&&data.list.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	/**
	 * 加载数据
	 */
	loadData:function(data){
		
		try{
		console.log("loadData-------------");
		if(data && data.list){
			var list=data.list;
			if (App.next=="0") {
				App.json=[];
				App.i=0;	
			}
			App.json.push(data.list);
			var html='';
			for(var i=0;i<list.length;i++){
				var loanMainType=list[i].loanMainType=="0"?'（企业借款）':'（企业主借款）';
				var applyStatus=list[i].applyStatus?Fw.util.Format.formatFianancStatus(list[i].applyStatus):"无状态";
				var applyTime=list[i].applyTime?Fw.util.Format.fmtTrsCreDate(list[i].applyTime,"yyyy-MM-dd"):'--';
				
				var applyAmount=list[i].applyAmount?Fw.util.Format.fmtAmt(list[i].applyAmount+''):'--';
				var approveAmount=list[i].approveAmount?Fw.util.Format.fmtAmt(list[i].approveAmount+''):'--';
				var interestRate=list[i].interestRate?list[i].interestRate:'';
				var transferInAcct=list[i].transferInAcct?Fw.util.Format.account(list[i].transferInAcct):'--'; 
				
				var color='',border='';
				if(["1","2","3"].indexOf(list[i].applyStatus)!=-1){
					color="color:#2574D2 ;";
					border='border-right:4px solid #2574D2;'
				}else if(["4","5"].indexOf(list[i].applyStatus)!=-1){
					color="color:#00A74C;";
					border='border-right:4px solid #00A74C;'
				}else{
					color="color:#FF3B30;";
					border='border-right:4px solid #FF3B30;'
				}
				
				if(App.tabStatus==''){//所有申请
					
					html+='<div class="list_item" onClick="App.btmClick('+0+','+i+','+App.i+')">'+
							'<div style="border-bottom:1px solid rgb(226, 226, 221);">'+
								'<div class="pro_num"><div style="color:#8F9DAD;-webkit-box-flex:1;-webkit-flex:1;flex:1">合同编号：'+list[i].loanContractNo+'</div><div style="min-width: 83px;text-align:right;'+color+'">'+applyStatus+'<span style="padding-left:5px;'+border+'"></span></div></div>'+
								'<div class="pro_name">'+list[i].productName+'-'+loanMainType+'</div>'+
							'</div>'+
							'<div class="pro_time">'+
								'<span>申请日期</span><span>'+applyTime+'</span>'+
							'</div>'+
						  '</div>';
				}else{
					var prodNum=list[i].productCode=='CP0000002'?list[i].loanContractNo:list[i].financingApplyNo;
					var proName=list[i].productCode=='CP0000002'?'快押贷':list[i].productName;
					if(list[i].productCode=='CP0000002'){
						applyStatus='有效';
						color="color:#00A74C;";
						border='border-right:4px solid #00A74C;'
						loanMainType='（企业借款）';
					}
					
					
					html+='<div class="list_item">'+
							'<div onClick="App.btmClick('+0+','+i+','+App.i+')">'+
							'<div style="border-bottom:1px solid rgb(226, 226, 221);">'+
								'<div class="pro_num"><span style="color:#8F9DAD;flex:1;">合同编号：'+list[i].loanContractNo+'</span><span style="min-width: 83px;text-align: right;'+color+'">'+applyStatus+'<span style="padding-left:5px;'+border+'"></span></span></div>'+
								'<div class="pro_name">'+proName+'-'+loanMainType+'</div>'+
							'</div>';
					if(list[i].productCode=='CP0000002'){//快压贷
						var usedAmout=list[i].usedAmout?Fw.util.Format.fmtAmt(list[i].usedAmout+''):'--';
						html+='<div class="pro_detail">'+
								'<div><label>贷款主体</label><span style="color:#FF7F00;display:inline-block;">'+list[i].firmName+'</span></div>'+
								'<div><label>货币种类</label><span>'+list[i].currency+'</span></div>'+
								'<div><label>核定额度</label><span>'+approveAmount+'</span></div>'+
								'<div><label>活期账号</label><span>'+transferInAcct+'</span></div>'+
								'<div><label>已用额度</label><span>'+usedAmout+'</span></div>'+
							  '</div>'+
						'</div>';
						html+='<div class="pro_btm">';
						if(!list[i].usedAmout || (list[i].approveAmount && list[i].approveAmount*1>list[i].usedAmout*1)){
							html+='<div onClick="App.btmClick('+3+','+i+','+App.i+')">提款申请</div>';
						}else{
							html+='<div style="background: #ccc;color: #fff; border: 1px solid #ccc;">提款申请</div>';
						}
						html+='<div onClick="App.btmClick('+4+','+i+','+App.i+')">立即还款</div>';
						html+= '</div>'+
						'</div>';
						//已生效且为快押贷
						if(App.tabStatus == '5'){
								$(".financeList_sel").css("visibility","hidden");
						}
					}else{
						html+='<div class="pro_detail">'+
								'<div><label>审批金额</label><span style="color:#FF7F00;">￥'+approveAmount+'</span></div>'+
								'<div><label>申请金额</label><span>￥'+applyAmount+'</span></div>'+
								'<div><label>申请日期</label><span>'+applyTime+'</span></div>'+
								'<div><label>申请主体</label><span>'+list[i].firmName+'</span></div>'+
								'<div><label>企业主</label><span>'+list[i].firmOwnerName+'</span></div>'+
								'<div><label>借款利率</label><span>'+interestRate+'%</span></div>'+
								'<div><label>入款及还款账户</label><span>'+transferInAcct+'</span></div>'+
							'</div>'+
						'</div>';
						if(App.tabStatus=='3'){
							if(applyStatus=='失效'){
								html+='<div class="pro_btm">'+
								'<div style="background: #ccc;color: #fff; border: 1px solid #ccc;">取消合同</div>'+
								'<div style="background: #ccc;color: #fff; border: 1px solid #ccc;">签订合同</div>'+
								'</div>'+
								'</div>';
							}else{
								html+='<div class="pro_btm">'+
								'<div onClick="App.btmClick('+1+','+i+','+App.i+')">签订合同</div>'+
								'</div>'+
								'</div>';
							}
							
						}else{
							html+='<div class="pro_btm">';
							if(applyStatus=='已发放'){
								html+='<div onClick="App.btmClick('+3+','+i+','+App.i+')">提款申请</div>';
							}else{
								html+='<div style="background: #ccc;color: #fff; border: 1px solid #ccc;">提款申请</div>';
							}
							if(applyStatus=='已发放' ||　applyStatus=='已终止'){
								html+='<div onClick="App.btmClick('+4+','+i+','+App.i+')">立即还款</div>';
							}else{
								html+='<div onClick="App.btmClick('+4+','+i+','+App.i+')">还款清单</div>';
							}
							html+= '</div>'+
							'</div>';
						}
					}
					}	
			}
			App.i++;
			if(App.next=='0'){
				$("#finance-list").html(html);
			}else{
				$("#finance-list").append(html);
			}
		}else{
			$("#more").hide()
			$("#end").hide();
			$("#finance-list").html('<div style="text-align:center;padding-top: 50%;color:#999;background:#f8f8f8;">暂无申请记录~</div>');
		}
		//只有已生效含快押贷 不进行分页
		if(App.tabStatus!='5'){
			 if(data.NEXT_PAGE){
					$("#more").show();
					$("#end").hide();
					App.next=data.NEXT_KEY/1+10;
				}else{
					if (App.next>0) {
						$("#more").hide();
						$("#end").show();
					}else{
						$("#more").hide();
						$("#end").hide();
					}
				}
		}
		YT.showPageArea(App.pageA, [], true);
		Fw.Client.hideWaitPanel();
		}
		catch(e){
			alert(e);
			Fw.Client.hideWaitPanel();
		}
	},
	/**
	 * btmClick 详情 签订 取消
	 */
	btmClick:function(type,index,j){
		Fw.Client.openWaitPanel();
		var json={
				page:'1061820.html',
			}
		var url= YT.dataUrl("private/findFinancingApplyDetail");
		var params={
	      "financingApplyNo":App.json[j][index].financingApplyNo,	
        }
		if (App.json[j][index].productCode=="CP0000002") {
   			json.financingApply=App.json[j][index];
   			App.changePage(type,json);
		}else{
			YT.ajaxData(url,params,function(data){
				if(data.STATUS=="1"){
					json.financingApply=data.data;
					App.changPage(type,json);
				}else{
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG,"消息提示","App.fail()");
				}
			})
      	}
       
	},
	changePage:function(type,json){
		if(type==0){//详情
			Fw.redirect("1061821.html",json);
		}else if(type==1){//签订合同
		//001
		var url= YT.dataUrl("private/financingES001");
		var params={
			contractType:"y3",
			financingApplyNo:json.financingApply.financingApplyNo,
			productCode:json.financingApply.productCode,
			productVersion:json.financingApply.productVersion
	}
	YT.ajaxData(url, params, function(data) {
		if (data.STATUS == "1") {
			json.queryType="dqht";
			json.y3=data.downFilePath;
			json.md5=data.md5;
			Fw.redirect("1061822.html",json);
        } else {
			App.flag=false;
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
		}
		},function(data){
			App.flag=false;
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
		});
		}else if(type==2){
			Fw.redirect("1061821.html",json);
		}else if(type==3){//提款
			Fw.redirect("1061830.html",json);
		}else if(type==4){//还款
			if (json.financingApply.productCode=="CP0000002") {
				Fw.redirect("1061847.html",json);
			}else{
				Fw.redirect("1061840.html",json);
			}
	
		}
	},
	
	back:function(){
		Fw.redirect("1061800.html");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);