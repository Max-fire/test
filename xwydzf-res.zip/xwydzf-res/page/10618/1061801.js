/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		try {
			
			App.initEvent();
		} catch (e) {
			// TODO: handle exception
			alert(e)
		}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toNext);
		App.pageA.on("click","#amount",App.showMoneyPicker);	
		$("#minAmount").html(Fw.util.Format.fmtMoney(App.data.List.minAmount+""));
		$("#maxAmount").html(Fw.util.Format.fmtMoney(App.data.financingList.amount+""));
		$("#firmOwnerName").html(App.data.financingList.firmOwnerName);
		$("#ownerIdNo").html(Fw.util.Format.fmtAcct(App.data.financingList.ownerIdNo.trim()+""));
		if (App.data.financingApply) {
			$("#amount").val(Fw.util.Format.fmtMoney(App.data.financingApply.applyAmount+""));
			$("#writeAmount").html(Fw.util.Format.fmtMoney(App.data.financingApply.applyAmount+""))
			$("#amount").attr("data-value",App.data.financingApply.applyAmount);
			$("#date").html(App.data.financingApply.loanTerm);
			$("#acct").html(App.data.financingApply.transferInAcct);
			$("#btnSubmit").removeAttr("disabled", "");
		}
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/findAcctList");
		var json={
				type:"1",//只显示当前企业所在地区的对公账号
				brNo:App.data.financingList.brNo
		}
		App.acct=new Array();
		YT.ajaxData(url, json, function(data) {
			if (data.STATUS == "1") {
				for ( var i = 0; i < data.datels.length; i++) {
					App.acct.push({
						account : data.datels[i].account.acctNo,
						balance : data.datels[i].response.kyye,
						accountName:data.datels[i].response.khmc
					});
				}
			}
			YT.showPageArea(App.pageA, [], true);
			Fw.Client.hideWaitPanel();
			},function(data){
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
				
			})
	},
	toNext:function(){
		var amount=$("#amount").attr("data-value");
		var date=$("#date").html();
		var acct=$("#acct").html();
		if (amount*1>App.data.financingList.amount*1 || amount*1<App.data.List.minAmount*1) {
			Fw.Client.alertinfo("贷款申请额度不得低于最低可申请额度，不得高于最高可申请额度","温馨提示");
			return;
		}
		if (date == "请选择贷款额度期限" ) {
			Fw.Form.showPinLabel($(this), "请选择贷款额度期限!", true);
			return;
		}
		if (acct == "请选择活期账号" ) {
			Fw.Form.showPinLabel($(this), "请选择活期账号!", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/financingApply");
		var params={
				productVersion:App.data.financingList.productVersion+"",
				productCode:App.data.financingList.productCode+"",
				loanMainType:"0",
				applyAmount:amount+"",
				transferInAcct:acct+"",
				singleLoanTerm:date+""
		}
		YT.ajaxData(url, params, function(data) {
			if (data.STATUS == "1") {
				App.data.financingApply=data.financingApply;
				if (App.data.financingList.brNo =="G0000024") {
					App.toFinancingES001();
					
				}else {
					Fw.redirect("1061802.html",App.data);
					Fw.Client.hideWaitPanel();
				}
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			})
	},
	toFinancingES001:function(){
		var url= YT.dataUrl("private/financingES001");
		var params={
				contractType:"y6",
				financingApplyNo:App.data.financingApply.financingApplyNo,
				productCode:App.data.financingApply.productCode,
				productVersion:App.data.financingApply.productVersion
		}
		YT.ajaxData(url, params, function(data) {
			if (data.STATUS == "1") {
				App.data.y6=data.downFilePath;
				App.data.md5=data.md5;
				Fw.redirect("1061805.html",App.data);
				Fw.Client.hideWaitPanel();
            } else {
				App.flag=false;
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			App.flag=false;
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
		});
	},
	//选择贷款期限
	toChooseDate:function(){
		var data=new Array();
		var date="";
		var length=App.data.List.singleLoanTerm*1+1;
		for ( var i = 1; i < length; i++) {
			data.push({
				account : i+"",
				balance : "0",
				accountName:"0"
			});
		}
		var json = {
				jsonArray : data,
				"func" : "App.showDate",
				type:"1"
			};
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	showDate:function(account, balances,name){
		$("#date").html(account);
		if ($("#date").html() != "请选择贷款额度期限" && $("#acct").html() != "请选择活期账号" && $("#amount").val() && $("#amount").val()!="0.00") {
			$("#btnSubmit").removeAttr("disabled", "")
		}else{
			$("#btnSubmit").attr("disabled", "disabled")
		}
	},
	//选择入款账号
	toChooseAcct : function() {
		var json = {
				jsonArray : App.acct,
				"func" : "App.showAcct"
			};
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	showAcct:function(account, balances,name){
		$("#acct").html(account);
		if ($("#date").html() != "请选择贷款额度期限" && $("#acct").html() != "请选择活期账号" && $("#amount").val()&& $("#amount").val()!="0.00") {
			$("#btnSubmit").removeAttr("disabled", "")
		}else{
			$("#btnSubmit").attr("disabled", "disabled")
		}
	},
	toCheck:function(){
		if ($("#date").html() != "请选择贷款额度期限" && $("#acct").html() != "请选择活期账号" && $("#amount").val()&& $("#amount").val()!="0.00") {
			$("#btnSubmit").removeAttr("disabled", "")
		}else{
			$("#btnSubmit").attr("disabled", "disabled")
		}
		if ($("#amount").val()) {
			$("#writeAmount").html($("#amount").val())
		}else{
			$("#writeAmount").html("请输入");
		}
		
	},
	toAmount:function(){
		App.showMoneyPicker();
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker: function(){
		Fw.Client.showMoneyPicker($("#amount"),true);
	},
	sumMoney:function(){
		App.toCheck();
	},
	/**
	 * 客户经理信息提示
	 */
	custManagerInfo:function(){
		var msg="请联系客户经理："+App.data.financingList.custManagerName+"\n手机号："+App.data.financingList.custManagerPhone
		Fw.Client.alertinfo(msg,"企业主信息错误");
	},
	ownerInfo:function(){
		Fw.Client.alertinfo("企业主是指企业持股比例50%以上的自然人控股、占有企业股份的企业法定代表人或企业实际控制人","消息提示");
	},
	//返回
	gotoMsg:function(){
		Fw.redirect("1061800.html");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);