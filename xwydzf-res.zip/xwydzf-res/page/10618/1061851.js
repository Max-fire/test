﻿/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		 App.pageA.on("click",".payAgain",App.payAgain);
		 var list={}
		 for ( var i in App.data.financingApply) {
			 list[i]=App.data.financingApply[i]
		}
		 for ( var i in App.data.trsTrsfr) {
			 list[i]=App.data.trsTrsfr[i]
		 }
		 for ( var i in App.data.financingPayment) {
			 list[i]=App.data.financingPayment[i]
		 }
		 if(App.data.financingApply.productCode&&App.data.financingApply.productCode=="CP0000002"&&App.fmtPayStatus()=='提款成功'){
		     $("#itip").removeClass("hidden");
		 }
		 App.loadData(list);
	},
	loadData:function(data){
		try{
			Fw.Client.openWaitPanel();
			var list=data;
			if(App.fmtPayStatus()=='支付失败' || App.fmtPayStatus()=='提款失败'|| App.fmtPayStatus()=='重新支付失败'){
				YT.showPageArea(App.pageA, [App.pageB], true);
				if(App.fmtPayStatus()!='支付失败'){
					$("#payAgain").attr("style","display:none");
				}
				$("#zfzt").html(App.fmtPayStatus());//支付状态
				$("#dkedqx").html(App.dateMonth(list.beginDate,list.expiringDate));//贷款额度期限
				
				var arr=['tkje','tksqbh','sqrq','hqzh','zhmc','dkll','skfzh','skfzhm','skfkhhm','skfkhhh','sbyy','dkzh','dkhtbh','yt'];
				for(var i=0;i<arr.length;i++){
					var name=App.fmtIdToFiledName(arr[i]);
					if(list[name] || list[name]==0){
						$("#"+arr[i]).html(list[name]);
						if(name=='amount'){
							$("#"+arr[i]).html(Fw.util.Format.fmtAmt(list[name]+''));
						}
						if(name=='beginDate' ||　name=='expiringDate' || name=='creTime'){
							$("#"+arr[i]).html(Fw.util.Format.fmtTrsCreDate(list[name],'yyyy-MM-dd'));
						}
						if(name=='dkll'){
							$("#"+arr[i]).html(list[name]+'%');
						}
					}
				}
				
			}else{
				YT.showPageArea(App.pageB, [App.pageA], true);
				$("#dkedqx1").html(App.dateMonth(list.beginDate,list.expiringDate));//贷款额度期限
				
				var arr1=['tksqbh1','hqzh1','zhmc1','dkzh1','dkll1','skfzh1','skfzhm1','skfkhhm1','skfkhhh1','dkhtbh1','yt1',
				          'zfje1','hted1','qsrq1','dqrq1','dkpz1','wtr1','dsbxzh1','fkzflx1'];
				for(var j=0;j<arr1.length;j++){
					var name=App.fmtIdToFiledName(arr1[j]);
					if(list[name] || list[name]==0){
						$("#"+arr1[j]).html(list[name]);
						if(name=='amount'　|| name=='contractLimit'){
							$("#"+arr1[j]).html(Fw.util.Format.fmtAmt(list[name]+'')+'元');
						}
						if(name=='beginDate' ||　name=='expiringDate'){
							$("#"+arr1[j]).html(Fw.util.Format.fmtTrsCreDate(list[name],'yyyy-MM-dd'));
						}
						if(name=='interestRate'||name=='dkll1'){//贷款利率 执行利率
							$("#"+arr1[j]).html(list[name]+'%');
						}
						if(name=='loanPayType'){
							var zname=list[name]=='0'?'自主支付':'受托支付'
							$("#"+arr1[j]).html(zname);
						}
						if(name=='loanVariety'){
							var loanVariety=list[name]=="06"?"额度循环贷款":"--";
							$("#"+arr1[j]).html(loanVariety);
						}
						
					}
					
				}
				
				
			}
			Fw.Client.hideWaitPanel();
			
		}catch(e){
			alert(e);
			Fw.Client.hideWaitPanel();
		}
	},
	fmtIdToFiledName:function(id){
		switch(id){
			case 'tkje'://提款金额
				return 'amount';
			case 'zfje1'://支付金额
				return 'amount';
			case 'tksqbh'://提款申请编号
				return 'withdrawApplyNo';
			case 'tksqbh1':
				return 'withdrawApplyNo';
			case 'sqrq'://申请日期
				return 'creTime';
			case 'hqzh'://活期账号
				return 'fromAcctNo';
			case 'hqzh1':
				return 'fromAcctNo';
			case 'zhmc'://账户名称
				return 'fromAcctName';
			case 'zhmc1':
				return 'fromAcctName';
			case 'dkll'://贷款利率
				return 'interestRate';
			case 'dkll1':
				return 'interestRate';
			case 'skfzh'://收款方账号
				return 'toAcctNo';
			case 'skfzh1':
				return 'toAcctNo';
			case 'skfzhm'://收款方账户名
				return 'toAcctName';
			case 'skfzhm1':
				return 'toAcctName';	
			case 'skfkhhm'://收款方开户行名
				return 'toBankName';
			case 'skfkhhm1':
				return 'toBankName';
			case 'skfkhhh'://收款方开户行号
				return 'toBrCode';
			case 'skfkhhh1':
				return 'toBrCode';
			case 'sbyy'://失败原因
				return 'errMsg';
			case 'dkzh'://贷款账号
				return 'loanAcctNo';
			case 'dkzh1':
				return 'loanAcctNo';
			case 'dkhtbh'://贷款合同编号
				return 'loanContractNo';
			case 'dkhtbh1':
				return 'loanContractNo';
			case 'yt'://用途
				return 'purpose';
			case 'yt1':
				return 'purpose';	
			case 'hted1'://合同额度
				return 'contractLimit';
			case 'qsrq1'://起始日期
				return 'beginDate';
			case 'dqrq1'://到期日期
				return 'expiringDate';
			case 'dkpz1'://贷款品种
				return 'loanVariety';
			case 'wtr1'://委托人
				return 'consignName';
			case 'dsbxzh1'://代收本息账号
				return 'clctPnpintAcctno';
			case 'fkzflx1'://放款支付类型
				return 'loanPayType';
			default:
				return '';
				
		}
	},
	dateMonth:function(date1,date2){
		if(date1 && date2){
			date1=Fw.util.Format.fmtTrsCreDate(date1,"yyyy-MM-dd");
			date1=date1.split('-');
			var num1=date1[2];
			date1=parseInt(date1[0])*12+parseInt(date1[1]);
			
			date2=Fw.util.Format.fmtTrsCreDate(date2,"yyyy-MM-dd");
			date2=date2.split('-');
			var num2=date2[2];
			date2=parseInt(date2[0])*12+parseInt(date2[1]);
			if(num2-num1>0){//date2 日 大于 date1 日
				date2+=1;	
			}
			return Math.abs(date2-date1)+"个月";
		}else{
			return '--';
		}
	},
	fmtPayStatus:function(){
		var fpment=App.data.financingPayment,fpstatus='--';
		var trs=App.data.trsTrsfr;
		var status=fpment.status;
		if (status=="1") {
			if(fpment.withdrawStatus=='2' && fpment.paymentStatus=='3' && trs.trsferType !="PAY_AGAIN_TRANSFER"){
				fpstatus="支付失败";
			}else if(fpment.withdrawStatus=='2' && fpment.paymentStatus=='3' && trs.trsferType =="PAY_AGAIN_TRANSFER"){
				fpstatus="重新支付失败";
			}else if(fpment.withdrawStatus=='3'){
				fpstatus="提款失败";
			}else{
				fpstatus="--";
			}
		}else if(status=="2"){
			if(App.data.financingApply.productCode=="CP0000002"){//快押贷
				    fpstatus="申请已提交"
			}else{
					fpstatus="银行处理中"
			}
		}else if(status=="3"){
			fpstatus="提款成功";
		}
		return fpstatus;
	},
	//返回
	willBack:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1061850.html",App.data);
	},
	/**
	 * 重新支付
	 */
	payAgain:function(){
		var url = YT.dataUrl("private/queryFinacWithdrawSeria");
		Fw.Client.openWaitPanel();
		var params={
				withdrawApplyNo:App.data.financingPayment.withdrawApplyNo,
				trs_no:App.data.financingPayment.trsNo
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				Fw.redirect("1061830.html",App.data)
				Fw.Client.hideWaitPanel();
			}else{
				App.callback(data);
			}
		},function(data){
			App.callback(data);
		})
	 },
	 callback:function(data){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示","App.success()");
		},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);