﻿/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.datas={};
		App.attach=new Array();
		App.canGo=true;
		if(App.data.financingApply.productCode=='CP0000002'){
			App.loadKyadDetail(App.data.financingApply)
		}else{
			App.initEvent();
			App.query();
		}
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
	     App.pageA.on("click","#fail",App.onReason);
		 App.pageA.on("click","#okBtn",App.okBtn);
		 App.pageA.on("click","#okbtn",App.okQdht);
		 App.pageA.on("click","#cancelBtn",App.cancelBtn);
		 $("#kytk").bind("click",function(){App.toGo("2")});
		 $("#tkuan").bind("click",function(){App.toGo("2")});
		 $("#hkuan").bind("click",function(){App.toGo("3")});
		 App.queryProduct();
	},
	/**
	 * 查询产品
	 */
	queryProduct:function(){
		var params={
				productCode:App.data.financingApply.productCode,
				productVersion:App.data.financingApply.productVersion
			}
		var url = YT.dataUrl('private/queryFinancingProduct');
		Fw.Client.openWaitPanel();
		YT.ajaxData(url, params, function(data) {
			if(data.STATUS=="1"){
				App.data.financingProduct=data.financingProduct;
				$("#dbfs").html(data.financingProduct.guarantyDetail||"")
			}else{
				App.callback(data);
			}	
		},function(data){
			App.callback(data);
		});
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
        Fw.Client.alertinfo(data.MSG,"消息提示");
	},
	query:function(){
		Fw.Client.openWaitPanel();
        var url= YT.dataUrl("private/findFinancingApplyDetail");
       var params={
	      "financingApplyNo":App.data.financingApply.financingApplyNo,	
        }
       YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.data||data.List){
					App.custManagerName=data.data.custManagerName||"";
					App.custManagerPhone=data.data.custManagerPhone||"";
					App.datas=data
					App.loadData(data)
				}
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.fail()");
			}
		})
   },
   fail:function(){
	   Fw.redirect("1061820.html");
   },
   loadData:function(data){
	   try{
		var List=App.attach=data.List; 
    	var data=data.data;
    	App.data.financingApply=data;
    	document.title=(data.productName||"")+"详情";
    	var title=(data.productName||"")+"详情"
    	App.pageA.attr("title",title);
    	$("#zt").html(Fw.util.Format.formatFianancStatus(data.applyStatus+""))
    	var spje=data.approveAmount?"￥"+Fw.util.Format.fmtAmt(data.approveAmount+''):"--"
    	var jdll=data.interestRate?data.interestRate+'%':"--"
		$("#spje").html(spje)
		$("#jdll").html(jdll)
		$("#sytked").html(Fw.util.Format.fmtAmt(data.remainLimit+''));
		if(data.applyStatus){
			var applySta=Fw.util.Format.formatFianancStatus(data.applyStatus);
			if(applySta=='失效'){
				$("#zt").css("color","#FF3B30");
			}else{
		    	if(data.applyStatus<="3"){
		    	    var width=(document.body.clientWidth-144)/2;
					$("#shzcbx1").attr("style","width:"+width+"px;");
					$("#shzcbx2").attr("style","width:"+width+"px;");
					$("#titlew").removeClass("hidden")
					$("#cancelBtn").removeClass("hidden")
					for(var i=0;i<data.applyStatus;i++){
						$("#circle"+(i+1)).attr("src","../../css/img/yshw.png")
						if(i>=1){
							 $("#shzcbx"+i).attr("src","../../css/img/shzclbg.png");
						}
					}
					if(data.applyStatus=="3"){
						$("#okbtn").removeClass("hidden")
					}
		    	 }else{
					var width=(document.body.clientWidth-110)/4;
				    $("#shzcbx4").css("width",width);
				    $("#shzcbx5").css("width",width);
				    $("#shzcbx6").css("width",width);
				    $("#shzcbx7").css("width",width);
				    $("#titley").removeClass("hidden")
				    if(data.applyStatus>4){
				    	$("#sytked0").removeClass("hidden");
				    	if(applySta=='已发放'){
					    	$("#tkuan").removeClass("icurrent");
					    	$("#hkuan").removeClass("icurrent");
					   }else{
						   $("#tkuan").addClass("icurrent");
						   if(applySta!="已终止"){
							   $("#hkuan").addClass("icurrent");
							   $("#hkuan").unbind("click")
						   }
					       $("#tkuan").unbind("click")
					       $("#sytked").html("0.00")
					    }
					}
				    
				    $("#cancelBtn").addClass("hidden")
				    $("#okbtn").addClass("hidden")
					for(var i=0;i<data.applyStatus-3;i++){
						$("#circle"+(i+4)).attr("src","../../css/img/yshw.png")
						if(i>=1){
							 $("#shzcbx"+(i+3)).attr("src","../../css/img/shzclbg.png");
						}
					}
				}
			}
    	
    	}
		App.loadKyidDetail(data);
	    var attach="";
	    if(List&&List.length>0){
	    	for(var i=0;i<List.length;i++){
	    		attach +='<span class="shu" onclick="App.gotoPage('+i+')">'+App.fmtHT(List[i].docType)+'</span>'	    	    
	    	}
	    }
		$("#List").html(attach)
	   }catch(e){
		   alert(e)
	   }
	    // data.docName
	    Fw.Client.hideWaitPanel();
	    YT.showPageArea(App.pageA, [], true);
	},
	//快易贷详情加载
	loadKyidDetail:function(data){
		App.pageA.attr("title",title);
    	$("#rzlsh").html(data.financingApplyNo)		
		$("#sqrq").html(Fw.util.Format.fmtTrsCreDate(data.applyTime,"yyyy-MM-dd"))	
		$("#yxq").html(data.loanTermExpire)
		$("#sqzt").html(data.firmName)		
		$("#qyz").html(data.firmOwnerName)
		var zh=Fw.util.Format.account(data.transferInAcct);
		$("#zh").html(zh)		
		var gdjy="未审核"
		if(data.shrhlderDecisionFlag=="1"){
			gdjy="已审核"
		}else{
			gdjy+='<img id="fail" style="width: 16px;padding-left: 6px;vertical-align: sub;"  src="../../css/img/what.png"/>' 
		}
		$("#gdjy").html(gdjy)
		var sqje=data.applyAmount?"￥"+Fw.util.Format.fmtAmt(data.applyAmount+''):"--"
		$("#sqje").html(sqje)
		$("#dkqx").html(data.loanTerm)		
	    $("#hfs").html(data.repayType=="02"?"每月付息,到期还本":"--")
	    Fw.Client.hideWaitPanel();
	    YT.showPageArea(App.pageA, [], true);
	},
	//快押贷详情加载
	loadKyadDetail:function(data){
		try{
		var applyAmount=data.applyAmount?Fw.util.Format.fmtAmt(data.applyAmount+''):'--'
		var approveAmount=data.approveAmount?Fw.util.Format.fmtAmt(data.approveAmount+''):'--'
		var usedAmout=data.usedAmout?Fw.util.Format.fmtAmt(data.usedAmout+''):'--'
		var	transferInAcct=data.transferInAcct?Fw.util.Format.account(data.transferInAcct):'--'; 
		var interestRate=data.interestRate?data.interestRate+'%':'--';
		var fxl=data.interestRate?data.fxl+'%':'--';
		var contractStartDate=data.contractStartDate?Fw.util.Format.fmtTrsCreDate(data.contractStartDate,"yyyy-MM-dd"):'--';
		var contractExpire=data.contractExpire?Fw.util.Format.fmtTrsCreDate(data.contractExpire,"yyyy-MM-dd"):'--';
		var status=data.status=="1"?"有效":"失效";
		$("#zt1").html(status);
		if(status=='失效'){
			$("#zt1").css("color","#FF3B30");
		}
		document.title=(data.productName||"")+"详情";
		var title=(data.productName||"")+"详情";
		App.pageA.attr("title",title);
		$("#kyidDetail").addClass('hidden');
		$("#kyadDetail").removeClass('hidden');
		
		//合同编号
		$("#htbh").html(data.loanContractNo);
		//产品代号
		$("#cpdh").html(data.coreCode);
		//额度生效日期
		$("#edsxrq").html(contractStartDate);
		//额度结束日期
		$("#edjsrq").html(contractExpire);
		//客户代号
		$("#khdh").html(data.cid);
		//客户名称
		$("#khmc").html(data.firmName);
		//地区代号
		$("#dqdh").html(data.areaCode);
		//机构代号
		$("#jgdh").html(data.orgCode);
		//额定额度（元）
		$("#eded").html(approveAmount);
		//已用额度（元）
		$("#yyed").html(usedAmout);
		//货比种类
		$("#hbzl").html(data.currency);
		//执行利率
		$("#zxll").html(interestRate);
		//罚息率
		$("#fxl").html(fxl);
		//活期账号
		$("#hqzh").html(transferInAcct);
		var dMon=data.remainLimit+"";
		$("#lessMon").html(dMon);
		//提款置灰
		if(dMon*1<=0){
			$("#kytk").addClass("icurrent");
			 $("#tkuan").unbind("click")
			App.canGo=false;
		}else{
			$("#kytk").removeClass("icurrent");
		}
		}catch(e){alert(e)}
		
		 Fw.Client.hideWaitPanel();
		 YT.showPageArea(App.pageA, [], true);
	},
	onReason:function(v){
		if(v==1){
			$("#tsk").html("系统提示");
			$("#failreason").html("确认取消申请？")
			var html='<div onclick="App.okBtn()" style="text-align: center;height: 44px;line-height: 44px;color: black;width:50%;float:left;">取消</div>'
				+'<div id="okBtn"style="text-align: center;height: 44px;line-height: 44px;color: #0091FF;width:50%;float:left;">确定</div>'
			$("#qbtn").html(html)
		}else{
			$("#tsk").html("请联系客户经理办理");
			var h1='<div>姓名：'+App.custManagerName+'</div>'
			   +'<div>手机号：'+App.custManagerPhone+'</div>'
			   $("#failreason").html(h1)
			   var h2='<div id="okBtn"style="text-align: center;height: 44px;line-height: 44px;color: #0091FF;">确定</div>'
				   $("#qbtn").html(h2)
		}
		$("#black_b").show();
		$("#giveUpDesc").show();
	},
	okBtn:function(){
		$("#black_b").hide();
		$("#giveUpDesc").hide();
	},
	gotoPage:function(i){
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host
		var url=path+App.datas.uploadUrl+""+App.attach[i].docName;
		url=basePath+"/page/10618/css/pdf/web/viewer.html?url="+url;
		$("#pageB").attr("title",App.fmtHT(App.attach[i].docType))
		Fw.Client.changeWeb(url,false,pageB);
	},
	//格式化合同
	fmtHT:function(v){
		switch(v){
		case 'y2':
			return '《最高额保证合同》';
		case 'y3':
			return '《借款合同》';
		case 'y6':
			return '《涉税数据查询授权书》';
		case 'y7':
			return '《个人征信授权书》';
		default:
			return '';
		}
	},
	//返回
	toChangeList:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1061820.html");
	},
	//签订合同
	okQdht:function(){
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/financingES001");
		var params={
				contractType:"y3",
				financingApplyNo:App.data.financingApply.financingApplyNo,
				productCode:App.data.financingApply.productCode,
				productVersion:App.data.financingApply.productVersion,
		}
		YT.ajaxData(url, params, function(data) {
			if (data.STATUS == "1") {
				App.data.page="1061821.html";
				App.data.y3=data.downFilePath;
				App.data.md5=data.md5;
				Fw.redirect("1061822.html",App.data);
            } else {
				App.flag=false;
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			App.flag=false;
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
		});
	},
	toGo:function(v){
		Fw.Client.openWaitPanel();
		App.data.page="1061821.html";
		if(v==1){
			Fw.redirect("1061850.html",App.data);
		}else if(v==3){
			Fw.redirect("1061840.html",App.data);
		}else{
			if(!App.canGo){
				return
			}
			Fw.redirect("1061830.html",App.data);
		}
		
	},
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);