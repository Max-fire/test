﻿/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;
		App.clickId="";
		App.showId="";
		App.picLength="";
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#bank", App.queryBank);
		App.pageA.on("click", "#needUploadMsg", App.toShowUpLoad);
		App.pageA.on("click", "#cy", App.CyAcct);
		App.pageA.on("click", "#allAmount", App.toChooseAllAmount);
		App.pageA.on("click", "#allAmount", App.toShowSubmit);
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		App.pageA.on("porpertychanger","#cardNo",App.toShowSubmit);
		App.pageA.on("input","#cardNo",App.toShowSubmit);
		App.pageA.on("change","#cardNo",App.toFindBank);
		App.pageA.on("porpertychanger","#toAcctName",App.toShowSubmit);
		App.pageA.on("input","#toAcctName",App.toShowSubmit);
		App.pageA.on("click","#amount",App.showMoneyPicker);
		App.pageA.on("click","#iconAmount",App.showMoneyPicker);
		App.pageA.on("click", "#otherClick", function(){App.toAddAttcchment('otherClick','otherShow','9')});
		var kyAmount=App.data.financingApply.remainLimit?App.data.financingApply.remainLimit:(App.data.financingApply.remainLimit === 0?0:App.data.financingApply.approveAmount);
		$("#date").html(App.data.financingApply.singleLoanTerm);
		$("#rate").html(App.data.financingApply.interestRate+"%");
		if (!App.data.back && App.data.trsTrsfr) {
			App.data.brName=App.data.trsTrsfr.toBrName;
			App.data.bankName=App.data.trsTrsfr.toBankName;
			App.data.bankCode=App.data.trsTrsfr.toBankCode;
			App.data.brCode=App.data.trsTrsfr.toBrCode;
			App.data.provinceCode=App.data.trsTrsfr.provinceCode;
			App.data.provinceName=App.data.trsTrsfr.toExchngCity;
			App.data.cityCode=App.data.trsTrsfr.toBrCode.substring(3,7);
			$("#cardNo").val(App.data.trsTrsfr.toAcctNo);
			$("#toAcctName").val(App.data.trsTrsfr.toAcctName);
			$("#bank").html(App.data.trsTrsfr.toBankName);
			$("#brCode").html(App.data.trsTrsfr.toBrCode);
		}else{
			if (App.data.cardNo) {
				$("#cardNo").val(App.data.cardNo);
			}
			if (App.data.toAcctName) {
				$("#toAcctName").val(App.data.toAcctName);
			}
			if (App.data.brName) {
				$("#bank").html(App.data.brName);
				$("#brCode").html(App.data.brCode);
				$("#bank").removeClass("yui-dk-bankFont").addClass("yui-dk-bankSpace");
			}else{
				$("#bank").removeClass("yui-dk-bankSpace").addClass("yui-dk-bankFont");
			}
		}
		if (App.data.financingProduct) {
			App.showType();
		}else{
			App.queryType();
		}
		if (App.data.attach && App.data.attach.length>0) {
			App.clickId="otherClick";
			App.showId="otherShow";
			App.picLength="9";
			for ( var k = 0; k < App.data.attach.length; k++) {
				if(App.data.attach[k] != null){
					App.showAttcchment(App.data.attach[k].name,App.data.url);
				}
			}
		}
		//重新支付处理
		if (App.data.financingPayment) {
			$(".allShow").addClass("hidden");
			App.pageA.off("click","#amount",App.showMoneyPicker);
			$("#iconAmount").addClass("hidden");
			$("#amount").val(Fw.util.Format.fmtMoney(App.data.trsTrsfr.amount+""));
			$("#writeAmount").html(Fw.util.Format.fmtMoney(App.data.trsTrsfr.amount+""));
			$("#amount").attr("data-value",App.data.trsTrsfr.amount);
			$("#amountCaps").html(Fw.util.Format.fmtNumber2Chinese(Fw.util.Format.unfmtAmt(App.data.trsTrsfr.amount+"")+""));
			$("#transferInAcct").html(App.data.financingPayment.loanAcctNo);
			kyAmount=App.data.financingPayment.grantAmt;
		}else{
			if (App.data.amount) {
				$("#amount").val(App.data.amount);
				$("#writeAmount").html(App.data.amount);
				$("#amount").attr("data-value",Fw.util.Format.unfmtAmt(App.data.amount+""));
				$("#amountCaps").html(Fw.util.Format.fmtNumber2Chinese(Fw.util.Format.unfmtAmt(App.data.amount+"")+""));
			}
			$("#transferInAcct").html(App.data.financingApply.transferInAcct);
		}
		$("#kyAmount").html(Fw.util.Format.fmtMoney(kyAmount+""));
		$("#kyAmount").attr("data-value",kyAmount);
		App.toShowSubmit();
	},
	toAddAttcchment:function(clickId,showId,picLength){
		App.clickId=clickId;
		App.showId=showId;
		App.picLength=picLength;
		Fw.Client.chooseAccessory("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		attach.addAttach(name,url,App.clickId,App.showId,App.picLength);
	},
	/**
	 * 显示自主自发还是受托支付
	 */
	showType:function(){
		if (App.data.financingProduct.paymentType=="0") {
			//自主支付处理
			$("#payType").html("自主支付");
		}else{
			//受托支付处理
			$("#payType").html("受托支付");
			$("#cardNo").attr("readonly","readonly");
			$("#toAcctName").attr("readonly","readonly");
			App.pageA.off("click", "#bank", App.queryBank);
			App.pageA.on("click", "#cardNo", App.chooseAcct);
			$("#cy").html('<img src="../../css/img/right_disable.png" style="height: 12px;width: 8px;margin-top: 15px;">');
			App.pageA.off("click", "#cy", App.CyAcct);
			//$(".allShow").addClass("hidden");
			$("#addAcctShow").addClass("hidden");
			App.queryAcct();
		}
		//附件显示
		if (App.data.financingProduct.auditImageFlag == "1") {
			$(".auditImage").removeClass("hidden");
			$(".auditImageShow").addClass("hidden");
		}else{
			$(".auditImage").addClass("hidden");
			$(".auditImageShow").removeClass("hidden");
		}
		$("#memo").html(App.data.financingProduct.loanPurse?App.data.financingProduct.loanPurse:"")
		$("#purpose").html(App.data.financingProduct.loanPurse?App.data.financingProduct.loanPurse:"")
		var minAmount=App.data.financingProduct.minSingleWithdraw*1;
		var kyAmount=$("#kyAmount").attr("data-value")*1;
		if (minAmount>kyAmount) {
			$("#amount").val(kyAmount);
			$("#amountCaps").html(Fw.util.Format.fmtNumber2Chinese(kyAmount+""));
			App.pageA.off("click","#amount",App.showMoneyPicker);
			$("#allAmount").attr("checked","checked");
		}else{
			$("#allAmount").removeAttr("checked");
		}
		$("#minAmount").html(Fw.util.Format.fmtMoney(minAmount+""));
		Fw.Client.hideWaitPanel();
		App.toShowSubmit();
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 查询产品
	 */
	queryType:function(){
		var params={
				productCode:App.data.financingApply.productCode,
				productVersion:App.data.financingApply.productVersion
			}
		var url = YT.dataUrl('private/queryFinancingProduct');
		Fw.Client.openWaitPanel();
		YT.ajaxData(url, params, function(data) {
			if(data.STATUS=="1"){
				App.data.financingProduct=data.financingProduct;
				App.showType();
			}else{
				App.callback(data);
			}	
		},function(data){
			App.callback(data);
		});
	},
	/**
	 * 常用账户
	 */
	CyAcct:function(){
		App.data.amount=$("#amount").val();
		App.data.cardNo=$("#cardNo").val();
		App.data.toAcctName=$("#toAcctName").val();
		App.data.attach=App.attch;
		App.data.url=App.url;
		Fw.redirect("1061835.html",App.data);
	},
	/**
	 * 选择银行
	 */
	queryBank:function(){
		App.data.amount=$("#amount").val();
		App.data.cardNo=$("#cardNo").val();
		App.data.toAcctName=$("#toAcctName").val();
		App.data.attach=App.attch;
		App.data.url=App.url;
		App.data.oldData=YT.JsonToStr(App.data);
		Fw.redirect("1061832.html",App.data);
	},
	/**
	 * 查询归属银行
	 */
	toFindBank:function(){
		var card=$("#cardNo").val();
		if (!card) {
			return;
		}
		var url = YT.dataUrl("private/findBankInfo");
		YT.ajaxData(url,{cardNo:card},function(data){
			if(data.STATUS=="1"){
				if(data.payBankCode && data.payBankCode.substring(0,3)=="309"){
					Fw.Client.openWaitPanel();
					$("#bank").html(data.bankName);
					$("#brCode").html(data.payBankCode);
					App.pageA.off("click", "#bank", App.queryBank);
					$("#bank").removeClass("yui-dk-bankFont").addClass("yui-dk-bankSpace");
					App.queryBrName(data.payBankCode);
					App.queryAcctName(card);
				}else{
					App.pageA.off("click", "#bank", App.queryBank).on("click", "#bank", App.queryBank);
					$("#toAcctName").removeAttr("readonly");
				}
			}else{
				App.callback(data);
			}
		},function(data){
			App.callback(data);
		});
	},
	/**
	 * 查询卡主姓名
	 */
	queryAcctName:function(card){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("normal/tr1699");
		var params = {
			zhdh : card,
			sfbz : "0"
		}
		YT.ajaxData(url, params, function(datas) {
			if (datas.STATUS == "1") {
				Fw.Client.hideWaitPanel();
				$("#toAcctName").val(datas.LIST.khmc);
				$("#toAcctName").attr("readonly","readonly");
				App.toShowSubmit();
			} else {
				$("#toAcctName").val("");
				Fw.Client.hideWaitPanel();
			}

		});
	},
	/**
	 * 查询支行
	 */
	queryBrName:function(brCode){

		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/searchBranch");
		var params={
				field : "brCode",
				value : brCode	
		}
	    YT.ajaxData(url,params,function(data){
	    	if (data.STATUS=="1") {
	    		data.lbranch;
	    		var brCode=data.lbranch[0].brCode.trim();
	    		var brName=data.lbranch[0].brName.trim();
	    		var bankName=data.lbranch[0].bankName.trim();
	    		var bankCode=data.lbranch[0].bankCode.trim();
	    		var cityCode=data.lbranch[0].cityCode.trim();
	    		App.data.brCode=brCode;
	    		App.data.brName=brName;
	    		App.data.bankName=bankName;
	    		App.data.bankNameA=bankName;
	    		App.data.bankCode=bankCode;
	    		App.data.cityCode=cityCode;
	    		App.data.provinceCode="";
	    		App.data.provinceName="";
	    		if (data.lbranch[0].provinceCode) {
	    			App.data.provinceCode=data.lbranch[0].provinceCode;
	    		}
	    		if (data.lbranch[0].provinceName) {
	    			App.data.provinceName=data.lbranch[0].provinceName+" "+data.lbranch[0].cityName;
	    		}
	    		Fw.Client.hideWaitPanel();
			}
	    },function(data){
	    	Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
	    })	
	
	},
	/**
	 * 查询受托账户
	 */
	queryAcct:function(){
		var params={
				financingApplyNo:App.data.financingApply.financingApplyNo,
				loanContractNo:App.data.financingApply.loanContractNo
			}
		
		var url = YT.dataUrl('private/queryEntrustPayAcct');
		Fw.Client.openWaitPanel();
		YT.ajaxData(url, params, function(data) {
			if(data.STATUS=="1"){
				App.List=data.List;
				App.showSel(data);
				Fw.Client.hideWaitPanel();
			}else{
				App.callback(data);
			}	
		},function(data){
			App.callback(data);
		});
		
	},
	/**
	 * 输入金额处理
	 */
	toCheckAmount:function(){
		$("#allAmount").removeAttr("checked");
		var amount=$("#amount").attr("data-value");
		if (amount && amount !="0") {
			$("#amountCaps").html(Fw.util.Format.fmtNumber2Chinese(amount+""));
		}else{
			$("#amountCaps").html("零");
		}
		if ($("#amount").val()) {
			$("#writeAmount").html($("#amount").val())
		}else{
			$("#writeAmount").html("请输入");
		}
	},
	/**
	 * 选择全部金额
	 */
	toChooseAllAmount:function(){
		$("#amount").removeClass("yui-dk-errorFont");
		var kyAmount=$("#kyAmount").attr("data-value");
		$("#amount").val(Fw.util.Format.fmtMoney(kyAmount+""));
		$("#amount").attr("data-value",kyAmount);
		$("#amountCaps").html(Fw.util.Format.fmtNumber2Chinese(kyAmount+""));
		$("#writeAmount").html(Fw.util.Format.fmtMoney(kyAmount+""))
	},
	/**
	 * 处理金额字体颜色
	 */
	toAmount:function(){
		var writeAmount=$("#amount").attr("data-value")*1;
		var kyAmount=$("#kyAmount").attr("data-value")*1;
		var minAmount=App.data.financingProduct.minSingleWithdraw*1;
		if (writeAmount<minAmount || writeAmount>kyAmount) {
			$("#amount").addClass("yui-dk-errorFont");
		}else{
			$("#amount").removeClass("yui-dk-errorFont");
		}
	},
	toShowAmount:function(){
		App.showMoneyPicker();
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker: function(){
		Fw.Client.showMoneyPicker($("#amount"),true);
	},
	sumMoney:function(){
		App.toCheckAmount();
		App.toAmount();
		App.toShowSubmit();
	},
	toShowSubmit:function(){
		var amount=$("#amount").attr("data-value");
		var cardNo=$("#cardNo").val();
		var toAcctName=$("#toAcctName").val();
		if (amount && cardNo && toAcctName && $("#bank").html() != "请选择开户行") {
			if (App.data.financingProduct && App.data.financingProduct.auditImageFlag=="1") {
				if (App.attch.length>0) {
					$("#btnSubmit").removeAttr("disabled", "");
				}else{
					$("#btnSubmit").attr("disabled", "disabled");
				}
			}else{
				$("#btnSubmit").removeAttr("disabled", "disabled");
			}
		}else{
			$("#btnSubmit").attr("disabled", "disabled");
		}
	},
	toSubmit : function() {
		var writeAmount=$("#amount").attr("data-value")*1;
		var kyAmount=$("#kyAmount").attr("data-value")*1;
		var minAmount=App.data.financingProduct.minSingleWithdraw*1;
		var callBack="App.callSuccess";
		if (writeAmount<minAmount && minAmount<kyAmount) {
			Fw.Form.showPinLabel($(this),"提款金额不得小于单次提款最小金额",true);
			return;
		}
		if (writeAmount>kyAmount) {
			Fw.Form.showPinLabel($(this),"提款金额不得大于可用额度",true);
			return;
		}
		if (!$("#cardNo").val()) {
			Fw.Form.showPinLabel($(this),"请输入收款账号",true);
			return;
		}
		if (!$("#toAcctName").val()) {
			Fw.Form.showPinLabel($(this),"请输入收款户名",true);
			return;
		}
		if ($("#bank").html() == "请选择开户行") {
			Fw.Form.showPinLabel($(this),"请输入收款方开户名称",true);
			return;
		}
		if (App.data.financingProduct.auditImageFlag == "1") {
			if (App.attch.length<0) {
					Fw.Form.showPinLabel($(this),"请上传相关附件",true);
				return;
			}
		}else{
			callBack="App.showBJ";
		}
		//添加常用收款人
		if (App.data.financingProduct.paymentType=="0") {
			if ($("#inputCheckbox").is(":checked")) {
				App.acctOperate();
			}
		}
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("public/getRandomNum");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = "private/financingPaymentTask.json";
				var params ={
						type:"1",
						trsType:"A",
						toAcctName:$("#toAcctName").val(),
						toAcctNo:$("#cardNo").val(),
						toBankCode:App.data.bankCode,
						toBankName:App.data.bankName,
						toBrCode:App.data.brCode,
						toProvinceCode : App.data.provinceCode,
						toCityCode : App.data.cityCode,
						toExchngCity:App.data.provinceName,
						toBrName : App.data.brName,
						purpose:$("#purpose").html(),
						amount:writeAmount+"",
						fromAcctNo:App.data.financingApply.transferInAcct,
						loanContractNo:App.data.financingApply.loanContractNo,
						isComplete:"1",
						TOKEN:data.randomNum
				};
				if (App.data.financingPayment) {
					url= "private/financingPaymentAgainTask.json";
					params.prevTrsNo=App.data.trsTrsfr.trsNo;
				}
				Fw.Client.post(url, params, callBack, "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),data.MSG,true);
				return;
			}
		});
	},
	
	callSuccess:function(data){
		if (data.STATUS=="1") {
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo:data.trsNo,
					uploadType:"FINACING",
					FileUrl:App.url,
					FileNameList:App.attch
			}
			YT.ajaxData(url, params, function(success) {
				if (success.STATUS=="1") {
					App.trsNo=data.trsNo;
					var xml='<M><k>收款账号</k><v>'+$("#cardNo").val()+'</v></M><M><k>收款人名称</k><v>'+$("#toAcctName").val()+'</v></M><M><k>申请额度</k><v>'+$("#amount").attr("data-value")+'</v></M>';
					var json = {
							type : "4",
							func : "App.initComplete",
							funcAndroid:"App.initCompleteAndroid",
							XML : '<?xml version="1.0" encoding="utf-8"?><T><D>'+xml+'</D></T>',
							funcBack:"App.canBack"
					};
					Fw.Client.showBB(json);
				}else{
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(success.MSG,"消息提示","App.fail()");
				}
			});
		}else{
			App.callback(data);
		}
	},
	showBJ:function(data){
		if (data.STATUS=="1") {
			App.trsNo=data.trsNo;
			var xml='<M><k>收款账号</k><v>'+$("#cardNo").val()+'</v></M><M><k>收款人名称</k><v>'+$("#toAcctName").val()+'</v></M><M><k>申请额度</k><v>'+$("#amount").attr("data-value")+'</v></M>';
			var json = {
					type : "4",
					func : "App.initComplete",
					funcAndroid:"App.initCompleteAndroid",
					XML : '<?xml version="1.0" encoding="utf-8"?><T><D>'+xml+'</D></T>'
			};
			Fw.Client.showBB(json);
			Fw.Client.hideWaitPanel();
		}else{
			App.callback(data);
		}
		
	},
	canBack:function(){
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;
		App.clickId="";
		App.showId="";
		App.picLength="";
		$("#picotherClick").html("0")
		if (App.data.attach) {
			App.data.attach=[];
		}
		var html='<div class="swiper-slide swiper-slide-active"style="width: 120px;" id="otherClick">'+
				'<div class="picInfo" style="background: #F2F7FB;">'+
				'<img src="../../css/img/addButtom.png" class="addPic" />'+
				'<div style="font-size: 10px; color: #5D6574; line-height: 14px;">拍摄/上传</div></div></div>';
		$("#otherShow").html(html)
		App.toShowSubmit();
	},
	fail:function(){
		App.attch = new Array();
		App.i=0;
		App.clickId="";
		App.showId="";
		App.picLength="";
		$("#picotherClick").html("0");
		$("#otherShow").html('<div class="swiper-slide swiper-slide-active" style="width: 120px;" id="otherClick"><div class=""><img src="../../css/img/addButtom.png" class="addPic" style="height: 45px;width: 45px;"></div></div>');
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(data.MSG,"消息提示","");
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
			App.initBJ(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	initBJ:function(a,b,frAcctNo,frAcctName,ppose){
		var writeAmount=$("#amount").attr("data-value")+"";
		var params={
				type:"2",
				trsType:"A",
				tpAcctName:$("#toAcctName").val(),
				toAcctNo:$("#cardNo").val(),
				toBankCode:App.data.bankCode,
				toBankName:App.data.bankName,
				toBrCode:App.data.brCode,
				toProvinceCode : App.data.provinceCode,
				toCityCode : App.data.cityCode,
				toExchngCity:App.data.provinceName,
				toBrName : App.data.BrName,
				purpose:$("#purpose").html(),
				amount:writeAmount,
				transferInAcct:App.data.financingApply.transferInAcct,
				loanContractNo:App.data.financingApply.loanContractNo,
				financingApplyNo:App.data.financingApply.financingApplyNo,
				
				productCode:App.data.financingProduct.productCode,
				productVersion:App.data.financingApply.productVersion,
				trsNo:App.trsNo,
				signData:a,
				signSrc:b
			}
		var url = YT.dataUrl('private/financingPaymentTask');
		if (App.data.financingPayment) {
			url= YT.dataUrl('private/financingPaymentAgainTask')
			params.prevTrsNo=App.data.trsTrsfr.trsNo;
		}
		Fw.Client.openWaitPanel();
		YT.ajaxData(url, params, function(data) {
			if(data.STATUS=="1"){
				Fw.Client.hideWaitPanel();
				var json={};
				json.financingApply=App.data.financingApply
				Fw.redirect("1061831.html",json);
			}else{
				App.callback(data);
			}	
		},function(data) {
			App.callback(data)
		});
	},
	/**
	 * 客户端select选择
	 */
	showSel:function(data){
		var clickId=$(this).attr("id");
		App.jsonArray=new Array();
		for(var i=0;i<data.List.length;i++){
			App.jsonArray.push({
				account : data.List[i].toAcctNo,
				balance : i,
				accountName:i
			});
		}
		Fw.Client.hideWaitPanel();
	},
	chooseAcct:function(){
		var json = {
				jsonArray : App.jsonArray,
				"func" : "App.showCommonlyUsedAccount",
			};
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	/**
	 * 回显选择
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		$("#cardNo").val(account);
		$("#toAcctName").val(App.List[balances].toAcctName);
		$("#bank").html(App.List[balances].toBankName);
		$("#brCode").html(App.List[balances].toBrCode);
		App.data.bankName=App.List[balances].toBankName;
		App.data.brCode=App.List[balances].toBrCode;
		App.data.bankCode=App.List[balances].toBrCode.substring(0,3);
	},
	/**
	 * 添加常用收款账号
	 */
	acctOperate:function(){
		var url1 = YT.dataUrl("private/acctOperate");
		var param = {
				OperateType : "0",
				ACCT_NO :$("#cardNo").val(),
				innerBank : "1",
				ACCT_NAME : $("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
				BANK_NAME : App.data.bankName,
				BANK_CODE:App.data.bankCode,
				BR_CODE:App.data.brCode,
				CITY_CODE:App.data.cityCode
		};
		YT.ajaxData(url1, param, function(data){
		}, function(){
			App.flag = false;
			Fw.Client.alertinfo("网络异常","消息提示");
		});
	},
	isOK:function(){
		App.toShowSubmit();
	},
	/**
	 * 需要上传什么
	 */
	toShowUpLoad:function(){
		if (App.data.financingProduct.needUploadMsg) {
			Fw.Client.alertinfo(App.data.financingProduct.needUploadMsg,"消息提示");
		}
	},
	willBack:function(){
		var json={};
		json.financingApply=App.data.financingApply
		if (App.data.financingPayment) {
			Fw.redirect("1061850.html",json);
		}else if (App.data.page) {
			Fw.redirect(App.data.page,json);
		}else{
			Fw.redirect("1061820.html?queryType=ysx");
		}
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);