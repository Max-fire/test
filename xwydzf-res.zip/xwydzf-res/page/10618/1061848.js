/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.next=0;
		App.beginTime ='';
		App.endTime = '';
		App.tabValue='0';
		App.initEvent();
		App.queryDetail();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", ".tabClick", App.changeTab);
	},
	changeTab:function(){
		if(App.tabValue!=$(this).attr("data-value")){
			if ($(this).attr("data-value")) {
				$("#choose").addClass("hidden");
			}else{
				$("#choose").removeClass("hidden")
			}
			$(this).find("span").addClass("tab_spansel");
			$(this).siblings().find("span").removeClass("tab_spansel");
			App.tabValue=$(this).attr("data-value");
			App.next=0;
			App.beginTime ='';
			App.endTime = '';
			App.queryDetail();
		}
	},
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		App.queryDetail();
	},
	queryDetail:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/repayRecordList");
		var params={
				toAcctNo:App.data.loanAcctNo,
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				rePayRecordStatus:App.tabValue,
				NEXT_KEY:App.next+"",
        		PAGE_SIZE:"10"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.list&&data.list.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
		try{
		if(data && data.list){
			var list=App.list=data.list;
			var html='';
			var type="";
			for(var i=0;i<list.length;i++){
				if (App.tabValue=="1") {
					type="摘要类型:"+list[i].fromAcctNo;
				}else{
					type="还款账号:"+Fw.util.Format.fmtAcct(list[i].fromAcctNo+"");
				}
				html+='<div class="list_item">'+
				'<div onClick="App.gotoDetail('+i+')">'+
				'<div class="yui-info-border">'+
					'<div class="pro_num"><span style="color:#8F9DAD;flex:1;">'+type+'</span></div>'+
					'<div class="yui-amount-info">'+
						'<div class="pro_name">还款金额</div>'+
						'<div class="yui-amount-font"><span style="font-size:16px;">'+Fw.util.Format.fmtAmt(list[i].amount+"")+'</span>元</div>'+
					'</div>'+
				'</div>'+
				'<div class="pro_detail">'+
					'<div><label>还款时间</label><span>'+Fw.util.Format.fmtTrsCreDate(list[i].creTime)+'</span></div>'+
				'</div>'+
				'</div>'+
				'</div>';
				if(App.next=='0'){
					$("#repay_list").html(html);
				}else{
					$("#repay_list").append(html);
				}
			}
		}else{
			$("#more").hide()
			$("#end").hide();
			$("#repay_list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无还款记录~</div>');
		}
		if(data.NEXT_PAGE){
			$("#more").show();
			$("#end").hide();
			App.next=data.NEXT_KEY/1+10;
		}else{
			if (App.next>0) {
				$("#more").hide();
				$("#end").show();
			}else{
				$("#more").hide();
				$("#end").hide();
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
		}catch(e){
			alert(e)
		}
	},
	gotoDetail:function(i){
		App.data.list=App.list[i];
		App.data.tabValue=App.tabValue;
		Fw.redirect("1061846.html",App.data);
	},
	//返回
	goBack:function(){
		Fw.redirect("1061847.html",App.data);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);