﻿/**
 * 创建应用
 * 
 * @author sunz
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.queryDetail(App.data.loanAcctNo )
		//Fw.Client.hideWaitPanel();
		//YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		 App.pageA.on("click","#okbtn",App.okDq);
	},
	queryDetail:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/finaRepayDetail");
		var params={
				loanAcctNo:App.data.loanAcctNo,
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data){
					App.loadData(data.response)
				}else{
					App.loadData([]);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
	  try{
		  $("#dkzzh").html(data.dkzzh);
		  $("#htbh").html(data.htbh);
		  $("#cpdh").html(data.cpdh);
		  $("#dkxz").html(Fw.util.Format.loanNatureFmt(data.dkxz));
		  $("#jlzt").html(Fw.util.Format.recordStatusFmt(data.jlzt));
		  
		  
		  $("#khmc").html(data.khmc);
		  $("#khdh").html(data.khdh);
		  $("#dkjszh").html(data.dkjszh);
		  
		  
		  
		  $("#dked").html(Fw.util.Format.fmtAmt(data.dked.toString()));
		  $("#hjje").html(Fw.util.Format.fmtAmt(data.hjje.toString()));
		  $("#lldh").html(data.lldh);
		  var llfdfs = data.llfdfs == '0'? '按浮动值浮动':(data.llfdfs == '1'?'按百分比浮动':'按逾期浮动值浮动');
		  $("#llfdfs").html(llfdfs);
		  $("#llfdz").html(data.llfdz+'%');
		  $("#fxl").html(data.fxl+'%');
		  var zdhbfxbz = data.zdhbfxbz == '0'?'不自动':'自动';
		  $("#zdhbfxbz").html(zdhbfxbz);
		  $("#hbfxzh").html(data.hbfxzh);
		  $("#qsrq").html(Fw.util.Format.fmtTrsCreDate(data.qsrq,'yyyy-MM-dd'));
		  $("#dqrq").html(Fw.util.Format.fmtTrsCreDate(data.dqrq,'yyyy-MM-dd'));
		 
		  if(data.dkxz == '3'){
			  $("#yqqsrq").parent().removeClass('hidden');
			  $("#yqqsrq").html(Fw.util.Format.fmtTrsCreDate(data.yqqsrq,'yyyy-MM-dd'))
		  }
		  
		  Fw.Client.hideWaitPanel();
		  YT.showPageArea(App.pageA, [], true);
	  }catch(e){
			alert(e)
		}
	 
	},
	//返回
	toChangeList:function(){
		Fw.redirect("1061847.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);