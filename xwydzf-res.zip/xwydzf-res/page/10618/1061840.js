/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.next=0;
		App.sort="0";
		App.arr=[{name:'所有状态',value:''},{name:'待还款',value:'1'},{name:'还款成功',value:'2'},{name:'逾期',value:'3'}];
		App.i=0;
		App.json=new Array();
		App.beginTime ='';
		App.endTime = '';
		App.initEvent();
		App.queryList();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		App.pageA.on("click", "#syzt", App.showSel);
		App.pageA.on("click", ".sortTime", App.sortTime);
//		App.pageA.on("click", "#black_b", App.hideSel);
//		App.pageA.on("click", ".sel_click", App.selClick);
		App.pageA.on("click", "#more", App.queryList);
		
	},
	
	sortTime:function(){
		
		if(App.sort=="0"){
			App.sort="1";
			$("#sortTime").html("从旧到新");
		}else{
			App.sort="0";
			$("#sortTime").html("从新到旧");
		}
//		App.hideSel();
		App.next=0;
		App.queryList();
	},
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		App.queryList();
	},
//	selClick:function(){
//		
//		$(this).find("span").addClass("selSpan");
//		$(this).siblings().find("span").removeClass("selSpan");
//		
//		if(App.statusValue==$(this).attr("data-value")){
//			App.hideSel();
//			return false;//相同不查
//		}
//		App.statusValue=$(this).attr("data-value");
//		App.hideSel();
//		App.next=0;
//		App.queryList();
//	},
	/**
	 * 查询记录
	 */
	queryList:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/finaRepaymentList");
		var params={
//				statusValue:$("#syzt").attr("data-value"),
				loanContractNo:App.data.financingApply.loanContractNo,
				order:App.sort,
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				NEXT_KEY:App.next+"",
        		PAGE_SIZE:"5"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.list&&data.list.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			}else{
				$("#repayment_list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无还款清单~</div>');
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
		if(data && data.list){
			var list=data.list;
			var html='';
			if (App.next=="0") {
				App.json=[];
				App.i=0;	
			}
			App.json.push(data.list);
			for(var i=0;i<list.length;i++){
				var bodColor='',day='',isOut=false;
				if(list[i].dayNumber<0 && (list[i].remainAmount>0||list[i].remainInterest>0)){
					day='已逾期'+list[i].dayNumber+'天';
					bodColor='border-right: 4px solid #FF3B30;color:#FF3B30';
					isOut=true;
				}else if(list[i].dayNumber>=0 && (list[i].remainAmount>0||list[i].remainInterest>0)){
					day='待还款';
					bodColor='border-right: 4px solid #2574D2 ;color:#2574D2';
				}else if(list[i].remainAmount==0 && list[i].remainInterest==0){
					day='已结清';
					bodColor='border-right: 4px solid #00A74C;color:#00A74C';
				}
				html+='<div class="list_item">'+
							'<div style="display: flex;display:-webkit-box;display: -webkit-flex;justify-content: space-between;word-break: break-all;padding: 10px 0 10px 15px;color:#8F9DAD">'+
								'<div class="list_flex">提款申请编号：'+list[i].withdrawApplyNo+'</div>'+
								'<div style="min-width: 40px;text-align: right;height: 16px;line-height: 16px;padding-right: 5px;'+bodColor+'">'+day+'</div>'+
							'</div>'+
							'<div style="padding:5px 15px 15px 15px;border-bottom:1px solid #F2F4F8;">'+
								'<div>全部待还</div>'+
								'<div style="text-align: center;"><span style="font-size: 28px;color: #FF7F00;font-weight: bold;">'+Fw.util.Format.fmtAmt((list[i].remainAmount*10*10+list[i].remainInterest*10*10)/100+'')+'</span>元</div>'+
									'<div style="text-align: center;padding: 15px 0;" class="item_btn">'+
										'<div style="margin-right: 10px;" onClick="App.gotoPage('+0+','+i+','+App.i+')">还款记录</div>';
										if(list[i].remainAmount==0 && list[i].remainInterest==0){
											html+='<div style="margin-left: 10px;background: #ccc;color: #fff; border: 1px solid #ccc;">立即还款</div>';
										}else{
											html+='<div style="margin-left: 10px;"  onClick="App.gotoPage('+1+','+i+','+App.i+')">立即还款</div>';
										}
								html+='</div>'+
							'</div>'+
							'<div style="padding: 8px 15px; line-height: 24px;">'+
								'<div style="display: flex;display:-webkit-box;display: -webkit-flex;justify-content: space-between;word-break: break-all;">'+
									'<div class="list_flex">最后还款日</div>';
									if(isOut){
										html+='<span style="color:#FF3B30">'+Fw.util.Format.fmtTrsCreDate(list[i].expiringDate)+'</span>';
									}else{
										html+='<span>'+Fw.util.Format.fmtTrsCreDate(list[i].expiringDate)+'</span>';
									}
								html+='</div>'+
								'<div style="display: flex;display:-webkit-box;display: -webkit-flex;justify-content: space-between;word-break: break-all;">'+
									'<div class="list_flex">提款金额</div>'+
									'<span>'+Fw.util.Format.fmtAmt(list[i].amount+'')+'元</span>'+
								'</div>'+
								'<div style="display: flex;display:-webkit-box;display: -webkit-flex;justify-content: space-between;word-break: break-all;">'+
								'<div class="list_flex">剩余利息</div>'+
								'<span>'+Fw.util.Format.fmtAmt(list[i].remainInterest+'')+'元</span>'+
							'</div>'+
							'</div>'+
						'</div>';
			}
			App.i++;
			if(App.next=='0'){
				$("#repayment_list").html(html);
			}else{
				$("#repayment_list").append(html);
			}
		}else{
			$("#more").hide()
			$("#end").hide();
			$("#repayment_list").html('<div style="text-align:center;margin-top: 50%;color:#999;">暂无还款清单~</div>');
		}
		if(data.NEXT_PAGE){
			$("#more").show();
			$("#end").hide();
			App.next=data.NEXT_KEY/1+5;
		}else{
			if (App.next>0) {
				$("#more").hide();
				$("#end").show();
			}else{
				$("#more").hide();
				$("#end").hide();
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
		
	},
	showSel:function(){
//		$("#white_b").removeClass("hidden");
//		$("#black_b").removeClass("hidden");
//		//静止滑动
//		App.pageA.bind("touchmove",function(e){
//			e.preventDefault();
//		});

		App.type=$(this).attr("id");
		var arr=App.arr;
		var jsonArray=[];
		for(var i=0;i<arr.length;i++){
			jsonArray.push({
				account : arr[i].name,
				balance : arr[i].value,
				accountName:''
			});
		}
		var json = {
				jsonArray : jsonArray,
				"func" : "App.showCommonlyUsedAccount",
				"title":''
			};
		Fw.Client.hideWaitPanel();
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
		
	},
	/**
	 * 回显
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		$("#"+App.type).val(account);
		$("#"+App.type).attr("data-value",balances);
		App.queryList();
	},
	gotoPage:function(v,i,j){
		try{
		var json={
				loanContractNo:App.data.financingApply.loanContractNo,
				financingApplyNo:App.data.financingApply.financingApplyNo,
				toAcctNo:App.json[j][i].loanAcctNo,
				trsNo:App.json[j][i].trsNo,
		}
		if (App.data.page) {
			json.page=App.data.page;
		}
		json.financingApply=App.data.financingApply;
		if(v==0){
			Fw.redirect("1061841.html",json);
		}else if(v==1){
			Fw.redirect("1061843.html",json);
		}
		}catch(e){
			alert(e)
		}
	},
//	hideSel:function(){
//		$("#white_b").addClass("hidden");
//		$("#black_b").addClass("hidden");
//		App.pageA.unbind("touchmove");
//	},
	//返回
	goBack:function(){
		if(App.data.page){
			Fw.redirect(App.data.page,App.data);
		}else{
			Fw.redirect("1061821.html",App.data);
		}
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);