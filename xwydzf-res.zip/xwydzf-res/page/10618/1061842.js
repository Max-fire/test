﻿/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.queryDetail(App.data.trsNo )
		//Fw.Client.hideWaitPanel();
		//YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		 App.pageA.on("click","#okbtn",App.okDq);
	},
	queryDetail:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findRePaymentDetail");
		var params={
				trsNo:App.data.trsNo,
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data&&data.repayment){
					App.loadData(data.repayment,data.withdrawApplyNo)
				}else{
					App.loadData([]);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data,withdrawApplyNo){
	  try{
		  $("#trsNo").html(Fw.util.Format.subTrsNo(data.trsNo));
		  $("#tksqbh").html(withdrawApplyNo)//?
		  $("#loanContractNo").html(data.loanContractNo);
		  $("#toAcctNo").html(data.toAcctNo);
		  $("#firmName").html(data.firmName);
		  $("#fromAcctNo").html(data.fromAcctNo);
		  $("#fromAcctName").html(data.fromAcctName);
		  $("#creTime").html(Fw.util.Format.fmtTrsCreDate(data.creTime,'yyyy-MM-dd'));
		  var repayType=data.repayType=="1"?"本金还款":"全部还款"
		  $("#repayType").html(repayType);
		  $("#repayCorAmt").html(Fw.util.Format.fmtAmt(data.repayCorAmt+'')+"元");
		  $("#stageRemainAmt").html(Fw.util.Format.fmtAmt(data.stageRemainAmt+'')+"元");
		  var chlx=data.repayType=="1"||!data.bnRepymtInt?"0.00":Fw.util.Format.fmtAmt(data.bnRepymtInt+'')+"元";
		  var sylx=data.repayType=="1"||!data.otsndInt1?"0.00":Fw.util.Format.fmtAmt(data.otsndInt1+'')+"元";
		  $("#chlx").html(chlx);//?
		  $("#sylx").html(sylx); //? 
		  Fw.Client.hideWaitPanel();
		  YT.showPageArea(App.pageA, [], true);
	  }catch(e){
			alert(e)
		}
	 
	},
	//返回
	toChangeList:function(){
		Fw.redirect("1061841.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);