/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#toQuery",App.toQuery);
		App.pageA.on("click","#toMore",App.toMore);
	},
	toQuery:function(){
		Fw.redirect("1061850.html",App.data);
	},
	toMore:function(){
		Fw.redirect("1061820.html");
	},
	//返回
	gotoMsg:function(){
		Fw.redirect("1061800.html");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);