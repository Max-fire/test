/**
 * 创建应用
 * 
 * @author yql
 */
var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		Fw.Client.hideWaitPanel(); 
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
		App.onQueryData();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		//公用数据字段  【行内0】【跨行1】
		//公用列表样式
		App.temp1 = [
				'<ul class="ui-list swiper-container">',
			        '<li class="ui-border-b swiper-wrapper">',
			        	'<div class="swiper-slide swiper-slide-change">',
			        		'<div  style="height:50px;margin:10px 20px 10px 0;position:relative">',
			        			'<span style="background-image:url(../img/100x100.png); background-size: 100% auto"></span>',
			        		'</div>',
			        		'<div class="ui-list-info">',
			        			'<h4 class="ui-nowrap">${item.acctName}</h4>',
			        			'<p class="yui-word-break " >${item.bankName}(${item.acctNo})</p>',
			        			'<input type=text  id=hm value="${item.bankName}" class="hidden bankName">',
			        			'<input type=text  id=hm value="${item.acctName}" class="hidden toAcctName">',
			        			'<input type=text  id=zh value="${item.acctNo}" class="hidden acctNo">',
			        			'<input type=text  id=bankCode value="${item.bankCode}" class="hidden bankCode">',
			        			'<input type=text  id=brCode value="${item.brCode}" class="hidden brCode">',
			        			'<input type=text  id=cityCode value="${item.cityCode}" class="hidden cityCode">',
			        		'</div>',
			        	'</div>',
			        	'<div class="swiper-slide item-delete" id="${item.acctNo}"><span>删除</span></div>',
			       '</li>',
			   ' </ul>',
			].join("");
		
		
		App.pageA.on("click", "#deleteData", App.onShowDeleteBtn);
		$(".ui-searchbar-text").tap(function(){
			$(".ui-searchbar-wrap").addClass('focus');
			$(".ui-searchbar-input input").focus();
		});
		$(".ui-searchbar-cancel").tap(function(){
			//发送请求
			App.search();
		});
		$(".ui-icon-close").tap(function(){
			$(".ui-searchbar-wrap").removeClass('focus');
			$(".ui-searchbar-input input").val("");
		});
	},
	
	/**
	 * 模糊查询
	 * type   1:为常用收款人
	 * key:模糊搜索关键字
	 * innerBank:0:行内,1:跨行
	 */
	search:function(){
		App.keys = $(".ui-searchbar-input input").val().replace(/\s/g,"");
		if(App.keys == ""){
			Fw.Form.showPinLabel($(this),"关键字不能为空", true);
			return false;
		}
		App.url = YT.dataUrl("private/blurQuery");
		App.json = {
				type:"1",
				innerBank:"1",
				key:App.keys
		}
		App.query();
	},
	/**
	 * 下拉列表
	 */
	query : function() { 
		Fw.Client.openWaitPanel();
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "acctList",
			page : true,
			pageSize:20,
			disclosure : true,
			ajax : {
				url : App.url,
				params : App.json
			},
			itemTpl : App.temp1,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showToacctno, this);
		listView.swiper = App.swiper1;
		listView.loadData();
		
	},
	swiper1:function(res){
		return true;
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		Fw.Client.hideWaitPanel();
		if(rst.acctList.length == 0 && App.keys.length != 0){
			Fw.Client.alertinfo("无匹配记录，请重新输入","消息提示","App.onQueryData()");
			return false;
		}
		if(rst.acctList.length == 0 && App.keys.length == 0){
			$(".ui-searchbar-wrap").hide();
			return false;
		}
		var page = pageIndex || 1;
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 加载数据
	 */
	onQueryData : function() {
		Fw.Client.openWaitPanel("加载中..."); 
		App.url = YT.dataUrl('private/acctOperate');
		// 【行内0】【跨行1】
		App.json = {
				OperateType:"2",
				innerBank: "1"
		}
		App.keys = "";
		App.query();
	},
	
	/**
	 * 账号格式化
	 *	format : function(s) {
	 *		a = s.substring(s.length - 4, s.length);
	 *	},
	 */
	/**
	 * 滑动事件加载
	 */
	HUDONG: function(){
		var swiper = new Swiper('.swiper-container', {
		        slidesPerView: 'auto',
		        freeMode: true,
		        freeModeMomentumBounce: false,
		        spaceBetween: 0
		    });
    	$(".swiper-slide-change").on("click",function(){
    		var e = $(this);
    			var url = YT.dataUrl("private/findAcctInfo");
        		var params = {
        				brCode:$(this).find(".brCode").val(),
        				cityCode:$(this).find(".cityCode").val(),
        		}
        		Fw.Client.openWaitPanel();
        		YT.ajaxData(url,params,function(data){
        				App.datas = data;
        				App.showToacctno(e);
        		});
    		App.showToacctno($(this));
    	});
    	$(".item-delete").on("click", function (e) {
        	e.stopPropagation();
            console.log('tap:item-delete button');
            mydialog( $(this) );
        });
        function mydialog( elem ) {
        	App.acctNo = elem.attr("id");
        	App.elem = elem
        	Fw.Client.confirm("确认删除该账户","消息提示","App.test()",null,"确定","取消");
        }
	},
	/**
	 * 选择账号后返回
	 */
	showToacctno:function(e){
    	App.data.brName=App.datas.BRNAME;
    	App.data.brCode=App.datas.brCode;
    	App.data.provinceName=App.datas.PROVINCENAME +" "+ App.datas.CITYNAME;
    	App.data.provinceCode=App.datas.PROVINCECODE;
    	App.data.cityCode=App.datas.cityCode;
    	App.data.toAcctName=e.find(".toAcctName").val();//收款户名
    	App.data.bankName=e.find(".bankName").val();//收款银行
    	App.data.bankCode=e.find(".bankCode").val();
    	App.data.cardNo=e.find(".acctNo").val();////收款账号
    	App.data.back="1";
    	Fw.redirect("1061830.html",App.data);
	},
	/**
	 * 删除账号
	 */
	test:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/acctOperate");
		var params = {
				innerBank:"1",
				ACCT_NO:App.acctNo,
				OperateType:"1"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS == "1"){
				Fw.Form.showPinLabel($(this), "删除账户成功", true);
				App.elem.parent().remove();
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});
	},
	/**
	 * 返回前一页
	 */
	gotoBackTest:function(){
		App.data.back = "1";
    	Fw.redirect("1061830.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
