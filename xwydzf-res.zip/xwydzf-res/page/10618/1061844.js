/**
 * 创建应用
 * @author 
 */
var App = {
	requires : ['Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
			Fw.Client.hideWaitPanel();
			App.func = window['_getParameter'];
			App.pageA = $("#pageA");
			YT.showPageArea(App.pageA, null, true);
			App.data = Fw.getParameters();
			App.flag = false;
			App.attach = new Array();
			App.next="0";
			App.initEvent();
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
	},
	
	onGobtn:function(v) {
		if(v=="1"){
			Fw.redirect("1061841.html", App.data);
		}else{
			Fw.redirect("1061840.html", App.data);
		}
		
	},
	/**
	 * 返回待办列表
	 */
	gotoBackTest:function(){
		Fw.redirect("1061841.html", App.data);
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
