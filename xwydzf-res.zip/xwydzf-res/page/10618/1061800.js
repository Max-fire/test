/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toSQ);
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryFinancingProduct");
	    YT.ajaxData(url,{},App.success,App.fail);
	},
	success:function(data){
		if (data.STATUS == "1") {
			var html="";
			App.List=data.List;
			var width=document.body.clientWidth-72;
			if (data.List) {
				for ( var i in data.List) {
					//if (data.List[i].productCode=="CP0000001") {
						html+='<div class="swiper-slide" style="height: auto;">';
						html+='<div class="yui-dk-slideInfo" style="width:'+width+'">';
						html+='<div class="yui-dk-nameFont">'+data.List[i].productName+'</div>';
						html+='<div style="padding-top: 5px;"><span class="yui-dk-tipsFont" style="margin-left: 0px;">线上申请</span><span class="yui-dk-tipsFont">自动审批</span><span class="yui-dk-tipsFont">循环使用</span></div>';
						html+='<div class="yui-dk-maxFont">最高额度</div>';
						html+='<div class="yui-dk-maxAmountFont">'+Fw.util.Format.fmtAmt(data.List[i].maxAmount+"")+'<span class="yui-dk-bzFont">元</span></div>';
						html+='<div class="yui-dk-rateFont">';
						html+='<div>每月付息，到期还本<span style="padding-left: 15px;">年利率≥'+data.List[i].minYearRate+'%</span></div>';
						html+='</div>';
						html+='<div class="yui-dk-lineStyle"></div>';
						html+='<div class="yui-dk-productDescription">'+data.List[i].productDescription+'</div>';
						html+='<div class="yui-dk-buttomSpace">';
						html+='<button  type="submit"  class="yui-dk-button" onclick="App.gotoQuery()">我的申请</button>';
						html+='<button  type="submit"  class="yui-dk-myButton" onclick="App.toSQ('+i+')">立即申请</button>';
						html+='</div>';
						html+='</div>';
						html+='</div>';					
					//}
				}    
				$("#list").html(html);				
				YT.showPageArea(App.pageA, [], true);
				var swiper = new Swiper('.swiper-container', {
					pagination:'.swiper-pagination',
					loop:false,
					mode:"horizontal",
					freeMode:false,
					touchRatio:0.5,
					longSwipesRatio:0.1,
					threshold:50,
					followFinger:false,
				});
			}else{
				//无产品显示
				html='<img src="../../css/img/zwmx.png" style="width: 50%;margin: 10% 25%;"><div style="text-align:center;color:#999;">暂无融资产品,敬请期待~</div>'
				App.pageA.html(html)
				YT.showPageArea(App.pageA, [], true);
			}
			Fw.Client.hideWaitPanel();
		} else {
			Fw.Client.alertinfo(data.MSG,"系统提示","App.gotoMsg()");
			Fw.Client.hideWaitPanel();
		}
	},
	fail:function(data){
		Fw.Client.alertinfo(data.MSG,"系统提示");
		Fw.Client.hideWaitPanel();
	},
	//查询是否在白名单
	toSQ:function(i){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/financingCheckInfo");
		var json={
				productCode:App.List[i].productCode,
				productVersion:App.List[i].productVersion
		}
	    YT.ajaxData(url,json,function(data){
	    	if (data.STATUS=="1") {
	    		var json={};
	    		json.List=App.List[i];
	    		json.financingList=data.financingList;
				Fw.redirect("1061801.html",json);
	    		Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			}
	    },App.fail);
	},
	gotoQuery:function(){
		Fw.redirect("1061820.html");
	},
	//返回
	gotoMsg:function(){
		Fw.Client.gotoHomePage();
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);