﻿/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.flag=false;
		App.y3=false;
		App.md5="";
		App.initEvent();
		Fw.Client.hideWaitPanel();
		App.query();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		 App.pageA.on("click","#okbtn",App.okDq);
		 App.pageA.on("click","#xyyh",App.toHT);
		 App.queryProduct();
	},
	query:function(){
		Fw.Client.openWaitPanel();
        var url= YT.dataUrl("private/findFinancingApplyDetail");
       var params={
	      "financingApplyNo":App.data.financingApply.financingApplyNo,	
        }
       YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.data||data.List){
					App.datas=data
					App.loadData(data)
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
   },
   /**
	 * 查询产品
	 */
	queryProduct:function(){
		var params={
				productCode:App.data.financingApply.productCode,
				productVersion:App.data.financingApply.productVersion
			}
		var url = YT.dataUrl('private/queryFinancingProduct');
		Fw.Client.openWaitPanel();
		YT.ajaxData(url, params, function(data) {
			if(data.STATUS=="1"){
				App.data.financingProduct=data.financingProduct;
				$("#dbfs").html(data.financingProduct.guarantyDetail||"")
				$("#rz").html("“"+data.financingProduct.productName+"”借款额度")
			}else{
				App.callback(data);
			}	
		},function(data){
			App.callback(data);
		});
	},
   loadData:function(data){
	   try{
    	var data=data.data;
    	$("#sqzt").html(data.firmName)
    	$("#sqzt1").html(data.firmName)	
		$("#zh").html(data.transferInAcct||"")		
		var sqje=data.approveAmount?"￥"+data.approveAmount:""
		$("#sqje").html(sqje)
		var jdll=data.interestRate?data.interestRate:"--"
		$("#jdll").html(jdll+"%")
		$("#dkqx").html((data.loanTerm||"")+"个月")		
	    $("#hfs").html(data.repayType=="02"?"每月付息，到期还本":"--")//?
	   
	   }catch(e){
		   alert(e)
	   }
	    // data.docName
	    Fw.Client.hideWaitPanel();
	    YT.showPageArea(App.pageA, [], true);
	},
	//返回
	toChangeList:function(){
		Fw.redirect(App.data.page,App.data);
	},
	ty:function(){
		if (!App.y3) {
			Fw.Form.showPinLabel($(this), "请您认真阅读相关协议", true);
			$("#ty").prop("checked","")
			return;
		}
		 if($("#ty:checked").val()=="on"){
			 $("#okbtn").removeClass("okbtndis")
		 }else{
			 $("#okbtn").addClass("okbtndis")
		 }
	},
	okDq:function(){
		if($("#ty:checked").val()==null){
		  Fw.Form.showPinLabel($(this), "用户注册需阅读并勾选同意业务协议", true);
		  return;
	    }
		if(App.flag==true){
			Fw.Form.showPinLabel($(this),"请勿重复提交！", true);
	    	return;
		}
		Fw.Client.openWaitPanel();
				var xml='<M><k>'+App.datas.data.firmName+'</k><v>同意签署合同编号为'+App.data.financingApply.loanContractNo+'的借款合同</v></M>'
				var json = {
						type : "4",
						func : "App.initComplete",
						funcAndroid:"App.initCompleteAndroid",
						XML : '<?xml version="1.0" encoding="utf-8"?><T><D>'+xml+'</D><E><M><k>md5:</k><v>'+App.data.md5+'</v></M></E></T>'
					};
				Fw.Client.showBB(json);
		
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * 支付棒确认提交
	 */
	initSubmit:function(a,b){	
		App.flag=true;
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/finacAudit");
		var json = {
				signData:a,
				signSrc:b,
				contractType:"y3",
				financingApplyNo:App.data.financingApply.financingApplyNo
		};
		YT.ajaxData(url, json, function(data) {
			if (data.STATUS == "1") {
				Fw.Client.hideWaitPanel();
				App.successBack();
//                Fw.Client.alertinfo("已提交申请，待银行审核通过后即可受理成功","消息提示","App.successBack()");
            } else {
				App.flag=false;
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
        Fw.Client.alertinfo(data.MSG,"消息提示");
	},
	successBack:function(){
        document.title="借款合同"
		$("#agree").addClass("hidden");
		$("#okbtn").html("立即提款");
		$("#okbtn").css("margin","40px 12px 10px");
		App.pageA.off("click","#okbtn",App.okDq);
		App.pageA.on("click","#okbtn",App.okTk);
	},
	toHT:function(){
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host;
		var url=App.data.y3;
		var path225="https://168.3.20.225:19020";
		if(url && url.indexOf(path225)>-1){
			url=path+url.substring(26,url.length);
		}
		App.y3=true;
		url=basePath+"/page/10618/css/pdf/web/viewer.html?url="+url;
		Fw.Client.changeWeb(url,false,pageB);
	},
	okTk:function(){
		Fw.redirect("1061820.html");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);