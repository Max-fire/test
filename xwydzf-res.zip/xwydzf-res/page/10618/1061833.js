/**
 * 创建应用
 * 
 * @author zyq
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
		
	},
    initEvent : function(){
    	Fw.Client.openWaitPanel();
    	App.pageA.on("click","#bankName",App.getMsg);
    	App.pageA.on("click","#bankCode",App.getMsg);
        var url = YT.dataUrl("private/findBank");
    	YT.ajaxData(url,{},function(Data){
    		if(Data.STATUS=='1'){
    			var ss = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    			var result = Data.result;
    			for(var i=0; i<ss.length; i++){
    				var key=ss[i];
    				var value=eval("result."+key);
    				/**
					 * create index title
					 */
    				var tites=[
					           '<div id="'+key+'Div">',
					           '<span class="yui-font ui-form-item ">'+key+'</span>' ,
					           		'<ul class="ui-list ui-border-tb" id="'+key+'">',
					           		'</ul>',
					           '</div">'
					          ]
    				if(!value){
    					tites=[
					           '<div id="'+key+'Div" class="hidden">',
					           '<span class="yui-font ui-form-item ">'+key+'</span>' ,
					           		'<ul class="ui-list ui-border-tb" id="'+key+'">',
					           		'</ul>',
					           '</div">'
					          ]
    				}
    				var htmls = Fw.template(tites,"");
					if(i==0){
						App.pageA.find("#remen").after(htmls);
					}else{
						App.pageA.find("#"+ss[i-1]+"Div").after(htmls);
					}
    				if(value){
    					var temp = [
    					            '{@each BankList as item}', 
    					                '<li class="ui-border-radius">',
    					                	'<div class="yui-list-thumb-s">',
    					                	'<span class="yui-yinhang-icon"></span>',
    					                	'</div>',
    					                	'<div class="ui-list-info  ui-border-t" >',
    					                		'<h4 id="bankName">${item.bankName}</h4>',
    					                		'<input id="${item.bankName}" value="${item.bankCode}" hidden/>',
    					                		'</div>',
    					                '</li>', 
    					            '{@/each}',
    					            ].join("");
    					  					
    					
    					var html = Fw.template(temp,value);
    					App.pageA.find("#"+key).html(html);
    					Fw.Client.hideWaitPanel();
    				}
        		}
        	}
    	});
    },
    /**
     * 得到对应的数据返回
     */
    getMsg : function(){
    	var bankName = $(this).html();
    	var bankCode = $("#"+ bankName).val();
    	App.data.bankName = bankName;
    	App.data.bankCode = bankCode;
    	App.data.back = "2";
    	Fw.redirect("1061832.html",App.data);
    },
    /**
     * 返回前一页
     */
    gotoBackTest:function(){
    	App.data.back = "1";
    	Fw.redirect("1061832.html",App.data);
    }
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
