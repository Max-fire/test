﻿/**
 * 创建应用
 * 
 * @author sunz
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.queryDetail(App.data.loanAcctNo)
		//Fw.Client.hideWaitPanel();
		//YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		 App.pageA.on("click","#okbtn",App.okDq);
	},
	queryDetail:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/finaRepayDetail");
		var params={
				loanAcctNo:App.data.loanAcctNo,
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data){

					App.loadData(data.response)
				}else{
					App.loadData([]);
				}
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageA, [], true);
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	loadData:function(data){
		 try{
		    $("#htbh").html(data.htbh);
			$("#dkzzh").html(data.dkzzh);
			$("#khmc").html(data.khmc);
			$("#hksj").html(Fw.util.Format.fmtTrsCreDate(App.data.list.creTime));
			
			if(App.data.tabValue=="0"){//全部还款
				
				$("#fromAcctNo").parent().removeClass('hidden');
				$("#fromAcctNo").html(App.data.list.fromAcctNo);
				$("#hkhm").parent().removeClass("hidden");
				$("#hkhm").html(App.data.list.firmName);//还款户名
				$("#chlx").parent().removeClass('hidden');
				var chlx=App.data.list.repayType=="1"||!App.data.list.bnRepymtInt?"0.00":Fw.util.Format.fmtAmt(App.data.list.bnRepymtInt+'');
				$("#chlx").html(chlx+"元");
				
				
				$("#repayType").parent().removeClass('hidden');
				var repayType=App.data.list.repayType=="1"?"本金还款":"全部还款";
				$("#repayType").html(repayType);
				var chbj = parseFloat(App.data.list.amount-chlx).toFixed(2);
				$("#amount").html(Fw.util.Format.fmtAmt(chbj)+"元");
				
			}else{//本金还款
			
				$("#amount").html(Fw.util.Format.fmtAmt(App.data.list.amount+'')+"元");
			   
			}
		
		  Fw.Client.hideWaitPanel();
		  YT.showPageArea(App.pageA, [], true);
	  }catch(e){
			alert(e)
		}
	 
	},
	//返回
	toChangeList:function(){
		Fw.redirect("1061848.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);