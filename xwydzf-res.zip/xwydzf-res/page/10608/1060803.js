/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.attch = new Array();
		App.url = null;
		App.ul = null;
		App.i = 100;
		App.flag = true;
		App.initEvent();
		App.initPage();
		Fw.Layer.hideWaitPanel(); 
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 上一步
		App.pageA.on("click", "#btnTop", App.gotoTop);
		// 下一步
		App.pageA.on("click", "#btnNext", App.gotoNext);
		// 上传图片
		//App.pageA.on("click", ".upload", App.initimg);
		// 查看图片
		App.pageA.on("click", ".CK", App.showPic);
		//删除图片
		App.pageA.on("click", ".SC", App.deletePic);
		// 分层消失时间
		App.pageA.on("click", "#black_b", App.initBlack);
		// 三证合一判断
		App.pageA.on("click", "#szhy", App.initSZHY);
		//--click
		App.pageA.on("click", ".upload", App.initimg);
		// 我知道了
		App.pageA.on("click", "#iknow", App.initIknow);
		
	},
	/**
	 *初始化页面缓存 
	 */
	initPage : function() {
		
		  
		 if(App.data.acctApplyInfo){
				// 账户类型判断
				  if(App.data.acctApplyInfo.acctProperty!=""){
					  if (App.data.acctApplyInfo.acctProperty == "1") {
							$("#generalDoor").addClass("hidden");
							$("#ZHLX").html("基本账户");
						} else if (App.data.acctApplyInfo.acctProperty == "0") {
							$("#generalDoor").removeClass("hidden");
							$("#ZHLX").html("一般账户");
						}
				  	}
					if( App.data.acctApplyInfo.wxZzjgdmzImg==""||App.data.acctApplyInfo.wxZzjgdmzImg==null ){
						$("#3-1").addClass("hidden");
						$("#yyzz").css("border-bottom","none");
						$("#SZHY").attr("checked","checked");
						
					}else{
						$("#3-1").removeClass("hidden");
						$("#yyzz").css("border-bottom","1px solid rgb(226,226,221)");
						$("#SZHY").removeAttr("checked");
					}
					if (App.data.acctApplyInfo.wxYyzzImg != "") {
						$("#ck1").removeClass("hidden");
						$("#ck1").attr("name",App.data.acctApplyInfo.yyzzImg);
						$("#ck1").attr("data-wxurl",App.data.acctApplyInfo.wxYyzzImg );
					}
					if (App.data.acctApplyInfo.wxYyzzImg == undefined) {
						$("#ck1").addClass("hidden");
						$("#ck1").attr("name","");
						$("#ck1").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxZzjgdmzImg != "") {
						$("#ck2").removeClass("hidden");
						$("#ck2").attr("name",App.data.acctApplyInfo.zzjgdmzImg);
						$("#ck2").attr("data-wxurl",App.data.acctApplyInfo.wxZzjgdmzImg );
					} 
					if (App.data.acctApplyInfo.wxZzjgdmzImg == undefined) {
						$("#ck2").addClass("hidden");
						$("#ck2").attr("name","");
						$("#ck2").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxGsdjzImg != "") {
						$("#ck3").removeClass("hidden");
						$("#dele3").removeClass("hidden");
						$("#ck3").attr("name",App.data.acctApplyInfo.gsdjzImg);
						$("#ck3").attr("data-wxurl",App.data.acctApplyInfo.wxGsdjzImg );
					} 
					if (App.data.acctApplyInfo.wxGsdjzImg == undefined) {
						$("#ck3").addClass("hidden");
						$("#dele3").addClass("hidden");
						$("#ck3").attr("name","");
						$("#ck3").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxDsdjzImg != "") {
						$("#ck4").removeClass("hidden");
						$("#dele4").removeClass("hidden");
						$("#ck4").attr("name",App.data.acctApplyInfo.dsdjzImg);
						$("#ck4").attr("data-wxurl",App.data.acctApplyInfo.wxDsdjzImg );
					} 
					if (App.data.acctApplyInfo.wxDsdjzImg == undefined) {
						$("#ck4").addClass("hidden");
						$("#dele4").addClass("hidden");
						$("#ck4").attr("name","");
						$("#ck4").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxJgxydmzImg != "") {
						$("#ck5").removeClass("hidden");
						$("#dele5").removeClass("hidden");
						$("#ck5").attr("name",App.data.acctApplyInfo.jgxydmzImg);
						$("#ck5").attr("data-wxurl",App.data.acctApplyInfo.wxJgxydmzImg );
					} 
					if (App.data.acctApplyInfo.wxJgxydmzImg == undefined) {
						$("#ck5").addClass("hidden");
						$("#dele5").addClass("hidden");
						$("#ck5").attr("name","");
						$("#ck5").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxJbhkhxkzImg != "") {
						$("#ck6").removeClass("hidden");
						$("#ck6").attr("name",App.data.acctApplyInfo.jbhkhxkzImg);
						$("#ck6").attr("data-wxurl",App.data.acctApplyInfo.wxJbhkhxkzImg );
					} 
					if (App.data.acctApplyInfo.wxJbhkhxkzImg == undefined) {
						$("#ck6").addClass("hidden");
						$("#ck6").attr("name","");
						$("#ck6").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxFrsfzzmImg != "") {
						$("#ck7").removeClass("hidden");
						$("#ck7").attr("name",App.data.acctApplyInfo.frsfzzmImg);
						$("#ck7").attr("data-wxurl",App.data.acctApplyInfo.wxFrsfzzmImg );
					} 
					if (App.data.acctApplyInfo.wxFrsfzzmImg == undefined) {
						$("#ck7").addClass("hidden");
						$("#ck7").attr("name","");
						$("#ck7").attr("data-wxurl","" );
					} 
					if (App.data.acctApplyInfo.wxFrsfzfmImg != "") {
						$("#ck8").removeClass("hidden");
						$("#ck8").attr("name",App.data.acctApplyInfo.frsfzfmImg);
						$("#ck8").attr("data-wxurl",App.data.acctApplyInfo.wxFrsfzfmImg);
					}
					if (App.data.acctApplyInfo.wxFrsfzfmImg == undefined) {
						$("#ck8").addClass("hidden");
						$("#ck8").attr("name","");
						$("#ck8").attr("data-wxurl","" );
					} 
			  }
		  
		  
		  var params={
				 url : location.href.split('#')[0],
				 type:'2'
  			}
  		var url = YT.dataUrlWeb("private/dealApplyImg");
			YT.ajaxDataWeb(url, params, function(data) {
				//alert(data);
				if (data.STATUS == "1") {
					try{
					
					wx.config({ 
						   debug:false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。 
						   appId:data.wxMsg.appid , // 必填，公众号的唯一标识 
						   timestamp: data.wxMsg.timestamp, // 必填，生成签名的时间戳 
						   nonceStr: data.wxMsg.nonceStr, // 必填，生成签名的随机串 
						   signature: data.wxMsg.signature,// 必填，签名，见附录1 
						   jsApiList: [ 
						         'checkJsApi',
						         'chooseImage', 
						         'uploadImage',
						         'previewImage',
						         'downloadImage'
						         ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2 
						 }); 
					
				
						wx.ready(function(){
							wx.checkJsApi({
							    jsApiList: ['checkJsApi','chooseImage','uploadImage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
							    success: function(res) {
	//						    	alert("----信息验证成功!-----");
							    }
							});
						    
						}); 
					  	
						wx.error(function(res){
							//alert(res.checkResult);
							Fw.Form.showPinLabel($(this), res.checkResult , true);
							return;
						});
					}catch(e){
						alert(e);
					}
				}else{
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
				}
			});
			//alert(wx.config);
			 
			 
		  
	},
	/**
	 * 三证合一判断
	 */
	initSZHY : function() {
		if ($("#SZHY").is(":checked")) {
			$("#3-1").addClass("hidden");
			$(".yui-sctp-div1-1").css("border-bottom","none");
		} else {
			$("#3-1").removeClass("hidden");
			$(".yui-sctp-div1-1").css("border-bottom","1px solid rgb(226,226,221)");
		}
	},
	/**
	 * 我知道了点击事件 
	 */
	initIknow : function() {
		$("#black_b").css("display", "none");
		$("#white_b").css("display", "none");
	},
	/**
	 *上传图片
	 */
	initimg : function() {
		var images = { 
	  			  localId: [], 
	  			  serverId: [] ,
	  			  downloadId:[]
	  			 };
		//图片id序号
		var id=$(this).attr("id");
		var idnum=id.substring(id.length - 1);
		//
		var preview=$('#ck'+idnum+'');
		try{
			//选择图片
			wx.chooseImage({  
				count: 1, // 默认9
			    sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
			    sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
				success: function (res) {  
					
					images.localId = res.localIds;
					var localIds = res.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片  
					//alert("--选择图片成功--localId---"+localIds);
					/*if(res.localIds.length>1){
						
						alert("一次只能上传一张图片!");
						return;
					}*/
					Fw.Layer.openWaitPanel();  	//等待层开启
					//上传图片
					wx.uploadImage({
						localId:localIds.toString(),
						isShowProgressTips:0,
						success:function(res){
							var serverId=res.serverId.toString();
							//alert("--开始上传图片--serverId---"+serverId);
							//alert("mediaId:"+serverId+"-----"+"imgName:"+localIds);
							//下载图片
							wx.downloadImage({
								serverId:serverId,
								isShowProgressTip:0,
								success: function (res) {  
									var localId=res.localId
									var params={
											mediaId:serverId,
											imgName:localIds,
											//fileName : '1234.jpg',
											type:'0'
									}
									var url = YT.dataUrlWeb("private/dealApplyImg");
									YT.ajaxDataWeb(url, params, function(data) {
										if (data.STATUS == "1") {
											if(idnum=="1"){
												if(data.fuzzyImage==1){
													Fw.Layer.hideWaitPanel();
													//alert("营业执照上传模糊，预约申请可能被拒绝，建议重新上传清晰影像提交");
												    $("#black_b").css("display", "");
													$("#white_b").css("display", "");
												}
											}
											preview.attr("name",data.fileName);
											//preview.attr("data-value",data.fileUrl);
											preview.removeClass("hidden");
											//显示删除按钮
											if(idnum=='2'){
												$("#dele2").removeClass("hidden");
											}
											if(idnum=='3'){
												$("#dele3").removeClass("hidden");
											}
											if(idnum=='4'){
												$("#dele4").removeClass("hidden");
											}
											if(idnum=='5'){
												$("#dele5").removeClass("hidden");
											}
											//preview.attr("data-value",localIds.toString());
											
										}else{
											//隐藏删除按钮
											if(idnum=='2'){
												$("#dele2").addClass("hidden");
											}
											if(idnum=='3'){
												$("#dele3").addClass("hidden");
											}
											if(idnum=='4'){
												$("#dele4").addClass("hidden");
											}
											if(idnum=='5'){
												$("#dele5").addClass("hidden");
											}
											preview.addClass("hidden");
											Fw.Form.showPinLabel($(this), data.MSG, true);
											return;
										}
										//微信图片地址
										preview.attr("data-wxurl",localIds.toString());
									});
								}
								
							});
						
							Fw.Layer.hideWaitPanel();	//等待层关闭
							
						},
						fail: function (res) { 
							Fw.Layer.hideWaitPanel();
							Fw.Form.showPinLabel($(this), res.checkResult, true);
							return;
						}  
					});
				},
				fail: function (res) { 
					//alert("fale");
					Fw.Form.showPinLabel($(this), res.checkResult, true);
					return;
				} 
			});  
		}catch(e){
			alert(e);
		}
	},

	/**
	 * 查看图片
	 */
	showPic : function() {
//		$("#pic").attr("src", $(this).attr("data-value"));
//		$("#black_b").css("display", "");
//		$("#white_b").css("display", "");
		
		wx.previewImage({
			current: $(this).attr("data-wxurl"), 
            urls: [$(this).attr("data-wxurl")]
		});

	},
	/**
	 * 机构信用代码证删除事件
	 */
	deletePic:function(){
		var idnum=$(this).attr("id").substring($(this).attr("id").length-1);
		
			 var params={
					 operatorPhone:App.data.acctApplyInfo.operatorPhone,
					 applyInfoSerial:App.data.acctApplyInfo.applyInfoSerial+"",
					 imgName: $('#ck'+idnum+'').attr("name"),
					 type:'1'
			 }
			 var url = YT.dataUrlWeb("private/dealApplyImg");
				YT.ajaxDataWeb(url, params, function(data) {
					if (data.STATUS == "1") {
						$('#ck'+idnum+'').addClass("hidden");
						$('#dele'+idnum+'').addClass("hidden");
						$('#ck'+idnum+'').attr("name","");
						$('#ck'+idnum+'').attr("data-wxurl",""); 
						if(idnum=="3"){
							App.data.gsdjzImg = "";
							App.data.wxGsdjzImg = "";
						}
						if(idnum=="4"){
							App.data.dsdjzImg = "";
							App.data.wxDsdjzImg = "";
						}
						if(idnum=="5"){
							App.data.jgxydmzImg = "";
							App.data.wxJgxydmzImg = "";
						}
						
						Fw.Form.showPinLabel($(this), "删除成功", true);
						return;
					}else{
						Fw.Form.showPinLabel($(this), data.MSG, true);
						return;
					}
				});
		
	},
	/**
	 * 弹出层关闭
	 */
	initBlack : function() {
		$("#black_b").css("display", "none");
		$("#white_b").css("display", "none");
	},
	/**
	 * 上一步
	 */
	gotoTop : function() {
		Fw.Layer.openWaitPanel()
		Fw.redirect("1060802.html", App.data);
	},
	/**
	 * 下一步
	 */
	gotoNext : function() {
		
		//ckk  的name属性为图片名
		//ck   的name属性为图片url地址
		
		if ($("#ck1").attr("name") == "") {
			Fw.Form.showPinLabel($(this), "请上传营业执照", true);
			return;
		}
		/*if (!$("#SZHY").is(":checked")) {
			if ($("#ck2").attr("name") == "") {
				Fw.Form.showPinLabel($(this), "请上传组织代码机构证", true);
				return;
			}
		}*/
		if ($("#ZHLX").html() == "一般账户") {
			if ($("#ck6").attr("name") == "") {
				Fw.Form.showPinLabel($(this), "请上传开户许可证", true);
				return;
			}
		}
		if ($("#ck7").attr("name") == "") {
			Fw.Form.showPinLabel($(this), "请上传法人证件正面", true);
			return;
		}
		if ($("#ck8").attr("name") == "") {
			Fw.Form.showPinLabel($(this), "请上传法人证件反面", true);
			return;
		}
		
		var params = {
			operatorPhone : App.data.acctApplyInfo.operatorPhone,
			yyzzImg : $("#ck1").attr("name"),
			wxYyzzImg: $("#ck1").attr("data-wxurl"),
			
			zzjgdmzImg : $("#ck2").attr("name"),
			wxZzjgdmzImg: $("#ck2").attr("data-wxurl"),
			
			gsdjzImg : $("#ck3").attr("name"),
			wxGsdjzImg: $("#ck3").attr("data-wxurl"),
			
			dsdjzImg : $("#ck4").attr("name"),
			wxDsdjzImg: $("#ck4").attr("data-wxurl"),
			
			jgxydmzImg : $("#ck5").attr("name"),
			wxJgxydmzImg: $("#ck5").attr("data-wxurl"),
			
			jbhkhxkzImg : $("#ck6").attr("name"),
			wxJbhkhxkzImg: $("#ck6").attr("data-wxurl"),
			
			frsfzzmImg : $("#ck7").attr("name"),
			wxFrsfzzmImg: $("#ck7").attr("data-wxurl"),
			
			frsfzfmImg : $("#ck8").attr("name"),
			wxFrsfzfmImg: $("#ck8").attr("data-wxurl"),
			
			applyInfoSerial:App.data.acctApplyInfo.applyInfoSerial+"",
			step : "3"
		}
		if ($("#SZHY").is(":checked")){
			params.zzjgdmzImg="";
			params.wxZzjgdmzImg="";
			params.gsdjzImg="";
			params.wxGsdjzImg="";
			params.dsdjzImg="";
			params.wxDsdjzImg="";
			params.szhy="1";//三证合一判断字段
			
		}else{
			params.szhy="0";
		}
		if($("#ZHLX").html() == "基本账户"){
			
			params.jgxydmzImg="";
			params.wxJgxydmzImg="";
			params.jbhkhxkzImg="";
			params.wxJbhkhxkzImg="";
			
		}
		Fw.Layer.openWaitPanel()
		var url = YT.dataUrlWeb("private/acctApply");
		YT.ajaxDataWeb(url, params, function(data) {

			if (data.STATUS == "1") {
						//图片名  图片url  localIds  传到写一个界面
						App.data.acctApplyInfo.yyzzImg = $("#ck1").attr("name");
						App.data.acctApplyInfo.wxYyzzImg = $("#ck1").attr("data-wxurl");
						
						App.data.acctApplyInfo.zzjgdmzImg = $("#ck2").attr("name");
						App.data.acctApplyInfo.wxZzjgdmzImg = $("#ck2").attr("data-wxurl");
						
						App.data.acctApplyInfo.gsdjzImg = $("#ck3").attr("name");
						App.data.acctApplyInfo.wxGsdjzImg = $("#ck3").attr("data-wxurl");
						
						App.data.acctApplyInfo.dsdjzImg = $("#ck4").attr("name");
						App.data.acctApplyInfo.wxDsdjzImg = $("#ck4").attr("data-wxurl");
						
						App.data.acctApplyInfo.jgxydmzImg = $("#ck5").attr("name");
						App.data.acctApplyInfo.wxJgxydmzImg = $("#ck5").attr("data-wxurl");
						
						App.data.acctApplyInfo.jbhkhxkzImg = $("#ck6").attr("name");
						App.data.acctApplyInfo.wxJbhkhxkzImg = $("#ck6").attr("data-wxurl");
						
						App.data.acctApplyInfo.frsfzzmImg = $("#ck7").attr("name");
						App.data.acctApplyInfo.wxFrsfzzmImg = $("#ck7").attr("data-wxurl");
						
						App.data.acctApplyInfo.frsfzfmImg = $("#ck8").attr("name");
						App.data.acctApplyInfo.wxFrsfzfmImg = $("#ck8").attr("data-wxurl");
						
						if ($("#SZHY").is(":checked")){
							
							App.data.acctApplyInfo.zzjgdmzImg = "";
							App.data.acctApplyInfo.wxZzjgdmzImg = "";
							
							
							App.data.acctApplyInfo.gsdjzImg = "";
							App.data.acctApplyInfo.wxGsdjzImg = "";
							
							
							App.data.acctApplyInfo.dsdjzImg = "";
							App.data.acctApplyInfo.wxDsdjzImg = "";
							
							App.data.acctApplyInfo.szhy="1";
						}else{
							App.data.acctApplyInfo.szhy="0";
						}
						if($("#ZHLX").html() == "基本账户"){
							
							App.data.acctApplyInfo.jgxydmzImg = "";
							App.data.acctApplyInfo.wxJgxydmzImg = "";
							
							App.data.acctApplyInfo.jbhkhxkzImg = "";
							App.data.acctApplyInfo.wxJbhkhxkzImg = "";
							
						}
						Fw.redirect("1060804.html", App.data);
			} else {
				Fw.Layer.hideWaitPanel()
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;

			}
		});

	}

};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);