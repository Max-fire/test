/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		//YT.showPageArea(App.pageA, [], true);
		App.flag = true;
		App.initEvent();
		App.loadData();
		Fw.Layer.hideWaitPanel(); 
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click",".DJXQ",App.toXQ);
	},
	/**
	 * 加载数据
	 */
	loadData:function(){
		var html="";
		var j=1;
		for ( var d in App.data.acctApplyList) {
			html+='<div style="height: 16px; line-height: 16px; font-size: 16px; border-bottom: 1px solid rgb(226, 226, 221); background-color: white; padding: 15px;">';
			html+='<div style="float: left; color: #333333;">申请记录<span>'+j+'</span></div>';
			if (App.data.acctApplyList[d].approveStatus=="0" || App.data.acctApplyList[d].approveStatus=="2") {
				html+='<span style="float: right; color: #0c9bff;">审核中</span>';
			}
			if (App.data.acctApplyList[d].approveStatus=="6") {
				html+='<span style="float: right; color: #0c9bff;">预约成功</span>';
			}
			if (App.data.acctApplyList[d].approveStatus=="7" || App.data.acctApplyList[d].approveStatus=="1") {
				html+='<span style="float: right; color: #f46c00;">预约失败</span>';
			}
			html+='</div>';
			html+='<div style="padding: 13px 15px; font-size: 13px; background-color: white;">';
			html+='<div>';
				html+='	<label style="width: 65px;color: #999999;float: left;">公司名称：</label>';
					html+='	<div id="GSMC" style="color: #333333; padding-left: 15px;float: left;width: 70%;word-wrap: break-word;word-break: break-all;">';
					html+=App.data.acctApplyList[d].firmName;
					html+='	</div>';
	    	html+='	</div>';
	    	html+='<div style="clear: both;"></div>';
			html+='<div style="margin-top: 10px;clear:both;">';
			html+='<label style="color: #999999;">账户类型：</label><span id="ZHLX" style="color: #333333; padding-left: 15px;">';
			if(App.data.acctApplyList[d].acctProperty=="1"){
				html+='基本账户';
			}else {
				html+='一般账户';
			}+'</span>'; 
				if (App.data.acctApplyList[d].approveStatus=="7" || App.data.acctApplyList[d].approveStatus=="1") {
					html+='<span  style="float: right; font-size: 12px; color: 0c9bff; display: block; height: 24px; line-height: 24px; width: 60px; text-align: center; border: 1px solid #0c9bff; border-radius: 4px;" onclick="App.toPage('+d+')">修改申请</span>';
				}
			html+='</div>';
			html+='<div style="margin-top: 10px;">';
			html+='<label style="color: #999999;">开户分行：</label><span id="KHZH" style="color: #333333; padding-left: 15px;">'+App.data.acctApplyList[d].applyAreaName+'</span>';
			html+='</div>';
			html+='<div style="margin-top: 10px;">';
			html+='<label style="color: #999999;">开户网点：</label><span id="KHZH" style="color: #333333; padding-left: 15px;">'+App.data.acctApplyList[d].applyOrgName+'</span>';
			html+='</div>';
			html+='<div style="margin-top: 10px;">';
			html+='<label style="color: #999999;float:left;">网点地址：</label>';
			html+='	<div id="WDDZ"  style="padding-left: 15px;color: #333333;float: left;width: 66%;word-wrap: break-word;word-break: break-all;">';
			html+=App.data.acctApplyList[d].orgAddr;
			html+='	</div>';
			html+='</div>';
			html+='<div style="clear: both;"></div>';
			html+='<div style="margin-top: 10px;">';
			html+='<label style="color: #999999;">预约编号：</label><span id="YYBH" style="color: #333333; padding-left: 15px;">'+App.data.acctApplyList[d].yybh+'</span>';
			html+='</div>';
			if (App.data.acctApplyList[d].approveStatus=="7" || App.data.acctApplyList[d].approveStatus=="1") {
			html+='<div id="YY" class="" style="margin-top: 10px;">';
			html+='<label style="color: #999999; float: left;">原因：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>';
			html+='	<div  style="padding-left: 15px;color: #f46c00;float: left;width: 66%;word-wrap: break-word;word-break: break-all;">';
			html+=App.data.acctApplyList[d].resultDesc;
			html+='	</div>';
			html+='</div>';
			html+='<div style="clear: both;"></div>';
			}
			
			html+='<div  id="SXXQ'+d+'" class="hidden">';
			
			
			
			html+='<div style="margin-top: 10px;">';
			html+='<label style="color: #999999;">法人电话：</label><span id="QYFR" style="color: #333333; padding-left: 15px;">'+App.data.acctApplyList[d].legalPhone+'</span>';
			html+='</div>';
			
			html+='<div style="margin-top: 10px;">';
			html+='	<label style="width: 80px;color: #999999;float: left;">财务负责人：</label>';
			html+='	<div  style="color: #333333; float: left;width: 66%;word-wrap: break-word;word-break: break-all;">';
			html+=App.data.acctApplyList[d].financeMan+'('+App.data.acctApplyList[d].financePhone+')';
			html+='	</div>';
			html+='	</div>';
			html+='<div style="clear: both;"></div>';
			
			html+='<div style="margin-top: 10px;">';
			html+='	<label style="width: 80px;color: #999999;float: left;">开户经办人：</label>';
			html+='	<div  style="color: #333333;float: left;width: 66%;word-wrap: break-word;word-break: break-all;">';
			html+=App.data.acctApplyList[d].operatorName+'('+App.data.acctApplyList[d].operatorPhone+')';
			html+='	</div>';
			html+='	</div>';
			html+='<div style="clear: both;"></div>';
			html+='<div style="margin-top: 10px;">';
				html+='	<label style="width: 65px;color: #999999;float: left;">办公地址：</label>';
				html+='	<div  style="color: #333333; padding-left: 15px;float: left;width: 70%;word-wrap: break-word;word-break: break-all;">';
				html+=App.data.acctApplyList[d].firmAddr;
				html+='	</div>';
			html+='	</div>';
			html+='<div style="clear: both;"></div>';
			html+='<div style="margin-top: 10px;">';
			html+='<label style="color: #999999;">预约时间：</label><span id="SQSJ" style="color: #333333; padding-left: 15px;">'+Fw.util.Format.fmtTrsCreDate(App.data.acctApplyList[d].applyTime,"yyyy-MM-dd")+'</span>';
			html+='</div>';
			html+='<div>';
			html+='</div>';
			html+='</div>';
			html+='</div>';
			html+='<div class="DJXQ" id="'+d+'" style="height: 44px; line-height: 44px; color: #666666; border-top: 1px solid rgb(226, 226, 221); background-color: white;text-align: center;">';
			html+='<span id="CKXQ'+d+'" class="yui-dgkh-zk" style="padding-right: 20px;background: url("../../css/img/zhankai.png") no-repeat; background-position: 100% 50%; background-size: 20%;">展开详情</span>';
			html+='</div>';
			html+='<div style="height: 10px"></div>';
			j++;
		}
		$("#LIST").html(html);
	},
	toXQ:function(){
		var i=$(this).attr("id");
		if($("#CKXQ"+i).hasClass('yui-dgkh-zk')){
			$("#CKXQ"+i).html("收起详情");
			$("#CKXQ"+i).removeClass("yui-dgkh-zk");
			$("#CKXQ"+i).addClass("yui-dgkh-sq");
			//$("#TG"+i).addClass("hidden");
			$("#SXXQ"+i).removeClass("hidden");
		}else{
			$("#CKXQ"+i).html("展开详情");
			$("#CKXQ"+i).removeClass("yui-dgkh-sq");
			$("#CKXQ"+i).addClass("yui-dgkh-zk");
			//$("#TG"+i).removeClass("hidden");
			$("#SXXQ"+i).addClass("hidden");
		}
	},
	toPage:function(i){
		var params={
			applyInfoSerial:""+	App.data.acctApplyList[i].applyInfoSerial,
			operatorPhone:App.data.acctApplyList[i].operatorPhone,
			step:"0"
		}
		Fw.Layer.openWaitPanel(); 
		var url = YT.dataUrlWeb("private/acctApply");
		YT.ajaxDataWeb(url, params, function(data) {
			if (data.STATUS == "1") {
				Fw.redirect("1060801.html",data);
			}else{
				Fw.Layer.hideWaitPanel(); 
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});
		
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);