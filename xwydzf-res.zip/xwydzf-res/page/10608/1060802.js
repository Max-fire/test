/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.initPage();
		Fw.Layer.hideWaitPanel(); //关闭等待层
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		// 检查公司名称
		//App.pageA.on("blur", "#GSMC", App.checkGSMC);
		
		//App.pageA.on("click", "#GSMC", App.checkGSMC111);
		// 动态校验公司名称位数
		App.pageA.on("input","#GSMC",App.checkGSMCNum);
		App.pageA.on("porpertychanger","#GSMC",App.checkGSMCNum);
		//公司名称模糊查询
		
		App.pageA.on("blur", "#GSMC", App.requireGSMC);
		//公司名称模糊查询结果点击触发事件
		App.pageA.on("click", "#searchresult li", App.searchResult);
		//点击body隐藏搜索结果
		App.pageA.on("click", "#all", App.hide1);
		//手机去空格
		App.pageA.on("blur", "#SJ1", App.removeKong1);
		App.pageA.on("blur", "#SJ2", App.removeKong2);
		
		// 动态校验姓名位数
		App.pageA.on("input","#XM",App.checkXMNum);
		App.pageA.on("porpertychanger","#XM",App.checkXMNum);
		
		App.pageA.on("click", "#XM", App.initXM);
		App.pageA.on("blur", "#XM", App.initXM1);
		
		// 动态校验详细地址位数
		App.pageA.on("input","#XXDZ",App.checkXXDZNum);
		App.pageA.on("porpertychanger","#XXDZ",App.checkXXDZNum);
		
		// 办公地址
		App.pageA.on("change", "#BGDZ", App.initBGDZ);
		App.pageA.on("blur", "#XXDZ", App.initXXDZ2);
		App.pageA.on("click", "#XXDZ", App.initXXDZ1);
		// 账户类型提示
		App.pageA.on("click", "#SM", App.initSM);
		// 我知道了
		App.pageA.on("click", "#iknow", App.initIknow);
		// 账户结算服务协议
		App.pageA.on("click", "#zhjs", App.gotoZHJS);
		// 上一步
		App.pageA.on("click", "#btnTop", App.gotoTop);
		// 下一步
		App.pageA.on("click", "#btnNext", App.gotoNext);
		//点击X隐藏搜索结果及自身
		App.pageA.on("click", "#cha", App.chahide);
		
		
	},
	/**
	 * 初始化页面
	 */
	initPage : function() {
		if(App.data && App.data.acctApplyInfo!=null){
			if(App.data.acctApplyInfo.firmName!=null ||　App.data.acctApplyInfo.firmName!=""){
				App.pageA.off("blur", "#GSMC", App.requireGSMC);
				$("#GSMC").val(App.data.acctApplyInfo.firmName);
				$("#GSMC").focus();
				$("#GSMC").blur();
				App.pageA.on("blur", "#GSMC", App.requireGSMC);
			}
			if(App.data.acctApplyInfo.acctProperty!=null || App.data.acctApplyInfo.acctProperty!=""){
				if (App.data.acctApplyInfo.acctProperty == "1") {
					$("#JBH").attr("checked", "checked");
				} else if (App.data.acctApplyInfo.acctProperty == "0") {
					$("#YBH").attr("checked", "checked");
				}
			}
			if(App.data.acctApplyInfo.firmAddr!=null){
				if(App.data.acctApplyInfo.firmAddr!="同注册地"){
					//alert("办公地址请重新输入!");
					$("#BGDZ").val("手动输入");
					$("#selAddress").removeClass("hidden");
					$("#lineBGDZ").css("border-bottom", "1px solid rgb(226,226,221)");
					$("#XXDZ").val(App.data.acctApplyInfo.firmAddr);
					$("#XXDZ").focus();
					$("#XXDZ").blur();
				}
			}
			if(App.data.acctApplyInfo.legalPhone!=null){
				$("#SJ1").val(App.data.acctApplyInfo.legalPhone);
			}
			if(App.data.acctApplyInfo.financeMan!=null){
				$("#XM").val(App.data.acctApplyInfo.financeMan);
				$("#XM").focus();
				$("#XM").blur();
			}
			if(App.data.acctApplyInfo.financePhone!=null){
				$("#SJ2").val(App.data.acctApplyInfo.financePhone);
			}
			
			
		
		}
	},
	/**
	 * 检查公司名称字节数 
	 */
	checkGSMCNum:function(){
		var w=0;//字节数
		var name=$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>120){
				name=name.substring(0,i);
				$("#GSMC").val(name);
				$("#GSMC").blur();
				break;
			}
		}
	},
	/**
	 * 检查财务负责人姓名字节数 
	 */
	checkXMNum:function(){
		var w=0;//字节数
		var name=$("#XM").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>30){
				name=name.substring(0,i);
				$("#XM").val(name);
				$("#XM").blur();
				break;
			}
		}
		$("#XM").css("text-align","left");
	},
	/**
	 * 检查详细地址字节数 
	 */
	checkXXDZNum:function(){
		var w=0;//字节数
		var name=$("#XXDZ").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>60){
				name=name.substring(0,i);
				$("#XXDZ").val(name);
				$("#XXDZ").blur();
				break;
			}
		}
	},
	/**
	 * 公司名称模糊查询 
	 */
	requireGSMC:function(){
		$("#searchresult").empty().hide();
		var  gsmc= $.trim($("#GSMC").val());
		if(gsmc.length==0){
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			//当公司名字为空时，无搜索结果，故把搜索结果清空
			$("#searchresult").empty().hide();
		}
		//发送请求之前先清空搜索结果
		if(gsmc.length!==0){
			var params={
					firmName:gsmc
			};
			Fw.Layer.openWaitPanel(); //等待层
			var url = YT.dataUrlWeb("private/fuzzyQueryByFirmName");
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					$("#searchresult").show();
					$("#cha").show();
					var result=data.firmList;
					var html='';
					for(var i=0;i<result.length;i++){
						html+='<li style="text-align:center;font-size:14px;" data-value="'+result[i].firmId+'">'+result[i].firmName+'</li>';
					}
					$("#searchresult").append(html);
					$("#resultresult").css({
						top:$("#GSMC").offset().top+$("#GSMC").height(),
					});
					Fw.Layer.hideWaitPanel(); //关闭等待层
				}else{
					Fw.Layer.hideWaitPanel(); //关闭等待层
					Fw.Form.showPinLabel($(this), data.MSG, true);
					$("#resultresult").hide();
					$("#cha").hide();
				}
			});
		}
	},
	/**
	 * 点击关闭按钮关闭搜索结果及自身
	 */
	chahide:function(){
		$(this).hide();
		$("#resultresult").hide();
	},
	/**
	 * 公司名称模糊查询结果点击触发事件
	 */
	searchResult:function(){
		var liVal=$(this).text();
		App.pageA.off("blur", "#GSMC", App.requireGSMC);
		var gsmc=$("#GSMC").val(liVal);
		$("#GSMC").focus();
		$("#GSMC").blur();
		App.pageA.on("blur", "#GSMC", App.requireGSMC);
		$(this).css("background","#017EF3").siblings().css("background","#ccc");
		
	},
	/**
	 * 点击body隐藏搜索结果
	 */
	hide1:function(){
		$("#searchresult").hide();
		$("#cha").hide();
	},
	/**
	 * 检查公司名称 
	 */
	/*
	checkGSMC:function(){
		var gsmc = $("#GSMC").val();
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (gsmc == "") {
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			return;
		}
		if (nnm.test(gsmc)) {
			Fw.Form.showPinLabel($(this), "公司名称含有非法字符!", true);
			return;
		}
		$("#GSMC").css("text-align","right");
	},
	checkGSMC111:function(){
		
		$("#GSMC").css("text-align","left");
	},*/
	/**
	 * 手机号误输入空格失去焦点去除 
	 */
	removeKong1:function(){
		var mobile1 = $("#SJ1").val().replace(/ /g,""); //企业法人手机
		$("#SJ1").val(mobile1);
	},
	removeKong2:function(){
		var mobile1 = $("#SJ2").val().replace(/ /g,""); //企业法人手机
		$("#SJ2").val(mobile1);
	},
	/**
	 * 办公地址
	 */
	initBGDZ : function() {
		if ($(this).val() == "手动输入") {
			$("#selAddress").removeClass("hidden");
			$("#lineBGDZ").css("border-bottom", "1px solid rgb(226,226,221)");
		} else if ($(this).val() == "同注册地") {
			$("#selAddress").addClass("hidden");
			$("#lineBGDZ").css("border-bottom", "none");
		}
	},
	//blur
	initXXDZ2:function(){
		$("#XXDZ").css("text-align","right");
	},
	//click
	initXXDZ1:function(){
		$("#XXDZ").css("text-align","left");
	},
	//click
	initXM:function(){
		$("#XM").css("text-align","left");
	},
	//blur
	initXM1:function(){
		$("#XM").css("text-align","right");
	},
	/**
	 * 账户类型介绍
	 */
	initSM : function() {
		$("#black_b").css("display", "");
		$("#white_b").css("display", "");
	},
	/**
	 * 我知道了点击事件 
	 */
	initIknow : function() {
		$("#black_b").css("display", "none");
		$("#white_b").css("display", "none");
	},
	gotoZHJS:function(){
		App.data.acctApplyInfo.firmName =$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		if ( $("#JBH").is(":checked") ) {
			App.data.acctApplyInfo.acctProperty = "1";
		}else if( $("#YBH").is(":checked") ){
			App.data.acctApplyInfo.acctProperty = "0";
		}
		if($("#XXDZ").val().replace(/(^\s*)|(\s*$)/g,"")==""){
			App.data.acctApplyInfo.firmAddr="同注册地";
		}else{
			App.data.acctApplyInfo.firmAddr = $("#XXDZ").val().replace(/(^\s*)|(\s*$)/g,""); // 手动输入地址
		}
		App.data.acctApplyInfo.legalPhone = $("#SJ1").val().replace(/ /g,""); //企业法人手机
		App.data.acctApplyInfo.financeMan = $("#XM").val().replace(/(^\s*)|(\s*$)/g,"");// 财务负责人姓名 
		App.data.acctApplyInfo.financePhone = $("#SJ2").val().replace(/ /g,"");// 财务负责人手机
		Fw.Layer.openWaitPanel(); //开启等待层
		Fw.redirect("1060802_ZHJS.html",App.data);
	},
	/**
	 * 上一步
	 */
	gotoTop : function() {
		Fw.Layer.openWaitPanel(); //开启等待层
		Fw.redirect("1060801.html", App.data);
	},
	/**
	 * 下一步
	 */
	gotoNext : function() {
		//alert($("#XXDZ").val());
		var ZHLX = null;
		var BGDZ = null; 
		var GSMC =$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		
		var XXDZ = $("#XXDZ").val().replace(/(^\s*)|(\s*$)/g,""); // 手动输入地址 
		var mobile1 = $("#SJ1").val().replace(/ /g,""); //企业法人手机
		var name = $("#XM").val().replace(/(^\s*)|(\s*$)/g,"");// 财务负责人姓名 
		var mobile2 = $("#SJ2").val().replace(/ /g,"");// 财务负责人手机
		//账户类型判断
		if ($("#JBH").is(":checked")) {
			ZHLX = "1";
		} else if ($("#YBH").is(":checked")) {
			ZHLX = "0";
		}
		if ($("#BGDZ").val() == "同注册地") {
			BGDZ = "同注册地";
		} else if ($("#BGDZ").val() == "手动输入") {
			BGDZ =  XXDZ;
		}
		
		if (GSMC=="") {
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			$("#GSMC").focus();
			return;
		}
		var tel =  /^(1)[0-9]{10}$/;
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (nnm.test(GSMC)||Fw.util.proofTest.proolEmoji(GSMC)) {
			Fw.Form.showPinLabel($(this), "公司名称不能含有非法字符!", true);
			$("#GSMC").focus();
			return;
		}
		// 检查账户类型是否选择
		if (!$("#JBH").is(":checked") && !$("#YBH").is(":checked")) {
			Fw.Form.showPinLabel($(this), "请选择账户类型!", true);
			return;
		}
		if ($("#BGDZ").val() == "手动输入") {
			if (XXDZ == "") {
				Fw.Form.showPinLabel($(this), "请输入详细地址!", true);
				$("#XXDZ").focus();
				return;
			} 
		}
		if (nnm.test(BGDZ)||Fw.util.proofTest.proolEmoji(BGDZ)) {
			Fw.Form.showPinLabel($(this), "办公地址不能含有非法字符!", true);
			$("#XXDZ").focus();
			return;
		}
		if (mobile1.length != "11"||mobile1 == "") {
			Fw.Form.showPinLabel($(this), "请输入正确法人手机号!", true);
			$("#SJ1").focus();
			return;
		}
		if (!tel.test(mobile1)) {
			Fw.Form.showPinLabel($(this), "请输入正确法人手机号!", true);
			$("#SJ1").focus();
			return;
		}
		if (name == ""||name.length<'2') {
			Fw.Form.showPinLabel($(this), "请输入财务负责人姓名", true);
			$("#XM").focus();
			return;
		}
		if (nnm.test(name)||Fw.util.proofTest.proolEmoji(name)) {
			Fw.Form.showPinLabel($(this), "财务负责人姓名含有非法字符!", true);
			$("#XM").focus();
			return;
		}
		if (mobile2.length != "11"||mobile2=="") {
			Fw.Form.showPinLabel($(this), "请输入正确财务负责人手机号!", true);
			$("#SJ2").focus();
			return;
		}
		if (!tel.test(mobile2)) {
			Fw.Form.showPinLabel($(this), "请输入正确财务负责人手机号!", true);
			$("#SJ2").focus();
			return;
		}
		if (!$("#xieyi").is(":checked")) {
			Fw.Form.showPinLabel($(this), "请勾选同意协议!", true);
			return;
		}
		var params = {
			operatorPhone : App.data.acctApplyInfo.operatorPhone,
			firmName:GSMC,
			firmAddr : BGDZ,
			acctProperty : ZHLX,
			legalPhone : mobile1,
			financeMan : name,
			financePhone : mobile2,
			applyInfoSerial : ""+App.data.acctApplyInfo.applyInfoSerial,
			step:"2"
		}
		Fw.Layer.openWaitPanel(); //开启等待层
		var url = YT.dataUrlWeb("private/acctApply");
		YT.ajaxDataWeb(url, params, function(data) {
			
			if (data.STATUS == "1") {
//				var cc=sessionStorage.getItem("firmId");
//				alert(cc)
				//alert(YT.JsonToStr(data));
				Fw.redirect("1060803.html", data);
				
				} else {
					Fw.Layer.hideWaitPanel(); //关闭等待层
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
			}
		});

	}

};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);