/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.flag = true;
		App.initEvent();
		Fw.Layer.hideWaitPanel(); 
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		//查看申请进度
		App.pageA.on("click", "#ck", App.ckAccount);
	},
	 /**
	  * 查看申请进度
	  */
	ckAccount:function(){
		var params={
				 operatorPhone:App.data.acctApplyInfo.operatorPhone ,
				 applyInfoSerial:App.data.acctApplyInfo.applyInfoSerial+'',
				 type:'2'
		 }
		Fw.Layer.openWaitPanel(); 
		 var url = YT.dataUrlWeb("private/findApplyProgress"); 
		 YT.ajaxDataWeb(url,params , function(data) {
			 if (data.STATUS == "1") {
				if(data.acctApplyList!=null){
					 Fw.redirect("1060806.html",data);
				}else{
					Fw.Layer.hideWaitPanel(); 
					Fw.Form.showPinLabel($(this), "暂无申情记录!", true);
					 return; 
				}
				 
			 }else{
				 Fw.Layer.hideWaitPanel(); 
				 Fw.Form.showPinLabel($(this), data.MSG, true);
				 return; 
			 }
			 
		 });
		//Fw.redirect("1060807.html");
	 }
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);