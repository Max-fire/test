/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		//YT.showPageArea(App.pageA, [], true);
		App.flag = false;
		App.initEvent();
		Fw.Layer.hideWaitPanel(); //关闭等待层
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 兴业管家
		App.pageA.on("click", "#XYGJ", App.initXYGJ);
		// 银企对账
		App.pageA.on("click", "#YQDZ", App.initYQDZ);
		// 回单服务
		App.pageA.on("click", "#HDFW", App.initHDFW);
		// 精灵信使
		App.pageA.on("click", "#JLXS", App.initJLXS);
		
		// 查看详细协议内容
		App.pageA.on("click", "#xygj1", App.gotoXYGJ);
		App.pageA.on("click", "#jlxs1", App.gotoJLXS);
		App.pageA.on("click", "#hdfw1", App.gotoHDFW);
		App.pageA.on("click", "#yqdz1", App.gotoYQDZ);
		
		//black背景
		App.pageA.on("click", "#black_b", App.initBLACK);
		// 上一步
		App.pageA.on("click", "#btnTop", App.gotoTop);
		// 下一步
		App.pageA.on("click", "#btnNext", App.gotoNext);
		
		
	},
	/**
	 * 兴业管家
	 */
	initXYGJ:function(){
		$("#black_b").css("display","");
		$("#white_x").css("display","");
		
	},
	/**
	 * 兴业管家服务协议内容 
	 */
	gotoXYGJ:function(){
		Fw.Layer.openWaitPanel(); 
		Fw.redirect("1060804_XYGJ.html",App.data);
	},
	/**
	 * 银企对账
	 */
	initYQDZ:function(){
		$("#black_b").css("display","");
		$("#white_y").css("display","");
	},
	/**
	 * 银企对账服务协议内容 
	 */
	gotoYQDZ:function(){
		Fw.Layer.openWaitPanel(); 
		Fw.redirect("1060804_YQDZ.html",App.data);
	},
	/**
	 * 回单服务
	 */
	initHDFW:function(){
		$("#black_b").css("display","");
		$("#white_h").css("display","");
	},
	/**
	 * 回单服务服务协议内容 
	 */
	gotoHDFW:function(){
		//Fw.redirect("1060804_HDFW.html",App.data);
	},
	/**
	 * 精灵信使
	 */
	initJLXS:function(){
		$("#black_b").css("display","");
		$("#white_j").css("display","");
	},
	/**
	 * 精灵信使服务协议内容 
	 */
	gotoJLXS:function(){
		Fw.Layer.openWaitPanel(); 
		Fw.redirect("1060804_JLXS.html",App.data);
	},
	/**
	 * 所有弹出层消失 
	 */
	initBLACK:function(){
		$("#black_b").css("display","none");
		$("#white_x").css("display","none");
		$("#white_y").css("display","none");
		$("#white_h").css("display","none");
		$("#white_j").css("display","none");
	},
	/**
	 * 上一步
	 */
	gotoTop:function(){
		Fw.Layer.openWaitPanel(); 
		Fw.redirect("1060803.html",App.data);
	},
	/**
	 * 提交
	 */
	gotoNext:function(){
		
		if (!$("#ty").is(":checked")) {
			Fw.Form.showPinLabel($(this), "请勾选同意协议!", true);
			return;
		}
		if ( App.flag ) {
			Fw.Form.showPinLabel($(this), "请勿重复提交!", true);
			return;
		}
		if(App.data && App.data.submit){
			Fw.Form.showPinLabel($(this), "请勿重复提交!", true);
			return;
		}
		App.data.acctApplyInfo.step='4';
		App.data.acctApplyInfo.applyTime=Fw.util.Format.fmtTrsCreDate(App.data.acctApplyInfo.applyTime,"yyyy-MM-dd");
		App.data.acctApplyInfo.applyInfoSerial+="";
		App.data.acctApplyInfo.org=sessionStorage.getItem("org");
		if (sessionStorage.getItem("inviteCode")) {
			App.data.acctApplyInfo.inviteCode=sessionStorage.getItem("inviteCode");
		}
		App.flag=true;
		Fw.Layer.openWaitPanel(); 
				var url = YT.dataUrlWeb("private/acctApply");
				YT.ajaxDataWeb(url, App.data.acctApplyInfo, function(data) {
					if (data.STATUS == "1") {
						App.data.submit="1";//已提交状态判断
						Fw.redirect("1060805.html",App.data);
					}else{
						App.flag=false;
						Fw.Layer.hideWaitPanel(); 
						Fw.Form.showPinLabel($(this), data.MSG, true);
						return;
					}
			});
		
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);