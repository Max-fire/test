/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.flag = false;
		App.brCode="";
		App.orgCode="";
		//开户分行查询
		App.initKHZH();
		App.initEvent();
		//alert(sessionStorage.getItem("org"));
		Fw.Layer.hideWaitPanel(); //关闭等待层
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 我知道了点击事件
		App.pageA.on("click", "#iknow", App.initWhite);
		// 查看申请进度
		App.pageA.on("click", "#ck", App.ckAccount);
		// 检查姓名
		 App.pageA.on("blur", "#name", App.checkName);
		 App.pageA.on("click", "#name", App.checkName1);
		// 动态校验姓名位数
		App.pageA.on("input","#name",App.checkNameNum);
		App.pageA.on("porpertychanger","#name",App.checkNameNum);
			
		// 开户支行-事件
		//App.pageA.on("click", "#KHZH", App.initKHZH);
		App.pageA.on("change", "#KHZH", App.initKHZH1);
		// 开户网点-事件
		//App.pageA.on("click", "#KHWD", App.initKHWD);
		App.pageA.on("change", "#KHWD", App.initKHWD1);
		// 下一步
		App.pageA.on("click", "#btnSubmit1", App.next);
		// 失去焦点去空格
		App.pageA.on("blur", "#mobile", App.removeKong);
		
		App.pageA.on("click", "#yzm", App.toYZM);
		
		App.pageA.on("click", "#selspan", App.alinfo);
		if (App.func("inviteCode")) {
			sessionStorage.setItem("inviteCode", App.func("inviteCode"));
		}
		
	},
	/**
	 * 初始化页面(上个页面传送过来)
	 */
	initPage : function() {
		// 初始化时间插件
		var date = (new Date()).format("yyyy-MM-dd hh:mm:ss");
		$(function() {
			$("#YYSJ").jeDate({
				format : "YYYY-MM-DD",
				isTime : true,
				isToday : true,
				// festival:true,
				// skinCell:'jedatered',
				minDate : $.nowDate(0),
				maxDate : $.nowDate(10)
			});
		});

		// 首次進入有提示，再次無
		if (App.data && App.data.acctApplyInfo) {
			// 页面赋值
			$("#name").val(App.data.acctApplyInfo.operatorName);
			$("#mobile").val(App.data.acctApplyInfo.operatorPhone);
			App.orgCode = App.data.acctApplyInfo.applyOrgCode;
			App.brCode = App.data.acctApplyInfo.applyAreaCode;
			$("#YYSJ").val(
					Fw.util.Format.fmtTrsCreDate(
							App.data.acctApplyInfo.applyTime, "yyyy-MM-dd"));
			$("#name").blur();
			// 页面加载完成后初始化开户网点
			$("#KHWD").removeClass("hidden");//span select状态切换用于解决安卓部分不适配
			$("#selspan").addClass("hidden");
			App.initKHWD();
			if (sessionStorage.getItem("org")) {
				//console.log("有缓存且sessionStorage中有org不为空和 null");
				org = sessionStorage.getItem("org");
				App.initOrgPage(org);
			}

		} else {
			// 显示提示
			$("#black_b").css("display", "");
			$("#white_b").css("display", "");

			// 取sessionStorage中org,有--》没退出浏览器，无--》首次进入前处理
			if (sessionStorage.getItem("org") && sessionStorage.getItem("org")!="0") {
				var org = sessionStorage.getItem("org");
				//console.log("首次进入检查sessionStorage中org,含有执行（包含进入界面进来,第一次查询错误的session中org）");
				App.initOrgPage(org);
			} else {
				//---.html?org=11051的形式取值
				if (App.func("org", window.location.href) == null) {
					//console.log('首次进入且找不到org，兴业管家微信公众号进入方式');
					org = "";
					sessionStorage.setItem("org", "")
					$("#KHZH").removeAttr("disabled");
					$("#KHWD").removeAttr("disabled");
					$("#KHWD").addClass("hidden");
					$("#selspan").removeClass("hidden");

				} else {
					//console.log("首次进入，无sessionStorage org,取org下表检查");
					App.initIndexorgPage();
				}

			}
		}

	},
	/**
	 * session方式匹配org
	 */
	initOrgPage : function(org) {
		// 事件不能点击
		$("#KHZH").attr("disabled", "disabled");
		$("#KHWD").removeClass("hidden");
		$("#selspan").addClass("hidden");
		$("#KHWD").attr("disabled", "disabled");
		
		// 匹配分行网点信息
		App.initOrgKHWD(org);
	},
	/**
	 * 取下标方式匹配org 
	 */
	initIndexorgPage : function() {
		// 点击事件关闭
		$("#KHZH").attr("disabled", "disabled");
		$("#KHWD").removeClass("hidden");
		$("#selspan").addClass("hidden");
		$("#KHWD").attr("disabled", "disabled");

		// org 长度判断
		org = App.func("org", window.location.href);
		if (org.length != "5") {
			App.brCode = ""
			App.orgCode = ""
			sessionStorage.setItem("org", "0");
			alert('网点信息有误，请联系网点核实！')
			return;
		}
		// 匹配分行网点信息
		App.initOrgKHWD(org);
		
	},
	/**
	 * 匹配开户网点 
	 */
	initOrgKHWD:function(org){
		// 匹配分行网点信息
		for ( var j = 0; j < App.khfh.brList.length; j++) {
			if (App.khfh.brList[j].brCode == org.substring(0, 2)) {
				App.brCode = App.khfh.brList[j].brCode;
				//console.log("App.brCode:" + App.brCode);
				var html = '<option selected="selected" >'
						+ App.khfh.brList[j].brName + '</option>';
				$("#KHZH").html("");
				$("#KHZH").append(html);
				break;
			}
		}
		if (App.brCode == "") {
			sessionStorage.setItem("org", "0");
			alert('网点信息有误，请联系网点核实！')
			return;
		}
		// 匹配网点
		var params = {
			brCode : App.brCode,
			type : "2"
		};
		var url = YT.dataUrlWeb("private/branchInfo");
		YT.ajaxDataWeb(url, params, function(data) {
			if (data.STATUS == "1") {
				for ( var i = 0; i < data.orgList.length; i++) {
					if (data.orgList[i].orgCode == org.substring(2, 5)) {
						App.orgCode = data.orgList[i].orgCode;
						//console.log("App.orgCode:" + App.orgCode);
						var html = '<option selected="selected" >'
								+ data.orgList[i].orgName + '</option>';
						$("#KHWD").html("");
						$("#KHWD").append(html);
						break;
					}
				}
				if (App.orgCode == "") {
					sessionStorage.setItem("org", "0");
					alert('网点信息有误，请联系网点核实！')
					return;
				}
				sessionStorage.setItem("org", org);
			} else {
				Fw.Layer.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});
	},
	/**
	 * 检查姓名位数 
	 */
	checkNameNum:function(){
		var w=0;//字节数
		var name=$("#name").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>30){
				name=name.substring(0,i);
				$("#name").val(name);
				$("#name").blur();
				break;
			}
		}
		if(sessionStorage.getItem("org")=="0"){
			alert('网点信息有误，请联系网点核实！')
			return;
		}
	},
	/**
	 * 检查姓名合法性 
	 */
	checkName:function(){
		var name = $("#name").val();
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (name == "") {
			Fw.Form.showPinLabel($(this), "姓名不能为空!", true);
			return;
		}
		if (nnm.test(name)||Fw.util.proofTest.proolEmoji(name)) {
			Fw.Form.showPinLabel($(this), "姓名不能含有非法字符!", true);
			return;
		}
		$("#name").css("text-align","right");
	},
	checkName1:function(){
		$("#name").css("text-align","left");
	},
	/**
	 * 
	 */
	removeKong:function(){
		var mobile = $("#mobile").val().replace(/ /g,"");
		 $("#mobile").val(mobile);
		 if(sessionStorage.getItem("org")=="0"){
				alert('网点信息有误，请联系网点核实！')
				return;
		 }
	},
	/**
	 * 显示层消失 
	 */
	initWhite : function() {
		$("#black_b").css("display", "none");
		$("#white_b").css("display", "none");
	},
	/**
	 * 查看申请进度
	 */
	ckAccount : function() {
		Fw.redirect("1060807.html", "");
	},
	/**
	 * 选择开户地区(分行)
	 */
	initKHZH : function() {
		var html = "";
		var url = YT.dataUrlWeb("private/branchInfo");
		var params = {
			type : "1"
		};
		YT.ajaxDataWeb(url,params,	function(data) {
			App.khfh=data;//开户分行赋值用于org参数存在判断
			if (data.STATUS == "1") {
				html+='<option selected="selected" >请选择</option>';
				for ( var i = 0; i < data.brList.length; i++) {
					if (App.data && App.data.acctApplyInfo) {
						if (App.data.acctApplyInfo.applyAreaCode==data.brList[i].brCode) {
							html+='<option id="opt'+i+'" selected="selected" data-value="'+data.brList[i].brCode+'">'+data.brList[i].brName+'</option>';
						}else{
							html+='<option id="opt'+i+'" data-value="'+data.brList[i].brCode+'">'+data.brList[i].brName+'</option>';
						}
					}else{
						
						html+='<option id="opt'+i+'" data-value="'+data.brList[i].brCode+'">'+data.brList[i].brName+'</option>';
					}
				}
				$("#KHZH").html("");
				$("#KHZH").append(html);
				App.initPage();
				} else {
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
					}
		});

	},
	initKHZH1:function(){
		if($("#KHZH option:selected").val()!="请选择"){
			var optid=$("#KHZH option:selected").attr("id");
			App.brCode=$("#"+optid+"").attr("data-value");
			if (App.data && App.data.acctApplyInfo) {
				if( $("#KHZH option:selected").val() == App.data.acctApplyInfo.applyAreaName){
					App.orgCode= App.data.acctApplyInfo.applyOrgCode ;
				}else{
					App.orgCode= "";
				}
			}else{
				App.orgCode= "";
			}
			$("#KHWD").removeClass("hidden");
			$("#selspan").addClass("hidden");
			App.initKHWD();
		}else{
			App.brCode="";
			App.orgCode="";
			$("#KHWD").addClass("hidden");
			$("#selspan").removeClass("hidden");
			App.pageA.on("click","#selspan",App.alinfo);
		}
		
	},
	alinfo:function(){
		Fw.Form.showPinLabel($(this), "请选择开户分行!", true);
		return;
	},
	/**
	 * 选择开户网点
	 */
	initKHWD : function() {
		
		if(!sessionStorage.getItem("org")){
			if(App.brCode==""){
				Fw.Form.showPinLabel($(this), "请选择开户分行!", true);
				return;
			}
		}
		Fw.Layer.openWaitPanel();
		var url = YT.dataUrlWeb("private/branchInfo");
		var params = {
			brCode : App.brCode,
			type : "2"
		}
		var html="";
		var j=0;
		YT.ajaxDataWeb(url,params,function(data) {
			if (data.STATUS == "1") {
				html+='<option selected="selected" >请选择</option>';
				for ( var i = 0; i < data.orgList.length; i++) {
					if (App.data && App.data.acctApplyInfo) {
						if (App.data.acctApplyInfo.applyOrgCode==data.orgList[i].orgCode) {
							html+='<option id="khwd'+i+'" selected="selected" data-value="'+data.orgList[i].orgCode+'">'+data.orgList[i].orgName+'</option>';
						}else{
							html+='<option id="khwd'+i+'" data-value="'+data.orgList[i].orgCode+'">'+data.orgList[i].orgName+'</option>';
						}
					}else{
						
						html+='<option id="khwd'+i+'" data-value="'+data.orgList[i].orgCode+'">'+data.orgList[i].orgName+'</option>';
					}
					j++;
				}
				if (j==data.orgList.length) {
					Fw.Layer.hideWaitPanel();
				}
					$("#KHWD").html("");
					$("#KHWD").append(html);
					Fw.Layer.hideWaitPanel();

			} else {
				Fw.Layer.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			 	}
		});

	},
	/**
	 *开户网点点击事件 
	 */
	initKHWD1 : function() {
		if($("#KHWD option:selected").val()!="请选择"){
			var optid=$("#KHWD option:selected").attr("id");
			App.orgCode=$("#"+optid+"").attr("data-value");
		}else{
			App.orgCode="";
		}
	},
	/**
	 * 下一步
	 */
	next : function() {
		if(sessionStorage.getItem("org")=="0"){
			alert('网点信息有误，请联系网点核实！')
			return;
	 }
		var name = $("#name").val().replace(/(^\s*)|(\s*$)/g,"");
		var mobile = $("#mobile").val().replace(/ /g,"");
		// alert(mobile);
		var KHZH = $("#KHZH option:selected").val();
		var KHWD = $("#KHWD option:selected").val();
		var time = $("#YYSJ").val();
		var code = $("#meg_code").val();
		var tel =  /^(1)[0-9]{10}$/;
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (name == ""||name.length<'2') {
			Fw.Form.showPinLabel($(this), "请输入正确姓名!", true);
			$("#name").focus();
			return;
		}
		if (nnm.test(name)||Fw.util.proofTest.proolEmoji(name)) {
			Fw.Form.showPinLabel($(this), "姓名不能含有非法字符!", true);
			$("#name").focus();
			return;
		}
		if (mobile == "" || mobile.length != '11') {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			$("#mobile").focus();
			return;
		}
		if (!tel.test(mobile)) {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			$("#mobile").focus();
			return;
		}
		if (KHZH == "请选择") {
			Fw.Form.showPinLabel($(this), "请选择开户分行!", true);
			return;
		}
		if ($("#KHWD").hasClass("hidden") || KHWD=="请选择") {
			Fw.Form.showPinLabel($(this), "请选择开户网点!", true);
			return;
		}
		
		if (time == "") {
			Fw.Form.showPinLabel($(this), "请选择预约时间!", true);
			return;
		}
		 
		if (code == "") {
			Fw.Form.showPinLabel($(this), "验证码不能为空!", true);
			$("#meg_code").focus();
			return;
		}
		if (code.length != '6') {
			Fw.Form.showPinLabel($(this), "验证码必须为6位!", true);
			$("#meg_code").focus();
			return;
		}
		 var num=/[0-9]{6}/;
		 if (!num.test($("#meg_code").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		var params = {
			operatorName : name,
			operatorPhone : mobile,
			applyAreaCode : App.brCode,
			applyAreaName : KHZH,
			applyOrgCode : App.orgCode,
			applyOrgName : KHWD,
			applyTime : time,
			MSG : code,
			step : "1"
		}

		if(App.data!= null&&App.data.acctApplyInfo!=null){
			//alert("1");
			if(App.data.acctApplyInfo.applyInfoSerial!=null){
				params.applyInfoSerial=App.data.acctApplyInfo.applyInfoSerial+"";
				if(App.data.acctApplyInfo.operatorPhone!=mobile){
					delete params.applyInfoSerial;
					
				}
			}
			
		}
		var url = YT.dataUrlWeb("private/acctApply");
		Fw.Layer.openWaitPanel();  	//等待层开启
		YT.ajaxDataWeb(url, params, function(data) {
			if (data.STATUS == "1") {
					  Fw.redirect("1060802.html", data);
				  }
			else {
				Fw.Layer.hideWaitPanel(); //关闭等待层
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});

	},
	
	
	toYZM:function(){
		App.timer=60;
		App._initTime = new Date().getTime()-1000;
		App._sumTime = 60;
		var tel =  /^(1)[0-9]{10}$/;
		 if (!tel.test( $("#mobile").val())|| $("#mobile").val() == "" ||  $("#mobile").val().length != "11") {
			 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			 return;
		 }
		var param={
				mobile : $("#mobile").val(),
				type : "6"
		}
		
		 App._startTimerListener();
		 var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
			var html="已向手机"+phone+"发送短信验证码，请注意查收";
			$("#yzm").val("");
			var url = YT.dataUrlWeb('normal/tr3888.json');
			YT.ajaxDataWeb(url, param, function(rsp){
				if(rsp.STATUS == '1'){
					callback && callback();
				}else{
					Fw.Form.showPinLabel($(this), rsp.MSG, true);
					return;
					//YT.alertinfo(rsp.MSG);
				}
			},function(data){
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
				//YT.alertinfo(data.MSG);
				
			});
	},
	/**
	 * 打开短信验证码计时器
	 */
	_startTimerListener: function(){
		if(App.timer > 0){
			var time = App._getTimer();
			App.timer = App._sumTime - time;
			if(App.timer>0){
				$("#yzm").text(App.timer + '秒后重发');
				$("#yzm").attr("disabled", true);
			}else{
				App._closeTimerListener();
				return;
			}
		}else{
			App._closeTimerListener();
			return;
		}
		App.intervalID = setTimeout("App._startTimerListener()", 1000);
	},
	_getTimer:function(){
		var time = new Date().getTime();
		return Math.floor((time-App._initTime)/1000);
	},
	
	/**
	 * 清除计时器
	 * @param id
	 */
	_closeTimerListener: function(){
		if(App.intervalID){ // 当intervalID存在时，清空
			clearTimeout(App.intervalID);
			$("#yzm").removeAttr("disabled");//启用按钮
            $("#yzm").text("重新获取");
            App.timer = 60;
            App.intervalID = null;
		}
	}
	

};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);