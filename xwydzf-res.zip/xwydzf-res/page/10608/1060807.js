/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.flag = true;
		App.initEvent();
		App.timer=60;
		App.intervalID="";
		Fw.Layer.hideWaitPanel(); 
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		//申请预约开户
		App.pageA.on("click", "#sq", App.sqAccount);
		//查询申请进度
		App.pageA.on("click", "#btnCheck", App.toCheck);
		
		App.pageA.on("click", "#yzm", App.toYZM);
		
		
	},

	/**
	 * 申请预约开户
	 */
	sqAccount:function(){
		Fw.Layer.openWaitPanel(); 
		Fw.redirect("1060801.html");
	 },
	 /**
	  * 查询申请进度
	  */
	 toCheck:function(){
		 var tel =  /^(1)[0-9]{10}$/;
		 if($("#mobile").val()=="" ||　$("#mobile").val().length!="11" || !tel.test($("#mobile").val())){
			 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			 $("#mobile").focus();
				return;
		 }
		 if($("#code").val()=="" || $("#code").val().length!="6"){
			 Fw.Form.showPinLabel($(this), "请输入6位验证码!", true);
			 $("#code").focus();
				return;
		 }
		 var num=/[0-9]{6}/;
		 if (!num.test($("#code").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		 var params={
				 operatorPhone: $("#mobile").val(),
				 MSG:$("#code").val(),
				 type:'1'
		 }
		 Fw.Layer.openWaitPanel(); 
		 var url = YT.dataUrlWeb("private/findApplyProgress"); 
		 YT.ajaxDataWeb(url,params , function(data) {
			 if (data.STATUS == "1") {
				if(data.acctApplyList!=null){
					 Fw.redirect("1060806.html",data);
				}else{
					Fw.Layer.hideWaitPanel(); 
					Fw.Form.showPinLabel($(this), "暂无申情记录", true);
					 return; 
				}
				 
			 }else{
				 Fw.Layer.hideWaitPanel(); 
				 Fw.Form.showPinLabel($(this), data.MSG, true);
				 return; 
			 }
			 
		 });
		
	 },
		toYZM:function(){
			App.timer=60;
			App._initTime = new Date().getTime()-1000;
			App._sumTime = 60;
			var tel =  /^(1)[0-9]{10}$/;
			 if (!tel.test( $("#mobile").val())|| $("#mobile").val() == "" ||  $("#mobile").val().length != "11") {
				 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
				 return;
			 }
			var param={
					mobile : $("#mobile").val(),
					type : "5"
			}
			
			 App._startTimerListener();
			 var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
				var html="已向手机"+phone+"发送短信验证码，请注意查收";
				$("#yzm").val("");
				var url = YT.dataUrlWeb('normal/tr3888.json');
				YT.ajaxDataWeb(url, param, function(rsp){
					if(rsp.STATUS == '1'){
						callback && callback();
					}else{
						Fw.Form.showPinLabel($(this), rsp.MSG, true);
						return;
						//YT.alertinfo(rsp.MSG);
					}
				},function(data){
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
					//YT.alertinfo(data.MSG);
					
				});
		},
		/**
		 * 打开短信验证码计时器
		 */
		_startTimerListener: function(){
			if(App.timer > 0){
				var time = App._getTimer();
				App.timer = App._sumTime - time;
				if(App.timer>0){
					$("#yzm").text(App.timer + '秒后重发');
					$("#yzm").attr("disabled", true);
				}else{
					App._closeTimerListener();
					return;
				}
			}else{
				App._closeTimerListener();
				return;
			}
			App.intervalID = setTimeout("App._startTimerListener()", 1000);
		},
		_getTimer:function(){
			var time = new Date().getTime();
			return Math.floor((time-App._initTime)/1000);
		},
		
		/**
		 * 清除计时器
		 * @param id
		 */
		_closeTimerListener: function(){
			if(App.intervalID){ // 当intervalID存在时，清空
				clearTimeout(App.intervalID);
				$("#yzm").removeAttr("disabled");//启用按钮
	            $("#yzm").text("重新获取");
	            App.timer = 60;
	            App.intervalID = null;
			}
		}		
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);