/**
 * 创建应用
 * @author lixiang
 */
var App = {
	init : function(require){
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 加载数据
	 */
	initEvent : function() {
		App.pageA.on("click", "#back", App.back);
	},
	/**
	 * 返回服务页面
	 */
	back:function(){
		Fw.Layer.openWaitPanel(); 
		Fw.redirect("1060804.html",App.data);
	}
	
};
	/**
	 * 页面加载完，加载
	 */
	Fw.onReady(App);