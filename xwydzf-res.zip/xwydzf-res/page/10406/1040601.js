var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		Fw.Client.initPageTitle("#pageA");
		App.data = Fw.getParameters();
		Fw.Client.openWaitPanel();
		App.initPageA();
		if(App.data){
			App.initDataA();
		}else{
			App.findInfo();
		}
	},
	fmtAcc:function(){
		var elem=document.getElementById("card");
		var pos=elem.selectionStart;
		if (elem.setSelectionRange) {
			setTimeout(function(){
				var card= Fw.util.Format.removeSpace($("#card").val());
				$("#card").val(Fw.util.Format.fmtAcctNo(card));
				if ($("#card").val().length>pos+2) {
					elem.setSelectionRange(pos,pos);
				}
				elem.focus();
			},0);
		}else if (elem.createTextRange) {
			var textRange=elem.createTextRange();
			textRange.moveStart("character",elem.value.length);
			textRange.moveEnd("character",0);
			textRange.select();
		}
		$("#toBank").val("");
		$("#img").html("");
		$("#toBank").attr("style","");
		$("#toBankId").val("");
		App.onCheckA();
	},
	/**
	 * 初始化事件
	 * 
	 */
	initPageA:function(){
		App.pageA.on("click","#SKYH",App.onBank);
		App.pageA.on("porpertychanger", "#card", App.fmtAcc);
		App.pageA.on("input", "#card", App.fmtAcc);
		App.pageA.on("click","#btnSubmit1",App.toSubmit1);
		App.pageA.on("click","#sk",App.toScanCard);
	},
	/**
	 * 加载pageA数据
	 * */
	initDataA:function(){
			var html="";
			$("#card").val(App.data.fmtCard);
			$("#name").html(App.data.userName);
			if (App.data.idType=="0") {
				$("#zjlx").html("身份证");
			}else if(App.data.idType=="7"||App.data.idType=="9"){
				$("#zjlx").html("护照");
			}else{
				$("#zjlx").html("其他");
			}
			$("#sfzhm").html(Fw.util.Format.account(App.data.idNo));
			$("#ylsjh").val(App.data.mobile);
			$("#toBank").val(App.data.bankName);
			$("#toBankId").val(App.data.payBankCode);
			if (App.data.payBankCode) {
				html='<img src="../../css/bank_logo/'+App.data.payBankCode+'.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" style="position: absolute;top: 5px;height:32px;width:32px;left: 95px;">';
				$("#img").html(html);
				$("#toBank").attr("style","padding-left: 115px;");
			}
			YT.showPageArea(App.pageA, null, true);
			Fw.Client.hideWaitPanel();
			App.onCheckA();
	},
	/**
	 * 查询用户信息
	 */
	findInfo:function(){
		var url = YT.dataUrl("private/findUserInfo");
		YT.ajaxData(url,{},App.success,App.fail);
	},
	/**
	 * 扫卡识别
	 */
	toScanCard:function(){
		Fw.Client.openWaitPanel();
		Fw.Client.ScanCard("App.ScanCard");
	},
	ScanCard:function(card){
		var card=card;
		$("#card").val("");
		$("#toBank").val("");
		$("#img").html("");
		$("#toBank").attr("style","");
		$("#toBankId").val("");
		$("#card").val(Fw.util.Format.fmtAcctNo(card));
		$("#card").blur();
		App.onBank();
	},
	/**
	 * 成功函数
	 */
	success:function(data){
		if(data.STATUS=="1"){
			App.data=data;
			$("#name").html(App.data.userName);
			if (App.data.idType=="0") {
				$("#zjlx").html("身份证");
			}else if(App.data.idType=="7"||App.data.idType=="9"){
				$("#zjlx").html("护照");
			}else{
				$("#zjlx").html("其他");
			}
			$("#sfzhm").html(Fw.util.Format.account(App.data.idNo));
			$("#ylsjh").val(App.data.mobile);
			YT.showPageArea(App.pageA, null, true);
			Fw.Client.hideWaitPanel();
		}else{
			Fw.Client.alertinfo(data.MSG,"消息提示","App.toBackA()");
		}
	},
	/**
	 * 失败返回
	 */
	failBack:function(){
		Fw.Client.changePage("1040600.html","");
	},
	/**
	 * 失败函数
	 */
	fail:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	
	/**
	 * 校验pageA填写完整
	 */
	onCheckA:function(){
		if($("#toBank").val().trim()!=""&&$("#card").val().trim()!=""){
			$("#btnSubmit1").removeAttr("disabled","");
		}else{
			$("#btnSubmit1").attr("disabled","disabled");
		}
	},
	/**
	 * 下一步
	 */
	toSubmit1:function(){
		var card = Fw.util.Format.removeSpace($("#card").val());
		 var tel =  /^(1)[0-9]{10}$/;
         if (!tel.test($("#ylsjh").val())) {
        	 Fw.Form.showPinLabel($(this), "请输入正确手机号", true);
 			return;
         }
		if (card.trim() == "") {
			Fw.Form.showPinLabel($(this), "请输入银行卡号", true);
			return;
		}
		if ($("#toBank").val() == "") {
			Fw.Form.showPinLabel($(this), "请选择归属银行", true);
			return;
		}
		var reg = /^[1-9][0-9]*$/.test(card);
		if(!reg){
			Fw.Form.showPinLabel($(this), "银行卡号不合法", true);
			return;
		}
		if (card.length <16||card.length>20) {
			Fw.Form.showPinLabel($(this), "请输入正确卡号", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var json = {
				card       :card,
				fmtCard    :$("#card").val(),
				bankName  :$("#toBank").val(),
				userName   :App.data.userName,
				idType     :App.data.idType,
				idNo       :App.data.idNo,
				mobile     :$("#ylsjh").val(),
				payBankCode:$("#toBankId").val()
		};
		var url = YT.dataUrl("private/checkMobile");
		var param={
				cardNo:card,
				mobile:$("#ylsjh").val(),
				payBankCode:$("#toBankId").val()
		};
		YT.ajaxData(url,param,function(data){
			if (data.STATUS=="1") {
				Fw.redirect("1040603.html",json);
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
			Fw.Client.hideWaitPanel();
		},function(data){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
		});
	},
	/**
	 * 选择银行
	 */
	onBank:function(){
		var url = YT.dataUrl("private/findBankInfo");
		var html="";
		var card= Fw.util.Format.removeSpace($("#card").val());
		if (card.trim() == "") {
			Fw.Form.showPinLabel($(this), "请输入银行卡号", true);
			return;
		}
		var reg = /^[1-9][0-9]*$/.test(card);
		if(!reg){
			Fw.Form.showPinLabel($(this), "银行卡号不合法", true);
			return;
		}
		if (card.length <16||card.length>20) {
			Fw.Form.showPinLabel($(this), "请输入正确卡号", true);
			return;
		}
		Fw.Client.openWaitPanel();
			YT.ajaxData(url,{cardNo:card},function(data){
				if(data.STATUS=="1"){
					if(data.bankName){
						$("#toBankId").val(data.payBankCode);
						$("#toBank").val(data.bankName);
						html='<img src="../../css/bank_logo/'+data.payBankCode+'.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" style="position: absolute;top: 5px;height:32px;width:32px;left: 95px;">';
						$("#img").html(html);
						$("#toBank").attr("style","padding-left: 115px;");
						App.onCheckA();
						Fw.Client.hideWaitPanel();
					}else{
						App.onSelct();
					}
				}else{
					Fw.Client.alertinfo(data.MSG,"消息提示");
					Fw.Client.hideWaitPanel();
				}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"消息提示","App.toBackA()");
			});
	},
	onSelct:function(){
		var json = {
				card       :$("#card").val(),
				fmtCard    :$("#card").val(),
				bankName  :$("#toBank").val(),
				userName   :App.data.userName,
				idType     :App.data.idType,
				idNo       :App.data.idNo,
				mobile     :$("#ylsjh").val(),
				payBankCode:$("#toBankId").val()
		};
		Fw.redirect("1040602.html",json);
	},
	/**
	 *返回前一页 
	 */
	toBackA:function(){
		Fw.Client.changePage("1040600.html","");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);