/**
 * 创建应用
 * 
 * @author cjh
 */
var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		datas:{},
	/**
	 * 初始化 应用入口
	 */
	init : function() {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		if(!App.data){
			Fw.Client.openWaitPanel();
		}
		App.attch = new Array();
		App.attchList = new Array();
		App.i=0;
		App.initEvent();
	},
	initEvent:function(){
		var width=(document.body.clientWidth-144)/2;
		$("#gdx1").attr("style","width:"+width+"px;");
		$("#gdx").attr("style","width:"+width+"px;");
		var url = YT.dataUrl("private/getTaskDetail");
		var params = {
				trsNo:App.func("trsNo"),
				trsType:"1"
		};
		if(App.data){
			App.showDatas(App.data);
			App.showChuli(App.data);
		}else{
			YT.ajaxData(url,params,function(data){
				if(data.STATUS == "1"){
					App.data = data;
					App.showDatas(data);
					App.showChuli(data);
				}
			});
		}
		App.pageA.on("click","#zmx",App.changeMX);
		App.pageA.on("click","#cmx",App.changeMX);
		App.pageA.on("click","#smx",App.changeMX);
		//再次汇款
		App.pageA.on("click","#btnSubmit",App.toZCHK);
		//查看凭证
		App.pageA.on("click","#ckpz",App.toCKPZ);
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});	
	},
	//撤销操作
	onTJ:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/transferCancel");
		var json = {
				trsNo:App.func("trsNo"),
				type:"2",
		};
		YT.ajaxData(url,json,function(data){
			if(data.STATUS == "1"){
				Fw.Client.alertinfo(data.MSG,"消息提示","App.goTask()");
				Fw.Client.hideWaitPanel();
	    	}else{
	    		Fw.Client.alertinfo(data.MSG,"消息提示","App.goTask()");
	    		Fw.Client.hideWaitPanel();
	    	}
		});
	},
	//查看凭证
	toCKPZ:function(){
		App.data.trsDate=App.trsDate;
		App.data.page="../10406/det15B.html?trsStatus=1&trsNo="+App.func("trsNo")+"";
		Fw.redirect("../10401/1040115.html", App.data);
	},
	goTask:function(){
		var json = {
				trsStatus:"1",
		}
		Fw.redirect("../10401/1040105.html",json);
	},
	/**
	 * 跳转明细页面
	 */
	changeMX:function(){
		App.data.no = "det15B";
		App.data.refuse = App.refuse;
		Fw.redirect('1040608.html?trsNo='+App.func("trsNo")+'&trsStatus='+App.func("trsStatus")+'&canBack='+App.func("canBack")+"",App.data);
	},
	//再次汇款----------------------------
	toZCHK:function(){
		var params={
				trsNo:App.func("trsNo"),
				type: "0"
		};
		if(App.data){
			params.trsNo=App.data.trsNo;
		}
		App.data.trsNo=params.trsNo;
		var url = YT.dataUrl("private/batchTransferAgain");
	    YT.ajaxData(url,params,function(data){
	    	if(data.STATUS=="1"){
	    	App.data.back="15B";
	    	if(data.userPcList.length!='0'){
	    		App.data.userPcList=data.userPcList;
	    		Fw.redirect("../10406/1040607.html?dealUser=1&trsStatus="+App.func('trsStatus')+"",App.data);
	    	}else{
	    		Fw.Form.showPinLabel($(this), "收款信息非有效，已被删除", true);
	    		App.data.userPcList=data.userPcList;
	    		setTimeout(function(){
	    			Fw.redirect("../10406/1040607.html?dealUser=1&trsStatus="+App.func('trsStatus')+"",App.data);
	    		},800);
	    	}
	    	}else{
	    		Fw.Form.showPinLabel($(this),data.MSG, true);
				return false;
	    	}
	    	})
		},
	showDatas:function(data){
		//判断是否有隐藏明细标志 
		if(data.readFlag=="1"){
			$("#zmx").addClass("hidden");
		}else{
			$("#zmx").removeClass("hidden");
		}
		if(App.func("trsStatus") == "1"){
			App.trsDate=data.dealLog[0].dealTime;
			if(data.isShield&&data.isShield=="0"){
				$("#TJ").removeClass("hidden");
			}
			$(".yui-hide").removeClass("hidden");
			$("#sjz").removeClass("hidden");
			if (data.dealLog[0].dealType=="2") {
				$("#ckpz").removeClass("hidden");
			}
			//判断落地审核
			if (data.audite && data.audite=="YES") {
				//未审核
				if (data.auditeStatus=="1") {
					$("#clz").html("待银行审核");
					$("#wczt").html("处理中");
					$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
				}else{
					//已审核
					//判断处理状态
					if(data.btStatus=="2"){
						$("#clz").html("银行已审核");
						$("#SB").removeClass("hidden");
						$("#CG").removeClass("hidden");
						$("#ccbs").removeClass("hidden");
						$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
						$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
						$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf");
						$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc1");
						if(data.dealLog[0].dealType=="4"||data.dealLog[0].dealType=="3"||data.failCount==data.count){
							$("#wczt").html("汇款失败");
							$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc3");
						}else if (data.succCount != data.count) {
							$("#wczt").html("部分成功");
						}
						$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.auditeTime,"MM-dd HH:mm:ss"));
						$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.btTime,"MM-dd HH:mm:ss"));
					}else{
						$("#clz").html("银行已审核");
						$("#wczt").html("处理中");
						$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
						$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
						$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swcl");
						$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf");
						$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.auditeTime,"MM-dd HH:mm:ss"));
					}
				}
			}else{
				$("#clz").html("待银行处理");
				$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
				$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
				//判断处理状态
				if(data.btStatus=="2"){
					$("#clz").html("银行已处理");
					$("#SB").removeClass("hidden");
					$("#CG").removeClass("hidden");
					$("#ccbs").removeClass("hidden");
					$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
					$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf");
					$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc1");
					if(data.dealLog[0].dealType=="4"||data.dealLog[0].dealType=="3"||data.failCount==data.count){
						$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc3");
						$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf").attr("style","color:#e61920;text-align: right;");
						$("#wczt").html("汇款失败");
					}else if (data.succCount != data.count) {
						$("#wczt").html("部分成功");
					}
					$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.btTime,"MM-dd HH:mm:ss"));
					$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.btTime,"MM-dd HH:mm:ss"));
				}else{
					$("#wczt").html("处理中");
				}
			}
			$('#hkzh').html(Fw.util.Format.account(data.trsTrsfr[0].fromAcctNo));
			$('#tjsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
			if(data.succCount==0){
				$("#cgbs").addClass("hidden");
				$("#dh").addClass("hidden");
				$("#CG").addClass("hidden");
			}
			if(data.failCount==0){
				$("#sbbs").addClass("hidden");
				$("#dh").addClass("hidden");
				$("#SB").addClass("hidden");
			}
			if(data.succCount==0&&data.failCount==0){
				$("#SB").addClass("hidden");
				$("#CG").addClass("hidden");
				$("#ccbs").addClass("hidden");
			}
		}else if (App.func("trsStatus") == "2") {
			if(data.isShield&&data.isShield=="0"){
				$("#pageA").attr("data-btnRight","true|修改|App.toZCHK()");
			}else{
				$("#pageA").attr("data-btnRight","false");
			}
		}
		if (data.trsTrsfr[0].expectedDate) {
			if(data.trsInfo[0].readFlag && data.trsInfo[0].readFlag=="1"){
	  			$('#hklx').html( "员工汇款（次日到账,屏蔽明细）");
	  		}else{
	  			$('#hklx').html( "员工汇款（次日到账）");
	  		}
		}else{
			if(data.trsInfo[0].readFlag && data.trsInfo[0].readFlag=="1"){
	  			$('#hklx').html( "员工汇款（屏蔽明细）");
	  		}else{
	  			$('#hklx').html( "员工汇款");
	  		}
		}
		$('#trsNo').html(Fw.util.Format.subTrsNo(data.trsNo));
		$('#hkje').html(Fw.util.Format.fmtAmt(data.amount+'')+"元");
		$('#cgje').html(Fw.util.Format.fmtAmt(data.succAmount+'')+"元");
		$('#sbje').html(Fw.util.Format.fmtAmt(data.failAmount+'')+"元");
		$('#bs').html(data.count+"笔");
		$('#cgbs').html("成功"+data.succCount+"笔");
		$('#sbbs').html("失败"+data.failCount+"笔");
		$('#memo').html(data.trsTrsfr[0].memo);
		App.attach_url = data.attach_url;
		App.showFj(data.attach);
		if (data.canBack=="1") {
			$("#pageA").attr("data-btnRight","true|撤销|App.onTJ()");
		}
		YT.showPageArea(App.pageA, [], true);
	},
	
	/**
	 * 显示附件
	 */
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},
	/**
	 * 加载处理意见
	 */
	showChuli:function( d ){
 		var html='',html1='',html2='';
 		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else if item.dealType == 2}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
				 						'</div>',
				 						'{@else if item.dealType == 3}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey ">撤　销</div>',
				 						'</div>',
				 						'{@else if item.dealType == 4}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="../../css/img/XTtouxiang.png" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey ">拒　绝</div>',
				 						'</div>',	
					 				'{@/if}',
					 					'{@if item.dealType == 4}',
					 					'<div class="ui_01_div4">系统用户</div>',
					 					'{@else}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@/if}',
					 					'{@if item.dealType == 3}',
					 					'<div class="ui-bg-ss2">',
					 					　'该笔汇款已撤销',
							 				'</div>',
					 					'{@/if}',
					 					'{@if item.dealMsg}',
					 						'{@if item.dealType == 4}',
							 				'<div class="ui-bg-ss2">',
							 					　'拒绝原因:&nbsp;&nbsp;${item.dealMsg}',
							 				'</div>',	 
							 				'{@else}',
							 				'<div class="ui-bg-ss2">',
						 					　	'${item.dealMsg}',
						 					 '</div>',	 
							 				'{@/if}',	 
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			Fw.Client.hideWaitPanel();
			
	},
	
	toBack:function(){
		var json = {
				trsStatus:"1"
		};
		Fw.redirect("../10401/1040105.html?trsStatus="+App.func("trsStatus")+"",json);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);