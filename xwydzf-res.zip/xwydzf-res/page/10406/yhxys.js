var App = {
		init:function(){
			App.pageA = $("#pageA");
			App.data = Fw.getParameters();
			App.func = window['_getParameter'];
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA, [], true);
		},
		toBack:function(){
				Fw.redirect(App.func("No")+".html?",App.data);
		}
};
Fw.onReady(App);