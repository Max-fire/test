var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function() {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		YT.showPageArea(App.pageA, [], true);
		Fw.Client.hideWaitPanel();
		App.initEvent();
		App.flag="all";
		App.query(App.flag);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		$('#qb').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current yui-current').siblings().removeClass('current yui-current');
			$('#bs1').removeClass("hidden");
			$('#bs2').addClass("hidden");
			$('#bs3').addClass("hidden");
			$('#bs4').addClass("hidden");
			App.flag="all";
			App.query(App.flag);
		})
		$('#cg').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current yui-current').siblings().removeClass('current yui-current');
			$('#bs2').removeClass("hidden");
			$('#bs1').addClass("hidden");
			$('#bs3').addClass("hidden");
			$('#bs4').addClass("hidden");
			App.flag="success";;
			App.query(App.flag);
		})
		$('#sb').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current yui-current').siblings().removeClass('current yui-current');
			$('#bs3').removeClass("hidden");
			$('#bs2').addClass("hidden");
			$('#bs1').addClass("hidden");
			$('#bs4').addClass("hidden");
			App.flag="failer";
			App.query(App.flag);
		})
		$('#clzA').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current yui-current').siblings().removeClass('current yui-current');
			$('#bs4').removeClass("hidden");
			$('#bs2').addClass("hidden");
			$('#bs3').addClass("hidden");
			$('#bs1').addClass("hidden");
			App.flag="deal";
			App.query(App.flag);
		})
	},
	query : function(flag) {
		//初始化笔数
		$('#amount').html("");
		if(flag=="all"){
			$('#amount').html(Fw.util.Format.fmtAmt(App.data.amount+"")+"元");
		  	$('#bs').html("共"+App.data.count+"笔");
		}else if(flag=="success"){
			$('#amount').html(Fw.util.Format.fmtAmt(App.data.succAmount+"")+"元");
		  	$('#cbs').html("共"+App.data.succCount+"笔");
		}else if(flag=="failer"){
			$('#amount').html(Fw.util.Format.fmtAmt(App.data.failAmount+"")+"元");
		  	$('#sbs').html("共"+App.data.failCount+"笔");
		}else{
			if(App.data.trsInfo[0].trsStatus=="1"){
				$('#amount').html(Fw.util.Format.fmtAmt((App.data.amount-App.data.succAmount-App.data.failAmount)+"")+"元");
				$('#clz').html("共"+(App.data.count-App.data.succCount-App.data.failCount)+"笔");
			}else{
				$('#amount').html(Fw.util.Format.fmtAmt(0+"")+"元");
				$('#clz').html("共"+0+"笔");
			}
		}
		var json = {
			trsNo:App.func("trsNo"),
			statu :flag
		};
		var html = "";
		html+='<div class="yui-cui-pd yui-yghk-list-xq" style="color: #666;">';
		html+='<div class="yui-grk_flex1A">';
		html+='{@if item.trsfrStatus==1 }';
		html+='	<img src="../../css/bank_logo/${ item.toBrCode}.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" style="padding-top: 32px;" class="yui-cui-yhtbA">';
		html+='{@else if item.trsfrStatus==3 }';
		html+='	<img src="../../css/bank_logo/${ item.toBrCode}.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" class="yui-cui-yhtbA">';
		html+='{@else if item.trsfrStatus !=0}';
		html+='	<img src="../../css/bank_logo/${ item.toBrCode}.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" class="yui-cui-yhtb">';
		html+='{@/if}';
		html+='	<div style="font-size: 12px;padding-left: 14px;color:#999999;padding-top: 0px;">${item.toBankName}</div>';
		html+='	</div>';
		html+='	<div class="yui-grk_flex4">';
		html+='	<div class="ui-form-item yui-det-item-cui-yg">';
		html+='	  	<label>收款户名:</label>';
		html+='			<div  style="padding-left:75px ;">${item.toAcctName}</div>';
		html+='	</div>';
		html+='	<div class="ui-form-item yui-det-item-cui-yg">';
		html+='	    <label>收款账号:</label>';
		html+='		    <div  style="padding-left:75px ;">${item.toAcctNo}</div>';
		html+='	</div>';
		html+='	<div class="ui-form-item yui-det-item-cui-yg">';
		html+='	  	<label>汇款金额:</label>';
		html+='		<div  style="padding-left:75px ;">${item.amount.toString()|fmtAmt}元</div>';
		html+='	</div>	';
		if(App.data.trsInfo[0].trsStatus=="1"){
			html+='<div class="ui-form-item yui-det-item-cui-yg">';
			html+='	<label>汇款状态:</label>';
			html+='{@if item.trsfrStatus==3 }';
			html+='	<div style="padding-left:75px;color: #32AC1F;">成功</div>';
			html+='{@else if item.trsfrStatus==1 }';
			html+='	<div style="padding-left:75px;color: #fb1b1b;">失败</div>';
			html+='{@else if item.trsfrStatus}';
			html+='	<div style="padding-left:75px;color: #478aee;">处理中</div>';
			html+='{@/if}';
			html+='</div>';
			html+='{@if item.trsfrStatus==1 }';
			html+='	<div class="ui-form-item yui-det-item-cui-yg">';
			html+='	    <label>失败原因:</label>';
			html+='{@if item.msg}';
			html+='<div  style="padding-left:75px ;">${item.msg}</div>';
			html+='{@else if item.msg }';
			html+='<div  style="padding-left:75px ;"></div>';
			html+='{@/if}';
			html+='	</div>';
			html+='{@/if}';
		}
		html+='</div>';
		html+='<div style="clear: both;"></div>';
		html+='</div>';
		var url = YT.dataUrl("private/getTransDetail");
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "datas",
			page : true,
			pageSize : 10,
			disclosure : true,
			ajax : {
				url : url,
				params : json
			},
			itemTpl : html,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(App.trsStatus);
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		var page = pageIndex || 1;
		Fw.Client.hideWaitPanel();
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	
	fmtCard:function(a){
		var b = "**** **** **** **** "+a.substring(a.length-4,a.length);
		return b;
	},
	toBack:function(){
		Fw.redirect(App.data.no+'.html?trsNo='+App.func("trsNo")+'&trsStatus='+App.func("trsStatus")+'&trsId='+App.func("trsId")+'&canBack='+App.func("canBack")+"",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);