/**
 * 创建应用
 * @author 
 */
var App = {
	requires : ['Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
			Fw.Client.hideWaitPanel();
			App.func = window['_getParameter'];
			App.pageA = $("#pageA");
			YT.showPageArea(App.pageA, null, true);
			App.data = Fw.getParameters();
			App.flag = false;
			App.attach = new Array();
			App.next="0";
			App.initEvent();
			$("#purpose").val(App.data.purpose);
			$("#purpose").blur();
			//点击协议跳转数据处理
			if(!App.func('back')){
					App.initCY();
			}else{
				App.datas = new Array();
				App.datas=App.data.zh;
				$("#fromAcctNo").val(App.data.fromAcctNo);
				$("#KYYE").html(App.data.KYYE);
				$("#fromAcctName").val(App.data.fromAcctName);
				if(App.data.sta=="1"){
					$("#XieYi").attr("checked","checked");
				}else{
					$("#XieYi").removeAttr("checked");
				}
				App.onKeypress();
			}
			App.zydh=App.data.zydh;
			if(App.zydh=='006'){
				$("#ZYType").html("代发工资");
			}else if(App.zydh=='022'){
				$("#ZYType").html("奖金");
			}else if(App.zydh=='023'){
				$("#ZYType").html("津贴");
			}else if(App.zydh=='047'){
				$("#ZYType").html("福利");
			}else if(App.zydh=='048'){
				$("#ZYType").html("费用报销");
			}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("input","#fromAcctName",App.onKeypress);
		App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
		App.pageA.on("input","#purpose",App.onKeypress);
		App.pageA.on("porpertychanger","#purpose",App.onKeypress);
		App.pageA.on("click", "#btnSubmit", App.onNext);
		App.pageA.on("click", "#HKZH", App.initZH);
		App.pageA.on("click", "#clickXY", App.clickXY);
		
		
	},
	clickXY:function(){
		//alert($("#fromAcctNo").val()+$("#KYYE").html()+$("#fromAcctName").val());
		App.data.fromAcctNo=$("#fromAcctNo").val();
		App.data.KYYE=$("#KYYE").html();
		App.data.fromAcctName=$("#fromAcctName").val();
		App.data.zh=App.datas;
		if($("#XieYi:checked").val()==null){
			App.data.sta="0";
		}else{
			App.data.sta="1";
		}
		Fw.redirect("../10406/xys.html?trsNo="+App.func('trsNo')+"&amount="+App.func('amount')+"&trsId="+""+
			"&toAcctNo="+App.func('toAcctNo')+"&dealMsg="+""+"&count="+App.func('count')+"",App.data);
		
	},
	/**
	 * 汇款账户
	 */
	initCY : function() {
		Fw.Client.openWaitPanel("提交中...");
		var url = YT.dataUrl("private/findAcctList");
		YT.ajaxData(url, {}, function(data) {
			if (data.STATUS == "1") {
				App.datas = new Array();
				for ( var i = 0; i < data.datels.length; i++) {
					App.datas.push({
						account : data.datels[i].account.acctNo,
						balance : data.datels[i].response.kyye,
						accountName:data.datels[i].response.khmc
					});
				}
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});
	},
	/**
	 * 显示账户
	 */
	initZH : function() {
		var json = {
				jsonArray : App.datas,
				"func" : "App.showCommonlyUsedAccount"
			};
		Fw.Client.hideWaitPanel();
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	
	/**
	 * 账户回显
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		App.flag = false;
		var balance = parseFloat(balances);
		$("#fromAcctNo").val(account);
		$("#KYYE").html("可用余额" + balance + "元");
		$("#fromAcctName").val(name);
		Fw.Client.hideWaitPanel();
		App.onKeypress();
	},
	/**
	 * 判断是否信息都填写完整
	 */
	onKeypress : function() {
		var SKR = $("#fromAcctName").val().trim();
		var YT = $("#purpose").val().trim();
		var SKZH = $("#fromAcctNo").val().trim();
		App.data.purpose=$("#purpose").val().trim();
		if (SKR != "" && YT != "" && SKZH !="" ) {
			$("#btnSubmit").removeAttr("disabled", "");
		} else {
			$("#btnSubmit").attr("disabled", "disabled");
		};
	},
	signFirm:function(){
			App.flag = true;
			Fw.Client.openWaitPanel("提交中...");
			var json = {
					func : "App.initComplete",
					funcAndroid:"App.initCompleteAndroid",
					type : "2",
					toName:App.data.toAcctName,//收款人名称
					toAcc:App.func("toAcctNo"),//收款账号
					fromName:$("#fromAcctName").val(),//付款名称
					fromAcc:$("#fromAcctNo").val(),//付款账号
					purpose:$("#purpose").val(),//用途
					xmlMoney:Fw.util.Format.replaceDouble("2",App.func("amount")),//金额
					xmlNo:App.func("trsNO")//流水账号
				};
			//alert(YT.JsonToStr(json));
			Fw.Client.hideWaitPanel();
			Fw.Client.showBB(json);
			App.flag = false;
		
	},
	/**
	 * 下一步事务提交
	 */
	onNext : function() {
		var purpose = $("#purpose").val();
		if(Fw.util.proofTest.proolEmoji(purpose)){
			Fw.Form.showPinLabel($(this), "付款用途包含特殊字符", true);
			return;
		};
		if($("#XieYi:checked").val()==null){
			Fw.Form.showPinLabel($(this), "请勾选电子代发协议", true);
			return;
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		Fw.Client.openWaitPanel("提交中...");
		//判断付款账户状态（1604接口）
		var url = YT.dataUrl("private/signFirmAcct");
		var params = {
				fromAcctNo:$("#fromAcctNo").val()
		};
		if(App.next=="0"){
			//防止重复提交
			App.next="1";
			YT.ajaxData(url, params, function(data) {
				if(data.STATUS=="1"){
					App.signFirm();
				}else{
					App.next="0";
					Fw.Client.alertinfo(data.MSG, "消息提示");
					return;
				}
			});
		}
		App.next="0";
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.pageA.off("input","#fromAcctName",App.onKeypress);
		App.pageA.off("porpertychanger","#fromAcctName",App.onKeypress);
		App.pageA.off("input","#purpose",App.onKeypress);
		App.pageA.off("porpertychanger","#purpose",App.onKeypress);
		App.pageA.off("click", "#HKZH", App.initZH);
		$("#btnSubmit").attr("disabled","disabled");
		var fromAcctNo = $("#fromAcctNo").val();
		var fromAcctName = $("#fromAcctName").val();
		var purpose = $("#purpose").val();
		if(fromAcctNo.trim() == ""){
			Fw.Form.showPinLabel($(this), "请选择付款账号", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款户名
		if(fromAcctName.trim()== ""){
			Fw.Form.showPinLabel($(this), "请填写付款款户名", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款用途
		if(purpose.trim() == ""){
			Fw.Form.showPinLabel($(this), "请输入付款用途", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		App.flag = false;
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
		App.pageA.off("input","#fromAcctName",App.onKeypress);
		App.pageA.off("porpertychanger","#fromAcctName",App.onKeypress);
		App.pageA.off("input","#purpose",App.onKeypress);
		App.pageA.off("porpertychanger","#purpose",App.onKeypress);
		App.pageA.off("click", "#HKZH", App.initZH);
		$("#btnSubmit").attr("disabled","disabled");
		if(fromAcctNo.trim() == ""){
			Fw.Form.showPinLabel($(this), "请选择付款账号", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款户名
		if(fromAcctName.trim()== ""){
			Fw.Form.showPinLabel($(this), "请填写付款款户名", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款用途
		if(purpose.trim() == ""){
			Fw.Form.showPinLabel($(this), "请输入付款用途", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		App.flag = false;
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	/**
	 * 直接办结
	 */
	initBJ:function(a,b,frAcctNo,frAcctName,ppose){
			var fromAcctNo = frAcctNo;
			var fromAcctName = frAcctName;
			var purpose = ppose;
			App.trsNo = App.func("trsNo");
			var params = {
				type:"2",
				trsNo : App.trsNo,
				fromAcctNo : fromAcctNo,
				fromAcctName : fromAcctName,
				fromBankName : "兴业银行",
				memo:purpose,
				purpose : purpose,
				zydh:App.zydh,
				signData:a,
				signSrc:b,
				dealMsg:decodeURI(App.func("dealMsg")),
				amount:Fw.util.Format.replaceDouble("2",App.func("amount")),
				count:App.func("count")
			};
			
			Fw.Client.openWaitPanel();
			var url = "private/traditionalTransfer.json";
			Fw.Client.post(url,params,"App.success","App.failuri");
			
	},
	/**
	 * 直接办结成功回调函数
	 */
	success:function(data){
		
			if (data.STATUS == "1") {
				if(App.data.FileUrl){
					var url = YT.dataUrl("private/oprtFile");
					var params = {
						trsNo : App.data.trsNo,
						FileUrl : App.data.FileUrl,
						FileNameList : App.data.FileNameList
					};
					YT.ajaxData(url, params, function(success) {});
				}
				
				var json = {
						trsType : "1",
						trsNo : App.func("trsNo"),
						trsId:App.func("trsId"),
						trsDate:data.trsDate
					};
				App.json = json;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.successBack()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示","App.initFail()");
			}
	},
	/**
	 * 办结成功返回
	 */
	successBack:function(){
		
		Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
		Fw.redirect("../10401/1040115.html", App.json);
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 * 转账失败回到待办列表
	 */
	initFail: function(){
		var json = {
				trsStatus:"0"
		};
		if(App.func("trsId") == ""){
			Fw.redirect("../10401/1040105.html", json);
		}else{
			Fw.Client.dealMessage("1",App.func("trsId"),App.trsNo);
		}
		
	},
	/**
	 * 返回待办列表
	 */
	gotoBackTest:function(){
		if(App.func("trsId") == ""||App.func("trsId")=="null"||App.func("trsId")==null){
			Fw.Client.changePage("../10401/1040105.html","0");
		}else{
			Fw.Client.dealMessage("1",App.func("trsId"),App.trsNo);
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
