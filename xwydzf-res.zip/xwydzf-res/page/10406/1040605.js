/**
 * 创建应用
 * 
 * @author wangjx
 * 
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.data = Fw.getParameters("_parameters");
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		YT.showPageArea(App.pageA, [App.pageB], true);
		App.query('qb');
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		$('#qb').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current').siblings().removeClass('current');
			App.query('qb');
		})
		$('#zc').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current').siblings().removeClass('current');
			App.query('zc');
		})
		$('#sr').on('click',function(){
			Fw.Client.openWaitPanel();
			$(this).addClass('current').siblings().removeClass('current');
			App.query('sr');
		})
	},
	/**
	 * 加载数据
	 */
	query:function( typ ){
		Fw.Client.openWaitPanel();
		var jdbj = "2";
		var tpl = '<div class="ui-list ui-list-text ui-border-t">'+
						'<div class="ui-list-item-link" style="padding:10px 0">'+
							'<div class="ui-list-info" style="width:100%">'+
								'<h4 class="yui-pl15"><b>${item.wlzhmc}</b></h4>'+
								'<p style="margin-top:10px"><span class="yui-span-img16"></span>&nbsp;<span>${item.jyrq|fmtYear} ${item.jysj|fmtDate}</span>'+
								'<span class="ui-txt-highlight" style="float:right; padding-right:15px;">${item.jdbj|fmtJDBJ}${item.jyje.toString()|fmtAmt}</span></p>'+
							'</div>'+
						'</div>'+
					'</div>';
		if(typ == "qb"){
			jdbj = "2";
		}
		if(typ == "zc"){
			jdbj = "0";
		}
		if(typ == "sr"){
			jdbj = "1";
		}
		
		var beginTime = App.data.beginTime;
		var endTime = App.data.endTime;
		var acctount = App.data.acctId;
		var Month = "";
		var date = "";
		var test = new Date();
		if((test.getMonth()+1) < 10){
			Month = "-0"+(test.getMonth()+1);
		}else{
			Month = "-"+(test.getMonth()+1);
		}
		if(test.getDate() < 10){
			date = "-0"+test.getDate();
		}else{
			date = "-"+test.getDate();
		}
		var time = test.getFullYear() + Month + date;
		var json = {
				"zhdh" : acctount,
				"jdbj" : jdbj,
				"qsrq":beginTime,
				"zzrq":endTime
			};
		var url = YT.dataUrl("normal/Tr8922");
		var listView = new Fw.ListView({
				contentEl : 'list',
				dataField : "items",
				page : true,
				pageSize:10,
				disclosure : true,
				ajax : {
					url : url,
					params : json
				},
				itemTpl : tpl,
			});
			// 自定义分页识别
			listView.custFunc4NextPage = App.hasNextPage1;
			//判断是否有历史数据
			listView.lishi = App.lishishuju;
			// 选中记录时触发
			listView.on('itemtap', App.showDetail, this);
			// 数据加载后触发
			listView.ajax.on('LoadTest', App.onLoad, this);
			// 加载数据
			listView.loadData(typ);
	},
	/**
	 * 是否查询历史
	 * 
	 */
	lishishuju:function(res){
		return res;
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage1 : function(rst, pageIndex) {
		Fw.Client.hideWaitPanel();
		var page = pageIndex || 1;
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 详情数据
	 */
	/**
	 * 详情数据
	 */
	showDetail:function(record,i,el,e,list){
		var d=record;
		var bj = '+';
		var sz = '收入';
		var sfkr = '付&nbsp;&nbsp;款&nbsp;&nbsp;人';
		var zhanghao = '付款账号';
		var yinhang = '付款银行';
		var rqsj = d.jyrq.substr(0,4)+'-'+d.jyrq.substr(4,2)+'-'+d.jyrq.substr(6,2)+' '+d.jysj.substr(0,2)+':'+d.jysj.substr(2 ,2);
		if(d.jdbj=='0'){
			bj = '-';
			sz = '支出';
			sfkr = '收&nbsp;&nbsp;款&nbsp;&nbsp;人';
			zhanghao = '收款账号';
			yinhang = '收款银行';
		}
		
		App.pageB.find('#sz').html( sz );
		App.pageB.find('#je').html( bj + Fw.util.Format.fmtAmt(d.jyje.toString()));
		App.pageB.find('#lx').html( d.wlzhmc);
		App.pageB.find('#sj').val(rqsj);
		
		
		App.pageB.find('#sfkr').html(sfkr);
		App.pageB.find('#skr').html(d.wlzhmc);
		
		
		App.pageB.find('#zhanghao').html(zhanghao);
		App.pageB.find('#skzh').html(d.dfzh);
		
		
		App.pageB.find('#yinhang').html(yinhang);
		App.pageB.find('#skyh').html(d.xzfdfhm);
		
		
		App.pageB.find('#ye').val( Fw.util.Format.fmtAmt(d.zhye.toString()));
		App.pageB.find('#bz').html(d.yt);
		App.pageB.find('#zysm').html(d.zysm);
		YT.showPageArea(App.pageB, [App.pageA], true);
	},
	/**
	 * 返回账户详情页面
	 */
	backPageA : function() {
		YT.showPageArea(App.pageA, [ App.pageB ], true);
		App.pageB.find('#sz').html( '' );
		App.pageB.find('#je').html( '');
		App.pageB.find('#sj').val('');
		App.pageB.find('#ye').val( '');
		App.pageB.find('#bz').html('');
		App.pageB.find('#skr').html("");
		App.pageB.find('#skzh').html("");
		App.pageB.find('#skyh').html("");
		App.pageB.find('#zysm').html("");
	},
	gotoPage:function(){
		Fw.redirect("1040604.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);