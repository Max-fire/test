var App = {
	/**
	 * 初始化 应用入口
	 */
	init:function() {
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		Fw.Client.initPageTitle("#pageA");
		App.initEvent();
		//判断行内行外
		App.pdCard();
	},
	/**
	 * 判断是行内还是行外
	 */
	pdCard:function(){
		if(App.data.payBankCode=="309391000011"){
			App.flag="1";
			$("#code").removeClass("hidden");
			$("#qkmm").val(App.data.qkmm);
			$("#qkmm").attr("data-value",App.data.password);
			$("#meg_code").val(App.data.validCode);
		}else{
			App.flag="2";
			$("#meg_code").val(App.data.validCode);
			$("#code").addClass("hidden");
		}
		YT.showPageArea(App.pageA, [], true);
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		/**
		 * 获取验证码
		 */
		var card=App.data.card.substring(App.data.card.length-4,App.data.card.length);
		var params = {
				"type":"2",
				"mobile":App.data.mobile,
				"cardNo":card
		};
		Fw.util.Format.openTimerListener("yzm",params);
		App.pageA.on("click","#qkmm",App.showPwdPicker);
		App.pageA.on("click","#meg_code",App.showNumberPicker);
		App.pageA.on("click","#btnSubmit1",App.toSubmit1);
		App.pageA.on("click","#yhkxy",App.toXY);
		App.pageA.on("click","#wc",App.toWC);
	},
	/**
	 * 提交绑定
	 */
	toSubmit1:function(){
		if(App.flag=="1"){
			if($("#qkmm").val()==""){
				Fw.Form.showPinLabel($(this), "取款密码不能为空", true);
				return;
			}else if($("#qkmm").val().length!="6"){
				Fw.Form.showPinLabel($(this), "取款密码必须为6位", true);
				return;
			}
		}
		if($("#meg_code").val()==""){
			Fw.Form.showPinLabel($(this), "验证码不能为空", true);
			return;
		}
		if($("#meg_code").val().length!="6"){
			Fw.Form.showPinLabel($(this), "验证码必须为6位", true);
			return;
		}
		if($("#ty:checked").val()==null){
			Fw.Form.showPinLabel($(this), "请勾选银行卡使用协议", true);
			return;
		}
		Fw.Client.openWaitPanel();
		/*var url = YT.dataUrl("private/checkMsg");
		var params = {
				mobile    :App.data.mobile,
				MSG :$("#meg_code").val(),
		};
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				App.bindCardAuth();
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		});*/
		
		App.bindCardAuth();
	},
	/**
	 * 绑卡
	 */
	bindCardAuth:function(){
		var url = YT.dataUrl("private/bindCardAuth");
		var params = {
				mobile    :App.data.mobile,
				MSG :$("#meg_code").val(),
				cardNo    :App.data.card,
				userName  :App.data.userName,
				bankName  :App.data.bankName,
				payBankCode  :App.data.payBankCode,
				password  :$("#qkmm").attr("data-value"),
				idNo      :App.data.idNo,
				idType    :App.data.idType,
				flag      :App.flag
		};
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				var msg=""
				if (App.flag=="1") {
					 $("#black_b").removeClass("hidden");
						$("#white_b").removeClass("hidden");
						//静止滑动
						App.pageA.bind("touchmove",function(e){
							e.preventDefault();
						});
					 
				}else{
					 msg="认证过程需要几分钟，请您稍后进入个人账户查看结果。"
					 Fw.Client.alertinfo(msg,"提交成功","App.FailBack()");
				}
					Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		});
	},
	//行内成功
	toWC:function(){
		App.pageA.unbind("touchmove");
		$("#black_b").addClass("hidden");
		$("#white_b").addClass("hidden");
		//设置支付开关
		if ($("#inputCheckboxpay").is(":checked")) {
			var url = YT.dataUrl("private/cardPaySwitch");
			var params={
					cardNo:	App.data.card,
					authenticated : "1",
					switchStatus : "7"
			}
			YT.ajaxData(url,params,function(data){
				if (data.STATUS=="1") {
				Fw.Client.hideWaitPanel();
				}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			});
		}
		//设置工资卡
		if ($("#inputCheckbox").is(":checked")) {
			var url = YT.dataUrl("private/salaryCard");
			var param = {
					cardNo : App.data.card,
					flag : "1",
			};
			YT.ajaxData(url, param,function(data){
				if (data.STATUS == "1") {
					App.checkPerson("1");
				}else{
					Fw.Client.alertinfo(data.MSG,"消息提示","App.FailBack()");
				}
				Fw.Client.hideWaitPanel();
			},function(data){
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示");
			});
		}else{
			App.checkPerson("0");
		}
	},
	FailBack:function(){
		Fw.Client.changePage("1040600.html","");
	},
	/**
	 * 判断是否是必经人
	 */
	checkPerson:function(wageFlag){
		var url = YT.dataUrl("private/isApproval");
		YT.ajaxData(url,{trsType:"3"},function(Data){
			if(Data.IsApproval=="YES"){
				App.data.page="1040603"
				App.data.cardNo=App.data.card,
				Fw.redirect("1040610.html",App.data);
			}else{
				if (wageFlag=="1") {
					Fw.redirect("1040600.html","1040603");
				}else{
					Fw.Client.changePage("1040600.html","");
				}
			}
		})	
	},
	/**
	 * 数字键盘
	 */
	showNumberPicker:function(){
		Fw.Client.showNumberPicker($("#meg_code"))
	},
	/**
	 * 密码键盘
	 */
	showPwdPicker:function(){
		Fw.Client.showPwdPicker($("#qkmm"));
	},
	/**
	 * 银行卡使用协议
	 */
	toXY:function(){
		App.data.qkmm=$("#qkmm").val();
		App.data.password=$("#qkmm").attr("data-value");
		App.data.validCode=$("#meg_code").val();
		Fw.redirect("yhxys.html?No=1040603",App.data);
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		Fw.redirect("1040601.html",App.data);
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);