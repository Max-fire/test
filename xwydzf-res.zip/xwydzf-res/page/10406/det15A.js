/**
 * 创建应用
 * 
 * @author wangjx
 */

var App = {
	datas:{},
	attach_url:"",
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require){
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		if(!App.data){
			Fw.Client.openWaitPanel();
		}
		App.pageA = $("#pageA");
		App.showPageA();
		App.i=0;
		App.attch = new Array();
		App.attchList = new Array();
		App.initEvent();
		var json ={
				trsType:"1",
				trsNo:App.func("trsNo")
		};
		var url = YT.dataUrl("private/getTaskDetail");
		if(App.data){
			App.initBJRPD(App.data);
			App.showDatas(App.data);
			App.showChuli(App.data);
		}else{
			YT.ajaxData(url,json,function(data){
				if(data.STATUS == "1"){
					App.data = data;
					App.initBJRPD(data);
					App.showDatas(data);
					App.showChuli(data);
				}
			});
		}
	},
	// 显示pageA
	showPageA:function(){
		YT.showPageArea(App.pageA,[],true);
	},
	// 绑定事件
	initEvent:function(){
		// 办结
		App.pageA.on("click","#BJ",App.initBJ);
		// 转办
		App.pageA.on("click","#ZB",App.initZB);
		// 退回
		App.pageA.on("click","#TH",App.initTH);
		// 转办2
		App.pageA.on("click","#ZB2",App.initZB2);
		// 退回2
		App.pageA.on("click","#TH2",App.initTH2);
		// 选择审批人
		App.pageA.on("click","#XZSPR",App.initSPR);
		//明细
		App.pageA.on("click","#mx",App.changeMX);
		// 提交
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		// 处理按钮事件
	  	$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  	});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	/**
	 * 跳转明细页面
	 */
	changeMX:function(){
		App.data.no = "det15A";
		App.data.mx = "0";
		App.data.refuse="0";
		Fw.redirect('1040608.html?trsNo='+App.func("trsNo")+'&trsStatus='+App.func("trsStatus")+"",App.data);
	},
	/**
	 * 判断是否经过必经人
	 */
	initBJRPD: function(d){ 
  		if(d.trsInfo[0].hasOwnProperty("effectiveUserId")){
			App.showJGBJR();
		}else{
			var url = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "3",
					amount :$("#HKJE").html(),
					bizNo: "3",
					flag:"2"
			};
			YT.ajaxData(url,params,function(data){
				if(data.isEffective == "YES"){
					App.showJGBJR();
				}else{
					App.showWJGBJR();
				}
			});
		}
  	},
  	/**
	 * 未经过有效必经人
	 */
  	showWJGBJR:function(){
  		$("#JGSPR").addClass("hidden");
  		$("#WJGSPR").removeClass("hidden");
  	},
  	/**
	 * 经过有效必经人
	 */
  	showJGBJR:function(){
  		$("#WJGSPR").addClass("hidden");
  		$("#JGSPR").removeClass("hidden");
  	},
  	showDatas:function( data ){
  		App.dealUserId1 = data.trsInfo[0].dealUserId;
  		App.trsNo = data.trsNo;
  		$('#trsNo').html(Fw.util.Format.subTrsNo(data.trsNo));
	  	$('#amount').html(Fw.util.Format.fmtAmt(data.amount+'')+"元");
	  	$('#HKJE').html(data.amount);
	  	$('#bs').html(data.count+"笔");
	  	$('#memo').html(data.trsTrsfr[0].memo);
	  	//判断是否有隐藏明细标志 
	  	if(data.readFlag=="1"){
			$("#mx").addClass("hidden");
		}else{
			$("#mx").removeClass("hidden");
		}
	  	if (data.trsTrsfr[0].expectedDate) {
	  		if(data.trsInfo[0].readFlag && data.trsInfo[0].readFlag=="1"){
	  			$('#hklx').html( "员工汇款（次日到账,屏蔽明细）");
	  		}else{
	  			$('#hklx').html( "员工汇款（次日到账）");
	  		}
		}else{
			if(data.trsInfo[0].readFlag && data.trsInfo[0].readFlag=="1"){
	  			$('#hklx').html( "员工汇款（屏蔽明细）");
	  		}else{
	  			$('#hklx').html( "员工汇款");
	  		}
		}
	  	if(data.count<=1){
	  		App.toAcctName=data.trsTrsfr[0].toAcctName;
	  		App.toAcctNo=data.trsTrsfr[0].toAcctNo;
	  	}else{
	  		App.toAcctName=data.trsTrsfr[0].toAcctName+"等";
	  		App.toAcctNo=data.trsTrsfr[0].toAcctNo;
	  	}
  	},
  	
  	/**
	 * 加载处理意见
	 */
    showChuli:function( d ){
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
					 					'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			App.attach_url = d.attach_url;
			App.showFj(d.attach);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			
  },
	// 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},	
	// 办结
	initBJ: function(){
		$("#SPR").attr("hidden","");
		$("#hkzh").removeAttr("hidden","");
		$("#trsStatus").val("2");
	},
	// 转办
	initZB: function(){
		$("#SPR").removeAttr("hidden","");
		$("#hkzh").attr("hidden","");
		$("#trsStatus").val("1");
	},
	// 退回
	initTH: function(){
		$("#SPR").attr("hidden","");
		$("#hkzh").attr("hidden","");
		$("#trsStatus").val("0");
	},
	// 转办2
	initZB2: function(){
		$("#SPR").removeAttr("hidden","");
		$("#hkzh").attr("hidden","");
		$("#trsStatus").val("1");
	},
	// 退回2
	initTH2: function(){
		$("#SPR").attr("hidden","");
		$("#hkzh").attr("hidden","");
		$("#trsStatus").val("0");
	},
	// 选择审批人
	initSPR : function() {
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id,co) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 事务提交
	 */
	toSubmit:function(){
		App.dealMsg = $("#dealMsg").val().replace(/\s/g,"");
		if($("#trsStatus").val() == ""){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		if($("#trsStatus").val() == "1"){
			if($("#dealUserId").val()==""||$("#dealUserId").val()==null){
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
		}
		if($("#trsStatus").val() == "0"){
			if (App.dealMsg==null||App.dealMsg=="") {
				Fw.Form.showPinLabel($(this), "请输入审批意见", true);
				return;
			}
		}
		if(Fw.util.proofTest.proolEmoji(App.dealMsg)){
			Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
			return;
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel();
		if($("#trsStatus").val() == "0"){
			// 退回
			var url = YT.dataUrl("private/batchTransfer");
			var params =  {
					type:"4",
					trsNo:App.trsNo,
					dealMsg:App.dealMsg
			};
			YT.ajaxData(url, params, App.callbackTrsStatus);
		}
		
		if($("#trsStatus").val() == "1"){
			// 转办
			if(App.dealMsg!=""){
				App.dealMsg = App.dealMsg;
			}else{
				App.dealMsg="同意";
			}
			var  url = YT.dataUrl("private/batchTransfer");
			var params =  {
			 	type:"3",
				trsNo:App.trsNo,
				nextDealUserName:$("#dealUserName").val(),
				nextDealUserId:$("#dealUserId").val(),
				dealMsg:App.dealMsg,
				dealUserId:App.dealUserId1,
				amount : $("#HKJE").html()
			};
			YT.ajaxData(url, params, App.callback);
		}
		if($("#trsStatus").val() == "2"){
			//办结
			var url = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "3",
					amount : $("#HKJE").html(),
					bizNo: "3"
			};
			if(App.data.trsInfo[0].hasOwnProperty("effectiveUserId") && App.data.trsInfo[0].effectiveUserId.trim() != ""){
				params.flag = "1";   // 1.只查权限 2、是否是必经人
			}else{
				params.flag = "2";   // 1.只查权限 2、是否是必经人
			}
			YT.ajaxData(url,params,function(data){
				if(data.isAmount == "YES"){
					if(data.isEffective == "YES"){
						var dealMsg = $("#dealMsg").val();
						if(dealMsg){
							App.dealMsg = dealMsg;
						}else{
							App.dealMsg="同意";
						}
						App.onNext();
					}else{
						App.flag = false;
						Fw.Client.hideWaitPanel();
						Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
						return;
					}
				}else{
					App.flag = false;
					Fw.Client.hideWaitPanel();
					Fw.Form.showPinLabel($(this), "汇款金额不得大于渠道限额("+data.listAmount.toFixed(2)+")", true);
					return;
				}	
			});
		}
	},
	onNext:function(){
		var amount = Fw.util.Format.replaceDouble("1",$("#HKJE").html());
		var count=App.data.count;
		var purpose=$("#memo").html();
		var json = {
				"purpose":purpose,
				list:App.data.trsTrsfr,
				toAcctName:App.toAcctName
				};
		if(App.func("trsId")){
			Fw.redirect("../10401/1040609.html?trsNo="+App.trsNo+"&amount="+amount+"&trsId="+App.func("trsId")+
			"&toAcctNo="+App.toAcctNo+"&dealMsg="+App.dealMsg+"&count="+count+"",json);
		}else{
			Fw.redirect("../10401/1040609.html?trsNo="+App.trsNo+"&amount="+amount+"&trsId="+""+
			"&toAcctNo="+App.toAcctNo+"&dealMsg="+App.dealMsg+"&count="+count+"",json);
		}
	},
	
	callbackTrsStatus:function(data){
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已回退给发起人:"+data.creUserName,"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	// 成功后返回函数
	callback:function(data){
		 var url = YT.dataUrl("private/addLinkUser");
			YT.ajaxData(url,{userId:$("#dealUserId").val()},function(data){
			});
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人:"+$("#dealUserName").val(),"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	test:function(){
		Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
		Fw.Client.changePage("../10401/1040105.html?trsStatus="+App.func("trsStatus")+"","");
	},
	toBack:function(){
		var json = {
				trsStatus:"0"
		};
		Fw.redirect("../10401/1040105.html?trsStatus="+App.func("trsStatus")+"",json);
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);