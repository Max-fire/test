/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		Fw.Client.initPageTitle("#pageA");
		Fw.Client.openWaitPanel();
		App.i=0;
		App.initEvent();
		App.result = Fw.getParameters();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#add",App.add);
		var url = YT.dataUrl("private/findPersonalAcct");
		var params={};
	    YT.ajaxData(url,params,App.success,App.failuri);	
	},
	/**
	 * 成功回调函数
	 */
	success:function(data){
			if (data.STATUS == "1") {
	    		App.loadData(data);
			} else {
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}
			Fw.Client.hideWaitPanel();
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 加载数据
	 */
	loadData:function(data){
		App.data=data;
		var html="";
		var innerHtml="";
		var outHtml="";
		var notHtml="";
		if (data.innerList==null&&data.outList==null) {
			$("#noCard").removeClass("hidden")
		}else{
			var totalAmount=Fw.util.Format.fmtAmt(data.totalAmount+"");
			$("#zye").html(totalAmount);
			if (data.innerList!="") {
				var i=0;
				for ( var d in data.innerList) {
					html="";
					if (data.innerList[d].cardStatus!="2"&&data.innerList[d].cardStatus!="3"&&data.innerList[d].cardStatus!="4") {
						if (data.innerList[d].cardStatus=="0") {
							if (data.innerList[d].authenticated && data.innerList[d].authenticated == "6") {
								html+='<div class="yui-qb-unCardStyle" onclick="App.toHNXQ('+i+')">';
							}else{
								html+='<div class="yui-qb-cardStyle" onclick="App.toHNXQ('+i+')">';
							}
						}else{
							if (data.innerList[d].authenticated && data.innerList[d].authenticated == "6") {
								html+='<div class="yui-qb-unCardStyle">';
							}else{
								html+='<div class="yui-qb-cardStyle">';
							}
						}
						html+='<div style="line-height: 40px;">';
						if (data.innerList[d].authenticated && data.innerList[d].authenticated == "6") {
							html+='<img src="css/img/309391000011.png"  class="yui-qb-cardLogo" style="opacity: 0.5;">';
						}else{
							html+='<img src="css/img/309391000011.png" class="yui-qb-cardLogo">';
						}
						html+='<div class="yui-qb-bankName">兴业银行</div>';
						if (data.innerList[d].cardStatus=="1") {
							if (data.innerList[d].authenticated && data.innerList[d].authenticated == "6") {
								html+='<div style="float: right;">未认证</div>';
							}else{
								html+='<div style="float: right;">认证中</div>';
							}
						}
						html+='<div style="clear: both;"></div>';
						html+='</div>';
						html+='<div class="yui-qb-cardAcct">'+data.innerList[d].cardNo.substring(0,4)+' **** **** '+data.innerList[d].cardNo.substring(data.innerList[d].cardNo.length-4,data.innerList[d].cardNo.length)+'</div>';
						if (data.innerList[d].wageFlag=="1"&&data.innerList[d].cardStatus=="0") {
							html+='<div style="padding: 16px 16px 12px 52px;">工资卡</div>';
						}
						html+='<div style="position: absolute;height: 132px;width: 95%;top: 0px;background: url(css/img/309391000011-bg.png) no-repeat;background-position: 100% 100%;background-size: 80px;"></div>';
						html+='</div>';
						
						if (data.innerList[d].authenticated && data.innerList[d].authenticated == "6") {
							notHtml+=html;
						}else{
							innerHtml+=html;
						}
					}
					i++;
				}
			}
			if (data.outList!="") {
				var j=0;
				for ( var d in data.outList) {
					if (data.outList[d].cardStatus!="2"&&data.outList[d].cardStatus!="3"&&data.outList[d].cardStatus!="4") {
						if (data.outList[d].cardStatus=="0") {
							outHtml+='<div class="'+App.fmtCardBg(data.outList[d].bankCode)+'" onclick="App.toHWXQ('+j+')">';
						}else{
							outHtml+='<div class="'+App.fmtCardBg(data.outList[d].bankCode)+'">';
						}
						outHtml+='<div style="line-height: 40px;">';
						var img="defult";
						if (App.fmtCardBg(data.outList[d].bankCode)=="yui-qb-defultCardStyle") {
							img="default";
						}else{
							img=data.outList[d].bankCode;
						}
						outHtml+='<img src="css/img/'+img+'.png" class="yui-qb-cardLogo">';
						outHtml+='<div class="yui-qb-bankName">'+data.outList[d].bankName+'</div>';
						if (data.outList[d].cardStatus=="1") {
							outHtml+='<div style="float: right;">认证中</div>';
						}
						outHtml+='<div style="clear: both;"></div>';
						outHtml+='</div>';
						outHtml+='<div class="yui-qb-cardAcct">'+data.outList[d].cardNo.substring(0,4)+' **** **** '+data.outList[d].cardNo.substring(data.outList[d].cardNo.length-4,data.outList[d].cardNo.length)+'</div>';
						if (data.outList[d].wageFlag=="1"&&data.outList[d].cardStatus=="0") {
							outHtml+='<div style="padding: 16px 16px 12px 52px;">工资卡</div>';
						}
						var url="background:url('css/img/"+img+"-bg.png') no-repeat";
						outHtml+='<div style="position: absolute;height: 132px;width: 95%;top: 0px;'+url+';background-position: 100% 100%;background-size: 80px;"></div>';
						outHtml+='</div>';
					}
					j++;
				}
			}
		}
		if (innerHtml.length>0) {
			$("#innerCard").removeClass("hidden");
			$("#innerList").html(innerHtml);
		}
		if (outHtml.length>0) {
			$("#outCard").removeClass("hidden");
			$("#outList").html(outHtml);
		}
		if (notHtml.length>0) {
			$("#notCard").removeClass("hidden");
			$("#unList").html(notHtml);
		}
		if (App.result=="1040606") {
			Fw.Form.showPinLabel($(this), "银行卡解绑成功!", true);
		}
		if (App.result=="1040603") {
			Fw.Form.showPinLabel($(this), "工资卡设置成功!", true);
		}
		if (data.attestFailedList!=null&&data.attestFailedList!="") {
			App.xb=data.attestFailedList.length;
				App.attestFailedList=data.attestFailedList;
				Fw.Client.AccountDialog("2",data.attestFailedList[0].reason,"App.callBack()");
				var url = YT.dataUrl("private/deleteCard");
				var param={
						cardSerial:data.attestFailedList[0].cardSerial+""
				}
				YT.ajaxData(url,param,function(){},function(){});	
			}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
	},
	callBack:function(){
		if (App.xb>App.i) {
			App.i=App.i+1;
			Fw.Client.AccountDialog("2",App.attestFailedList[App.i].reason,"App.callBack()");
			var url = YT.dataUrl("private/deleteCard");
			var param={
					cardSerial:App.attestFailedList[i].cardSerial+""
			}
			YT.ajaxData(url,param,function(){},function(){});	
		}
	},
	/**
	 * 行外详情
	 */
	toHWXQ:function(j){
		App.data.outList[j].flags="1";
		App.data.outList[j].phoneNo=App.data.phoneNo;
		Fw.redirect("1040604.html",App.data.outList[j]);
	},
	/**
	 * 行内详情
	 */
	toHNXQ:function(i){
		if (App.data.innerList[i].authenticated && App.data.innerList[i].authenticated=="6") {
			Fw.Client.openWaitPanel();
			App.list=App.data.innerList[i];
			var url = YT.dataUrl("private/findUserInfo");
			YT.ajaxData(url,{},function(data){
				if (data.STATUS == "1") {
					Fw.Client.hideWaitPanel();
					App.list.fromAcctName = data.userName;
					App.list.fromAcctNo=App.data.innerList[i].cardNo;
					App.list.back="1040600";
					Fw.redirect("../10406/1040611.html",App.list);
				}else{
					Fw.Client.hideWaitPanel();
					Fw.Form.showPinLabel($(this), data.MSG, true);
				}
			},function(data){Fw.Client.alertinfo(data.MSG,"系统提示");});
		}else{
			App.data.innerList[i].flags="0";
			App.data.innerList[i].phoneNo=App.data.phoneNo;
			Fw.redirect("1040604.html",App.data.innerList[i]);
		}
	},
	fmtCardBg:function(bankCode){
		var bg="yui-qb-cardStyle";
		var cardList=["318110000014","102100099996","303100000006","306581000003","315456000105","304100040000","105100000017","301290000007","305100000013","103100000026","310290000013","307584007980","403100000004","308584000013","313338707013","302100011000","104100000004","307584007998","316331000018"];
		var greenList=["305100000013","403100000004","103100000026"];
		var blueList=["301290000007","310290000013","105100000017","315456000105","318110000014"];
		if (cardList.indexOf(bankCode)>-1) {
			if (blueList.indexOf(bankCode)>-1) {
				bg="yui-qb-blueCardStyle";
			}else if (bankCode=="303100000006") {
				bg="yui-qb-purpleCardStyle";
			}else if (greenList.indexOf(bankCode)>-1) {
				bg="yui-qb-greenCardStyle";
			}else{
				bg="yui-qb-redCardStyle";
			}
		}else{
			bg="yui-qb-defultCardStyle";
		}
		return bg;
	},
	/**
	 * 添加银行卡
	 */
	add:function(){
		Fw.Client.changePage("../10406/1040601.html","");
	},
	gotoGift:function(){
		var url = YT.dataUrl("private/queryActivityQueryUrl");
		Fw.Client.openWaitPanel();
		var params={};
	    YT.ajaxData(url,params,function(data){
	    	if (data.STATUS=="1") {
	    		Fw.Client.changeWeb(data.url,false,pageB);
	    		Fw.Client.hideWaitPanel();
			}else{
				App.failuri(data.MSG)
			}
	    	
	    },App.failuri);	
	},
	/**
	 * 返回工作首页
	 */
	gotoHomePage:function(){
		if(App.func('back') && App.func('back')=='1061210'){
			Fw.Client.changePage("../10612/1061210.html");
		}else{
			Fw.Client.gotoHomePage();
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);