var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#qkmm",App.showPwdPicker);
		App.pageA.on("click","#meg_code",App.showNumberPicker);
		App.pageA.on("click","#wc",App.toWC);
		$("#name").val(App.data.fromAcctName);
		var card=App.data.fromAcctNo.substring(App.data.fromAcctNo.length-4,App.data.fromAcctNo.length);
		var params = {
				"type":"9",
				"cardNo":card
		};
		if (App.data.wageFlag=="1") {
			$("#inputCheckbox").attr("checked","checked");
		}
		Fw.util.Format.openTimerListener("yzm",params);
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 表单提交
	 */
	toSubmit:function(){
		var artifIdNo =$("#zjhm").val();
		var mobile =$("#mobile").val();
		var tel =  /^(1)[0-9]{10}$/;
		//证件号码
		if (artifIdNo == null || artifIdNo == "") {
			Fw.Form.showPinLabel($(this), "请输入证件号码", true);
			return;
		}
			//手机号码
		if (mobile == null || mobile == "") {
			Fw.Form.showPinLabel($(this), "请输入手机号码", true);
			return;
		}
		if (!tel.test(mobile)||mobile.length != '11') {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			return;
		}
		if($("#qkmm").val()==""){
			Fw.Form.showPinLabel($(this), "取款密码不能为空", true);
			return;
		}else if($("#qkmm").val().length!="6"){
			Fw.Form.showPinLabel($(this), "取款密码必须为6位", true);
			return;
		}
		if($("#meg_code").val()==""){
			Fw.Form.showPinLabel($(this), "验证码不能为空", true);
			return;
		}
		if($("#meg_code").val().length!="6"){
			Fw.Form.showPinLabel($(this), "验证码必须为6位", true);
			return;
		}
		var params = {
				idNo : artifIdNo,
				userName : App.data.fromAcctName,
				cardNo:	App.data.fromAcctNo,
				mobile : mobile,
				MSG :$("#meg_code").val(),
				password  :$("#qkmm").attr("data-value"),
				authenticated : "0",
				switchStatus : "8"
			}
		var	url = YT.dataUrl("private/cardPaySwitch");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
					Fw.Client.hideWaitPanel();
					App.data.authenticated="5";
					var width=(document.body.clientWidth-290)/2;
					$("#white_b").attr("style","width: 290px;left:"+width+"px;");
					$("#black_b").removeClass("hidden");
					$("#white_b").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		},function(data){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		);
	},
	toGO:function(){
		Fw.redirect("../10401/1040609.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
	},
	toGO2:function(){
		Fw.redirect("../10401/1040109.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&JYLS="+App.func("JYLS")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
	},
	toGO3:function(){
		Fw.redirect("../10406/1040604.html",App.data);
	},
	toGO4:function(){
		Fw.redirect("../10501/1040609.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
	},
	/**
	 * 数字键盘
	 */
	showNumberPicker:function(){
		Fw.Client.showNumberPicker($("#meg_code"))
	},
	/**
	 * 密码键盘
	 */
	showPwdPicker:function(){
		Fw.Client.showPwdPicker($("#qkmm"));
	},
	toWC:function(){
		App.pageA.unbind("touchmove");
		$("#black_b").addClass("hidden");
		$("#white_b").addClass("hidden");
		//设置支付开关
		Fw.Client.openWaitPanel();
		if ($("#inputCheckboxpay").is(":checked")) {
			var url = YT.dataUrl("private/cardPaySwitch");
			var params={
					cardNo:	App.data.fromAcctNo,
					authenticated : "1",
					switchStatus : "7"
			}
			YT.ajaxData(url,params,function(data){
				if (data.STATUS=="1") {
					App.data.paySwitch="7";
					App.toGZK();
				}else{
					App.toGZK();
					Fw.Client.alertinfo(data.MSG,"消息提示");
				}
			},function(data){
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			});
		}else{
			App.toGZK();
		}
	},
	/**
	 * 设置工资卡
	 */
	toGZK:function(){
		//设置工资卡
		if (App.data.wageFlag!="1") {
			if ($("#inputCheckbox").is(":checked")) {
				var url = YT.dataUrl("private/salaryCard");
				var params = {
						cardNo : App.data.fromAcctNo,
						flag : "1"
				}
				YT.ajaxData(url,params,function(data){
					if (data.STATUS=="1") {
						App.data.wageFlag="1";
						App.toGOTO();
						Fw.Client.hideWaitPanel();
					}else{
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG,"消息提示","App.toGOTO()");
					}
				},function(data){
					App.toGOTO();
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG,"消息提示");
				});
			}else{
				Fw.Client.hideWaitPanel();
				App.toGOTO();
			}
		}else{
			if ($("#inputCheckbox").is(":checked")) {
				Fw.Client.hideWaitPanel();
				App.toGOTO();
			}else{
				var url = YT.dataUrl("private/salaryCard");
				var params = {
						cardNo : App.data.fromAcctNo,
						flag : "0"
				}
				YT.ajaxData(url,params,function(data){
					if (data.STATUS=="1") {
						App.data.wageFlag="0";
						App.toGOTO();
						Fw.Client.hideWaitPanel();
					}else{
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG,"消息提示","App.toGOTO()");
					}
				},function(data){
					App.toGOTO();
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG,"消息提示");
				});
			
			}
		}
	},
	/**
	 * 返回页面
	 */
	toGOTO:function(){
		if (App.data.back=="1040609") {
			App.toGO();
		}
		if(App.data.back=="1040109"){
			App.toGO2();
		}
		if(App.data.back=="1040604"){
			App.toGO3();
		}
		if(App.data.back=="1040600"){
			App.toGO3();
		}
		if(App.data.back=="10501"){
			App.toGO4();
		}
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		if (App.data.back=="1040609") {
			Fw.redirect("../10401/1040609.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
		}
		if(App.data.back=="1040109"){
			Fw.redirect("../10401/1040109.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&JYLS="+App.func("JYLS")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
		}
		if(App.data.back=="1040604"){
			Fw.redirect("../10406/1040604.html",App.data);
		}
		if(App.data.back=="1040600"){
			Fw.redirect("../10406/1040600.html");
		}
		if (App.data.back=="10501") {
			Fw.redirect("../10501/1040609.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
		}
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);