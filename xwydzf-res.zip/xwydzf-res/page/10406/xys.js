var App = {
		init:function(){
			App.pageA = $("#pageA");
			App.data = Fw.getParameters();
			App.func = window['_getParameter'];	
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA, null, true);
			},
		toBack:function(){
			Fw.redirect("../10406/1040609.html?trsNo="+App.func('trsNo')+"&amount="+App.func('amount')+"&trsId="+""+
			"&toAcctNo="+App.func('toAcctNo')+"&dealMsg="+""+"&count="+App.func('count')+"&back=1"+"",App.data);
		}
};
Fw.onReady(App);