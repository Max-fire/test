/**
 * 创建应用
 * 
 * @author wangjx
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function() {
			Fw.Client.openWaitPanel();
			App.pageA = $("#pageA");
			App.data=Fw.getParameters();
			App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		var url = YT.dataUrl("private/acctLmt");
		var param = {
				type : "1",
				cardNo : App.data.cardNo
		};
		YT.ajaxData(url, param,function(data){
			if (data.STATUS == "1") {
				Fw.Client.hideWaitPanel();
				App.initPage(data);
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"系统提示");
		});
		// 提交事件
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		//调金额键盘
		App.pageA.on("click", "#nxe", App.showMoneyPicker);
		App.pageA.on("click", "#rbs", App.showNumberPicker);
		App.pageA.on("click", "#rxe", App.showMoneyPicker1);
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 加载数据
	 */
	initPage:function(data){
		if (data.rljxe!="") {
			App.rxe = Fw.util.Format.fmtMoney(data.rljxe+"");
			$("#rxe").val(App.rxe);
		}else{
			App.rxe = "";
			$("#rxe").val("");
		}
		if (data.nljxe!="") {
			App.nxe = Fw.util.Format.fmtMoney(data.nljxe+"");
			$("#nxe").val(App.nxe);
		}else{
			App.nxe = "";
			$("#nxe").val("");
		}
		App.rbs = data.rljbs;
		$("#rbs").val(App.rbs);
	},
	/**
	 * 数据提交
	 */
	toSubmit:function(){
		if ($("#nxe").val()==App.nxe&&$("#rbs").val()==App.rbs&&$("#rxe").val()==App.rxe) {
			Fw.Form.showPinLabel($(this), "您未做任何修改!", true);
			return;
		}
		if ($("#rxe").val()=="0.00") {
			Fw.Form.showPinLabel($(this), "日限额不能为零", true);
			return;
		}
		var rbs = $("#rbs").val();
		if (rbs==0&&rbs!="") {
			Fw.Form.showPinLabel($(this), "日笔数不能为零!", true);
			return;
		}
		if ($("#nxe").val()=="0.00") {
			Fw.Form.showPinLabel($(this), "年限额不能为零", true);
			return;
		}
		var nxe = Fw.util.Format.delFmtMony($("#nxe").val());
		var rxe = Fw.util.Format.delFmtMony($("#rxe").val());
		if (nxe*1<rxe*1&&nxe!=""&&rxe!="") {
			Fw.Form.showPinLabel($(this), "年限额不能小于日限额!", true);
			return;
		}
		var param = {
				type : "4",
				func : "App.initComplete",
				funcAndroid:"App.initCompleteAndroid",
				XML : '<?xml version="1.0" encoding="utf-8"?><T><D><M><k>日限额：</k><v>'+rxe+'</v></M><M><k>日笔数：</k><v>'+rbs+'</v></M><M><k>年限额：</k><v>'+nxe+'</v></M></D></T>'
		};
		Fw.Client.showBB(param);
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		$("#btnSubmit").attr("disabled","disabled");
		var nxe = Fw.util.Format.delFmtMony($("#nxe").val());
		var rbs = $("#rbs").val();
		var rxe = Fw.util.Format.delFmtMony($("#rxe").val());
		App.initBJ(a,b,nxe,rbs,rxe);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b){
		var nxe = Fw.util.Format.delFmtMony($("#nxe").val());
		var rbs = $("#rbs").val();
		var rxe = Fw.util.Format.delFmtMony($("#rxe").val());
		App.initBJ(a,b,nxe,rbs,rxe);
	},
	/**
	 * 办结
	 */
	initBJ:function(a,b,nxe,rbs,rxe){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/acctLmt");
		var param = {
				type : "2",
				cardNo : App.data.cardNo,
				nljxe : nxe+"",
				rljbs : rbs+"",
				rljxe : rxe+"",
				signData:a,
				signSrc:b
		};
		YT.ajaxData(url, param,function(data){
			if (data.STATUS == "1") {
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.gotoPage()");
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		},function(data){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"系统提示");
		});
			
	},
	/**
	 * 调用金额键盘
	 */
	showMoneyPicker:function(){
		$("#nxe").val("");
		Fw.Client.showMoneyPicker($("#nxe"),true);
	},
	/**
	 * 调用金额键盘
	 */
	showMoneyPicker1:function(){
		$("#rxe").val("");
		Fw.Client.showMoneyPicker($("#rxe"),true);
	},
	/**
	 * 调用数字键盘
	 */
	showNumberPicker:function(){
		$("#rbs").val("");
		Fw.Client.showNumberPicker($("#rbs"));
	},
	/**
	 * 返回
	 */
	gotoPage:function(){
		if (App.data.page) {
			Fw.Client.changePage("1040600.html","");
		}else{
			Fw.redirect("1040604.html",App.data);
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
