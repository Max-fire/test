/**
 * 创建应用
 * 
 * @author yql
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
		App.data = Fw.getParameters();
		App.keys="";
	},
    initEvent : function(){
    	App.pageA.on("click",".ui-list-info",App.getMsg);
    	$(".ui-searchbar-text").tap(function(){
			$(".ui-searchbar-wrap").addClass('focus');
			$(".ui-searchbar-input input").focus();
		});
		$(".ui-searchbar-cancel").tap(function(){
			//发送请求
			App.search();
		});
		$(".ui-icon-close").tap(function(){
			$(".ui-searchbar-wrap").removeClass('focus');
			$(".ui-searchbar-input input").val("");
			App.keys="";
			App.query();
		});
		App.query();
    },
    /**
	 * 下拉列表
	 */
	query : function() { 
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findBankList");
		var json = {
				currPage:"1",
				pageSize:"300",
				bankName:App.keys
		}
    	YT.ajaxData(url,json,function(Data){
    		if(Data.STATUS=='1'){
    				if(Data){
		var temp = [
    					            '{@each bankList as item}', 
    					                '<li class="ui-border-radius">',
    					                	'<div class="yui-list-thumb-s">',
    					                	'<span class="yui-yinhang-icon"><img src="../../css/bank_logo/${item.otherBankCode}.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" style="height: 32px;width: 32px;"></span>',
    					                	'</div>',
    					                	'<div class="ui-list-info  ui-border-t" >',
    					                		'<h4 class="bankName">${item.bankName}</h4>',
    					                		'<input class="payBankCode" value="${item.otherBankCode}" hidden/>',
    					                		'</div>',
    					                '</li>', 
    					            '{@/each}',
    					            ].join("");
		var html="";
		if (Data.bankList.length!=0) {
			 html = Fw.template(temp,Data);
		}else{
			 html = '<div style="width: 100%; height: 44px; line-height: 44px; color: #017ef3; font-size: 18px; text-align: center;">没有数据</div>';
		}
    					$("#list").html(html);
    					Fw.Client.hideWaitPanel();
    				}
        		}
    	});
		
	},
    search:function(){
		App.keys = $(".ui-searchbar-input input").val().replace(/\s/g,"");
		if(App.keys == ""){
			Fw.Form.showPinLabel($(this),"关键字不能为空", true);
			return false;
		}
		App.query();
    },
    /**
     * 得到对应的数据返回
     */
    getMsg : function(){
    	var bankName = $(this).find(".bankName").html();
    	var payBankCode = $(this).find(".payBankCode").val();
    	App.data.bankName=bankName;
    	App.data.payBankCode=payBankCode;
    	Fw.redirect("1040601.html",App.data);
    },
    /**
     * 返回前一页
     */
    toBack:function(){
    	   Fw.redirect("1040601.html",App.data);
    }
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
