var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		init:function(require){
			Fw.Client.openWaitPanel();
			App.pageA = $("#pageA");
			App.func = window['_getParameter'];
			App.attchList = new Array();
			App.attch = new Array();
			App.list = new Array();
			App.i=0;
			App.data = Fw.getParameters();
			App.initBJRPD();
			App.initEvent();
			App.Top();
			App.time=0;
			App.start="";
			App.cs = 0;
			App.id=0;
			App.showRemitDetails="0";//屏蔽交易明细
		},
		initEvent:function(){
			//初始化办结事件
			App.pageA.on("click","#bj",App.changeBj);
			//初始化转办事件
			App.pageA.on("click","#zb",App.changeZb);
			//提交
			App.pageA.on("click","#btnSubmit",App.submit);
			// 加载点击选择审批人-事件
			App.pageA.on("click", "#fbjr", App.initSPR);
			// 添加附件-事件
			App.pageA.on("click",".TJFJ",App.initTJFJ);
			// 添加员工-事件
			App.pageA.on("click","#add",App.addPeople);
			//调金额键盘
			App.pageA.on("click", ".money", App.showMoneyPicker);
			//落地审核提示显示
			App.pageA.on("click","#ts",App.initTS);
			//点击我知道了
			App.pageA.on("click","#iknow",App.toIknow);
			//备注控制字节
			App.pageA.on("porpertychanger","#memo",App.toMemo);
			App.pageA.on("input","#memo",App.toMemo);
			//屏蔽按钮
			App.pageA.on("click","#inputCheckbox",App.toInputCheckbox);
			App.pageA.on("click","#pbmxts",App.initPbmxts);
			App.pageA.on("click","#iknows",App.toIknows);
			
		},
		toInputCheckbox:function(){
			if ($("#inputCheckbox").is(":checked")) {
				$("#inputCheckboxText").html("是");
			}else{
				$("#inputCheckboxText").html("否");
			}
		},
		/**
		* 屏蔽明细提示显示
		*/
		initPbmxts:function(){
			var height=document.body.clientHeight+500;
			var top=document.body.scrollTop+$(window).height()/4;
			$("#black_c").attr("style","height:"+height+"px;");
			$("#white_c").attr("style","top:"+top+"px;");
			$("#black_c").removeClass("hidden");
			$("#white_c").removeClass("hidden");
			//静止滑动
			App.pageA.bind("touchmove",function(e){
				e.preventDefault();
			});
		},
		/**
		 * 落地审核提示显示
		 */
		initTS:function(){
			var height=document.body.clientHeight+500;
			var top=document.body.scrollTop+$(window).height()/4;
			$("#black_b").attr("style","height:"+height+"px;");
			$("#white_b").attr("style","top:"+top+"px;");
			$("#black_b").removeClass("hidden");
			$("#white_b").removeClass("hidden");
			//静止滑动
			App.pageA.bind("touchmove",function(e){
				e.preventDefault();
			});
		},
		/**
		 * 取消弹窗提示
		 */
		toIknow:function(){
			App.pageA.unbind("touchmove");
			$("#black_b").addClass("hidden");
			$("#white_b").addClass("hidden");
		},
		toIknows:function(){
			App.pageA.unbind("touchmove");
			$("#black_c").addClass("hidden");
			$("#white_c").addClass("hidden");
		},
		/**
		 * 备注控制字节
		 */
		toMemo:function(){
			Fw.util.Format.checkNum("memo",60);
		},
		swiper : function() {
			App.arrays = new Array();
			for(var i = 0;i<App.cs;i++){
				var swiper = new Swiper('#'+i, {
					slidesPerView : 'auto',
					freeMode : false,
					freeModeMomentumBounce : false,
					spaceBetween : 0,
				});
				App.arrays.push({swipera:swiper});
			}
			$("#pageA").click(function(){
				for(var i = 0;i<App.cs;i++){
					App.arrays[i].swipera.slideTo(0,1000,false);
				}
			});
			
		},
		initDelete:function(e){
			$(e).parent().parent().remove();
			App.count();
			App.sumMoney();
		},
		//置顶置底按钮
		Top:function(){
			var obj=document.getElementById("scroll");
			obj.onclick=function(){
				var timer=setInterval(function(){
					if (document.body.scrollTop>=document.body.clientHeight/3) {
						window.scroll(0,0);
						$("#scroll").removeClass("yui-yghk-zdan1");
						$("#scroll").addClass("yui-yghk-zdan")
						clearInterval(timer);
					}else{
						window.scroll(0,document.body.clientHeight);
						$("#scroll").removeClass("yui-yghk-zdan");
						$("#scroll").addClass("yui-yghk-zdan1")
						clearInterval(timer);
					}
				},2)
			};
			window.onscroll=function(){
				clearTimeout(App.start);
				$("#scroll").css("display","block");
				App.start=setTimeout(function(){
						$("#scroll").css("display","none");
					},2000);
				if (document.body.scrollTop>=document.body.clientHeight/3) {
					$("#scroll").removeClass("yui-yghk-zdan");
					$("#scroll").addClass("yui-yghk-zdan1")
				}else{
					$("#scroll").removeClass("yui-yghk-zdan1");
					$("#scroll").addClass("yui-yghk-zdan")
				}
			}
		},
		/**
		 * 加载页面
		 */
		initpage:function(){
			var data1=[];
			if(App.data && App.data.trsTrsfr){
				data1=App.data.userPcList;
			}else{
				data1=App.data;
			}
			if(data1){
				$("#list").html(App.circulate(data1));
			}
			Fw.Client.StaffGuide();
			Fw.Client.hideWaitPanel();
			App.count();
			App.sumMoney();
			YT.showPageArea(App.pageA, [], true);
			App.swiper();
			if(data1[0].memo){
				$("#memo").focus();
				$("#memo").blur();
			}
		},
		/**
		 * 统计总额
		 */
		sumMoney:function(){
			var sum =0;
			var length = $("#list").children().size();
			var money = $("#list").find(".money");
			var span = $("#list").find(".yui-cursor-span");
			var svalue = $("#list").find(".yui-hiden-val");
			for(var i = 0;i<length;i++){
				$(money[i]).attr("id","ID"+i);
				$(span[i]).attr("data-id","ID"+i);
				$(svalue[i]).attr("data-id","ID"+i);
				var acct = $(money[i]).attr("data-value");
				try {
					if(acct==""||acct==undefined){
						sum = (sum*1 + 0).toFixed(2);
					}else{
						sum = (sum*1 +acct*1).toFixed(2);
					}
					//alert(money[i].attr("data-value")+"总金额"+sum);
				} catch (e) {
					alert(e);
				}
			}
			//alert($(money[0]).attr("data-value")+"=="+$(money[1]).attr("data-value")+"---"+sum+"---"+length);
			$("#HKJE").val(sum);
			$("#HJJE").html(Fw.util.Format.fmtAmt(sum+""));
		},
		/**
		 * 查看金额有没有输完全
		 */
		checkMoney:function(){
			var sum =0;
			var bool="";
			var length = $("#list").children().size();
			var money = $("#list").find(".money");
			for(var i = 0;i<length;i++){
				var acct = $(money[i]).attr("data-value");
				var val=money[i].value;
				if (acct==""||acct==undefined||val=="0.00") {
					bool=$(money[i]).attr("id");;
					break;
				}
			}
			return bool;
		},
		/**
		 * 统计总笔数
		 */
		count:function(){
			var length = $("#list").children().size();
			$("#bs").html("共"+length+"笔");
			$("#zbs").val(length);
		},
		/**
		 * 办结
		 */
		changeBj : function() {
			$("#bj").removeClass("yui-backgroud-a");
			$("#bj").addClass("yui-backgroud-a1");
			$("#zb").removeClass("yui-backgroud-b1");
			$("#zb").addClass("yui-backgroud-b");
			$("#fbjr").addClass("hidden");
			$("#trsStatus").val("0");
			$("#showRemitDetails").removeClass("hidden");
			
		},
		/**
		 * 转办
		 */
		changeZb : function() {
			$("#zb").removeClass("yui-backgroud-b");
			$("#zb").addClass("yui-backgroud-b1");
			$("#bj").removeClass("yui-backgroud-a1");
			$("#bj").addClass("yui-backgroud-a");
			$("#fbjr").removeClass("hidden");
			$("#trsStatus").val("1");
			$("#showRemitDetails").removeClass("hidden");
			
		},
		/**
		 * 判断是否为必经人
		 */
		initBJRPD:function(){
			var url = YT.dataUrl("private/isApproval");
			var params = {
					trsType:"3"
			};
			YT.ajaxData(url,params,function(data){
				if(data.IsApproval == "YES"){
					App.showJGBJR();
					App.initpage();
				}else{
					App.showWJGBJR();
					App.initpage();
				}
			});
		},
	    /**
	     * 非效必经人
	     */
	  	showWJGBJR:function(){
	  		$("#bjr").addClass("hidden");
	  		$("#fbjr").removeClass("hidden");
	  		$("#showRemitDetails").removeClass("hidden");
	  	},
		/**
		 * 有效必经人
		 */
	  	showJGBJR:function(){
	  		$("#trsStatus").val("");
	  		$("#bjr").removeClass("hidden");
	  		$("#fbjr").addClass("hidden");
	  	},
	  	/**
		 * 选择审批人
		 */
		initSPR : function() {
			Fw.Client.openPersonnel("App.openPeople");
		},
		openPeople : function(name, id, co) {
			$("#dealUserName").val(name);
			$("#dealUserId").val(id);
			$("#communicateId").val(co);
		},
		/**
		 * 添加附件
		 */
		initTJFJ : function(){
			if(App.attch.length > 5){
				Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
				return;
			}
			Fw.Client.openAttcchment("App.showAttcchment");
		},
		showAttcchment: function(name,url){
			Fw.util.attach.addAttach(name,url);
		},
		/**
		 * 提交
		 */
		submit:function(){
			var memo = $("#memo").val().replace(/\s/g,"");
			var dealUserId = $("#dealUserId").val();
			var tomoney=App.checkMoney();
			var ibank=App.addList();
			if ($("#list").children().size()==0) {
				Fw.Form.showPinLabel($(this), "请添加收款人", true);
				return;
			}
			if (tomoney!="") {
				Fw.Form.showPinLabel($(this), "请输入汇款金额", true);
				App.toMoney(tomoney);
				return;
			}
			
			if (ibank!="") {
				Fw.Form.showPinLabel($(this), "他行的最高汇款金额为5万元", true);
				App.toMoney(ibank);
				return;
			}
			if(Fw.util.proofTest.proolEmoji(memo)){
				Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
				return;
			}
			if($("#trsStatus").val()==""||$("#trsStatus").val()==null){
				Fw.Form.showPinLabel($(this), "请选择操作类型", true);
				return;
			}
			if ($("#trsStatus").val() == "1") {
				if (dealUserId == "") {
					Fw.Form.showPinLabel($(this), "请选择审批人", true);
					return;
				}
			}
			//是否对后续处理人隐藏
			if ($("#inputCheckbox").is(":checked")) {
				App.showRemitDetails='1';
			}else{
				App.showRemitDetails='0';
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			Fw.Client.openWaitPanel("提交中...");
			// 判断发起人是不是有效必经人
			if ($("#trsStatus").val() == "0") {
				var url = YT.dataUrl("public/getRandomNum");
				YT.ajaxData(url, {}, function(data) {
					if (data.STATUS == "1") {
						var url = YT.dataUrl("private/isEffective");
						var json = {
								trsType : "3",
								amount : $("#HKJE").val(),
								bizNo : "3",
								TOKEN : data.randomNum,
								flag : "2"
						};
						YT.ajaxData(url, json, function(suc) {
							if (suc.isAmount == "YES") {
								if (suc.isEffective == "YES") {
									App.initComplete1();
								} else {
									App.flag = false;
									Fw.Form.showPinLabel($(this), "您的权限不足,请转办",
											true);
									Fw.Client.hideWaitPanel();
									return;
								}
							} else {
								App.flag = false;
								Fw.Form.showPinLabel($(this),"汇款金额不得大于渠道限额("+suc.listAmount.toFixed(2)+")",
										true);
								Fw.Client.hideWaitPanel();
								return;
							}
						});
					} else {
						App.flag = false;
						Fw.Client.alertinfo(data.MSG, "消息提示");
					}
				});
			}
			// 转办
			if ($("#trsStatus").val() == "1") {
				var url = YT.dataUrl("public/getRandomNum");
				YT.ajaxData(url, {}, function(data) {
					if (data.STATUS == "1") {
						var url = "private/batchTransfer.json";
						var jsons = {
								type:"1",
								isComplete:"2",
								trsType:"1",
								amount:$("#HKJE").val(),
								total:$("#HKJE").val(),
								dealUserName:$("#dealUserName").val(),
								dealUserId:$("#dealUserId").val(),
								List:App.list,
								memo:$("#memo").val(),
								trsferType:"STAFF_TRANSFER",
								readFlag:App.showRemitDetails
									
						};
						Fw.Client.post(url, jsons, "App.success");
					} else {
						App.flag = false;
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG, "消息提示");
					}
				});
			}
		},
		/**
		 * 转办
		 */
		success : function(datas) {
			if (datas.STATUS == "1") {
				var url = YT.dataUrl("private/oprtFile");
				var params = {
					trsNo : datas.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
				};
				YT.ajaxData(url, params, function(success) {
					Fw.Client.hideWaitPanel();
				});
				Fw.Client.alertinfo("已提交下一个处理人：" + $("#dealUserName").val(), "提交成功","App.goNext()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(datas.MSG, "消息提示");
				return;
			}
		},
		/**
		 * 转办成功后
		 */
		goNext : function() {
			Fw.Client.changePage("../10401/1040100.html", true);
		},
		/**
		 * 办结
		 */
		initComplete1 : function() {
			var params = {
					type:"1",
					isComplete:"1",
					trsType:"1",
					total:$("#HKJE").val(),
					List:App.list,
					memo:$("#memo").val(),
					trsferType:"STAFF_TRANSFER",
					readFlag:App.showRemitDetails
			};
			var url = "private/batchTransfer.json";
			Fw.Client.post(url, params, "App.initCommonAcct");
		},
		/**
		 * 办结成功
		 */
		initCommonAcct : function(data) {
			if (data.STATUS == "1") {
				App.trsNo = data.trsNo;
				var url = YT.dataUrl("private/oprtFile");
				var params = {
					trsNo : data.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
				};
				YT.ajaxData(url, params, function(success) {
					App.onNext();
					App.flag = false;
					Fw.Client.hideWaitPanel();
				});
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG, "消息提示");
				return;
			}
		},
		onNext : function() {
			var acctName = $("#list").find(".toAcctName");
			var acctNo = $("#list").find(".toAcctNo");
			var amount = Fw.util.Format.replaceDouble("1",$("#HKJE").val());
			var count=$("#zbs").val();
			var purpose=$("#memo").val()
			var json = {
				"purpose":purpose,
				list:App.list,
				toAcctName:$(acctName[0]).val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"")
				};
			if($("#list").children().size()==1){
				var toAcctNo=$(acctNo[0]).val();
			}else{
				var toAcctNo=$(acctNo[0]).val();
				json = {
						"purpose":purpose,
						list:App.list,
						toAcctName:$(acctName[0]).val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"")+"等"
						};
			}
			Fw.redirect("../10401/1040609.html?trsNo="+App.trsNo+"&amount="+amount+"&trsId="+""+
			"&toAcctNo="+toAcctNo+"&dealMsg="+""+"&count="+count+"",json);
		},
		/**
		 * 增加汇款人
		 */
		addPeople:function(){
			Fw.Client.chooseStaff("App.openPeopleA");
		},
		openPeopleA:function(data) {
			var data2=YT.JsonEval(data).userPcList;
			/*if($("#list").children().size()+data2.length>100){
				Fw.Form.showPinLabel($(this), "收款人数不能超过100", true);
				return;
			}*/
			$("#list").append(App.circulate(data2));
			App.swiper();
			App.count();
			App.sumMoney();
		},
		circulate:function(data){
			var html = "";
			for ( var d in data) {
				App.cs+=1; 
				html+='<div class="swiper-container" id="'+App.id+'" style="margin-bottom: 5px;">';
				html+='<div class="swiper-wrapper">';
				html+='<div class="swiper-slide swiper-slide-change ui-list">';
				html+='<div class="yui-cui-yghk-img">';
				html+='<img src="../../css/bank_logo/'+data[d].personalCard.bankCode+'.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'" style="height: 32px; width: 32px;margin-top: 8px; padding-left: 10px;">';
				html+='</div>';
				html+='<div class="yui-cui-yghk-f2">';
				html+='<div style="color:#333333;">'+data[d].firmUser.userName+'</div>';
				html+='<div style="font-size:12px;color: #999999;">尾号<span>'+data[d].personalCard.cardNo.substring(data[d].personalCard.cardNo.length-4,data[d].personalCard.cardNo.length)+'</span></div>';
				html+='</div>';
				html+='<div style="  border-right: 1px solid #e9edf3;height: 30px;margin-top: 10px;"></div>';
				html+='<div class="yui-cui-yghk-f3">';
				html+='<div class="yui-keyboard-panel">';
				if(data[d].amount){
					$("#memo").val(data[d].memo);
					html+='<input type="text"  class="money" readonly="readonly" placeholder="请输入金额" data-bank="'+data[d].personalCard.isCibCard+'" value="'+Fw.util.Format.fmtAmt(data[d].amount+"")+'" data-value="'+data[d].amount+'" style="font-size:16px;color:#017ef3;padding: 10px 0px 10px 20px;"/>';
				}else{
					html+='<input type="text"  class="money" readonly="readonly" placeholder="请输入金额" data-bank="'+data[d].personalCard.isCibCard+'"  style="font-size:16px;color:#017ef3;padding: 10px 0px 10px 20px;"/>';
				}
				html+='<span class="yui-cursor-span">';
				html+='<i class="yui-hiden-val"></i>';
				html+='</span>';
				html+='</div>';
				html+='<input type="text"  class="toBankCode hidden" value="'+data[d].personalCard.bankCode+'" readonly="readonly" />';
				html+='<input type="text"  class="innerBank hidden" value="'+data[d].personalCard.isCibCard+'" readonly="readonly" />';
				html+='<input type="text"  class="toAcctName hidden" value="'+data[d].firmUser.userName+'" readonly="readonly" />';
				html+='<input type="text"  class="toAcctNo hidden" value="'+data[d].personalCard.cardNo+'" readonly="readonly" />';
				html+='<input type="text"  class="toBankName hidden" value="'+data[d].personalCard.bankName+'" readonly="readonly" />';
				html+='</div>';
				html+='</div>';
				html+='<div class="swiper-slide item-delete" onClick="App.initDelete(this);">';
				html+='<span>删除</span>';
				html+='</div>';
				html+='</div>';
				html+='</div>';
				App.id+=1;
			}
			return html;
		},
		
		/**
		 * 传的参数
		 */
		addList:function(){
			var length = $("#list").children().size();
			var money = $("#list").find(".money");
			var innerBank=$("#list").find(".innerBank");
			var toAcctName=$("#list").find(".toAcctName");
			var toAcctNo=$("#list").find(".toAcctNo");
			var toBankCode=$("#list").find(".toBankCode");
			var toBankName=$("#list").find(".toBankName");
			App.list = new Array();
			var ibank=""
			for(var i = 0;i<length;i++){
				if (innerBank[i].value=="2"&&$(money[i]).attr("data-value")>50000) {
					return ibank=$(money[i]).attr("id");
					break;
				}
				App.list.push({
					innerBank:innerBank[i].value,
					toAcctName:toAcctName[i].value,
					toAcctNo:toAcctNo[i].value,
					toBrCode:toBankCode[i].value,
					toBankName:toBankName[i].value,
					amount:$(money[i]).attr("data-value")
				});
			}
			return false;
		},
		/**
		 * 金额键盘
		 */
		showMoneyPicker:function(){
			var a=$(this).attr("id");
			var time=new Date().getTime();
			var clickTime=time-App.time;
			if (clickTime>700) {
				App.showCursor($(this));
				App._preShowKeyBoard($(this));
				Fw.Client.showMoneyPicker($("#"+a),true);
			}
			App.time=time;
			$("#"+a).blur();
		},
		toMoney:function(tomoney){
			App.showCursor($("#"+tomoney));
			var top=$("#"+tomoney).offset().top;
			window.scroll(0,top-150);
			Fw.Client.showMoneyPicker($("#"+tomoney),true);
		},
		/**
		 * 光标
		 */
		showCursor : function(that) {
			var _id = that.attr("id");
			var keyboard_panel = $(".yui-keyboard-panel");
			keyboard_panel.find("span").hide();
			keyboard_panel.find("i").text("");
			var cursor = $('span[data-id=' + _id + ']')
			$(cursor).show();
			var _i = $('i[data-id=' + _id + ']');
			var _span = $('span[data-id=' + _id + ']');
			var parent = that.parent(".yui-keyboard-panel");
			_span.height(parent.height());
			that.css("opacity", "0");
			_span.show();
			_i.after('<i class="yui-cursor-i" data-iid="' + _id + '"> </i>');
			var cursor = $('i[data-iid=' + _id + ']');
			cursor.addClass("yui-sim-cursor");
			_i.show().html(that.val()).css("color", that.css("color"));

		},
		_preShowKeyBoard : function($ele) {
			if (Fw.isString($ele)) {
				$ele = $('#' + $ele);
			}

			var boardH = 255; // 自定义键盘高度
			var wHeight = $(window).height();
			var eh = $ele.height(); // 元素的高度
			var top = $ele.offset().top;
			var stop = $(window).scrollTop();// 滚动条高度
			var I = $ele.attr("data-boardI");// 偏移量，适用于页面没有导航条 推荐值55
			I = I ? I * 1 : 0;
			// 15为偏差量
			var newTop = wHeight - I + stop - top - eh - 20;
			if (newTop < boardH) {
					var top=$ele.offset().top;
					window.scroll(0,top-150);
			} 
		},
		toBack:function(){
			if(App.data.back=="15C"){
				Fw.redirect("../10406/det15C.html?dealUser=1&trsStatus="+App.func('trsStatus')+"&trsNo="+App.data.trsNo+"",App.data);
			}else if(App.data.back=="15B"){
				Fw.redirect("../10406/det15B.html?dealUser=2&trsStatus="+App.func('trsStatus')+"&trsNo="+App.data.trsNo+"",App.data);
			}else if(App.func("dealUser") == "1"){
				Fw.Client.changePage("../10401/1040100.html?trsStatus="+App.func("trsStatus")+"","1");
			}else if(App.func("dealUser") == "2"){
				Fw.Client.changePage("../10401/1040105.html?trsStatus="+App.func("trsStatus")+"","1");
			}
		}
};
Fw.onReady(App);