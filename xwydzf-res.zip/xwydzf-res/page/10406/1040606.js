/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function() {
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, [], true);
		App.data=Fw.getParameters();
		Fw.Client.hideWaitPanel();
		App.initEvent();
	},
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#meg_code",App.showNumberPicker);
		var card=App.data.cardNo;
		var wh=card.substring(card.length-4,card.length);
		$("#wh").html(wh+"");
		//发送短信
		Fw.util.Format.openTimerListener("mess_code",{"type":"3","mobile":App.data.phoneNo,"cardNo":wh});
	},
	/**
	 * 解绑
	 */
	toSubmit:function(){
		if($("#meg_code").val()==""){
			Fw.Form.showPinLabel($(this), "验证码不能为空", true);
			return;
		}
		if($("#meg_code").val().length!="6"){
			Fw.Form.showPinLabel($(this), "验证码必须为6位", true);
			return;
		}
		var url = YT.dataUrl("private/unbindCard");
		var params={
				cardSerial:App.data.cardSerial+'',
				validCode:$("#meg_code").val(),
				};
	    YT.ajaxData(url,params,App.success,App.failuri);
	},
	/**
	 * 调数字键盘
	 */
	showNumberPicker:function(){
		Fw.Client.showNumberPicker($("#meg_code"));
	},
	/**
	 * 成功回调函数
	 */
	success:function(data){
		if (data.STATUS=="1") {
			Fw.redirect("1040600.html","1040606");
		}else{
			Fw.Client.alertinfo(data.MSG,"系统提示");
		}
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 * 返回工作首页
	 */
	goback:function(){
		Fw.redirect("1040604.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);