/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data=Fw.getParameters();
		Fw.Client.openWaitPanel();
		App.flag = "0";
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		$("#bankName").html(App.data.bankName);
		$("#acctNo").html(Fw.util.Format.account(App.data.cardNo));
		if (App.data.cardStatus!="0") {
			$("#yxk").addClass("hidden");
		}else{
			$("#yxk").removeClass("hidden");
		}
		if (App.data.wageFlag=="1") {
			App.flag="1";
			$("#inputCheckbox").attr("checked","checked");
		}
		if (App.data.paySwitch=="7") {
			$("#inputCheckboxpay").attr("checked","checked");
		}
		App.pageA.on("click","#jcbd",App.onJCBD);
		App.pageA.on("click","#inputCheckbox",App.toGZK);
		App.pageA.on("click","#inputCheckboxpay",App.toZF);
		App.pageA.on("click","#cxmx",App.toCXMX);
		App.pageA.on("click","#szxe",App.toSZXE);
		
		if (App.data.flags=="1") {
			$("#ye").addClass("hidden");
			$("#kh").removeClass("ui-border-b");
			$("#cxmx").addClass("hidden");
			$("#szxe").attr("style","display: none;");
			$("#zf").attr("style","display: none;");
			Fw.Client.hideWaitPanel();
		}else{
			$("#ye").removeClass("hidden");
			$("#kh").addClass("ui-border-b");
			$("#amount").html(Fw.util.Format.fmtAmt(App.data.amount+""));
			var url = YT.dataUrl("private/isApproval");
			YT.ajaxData(url,{trsType:"3"},function(Data){
				Fw.Client.hideWaitPanel();
				if(Data.IsApproval=="YES"){
					$("#szxe").removeAttr("style");
					$("#zf").removeAttr("style");
				}else{
					$("#szxe").attr("style","display: none;");
					$("#zf").attr("style","display: none;");
				}
			})
		}
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 指定为工资卡
	 */
	toGZK:function(){
		if ($("#inputCheckbox").is(":checked")) {
			App.flag="1";
		}else{
			App.flag="0";
		}
		var url = YT.dataUrl("private/salaryCard");
		var param = {
				cardNo : App.data.cardNo,
				flag : App.flag,
		};
		YT.ajaxData(url, param,function(data){
			if (data.STATUS == "1") {
				if (App.flag=="0") {
					App.data.wageFlag="0";
					Fw.Form.showPinLabel($(this), "已取消工资卡!", true);
				}else{
					App.data.wageFlag="1";
					Fw.Form.showPinLabel($(this), "工资卡设置成功!", true);
				}
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示","App.toGZKF()");
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"系统提示");
		});
	},
	toGZKF:function(){
		$("#inputCheckbox").removeAttr("checked");
	},
	/**
	 * 支付开关
	 */
	toZF:function(){
		var flag="";
		if ($("#inputCheckboxpay").is(":checked")) {
			if (App.data.authenticated && App.data.authenticated=="6") {
				Fw.Client.openWaitPanel();
				var url = YT.dataUrl("private/findUserInfo");
				YT.ajaxData(url,{},function(data){
					if (data.STATUS == "1") {
						App.data.fromAcctName = data.userName;
						App.data.fromAcctNo = App.data.cardNo;
						App.data.wageFlag=App.flag;
						App.data.back="1040604";
						Fw.redirect("../10406/1040611.html",App.data);
					}else{
						Fw.Form.showPinLabel($(this), data.MSG, true);
					}
				});
				return;
			}
			flag="7";
		}else{
			flag="8";
		}
		var url = YT.dataUrl("private/cardPaySwitch");
		var params={
				cardNo:	App.data.cardNo,
				authenticated : "1",
				switchStatus : flag
		}
		YT.ajaxData(url,params,function(data){
			if (data.STATUS=="1") {
				if (flag=="7") {
					App.data.paySwitch="7";
					Fw.Form.showPinLabel($(this), "支付功能已开启!", true);
				}else{
					App.data.paySwitch="8";
					Fw.Form.showPinLabel($(this), "已关闭支付功能!", true);
				}
			Fw.Client.hideWaitPanel();
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
		});
	},
	/**
	 * 成功回调函数
	 */
	success:function(data){
			if (data.STATUS == "1") {
				Fw.redirect("1040601.html");
			} else {
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}
			Fw.Client.hideWaitPanel();
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 *查询明细
	 */
	toCXMX:function(){
		var datas = {
				"func" : "App.opData",
				"flag" : "0",
				"date" : "",
				"account":App.data.cardNo,
				"title":"筛选"
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	/**
	 * 明细查询回调函数
	 */
	opData : function(begin,end) {
		App.data.beginTime=begin;
		App.data.endTime=end;
		App.data.acctId=App.data.cardNo;
		Fw.redirect("1040605.html",App.data);
	},
	/**
	 *设置限额
	 */
	toSZXE:function(){
		Fw.redirect("1040610.html",App.data);
	},
	/**
	 * 解除绑定
	 */
	onJCBD:function(){
		Fw.redirect("1040606.html",App.data);
	},
	/**
	 * 返回工作首页
	 */
	goback:function(){
		Fw.redirect("1040600.html","");
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);