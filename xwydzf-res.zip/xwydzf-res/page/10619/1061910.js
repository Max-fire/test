/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data= Fw.getParameters()||{};
		App.flag = false;
		App.initEvent();
		App.initPage();
		Fw.Layer.hideWaitPanel(); //关闭等待层
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 动态校验公司名称位数
		App.pageA.on("input","#GSMC",App.checkGSMCNum);
		App.pageA.on("blur", "#GSMC", App.requireGSMC);
		// 下一步
		App.pageA.on("click", "#btnSubmit1", App.next);
		// 失去焦点去空格
		App.pageA.on("blur", "#mobile", App.removeKong);
		App.pageA.on("porpertychanger","#mobile",App.toCheck);
		App.pageA.on("input","#mobile",App.toCheck);
		App.pageA.on("porpertychanger","#meg_code",App.toCheck);
		App.pageA.on("input","#meg_code",App.toCheck);
		App.pageA.on("click", "#yzm", App.toYZM);
		App.pushHistory();
		App.pageA.show();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				WeixinJSBridge.call('closeWindow');
			 },false);
		},false)
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	/**
	 * 初始化页面(上个页面传送过来)
	 */
	initPage : function() {
		if (App.data) {
			// 页面赋值
			if(App.data.firmName){
				$("#GSMC").val(App.data.firmName);
			}
			if(App.data.mobile){
				$("#mobile").val(App.data.mobile);
			}
			$("#meg_code").val("");
			App.toCheck();
		} 
		
	},
	toCheck:function(){
		var name = $("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");
		var mobile = $("#mobile").val().replace(/ /g,"");
		var code = $("#meg_code").val();
		if (name && mobile.length=="11"&&code.length=='6') {
			$("#btnSubmit1").removeAttr("disabled", "");
			$("#btnSubmit1").css("background-image","linear-gradient(-135deg, #217DCA 0%, #46B4E7 96%)")
		}else{
			$("#btnSubmit1").attr("disabled", "disabled");
			$("#btnSubmit1").css("background-image","unset")
			$("#btnSubmit1").css("background","#B5BFCC")
		}
	},

	requireGSMC:function(){
		var  gsmc= $.trim($("#GSMC").val());
		if(gsmc.length==0){
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			return;
		}
		App.toCheck();
	},
	/**
	 * 检查公司名称字节数 
	 */
	checkGSMCNum:function(){
		var w=0;//字节数
		var name=$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>120){
				name=name.substring(0,i);
				$("#GSMC").val(name);
				$("#GSMC").blur();
				break;
			}
		}
		App.toCheck();
	},
    /**
	 * 下一步
	 */
	next : function() {
		var GSMC =$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		var mobile = $("#mobile").val().replace(/ /g,"");
		var code = $("#meg_code").val();
		var tel =  /^(1)[0-9]{10}$/;
		if (GSMC=="") {
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			$("#GSMC").focus();
			return;
		}
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (nnm.test(GSMC)||Fw.util.proofTest.proolEmoji(GSMC)) {
			Fw.Form.showPinLabel($(this), "公司名称不能含有非法字符!", true);
			$("#GSMC").focus();
			return;
		}
		if (mobile == "" || mobile.length != '11') {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			$("#mobile").focus();
			return;
		}
		if (!tel.test(mobile)) {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			$("#mobile").focus();
			return;
		}
		if (code == "") {
			Fw.Form.showPinLabel($(this), "验证码不能为空!", true);
			$("#meg_code").focus();
			return;
		}
		if (code.length != '6') {
			Fw.Form.showPinLabel($(this), "验证码必须为6位!", true);
			$("#meg_code").focus();
			return;
		}
		 var num=/[0-9]{6}/;
		 if (!num.test($("#meg_code").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		var params = {
			firmName:GSMC,
			mobile:mobile,
			smsCode : code,
		}
        App.data.firmName=GSMC;
		App.data.mobile=mobile;
		var url = YT.dataUrlWeb("private/financingCreditCheck");
		Fw.Layer.openWaitPanel();  	//等待层开启
		YT.ajaxDataWeb(url, params, function(data) {
			if (data.STATUS == "1") {
				      App.data.financingPreApply=data.financingPreApply
					  Fw.redirect("1061911.html", App.data);
				  }
			else {
				Fw.Layer.hideWaitPanel(); //关闭等待层
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});

	},
	toYZM:function(){
		var tel =  /^(1)[0-9]{10}$/;
		 if (!tel.test( $("#mobile").val())|| $("#mobile").val() == "" ||  $("#mobile").val().length != "11") {
			 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			 return;
		 }
		var param={
				mobile : $("#mobile").val(),
				type : "17"
		}
		
		var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
			var html="已向手机"+phone+"发送短信验证码，请注意查收";
			$("#yzm").val("");
			var url = YT.dataUrlWeb('normal/tr3888.json');
			Fw.Layer.openWaitPanel();  	//等待层开启
			YT.ajaxDataWeb(url, param, function(rsp){
				if(rsp.STATUS == '1'){
				    Fw.Layer.hideWaitPanel();
					App.timer=60;
					App._initTime = new Date().getTime()-1000;
					App._sumTime = 60;
					App._startTimerListener();
					callback && callback();
				}else{
					Fw.Form.showPinLabel($(this), rsp.MSG, true);
					Fw.Layer.hideWaitPanel();
					return;
					//YT.alertinfo(rsp.MSG);
				}
			},function(data){
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Layer.hideWaitPanel();
				return;
				//YT.alertinfo(data.MSG);
				
			});
	},
	/**
	 * 打开短信验证码计时器
	 */
	_startTimerListener: function(){
		if(App.timer > 0){
			var time = App._getTimer();
			App.timer = App._sumTime - time;
			if(App.timer>0){
				$("#yzm").text(App.timer + '秒后重发');
				$("#yzm").attr("disabled", true);
				$("#yzm").css("background", "#B5BFCC");
			}else{
				App._closeTimerListener();
				$("#yzm").css("background", "#2574D2");
				return;
			}
		}else{
			App._closeTimerListener();
			return;
		}
		App.intervalID = setTimeout("App._startTimerListener()", 1000);
	},
	_getTimer:function(){
		var time = new Date().getTime();
		return Math.floor((time-App._initTime)/1000);
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061910.html")},1500);
	},
	/**
	 * 清除计时器
	 * @param id
	 */
	_closeTimerListener: function(){
		if(App.intervalID){ // 当intervalID存在时，清空
			clearTimeout(App.intervalID);
			$("#yzm").removeAttr("disabled");//启用按钮
            $("#yzm").text("重新获取");
            App.timer = 60;
            App.intervalID = null;
		}
	}
	

};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);