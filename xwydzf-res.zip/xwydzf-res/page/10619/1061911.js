/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.initPage();
		Fw.Layer.hideWaitPanel(); //关闭等待层
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#lineBGDZ", App.BGDZ);
		// 本行银行卡号
		App.pageA.on("porpertychanger","#cardNo",App.toCheck);
		App.pageA.on("input","#cardNo",App.toCheck);
		//企业证件号码
		App.pageA.on("blur", "#SJ1", App.removeKong1);
		App.pageA.on("input",".textInput",App.removeKong1);// 控制输入字节数
		App.pageA.on("porpertychanger",".textInput",App.removeKong1);
		// 下一步
		App.pageA.on("click", "#btnNext", App.gotoNext);
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				App.data.cardNo =$("#cardNo").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
				App.data.firmIdNo = $("#SJ1").val().replace(/ /g,""); //企业证件号码
				Fw.redirect("1061910.html",App.data);
		   },false);
		},false)
	},
	BGDZ:function(){
	   weui.picker(
			   [
			    {label:"居民身份证或临时身份证",value:'0'},
			    //{label:"企业客户营业执照",value:"1"},
			    //{label:"企业代码证",value:"2"},
			    //{label:"商业登记证（香港）",value:"F"},
			    //{label:"SWIFT BIC",value:"S"},
			    //{label:"企业客户其他有效证件",value:"3"},
			      {label:"军人身份证",value:"4"},
			      {label:"武警身份证",value:"5"},
			      {label:"港、澳、台居民有效身份证",value:"6"},
			      {label:"外国护照",value:"7"},
			      {label:"个人客户其他有效证件",value:"8"},
			      {label:"中国护照",value:"9"},
			      {label:"港澳居民来往内地通行证",value:"A"},
			      {label:"台湾居民来往大陆通行证",value:"B"},
			      {label:"外国人永久居留证",value:"C"},
			      {label:"户口薄",value:"D"},
			    //{label:"公司注册证明书（香港）",value:"G"},
			    //{label:"社会团体法人登记证书",value:"I"},
			    //{label:"个体工商户营业执照",value:"L"},
			    //{label:"事业单位法人登记证",value:"Y"},
			   ],
			   {
				   className:"custom-className",
				   container:'body',
				  defaultValue:[ App.data.idType||"0"+""],
				   onChange:function(v){
				   },
				   onConfirm:function(result){
					   $("#BGDZ").html(result[0].label)
					   App.data.idType=result[0].value
					   App.data.label=result[0].label
					   App.toCheck();
					},
				   id:"BGDZ"
			   }
	   )
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061910.html")},1500);
	},
	/**
	 * 初始化页面
	 */
	initPage : function() {
		if(App.data ){
			if(App.data.cardNo){
				$("#cardNo").val(App.data.cardNo);
			}
		    if(App.data.label){
			   $("#BGDZ").html(App.data.label)
			}
		    if(App.data.firmIdNo){
		       $("#SJ1").html(App.data.firmIdNo)
		    }
		    App.toCheck();
		}
	},
	/**
	 * 企业证件号码
	 */
	removeKong1:function(){
		var w=0;//字节数
		for(var i=0;i<$(this).val().length;i++){
			var c=$(this).val().charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>32){
				$("#SJ1").val($(this).val().substring(0,i));
				$("#SJ1").blur();
				break;
			}
		}
		App.toCheck();
	},
	toCheck:function(){
		var cardNo =$("#cardNo").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		var mobile1 = $("#SJ1").val().replace(/ /g,""); //企业证件号码
		var BGDZ=$("#BGDZ").html().trim();
		if (cardNo&& mobile1&& BGDZ!="请选择") {
			$("#btnNext").removeAttr("disabled", "");
			$("#btnNext").css("background-image","linear-gradient(-135deg, #217DCA 0%, #46B4E7 96%)")
		}else{
			$("#btnNext").attr("disabled", "disabled");
			$("#btnNext").css("background-image","unset")
			$("#btnNext").css("background","#B5BFCC")
		}
	},
	/**
	 * 下一步
	 */
	gotoNext : function() {
		var cardNo =$("#cardNo").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		var zjh = $("#SJ1").val().replace(/ /g,""); //企业证件号码
		var BGDZ=$("#BGDZ").html();
		if (cardNo=="") {
			Fw.Form.showPinLabel($(this), "请输入本行银行卡号!", true);
			$("#cardNo").focus();
			return;
		}
		if (zjh == "") {
			Fw.Form.showPinLabel($(this), "请输入正确企业证件号码!", true);
			$("#SJ1").focus();
			return;
		}
		if (BGDZ == "请选择") {
			Fw.Form.showPinLabel($(this), "请选择企业主证件类型!", true);
			return;
		}
	 App.data.cardNo=cardNo
		var params = {
			    firmName: App.data.firmName, 
				cardNo:cardNo,
				idNo:zjh,
				mobile:App.data.mobile,
				idType:App.data.idType,
				productCode:App.data.financingPreApply.productCode,
				productVersion:App.data.financingPreApply.productVersion
		}
		App.data.firmIdNo=zjh
		Fw.Layer.openWaitPanel(); //开启等待层
		var url0=YT.dataUrlWeb("private/creditAuthorize");
		YT.ajaxDataWeb(url0, params, function(data0) {
			if(data0.STATUS == "1"){
				App.data.firmOwerName=data0.firmOwerName;
				App.data.applyNo=data0.applyNo
				App.data.financingProduct=data0.financingProduct
				var url = YT.dataUrlWeb("private/preApplyES001");
				var params1 = {
						cardNo:cardNo,
						idNo:zjh,
						contractType:"y7",
						firmOwerName:data0.firmOwerName,
						idType:App.data.idType,
						mobile:App.data.mobile,
						areaCode:App.data.financingPreApply.brCode,
						orgCode:App.data.financingPreApply.orgCode
				}
				YT.ajaxDataWeb(url, params1, function(data) {
				    if (data.STATUS == "1") {
				       App.data.eSignNo=data.result.eSignNo;
				       App.data.downFilePath=data.downFilePath;
				       App.data.idNo=zjh;
					   Fw.redirect("1061912.html", App.data);
					} else {
						Fw.Layer.hideWaitPanel(); //关闭等待层
						Fw.Form.showPinLabel($(this), data.MSG, true);
						return;
					 }
			     });
			}else {
				Fw.Layer.hideWaitPanel(); //关闭等待层
				Fw.Form.showPinLabel($(this), data0.MSG, true);
				return;
			 }
		    
		});

	}

};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);