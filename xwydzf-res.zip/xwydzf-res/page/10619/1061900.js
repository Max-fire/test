/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.initEvent();
		App.initData();
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		var scale=1/window.devicePixelRatio,deviceWidth=document.documentElement.clientWidth;
		document.documentElement.style.fontSize=deviceWidth/7.5+'px';
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				WeixinJSBridge.call('closeWindow');
			 },false);
		},false)
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	initData : function(){
		
		Fw.Layer.openWaitPanel();
		var url = YT.dataUrlWeb("private/queryFinancingProduct");
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url,{},function(data){
			
			if(data.STATUS=="1"){
				if(data.List){
					App.loadData(data.List);	
				}else{
					$("#list").html("暂无产品信息~");
					$("#list").addClass("prodList_none");
				}
			}else{
				$.tips({
					content:data.MSG,
					stayTime:2000,
					type:"fail",
				})
			}
			Fw.Layer.hideWaitPanel();
		});
	},
	loadData:function(list){
		
		var html='';
		App.list=list;
		for(var i=0;i<list.length;i++){
			var money=parseInt(list[i].maxAmount)+'';
			if(money.length>4){
				money=money.substring(0,money.length-4)+'万<span>元</span>';
			}else{
				money=money+'<span>元</span>';
			}
			html+='<div class="list_item" onClick="App.gotoDetail('+i+')">'+
						'<div class="item_left">'+
							'<div>'+money+'</div>'+
							'<p>最高额度</p>'+
						'</div>'+
						'<div class="item_right">'+
							'<div id="productName">'+list[i].productName+'</div>'+
							'<p>每月付息，到期还本</p>'+
							'<p>年利率≥'+list[i].minYearRate+'%</p>'+
						'</div><img style="float:right;width: 10px;padding:38px 20px 0 0;" src="../../css/img/choosetime.png"/>'+
					'</div>';
		}
		
		$("#list").html(html);
		
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061900.html")},1500);
	},
	gotoDetail:function(i){
		var json={
				list:App.list[i]
		}
		Fw.redirect("1061901.html",json);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);