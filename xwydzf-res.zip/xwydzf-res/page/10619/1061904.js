/**
 * 创建应用
 * @author 
 */
var App = {
	requires : ['Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
			Fw.Client.hideWaitPanel();
			App.func = window['_getParameter'];
			App.pageA = $("#pageA");
			App.data = Fw.getParameters();
			App.initEvent();
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pushHistory();
		window.addEventListener("popstate",function(e){
			Fw.redirect("1061900.html");
	},false);
	},
	
	onGobtn:function(v) {
		Fw.redirect("1061900.html");
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061900.html")},1500);
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
