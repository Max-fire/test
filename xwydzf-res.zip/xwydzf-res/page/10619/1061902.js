/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		//alert(YT.JsonToStr(App.data))
		App.flag = false;
		App.brCode="";
		App.orgCode="";
		//预约办理分行查询
		App.initKHZH();
		App.initEvent();
		//alert(sessionStorage.getItem("org"));
		Fw.Layer.hideWaitPanel(); //关闭等待层
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 检查姓名
		 App.pageA.on("blur", "#name", App.checkName);
		// 动态校验姓名位数
		App.pageA.on("input","#name",App.checkNameNum);
		App.pageA.on("porpertychanger","#name",App.checkNameNum);
		App.pageA.on("input","#name",App.toCheck);	
		// 开户支行-事件
		//App.pageA.on("click", "#KHZH", App.initKHZH);
		App.pageA.on("change", "#KHZH", App.initKHZH1);
		// 网点-事件
		//App.pageA.on("click", "#KHWD", App.initKHWD);
		App.pageA.on("change", "#KHWD", App.initKHWD1);
		// 下一步
		App.pageA.on("click", "#btnSubmit1", App.next);
		// 失去焦点去空格
		App.pageA.on("blur", "#mobile", App.removeKong);
		App.pageA.on("porpertychanger","#mobile",App.toCheck);
		App.pageA.on("input","#mobile",App.toCheck);
		App.pageA.on("porpertychanger","#applyAmt",App.toCheck);
		App.pageA.on("input","#applyAmt",App.toCheck);
		App.pageA.on("blur","#applyAmt",App.toFmtAmount);
		App.pageA.on("porpertychanger","#loanTerm",App.toCheck);
		App.pageA.on("input","#loanTerm",App.toCheck);
		App.pageA.on("porpertychanger","#meg_code",App.toCheck);
		App.pageA.on("input","#meg_code",App.toCheck);
		
		App.pageA.on("click", "#yzm", App.toYZM);
		
		App.pageA.on("click", "#selspan", App.alinfo);
		App.pushHistory();
		App.pageA.show();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				Fw.redirect("1061901.html",App.data);
		   },false);
		},false)
		if(App.data.list.productDescription){$("#js").html(App.data.list.productDescription)}
        if(App.data.list.minYearRate){$("#nl").html(App.data.list.minYearRate+"%")}
        if(App.data.list.maxAmount){
        	var money=parseInt(App.data.list.maxAmount)+'';
			if(money.length>4){
				money=money.substring(0,money.length-4)+'万';
			}else{
				money=money+'元';
			}
        	 $("#zge").html(money)
        }
        if(App.data.list.productName){$("#product").html(App.data.list.productName)};
        $("#applyAmt").attr("placeholder"," 最高可申请额度￥"+Fw.util.Format.fmtAmt(App.data.list.maxAmount+""))
        for ( var i = 1; i <=App.data.list.singleLoanTerm ; i++) {
        	var html = '<option value='+i+'>'
				+ i + '</option>';
		$("#loanTerm").append(html);
		}
	},
	toFmtAmount:function(){
		var amount=Fw.util.Format.delFmtMony($("#applyAmt").val()+"");
		$("#applyAmt").val(Fw.util.Format.fmtAmt(amount));
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	/**
	 * 初始化页面(上个页面传送过来)
	 */
	initPage : function() {
		if (App.data) {
			// 页面赋值
			document.title=App.data.list.productName+"申请"
			$("#name").val(App.data.acctApplyInfo.operatorName);
			$("#mobile").val(App.data.acctApplyInfo.operatorPhone);
			$("#applyAmt").val(App.data.acctApplyInfo.applyAmt);
			$("#loanTerm").val(App.data.acctApplyInfo.loanTerm);
			App.orgCode = App.data.acctApplyInfo.applyOrgCode;
			App.brCode = App.data.acctApplyInfo.applyAreaCode;
			$("#meg_code").val("");
		    $("#name").blur();
			// 页面加载完成后初始化网点
			$("#KHWD").removeClass("hidden");//span select状态切换用于解决安卓部分不适配
			$("#selspan").addClass("hidden");
			App.initKHWD();
			if (sessionStorage.getItem("org")) {
				//console.log("有缓存且sessionStorage中有org不为空和 null");
				org = sessionStorage.getItem("org");
				App.initOrgPage(org);
			}
		} 

	},
	toCheck:function(){
		var name = $("#name").val().replace(/(^\s*)|(\s*$)/g,"");
		var mobile = $("#mobile").val().replace(/ /g,"");
		var applyAmt = Fw.util.Format.delFmtMony($("#applyAmt").val()+"");
		var loanTerm = $("#loanTerm").val();
		var KHZH = $("#KHZH option:selected").val();
		var KHWD = $("#KHWD option:selected").val();
		var code = $("#meg_code").val();
		if (name && mobile && KHZH && KHWD&&code&&KHZH!="请选择"&&KHWD!="请选择"&&applyAmt&&loanTerm) {
			$("#btnSubmit1").removeAttr("disabled", "");
			$("#btnSubmit1").css("background-image","linear-gradient(-135deg, #217DCA 0%, #46B4E7 96%)")
		}else{
			$("#btnSubmit1").attr("disabled", "disabled");
			$("#btnSubmit1").css("background-image","unset")
			$("#btnSubmit1").css("background","#B5BFCC")
		}
	},
	onShowpro:function(){
		$("#black_b").css("display", "");
		$("#white_b").css("display", "");
	},
	onHidepro:function(){
		$("#black_b").css("display", "none");
		$("#white_b").css("display", "none");
	},
	/**
	 * session方式匹配org
	 */
	initOrgPage : function(org) {
		// 事件不能点击
		$("#KHZH").attr("disabled", "disabled");
		$("#KHWD").removeClass("hidden");
		$("#selspan").addClass("hidden");
		$("#KHWD").attr("disabled", "disabled");
		
		// 匹配分行网点信息
		App.initOrgKHWD(org);
	},
	/**
	 * 取下标方式匹配org 
	 */
	initIndexorgPage : function() {
		// 点击事件关闭
		$("#KHZH").attr("disabled", "disabled");
		$("#KHWD").removeClass("hidden");
		$("#selspan").addClass("hidden");
		$("#KHWD").attr("disabled", "disabled");

		// org 长度判断
		org = App.func("org", window.location.href);
		if (org.length != "5") {
			App.brCode = ""
			App.orgCode = ""
			sessionStorage.setItem("org", "0");
			alert('网点信息有误，请联系网点核实！')
			return;
		}
		// 匹配分行网点信息
		App.initOrgKHWD(org);
		
	},
	/**
	 * 匹配网点 
	 */
	initOrgKHWD:function(org){
		// 匹配分行网点信息
		for ( var j = 0; j < App.khfh.brList.length; j++) {
			if (App.khfh.brList[j].brCode == org.substring(0, 2)) {
				App.brCode = App.khfh.brList[j].brCode;
				//console.log("App.brCode:" + App.brCode);
				var html = '<option selected="selected" >'
						+ App.khfh.brList[j].brName + '</option>';
				$("#KHZH").html("");
				$("#KHZH").append(html);
				break;
			}
		}
		if (App.brCode == "") {
			sessionStorage.setItem("org", "0");
			alert('网点信息有误，请联系网点核实！')
			return;
		}
		// 匹配网点
		var params = {
			brCode : App.brCode,
			type : "2"
		};
		var url = YT.dataUrlWeb("private/branchInfo");
		YT.ajaxDataWeb(url, params, function(data) {
			if (data.STATUS == "1") {
				for ( var i = 0; i < data.orgList.length; i++) {
					if (data.orgList[i].orgCode == org.substring(2, 5)) {
						App.orgCode = data.orgList[i].orgCode;
						var tel=data.orgList[i].tel?data.orgList[i].tel.trim():"";
						tel=tel||"意向网点"
						App.data.tel = tel;
						//console.log("App.orgCode:" + App.orgCode);
						var html = '<option selected="selected" >'
								+ data.orgList[i].orgName + '</option>';
						$("#KHWD").html("");
						$("#KHWD").append(html);
						break;
					}
				}
				if (App.orgCode == "") {
					sessionStorage.setItem("org", "0");
					alert('网点信息有误，请联系网点核实！')
					return;
				}
				sessionStorage.setItem("org", org);
			} else {
				Fw.Layer.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});
	},
	/**
	 * 检查姓名位数 
	 */
	checkNameNum:function(){
		var w=0;//字节数
		var name=$("#name").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>30){
				name=name.substring(0,i);
				$("#name").val(name);
				$("#name").blur();
				break;
			}
		}
		if(sessionStorage.getItem("org")=="0"){
			alert('网点信息有误，请联系网点核实！')
			return;
		}
		App.toCheck();
	},
	/**
	 * 检查姓名合法性 
	 */
	checkName:function(){
		var name = $("#name").val();
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (name == "") {
			Fw.Form.showPinLabel($(this), "姓名不能为空!", true);
			return;
		}
		if (nnm.test(name)||Fw.util.proofTest.proolEmoji(name)) {
			Fw.Form.showPinLabel($(this), "姓名不能含有非法字符!", true);
			return;
		}
		$("#name").css("text-align","right");
	},
   /**
	 * 
	 */
	removeKong:function(){
		var mobile = $("#mobile").val().replace(/ /g,"");
		 $("#mobile").val(mobile);
		 if(sessionStorage.getItem("org")=="0"){
				alert('网点信息有误，请联系网点核实！')
				return;
		 }
	},
	
	/**
	 * 选择开户地区(分行)
	 */
	initKHZH : function() {
		var html = "";
		var url = YT.dataUrlWeb("private/branchInfo");
		var params = {
			type : "1"
		};
		YT.ajaxDataWeb(url,params,	function(data) {
			App.khfh=data;//预约办理分行赋值用于org参数存在判断
			if (data.STATUS == "1") {
				html+='<option selected="selected" >请选择</option>';
				for ( var i = 0; i < data.brList.length; i++) {
					if (App.data && App.data.acctApplyInfo) {
						if (App.data.acctApplyInfo.applyAreaCode==data.brList[i].brCode) {
							html+='<option id="opt'+i+'" selected="selected" data-value="'+data.brList[i].brCode+'">'+data.brList[i].brName+'</option>';
						}else{
							html+='<option id="opt'+i+'" data-value="'+data.brList[i].brCode+'">'+data.brList[i].brName+'</option>';
						}
					}else{
						
						html+='<option id="opt'+i+'" data-value="'+data.brList[i].brCode+'">'+data.brList[i].brName+'</option>';
					}
				}
				$("#KHZH").html("");
				$("#KHZH").append(html);
				App.initPage();
				} else {
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
					}
		});

	},
	initKHZH1:function(){
		if($("#KHZH option:selected").val()!="请选择"){
			var optid=$("#KHZH option:selected").attr("id");
			App.brCode=$("#"+optid+"").attr("data-value");
			if (App.data && App.data.acctApplyInfo) {
				if( $("#KHZH option:selected").val() == App.data.acctApplyInfo.applyAreaName){
					App.orgCode= App.data.acctApplyInfo.applyOrgCode ;
				}else{
					App.orgCode= "";
				}
			}else{
				App.orgCode= "";
			}
			$("#KHWD").removeClass("hidden");
			$("#selspan").addClass("hidden");
			App.initKHWD();
		}else{
			App.brCode="";
			App.orgCode="";
			$("#KHWD").addClass("hidden");
			$("#selspan").removeClass("hidden");
			App.pageA.on("click","#selspan",App.alinfo);
		}
		App.toCheck();
	},
	alinfo:function(){
		Fw.Form.showPinLabel($(this), "请选择预约办理分行!", true);
		return;
	},
	/**
	 * 选择网点
	 */
	initKHWD : function() {
		
		if(!sessionStorage.getItem("org")){
			if(App.brCode==""){
				Fw.Form.showPinLabel($(this), "请选择预约办理分行!", true);
				return;
			}
		}
		Fw.Layer.openWaitPanel();
		var url = YT.dataUrlWeb("private/branchInfo");
		var params = {
			brCode : App.brCode,
			type : "2"
		}
		var html="";
		var j=0;
		YT.ajaxDataWeb(url,params,function(data) {
			if (data.STATUS == "1") {
				html+='<option selected="selected" >请选择</option>';
				for ( var i = 0; i < data.orgList.length; i++) {
					var tel=data.orgList[i].tel?data.orgList[i].tel.trim():"";
					tel=tel||"意向网点"
					if (App.data && App.data.acctApplyInfo) {
						if (App.data.acctApplyInfo.applyOrgCode==data.orgList[i].orgCode) {
							html+='<option id="khwd'+i+'" selected="selected" data-value="'+data.orgList[i].orgCode+','+tel+'">'+data.orgList[i].orgName+'</option>';
						}else{
							html+='<option id="khwd'+i+'" data-value="'+data.orgList[i].orgCode+','+tel+'">'+data.orgList[i].orgName+'</option>';
						}
					}else{
						html+='<option id="khwd'+i+'" data-value="'+data.orgList[i].orgCode+','+tel+'">'+data.orgList[i].orgName+'</option>';
					}
					j++;
				}
				if (j==data.orgList.length) {
					Fw.Layer.hideWaitPanel();
				}
					$("#KHWD").html("");
					$("#KHWD").append(html);
					Fw.Layer.hideWaitPanel();

			} else {
				Fw.Layer.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			 	}
		});

	},
	/**
	 *网点点击事件 
	 */
	initKHWD1 : function() {
		if($("#KHWD option:selected").val()!="请选择"){
			var optid=$("#KHWD option:selected").attr("id");
			App.orgCode=$("#"+optid+"").attr("data-value").split(",")[0];
			App.data.tel=$("#"+optid+"").attr("data-value").split(",")[1];
		}else{
			App.orgCode="";
			App.data.tel="";
		}
		App.toCheck();
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061900.html")},1500);
	},
	/**
	 * 下一步
	 */
	next : function(e) {
		e.stopPropagation();
		if(sessionStorage.getItem("org")=="0"){
			alert('网点信息有误，请联系网点核实！')
			return;
	    }
		var name = $("#name").val().replace(/(^\s*)|(\s*$)/g,"");
		var mobile = $("#mobile").val().replace(/ /g,"");
		// alert(mobile);
		var KHZH = $("#KHZH option:selected").val();
		var KHWD = $("#KHWD option:selected").val();
		var code = $("#meg_code").val();
		var tel =  /^(1)[0-9]{10}$/;
		var applyAmt=Fw.util.Format.delFmtMony($("#applyAmt").val()+"");
		var loanTerm=$("#loanTerm").val();
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (name == ""||name.length<'2') {
			Fw.Form.showPinLabel($(this), "请输入正确姓名!", true);
			$("#name").focus();
			return;
		}
		if (nnm.test(name)||Fw.util.proofTest.proolEmoji(name)) {
			Fw.Form.showPinLabel($(this), "姓名不能含有非法字符!", true);
			$("#name").focus();
			return;
		}
		if (mobile == "" || mobile.length != '11') {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			$("#mobile").focus();
			return;
		}
		if (!tel.test(mobile)) {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			$("#mobile").focus();
			return;
		}
		if (!applyAmt) {
			Fw.Form.showPinLabel($(this), "请输入申请金额!", true);
			$("#applyAmt").focus();
			return;
		}
		if (!loanTerm) {
			Fw.Form.showPinLabel($(this), "请输入贷款期限!", true);
			$("#loanTerm").focus();
			return;
		}
		if (applyAmt*1>App.data.list.maxAmount*1) {
			Fw.Form.showPinLabel($(this), "贷款申请额度不得高于"+App.data.list.maxAmount+"元!", true);
			return;
		}
		if (applyAmt*1<App.data.list.minAmount*1) {
			Fw.Form.showPinLabel($(this), "贷款申请额度不得低于"+App.data.list.minAmount+"元!", true);
			return;
		}
		if (loanTerm*1>App.data.list.singleLoanTerm) {
			Fw.Form.showPinLabel($(this), "贷款期限不得高于"+App.data.list.singleLoanTerm+"月!", true);
			return;
		}
		if (KHZH == "请选择") {
			Fw.Form.showPinLabel($(this), "请选择预约办理分行!", true);
			return;
		}
		if ($("#KHWD").hasClass("hidden") || KHWD=="请选择") {
			Fw.Form.showPinLabel($(this), "请选择网点!", true);
			return;
		}
		if(App.brCode!="35"){
			var tips="尊敬的客户：您好！当前您所选择的机构暂未" +
					"开放在线融资微信预申请业务，如您有融资需求，请联系" +
					App.data.tel+"咨询";
			$(document).scrollTop(0);
			Fw.Client.alertinfo(tips,"系统提示");
			return;
		}
		if (code == "") {
			Fw.Form.showPinLabel($(this), "验证码不能为空!", true);
			$("#meg_code").focus();
			return;
		}
		if (code.length != '6') {
			Fw.Form.showPinLabel($(this), "验证码必须为6位!", true);
			$("#meg_code").focus();
			return;
		}
		 var num=/[0-9]{6}/;
		 if (!num.test($("#meg_code").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		var params = {
			mobile:mobile,
			smsCode : code,
		}

		if(App.data!= null&&App.data.acctApplyInfo!=null){
			if(App.data.acctApplyInfo.applyInfoSerial!=null){
				params.applyInfoSerial=App.data.acctApplyInfo.applyInfoSerial+"";
				if(App.data.acctApplyInfo.operatorPhone!=mobile){
					delete params.applyInfoSerial;
					
				}
			}
			
		}
		App.data.acctApplyInfo={};
		App.data.acctApplyInfo.operatorName=name;
		App.data.acctApplyInfo.operatorPhone=mobile;
		App.data.acctApplyInfo.applyAreaCode=App.brCode;
		App.data.acctApplyInfo.applyOrgCode=App.orgCode;
		App.data.acctApplyInfo.applyAmt=applyAmt;
		App.data.acctApplyInfo.loanTerm=loanTerm;
		var url = YT.dataUrlWeb("private/preApplyValidSmsCode");
		Fw.Layer.openWaitPanel();  	//等待层开启
		YT.ajaxDataWeb(url, params, function(data) {
			if (data.STATUS == "1") {
					  Fw.redirect("1061903.html", App.data);
				  }
			else {
				Fw.Layer.hideWaitPanel(); //关闭等待层
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});

	},
	toYZM:function(){
		var tel =  /^(1)[0-9]{10}$/;
		 if (!tel.test( $("#mobile").val())|| $("#mobile").val() == "" ||  $("#mobile").val().length != "11") {
			 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			 return;
		 }
		var param={
				mobile : $("#mobile").val(),
				type : "16"
		}
		
		var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
			var html="已向手机"+phone+"发送短信验证码，请注意查收";
			$("#yzm").val("");
			var url = YT.dataUrlWeb('normal/tr3888.json');
			Fw.Layer.openWaitPanel();  	//等待层开启
			YT.ajaxDataWeb(url, param, function(rsp){
				if(rsp.STATUS == '1'){
				    Fw.Layer.hideWaitPanel();
					App.timer=60;
					App._initTime = new Date().getTime()-1000;
					App._sumTime = 60;
					App._startTimerListener();
					callback && callback();
				}else{
					Fw.Form.showPinLabel($(this), rsp.MSG, true);
					Fw.Layer.hideWaitPanel();
					return;
					//YT.alertinfo(rsp.MSG);
				}
			},function(data){
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Layer.hideWaitPanel();
				return;
				//YT.alertinfo(data.MSG);
				
			});
	},
	/**
	 * 打开短信验证码计时器
	 */
	_startTimerListener: function(){
		if(App.timer > 0){
			var time = App._getTimer();
			App.timer = App._sumTime - time;
			if(App.timer>0){
				$("#yzm").text(App.timer + '秒后重发');
				$("#yzm").attr("disabled", true);
				$("#yzm").css("background", "#B5BFCC");
			}else{
				App._closeTimerListener();
				$("#yzm").css("background", "#2574D2");
				return;
			}
		}else{
			App._closeTimerListener();
			return;
		}
		App.intervalID = setTimeout("App._startTimerListener()", 1000);
	},
	_getTimer:function(){
		var time = new Date().getTime();
		return Math.floor((time-App._initTime)/1000);
	},
	
	/**
	 * 清除计时器
	 * @param id
	 */
	_closeTimerListener: function(){
		if(App.intervalID){ // 当intervalID存在时，清空
			clearTimeout(App.intervalID);
			$("#yzm").removeAttr("disabled");//启用按钮
            $("#yzm").text("重新获取");
            App.timer = 60;
            App.intervalID = null;
		}
	}
	

};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);