/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.xy=false;
		App.initEvent();
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#rz",App.toLook);
		App.pageA.on("porpertychanger","#userName",App.toCheck);
		App.pageA.on("input","#userName",App.toCheck);
		App.pageA.on("porpertychanger","#idCard",App.toCheck);
		App.pageA.on("input","#idCard",App.toCheck);
		App.pageA.on("porpertychanger","#swmm",App.toCheck);
		App.pageA.on("input","#swmm",App.toCheck);
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				Fw.redirect("1061903.html",App.data);
		   },false);
		},false)
		if (App.data) {
			if (App.data.firmIdNo) {
				$("#swNo").val(App.data.firmIdNo);
			}
			if (App.data.swmm) {
				$("#swmm").val(App.data.swmm);
			}
			if (App.data.userName) {
				$("#userName").val(App.data.userName);
			}
			if (App.data.idCard) {
				$("#idCard").val(App.data.idCard);
			}
			if (App.data.xy) {
				App.xy=App.data.xy;
			}
		}
		App.toCheck();
		YT.showPageArea(App.pageA, [], true);
		
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061900.html")},1500);
	},
	toLook:function(){
		if (!App.xy) {
			Fw.Form.showPinLabel($(this), "请您认真阅读《涉税数据查询授权书》", true);
			$("#rz").prop("checked","")
			return;
		}else{
			App.toCheck();
		}
	},
	toCheck:function(){
		var swmm=$("#swmm").val();
		var userName=$("#userName").val();
		var idCard=$("#idCard").val();
		if (swmm && userName && idCard && $("#rz:checked").val()) {
			$("#btnSubmit").removeAttr("disabled", "");
			$("#btnSubmit").css("background-image","linear-gradient(-135deg, #217DCA 0%, #46B4E7 96%)")
		}else{
			$("#btnSubmit").attr("disabled", "disabled");
			$("#btnSubmit").css("background-image","unset")
			$("#btnSubmit").css("background","#B5BFCC")
		}
	},
	toSubmit:function(){
		var swmm=$("#swmm").val();
		var reswmm=Sm2.encode(CryptoJS.enc.Hex.stringify(CryptoJS.enc.Utf8.parse(swmm)));
		var userName=$("#userName").val();
		var idCard=$("#idCard").val();
		if (!swmm) {
			Fw.Form.showPinLabel($(this), "请输入税务密码!", true);
			return;
		}
		if (!userName) {
			Fw.Form.showPinLabel($(this), "请输入用户姓名!", true);
			return;
		}
		if (!idCard) {
			Fw.Form.showPinLabel($(this), "请输入身份证号码!", true);
			return;
		}
		if (!$("#rz:checked").val()) {
			Fw.Form.showPinLabel($(this), "请勾选涉税数据查询授权书!", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var url = YT.dataUrlWeb("private/preFinancingTaxInfoQuery");
		var json={
				firmOwerId:idCard,
				taxRegistNo:App.data.firmIdNo+"",
//				firmOwerId:"330719196307092213",
//				taxRegistNo:"913307827519312795",
				bankName:"兴业银行",
				netPassWord:reswmm,
		}
	    YT.ajaxDataWeb(url,json,function(data){
	    	if (data.STATUS=="1") {
	    		Fw.redirect("1061904.html")
	    		Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			}
	    },App.fail);
	},
	fail:function(data){
		Fw.Client.alertinfo(data.MSG,"系统提示");
		Fw.Client.hideWaitPanel();
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
        Fw.Client.alertinfo(data.MSG,"消息提示");
	},
	/**
	 * 涉税信息查询授权书
	 */
	gotoSQ:function(){
		App.xy=true;
		var swmm=$("#swmm").val();
		var userName=$("#userName").val();
		var idCard=$("#idCard").val();
		var json={};
		if (App.data) {
			App.data.swmm=swmm;
			App.data.userName=userName;
			App.data.idCard=idCard;
			json=App.data;
		}else{
			json.swmm=swmm;
			json.userName=userName;
			json.idCard=idCard;
		}
		json.xy=App.xy;
		Fw.redirect("sssq.html",json)
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);