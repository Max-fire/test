/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.result={};
		App.initEvent();
		App.initData();
    },
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#grsq",App.toGRSQ);
		App.pageA.on("click","#rz",App.toCheckXY);
		App.pageA.on("input","#msgCode",App.toCheck);
		App.pageA.on("porpertychanger","#msgCode",App.toCheck);
		
		App.pageA.on("click","#close_btn",App.hidePDF);
		
		var params = {
				mobile:App.data.mobile,
				eSignNo:App.data.eSignNo,
				firmOwerName:App.data.firmOwerName,
				idNo:App.data.idNo
		};
		sendUtil.openTimerListener("yzm",params, true);

		var scale=1/window.devicePixelRatio,deviceWidth=document.documentElement.clientWidth;
		document.documentElement.style.fontSize=deviceWidth/7.5+'px';
	},
	/**
	 * 
	 */
	initData:function(){
		//緩存頁面數據
		if(App.data){
			$("#firmName").html(App.data.financingPreApply.firmName);
			$("#productName").html(App.data.financingPreApply.productName);
			
			if(App.data.isCheck){
				$("#rz").prop("checked","checked")
			}
			if(App.data.msgCode){
				$("#msgCode").val(App.data.msgCode)
			}
			App.toCheck();
			
			var loc = document.location;
			var protocol = loc.protocol;
			var host = loc.host;
			var path=protocol + '//' + host
			var pdfUrl=path+App.data.downFilePath;
			$("#frame_pdf").attr("src",basePath+"/page/10618/css/pdf/web/viewer.html?url="+pdfUrl);
		}
		//微信返回
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				App.data.hasRead=false;
				App.data.isCheck=false;
				Fw.redirect("1061911.html",App.data);
			 },false);
		},false)
		
	},
	toCheckXY:function(){
		if (!App.data.hasRead) {
			Fw.Form.showPinLabel($(this), "请您认真阅读相关协议", true);
			$("#rz").prop("checked","")
			return;
		}
		App.toCheck();
	},
	toCheck:function(){
		if ($("#rz:checked").val() && $("#msgCode").val().length=='6') {
			$("#btnSubmit").removeAttr("disabled", "");
		}else{
			$("#btnSubmit").attr("disabled", "disabled");
		}
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	toSubmit:function(){
		
		if($("#rz:checked").val()==null){
			Fw.Form.showPinLabel($(this), "请勾选授权协议", true);
			return;
		}
		if(!$("#msgCode").val()){
			Fw.Form.showPinLabel($(this), "请输入验证码", true);
			return;
		}
		if($("#yzm").html()=="发送验证码"){
			Fw.Form.showPinLabel($(this), "请获取数字认证码", true);
			return;
		}
		App.preApplyAuthorize();
	},
	/**
	 * 签名
	 */
	preApplyAuthorize:function(){
		
		var url1= YT.dataUrlWeb("private/preApplyAuthorize");
		var params={
				eSignNo:App.data.eSignNo,
				id:App.result.result.id,
				smsCode:$("#msgCode").val(),
				mobile:App.data.mobile,
				firmOwerName:App.data.firmOwerName,
				idType:App.data.idType,
				idNo:App.data.idNo,
				firmName:App.data.firmName,
				applyNo:App.data.applyNo
		}
		Fw.Layer.openWaitPanel();
		var url = YT.dataUrlWeb("public/getRandomNum");
		YT.ajaxDataWeb(url,{},function(data1){
			if(data1.STATUS == "1"){
				YT.ajaxDataWeb(url1, params, function(data) {
					if (data.STATUS == "1") {
						App.data.filePath=data.filePath;
						Fw.redirect("1061914.html",App.data);
					}else{
						Fw.Form.showPinLabel($(this), data.MSG, true);
					}
					Fw.Layer.hideWaitPanel();
					},function(data){
						Fw.Layer.hideWaitPanel();
						Fw.Form.showPinLabel($(this), data.MSG, true);
					})
			}else{
				Fw.Layer.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data1.MSG, true);
			}
		});
		
	},
	showCallBack:function(data){
		//preApplyES007返回
		App.result=data;
	},
	/**
	 * 查看个人征信授权书
	 */
	toGRSQ:function(){

		App.data.hasRead=true;
		$("#black_b").removeClass("hidden");
		$("#close_btn").removeClass("hidden");
		$("#frame_pdf").removeClass("hidden");
		
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host
		var pdfUrl=path+App.data.downFilePath;
		$("#frame_pdf").attr("src",basePath+"/page/10618/css/pdf/web/viewer.html?url="+pdfUrl);
		
	},
	hidePDF:function(){
		$("#close_btn").addClass("hidden");
		$("#frame_pdf").addClass("hidden");
		$("#black_b").addClass("hidden");
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061910.html")},1500);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);