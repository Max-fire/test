/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		var ua=navigator.userAgent.toLowerCase();
		try{
			if(ua.match(/MicroMessenger/i)){
				App.initWX();
			}else{
				App.initAPP();
			}
		}catch(e){
			alert(e)
			}
	},
	/**
	 * 微信端
	 */
	initWX : function() {
		//返回
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				Fw.redirect(App.data.page,App.data);
			 },false);
		},false)
		
		//pdf展示
		$("#pdf").attr("src",basePath+"/page/10618/css/pdf/web/viewer.html?url="+App.data.pdfUrl);
		if(App.data.title){
			document.title=App.data.title;
		}else{
			document.title="PDF展示";
		}
		
	},
	/**
	 * APP端
	 */
	initAPP:function(){
		
		var url=App.data.pdfUrl;
		url=basePath+"/page/10618/css/pdf/web/viewer.html?url="+url;
		if(App.data.title){
			$("#pageA").attr("title",App.data.title);
		}else{
			$("#pageA").attr("title","PDF展示");
		}
		Fw.Client.changeWeb(url,false,pageA);
		
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061910.html")},1500);
	},
	/**
	 * App返回
	 */
	goBack:function(){
		Fw.redirect(App.data.page,App.data);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);