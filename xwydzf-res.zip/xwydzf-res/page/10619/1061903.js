/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.initPage();
		Fw.Layer.hideWaitPanel(); //关闭等待层
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		// 检查公司名称
		//App.pageA.on("blur", "#GSMC", App.checkGSMC);
		
		//App.pageA.on("click", "#GSMC", App.checkGSMC111);
		// 动态校验公司名称位数
		App.pageA.on("input","#GSMC",App.checkGSMCNum);
		App.pageA.on("porpertychanger","#GSMC",App.checkGSMCNum);
		//公司名称模糊查询
		App.pageA.on("input","#GSMC",App.toCheck);
		App.pageA.on("blur", "#GSMC", App.requireGSMC);
		//公司名称模糊查询结果点击触发事件
		App.pageA.on("click", "#searchresult li", App.searchResult);
		//点击body隐藏搜索结果
		App.pageA.on("click", "#all", App.hide1);
		//企业证件号码
		App.pageA.on("blur", "#SJ1", App.removeKong1);
		App.pageA.on("input",".textInput",App.removeKong1);// 控制输入字节数
		App.pageA.on("porpertychanger",".textInput",App.removeKong1);
		// 下一步
		App.pageA.on("click", "#btnNext", App.gotoNext);
		//点击X隐藏搜索结果及自身
		App.pageA.on("click", "#cha", App.chahide);
		App.pushHistory();
		App.pageA.show();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				App.data.firmName =$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
				App.data.firmIdNo = $("#SJ1").val().replace(/ /g,""); //企业证件号码
				if(App.data.firmName){
					App.data.firmIdType="1"
				}
				Fw.redirect("1061902.html",App.data);
		   },false);
		},false)
		
		
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	/**
	 * 初始化页面
	 */
	initPage : function() {
		if(App.data ){
			if(App.data.firmName!=null ||　App.data.firmName!=""){
				App.pageA.off("blur", "#GSMC", App.requireGSMC);
				$("#GSMC").val(App.data.firmName);
				$("#GSMC").focus();
				$("#GSMC").blur();
				App.pageA.on("blur", "#GSMC", App.requireGSMC);
			}
		    if(App.data.firmIdType){
		    	var firm="--"
					if(App.data.firmIdType=="1"){
						firm="统一社会信用代码证"
					}
		    	$("#BGDZ").html(firm)
		    }
		    if(App.data.firmIdNo){
		       $("#SJ1").html(App.data.firmIdNo)
		    }
		    App.toCheck();
		}
		
	},
	/**
	 * 检查公司名称字节数 
	 */
	checkGSMCNum:function(){
		var w=0;//字节数
		var name=$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");
		for(var i=0;i<name.length;i++){
			var c=name.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>120){
				name=name.substring(0,i);
				$("#GSMC").val(name);
				$("#GSMC").blur();
				break;
			}
		}
		App.toCheck();
	},
	/**
	 * 公司名称模糊查询 
	 */
	requireGSMC:function(){
		$("#searchresult").empty().hide();
		var  gsmc= $.trim($("#GSMC").val());
		if(gsmc.length==0){
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			//当公司名字为空时，无搜索结果，故把搜索结果清空
			$("#searchresult").empty().hide();
		}
		//发送请求之前先清空搜索结果
		if(gsmc.length!==0){
			var params={
					firmName:gsmc
			};
			var html='';
			Fw.Layer.openWaitPanel(); //等待层
			var url = YT.dataUrlWeb("private/fuzzyQueryByFirmName");
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					$("#searchresult").show();
					$("#cha").show();
					var result=data.firmList;
					for(var i=0;i<result.length;i++){
						html+='<li style="text-align:center;font-size:14px;" data-value="'+result[i].firmId+'">'+result[i].firmName+'</li>';
					}
					$("#searchresult").append(html);
					$("#resultresult").css({
						top:$("#GSMC").offset().top+$("#GSMC").height(),
					});
					Fw.Layer.hideWaitPanel(); //关闭等待层
				}else{
					Fw.Layer.hideWaitPanel(); //关闭等待层
					Fw.Form.showPinLabel($(this), data.MSG, true);
					$("#resultresult").hide();
					$("#cha").hide();
					//企业证件类型
					if($("#GSMC").val()&&$("#GSMC").val().trim()!=""){
						$("#BGDZ").html("统一社会信用代码证");
						App.data.firmIdType="1"
						$("#SJ1").val("")
					}
				}
			});
		}
	},
	/**
	 * 点击关闭按钮关闭搜索结果及自身
	 */
	chahide:function(){
		$(this).hide();
		$("#resultresult").hide();
		//企业证件类型
		if($("#GSMC").val()&&$("#GSMC").val().trim()!=""){
			$("#BGDZ").html("统一社会信用代码证");
			App.data.firmIdType="1"
			$("#SJ1").val("")
		}
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061900.html")},1500);
	},
	/**
	 * 公司名称模糊查询结果点击触发事件
	 */
	searchResult:function(){
		var liVal=$(this).text(),firmId=$(this).attr("data-value");
		App.pageA.off("blur", "#GSMC", App.requireGSMC);
		var gsmc=$("#GSMC").val(liVal);
		$("#GSMC").focus();
		$("#GSMC").blur();
		App.pageA.on("blur", "#GSMC", App.requireGSMC);
		$(this).css("background","#017EF3").siblings().css("background","#ccc");
		if(firmId!=""){
			var params = {
					firmId : firmId
				}
				Fw.Layer.openWaitPanel(); //开启等待层
				var url = YT.dataUrlWeb("private/queryFirmInfoByFirmId");
				YT.ajaxDataWeb(url, params, function(data) {
					
					if (data.STATUS == "1") {
						$("#SJ1").val(data.firmIdNo)
						var firm="--"
						if(data.firmIdType=="1"){
							firm="统一社会信用代码证"
						}
						$("#BGDZ").html(firm);
						if(data.firmIdNo){App.data.firmIdNo=data.firmIdNo}
						if(data.firmIdType){App.data.firmIdType=data.firmIdType}
						Fw.Layer.hideWaitPanel(); //关闭等待层
					} else {
							Fw.Layer.hideWaitPanel(); //关闭等待层
							Fw.Form.showPinLabel($(this), data.MSG, true);
							if($("#GSMC").val()&&$("#GSMC").val().trim()!=""){
								$("#BGDZ").html("统一社会信用代码证");
								App.data.firmIdType="1"
								$("#SJ1").val("")
							}
							return;
					}
					App.toCheck();
				});
		}
		
	},
	/**
	 * 点击body隐藏搜索结果
	 */
	hide1:function(){
	     if($("#GSMC").val()&&$("#GSMC").val().trim()!=""){
			$("#BGDZ").html("统一社会信用代码证");
			App.data.firmIdType="1"
         }
		$("#searchresult").hide();
		$("#cha").hide();
	},
	
	/**
	 * 企业证件号码
	 */
	removeKong1:function(){
		var w=0;//字节数
		for(var i=0;i<$(this).val().length;i++){
			var c=$(this).val().charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>32){
				$("#SJ1").val($(this).val().substring(0,i));
				$("#SJ1").blur();
				break;
			}
		}
		App.toCheck();
	},
	toCheck:function(){
		var GSMC =$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		var mobile1 = $("#SJ1").val().replace(/ /g,""); //企业证件号码
		if (GSMC && mobile1) {
			$("#btnNext").removeAttr("disabled", "");
			$("#btnNext").css("background-image","linear-gradient(-135deg, #217DCA 0%, #46B4E7 96%)")
		}else{
			$("#btnNext").attr("disabled", "disabled");
			$("#btnNext").css("background-image","unset")
			$("#btnNext").css("background","#B5BFCC")
		}
	},
	/**
	 * 下一步
	 */
	gotoNext : function() {
		var GSMC =$("#GSMC").val().replace(/(^\s*)|(\s*$)/g,"");// 公司名称 
		var mobile1 = $("#SJ1").val().replace(/ /g,""); //企业证件号码
		if (GSMC=="") {
			Fw.Form.showPinLabel($(this), "公司名称不能为空!", true);
			$("#GSMC").focus();
			return;
		}
		var nnm=/\'|\"|,|=|:|\{|\}|\[|\]$/;
		if (nnm.test(GSMC)||Fw.util.proofTest.proolEmoji(GSMC)) {
			Fw.Form.showPinLabel($(this), "公司名称不能含有非法字符!", true);
			$("#GSMC").focus();
			return;
		}
		if (mobile1 == "") {
			Fw.Form.showPinLabel($(this), "请输入正确企业证件号码!", true);
			$("#SJ1").focus();
			return;
		}
		/*contactName|联系人姓名","contactPhone|联系人手机号","brCode|地区号","orgCode|机构号",
"productCode|产品编号","productName|产品名称","productVersion|产品版本","firmIdType|企业证件类型",
"firmIdNo|企业证件号码","firmName|企业名称"
*/
		App.data.firmName=GSMC
		var params = {
            contactName:App.data.acctApplyInfo.operatorName,
			contactPhone:App.data.acctApplyInfo.operatorPhone,
			brCode:App.data.acctApplyInfo.applyAreaCode,
			orgCode:App.data.acctApplyInfo.applyOrgCode,
			productCode:App.data.list.productCode,
			productName:App.data.list.productName,
			productVersion:App.data.list.productVersion,
			firmIdType:App.data.firmIdType,
			firmIdNo:mobile1,
			firmName:GSMC,
			applyAmt:App.data.acctApplyInfo.applyAmt,
			loanTerm:App.data.acctApplyInfo.loanTerm
		}
		App.data.firmIdNo=mobile1
		Fw.Layer.openWaitPanel(); //开启等待层
		var url0=YT.dataUrlWeb("public/getRandomNum");
		YT.ajaxDataWeb(url0, {}, function(data0) {
			if(data0.STATUS == "1"){
				var url = YT.dataUrlWeb("private/preApplySubmit");
				params.TOKEN=data0.randomNum
			    YT.ajaxDataWeb(url, params, function(data) {
				    if (data.STATUS == "1") {
					   if(App.data.acctApplyInfo.applyAreaCode=="35"){
							 Fw.redirect("1061920.html", App.data);
						 }else{
					         Fw.redirect("1061904.html", App.data);
						 }
				     } else {
						Fw.Layer.hideWaitPanel(); //关闭等待层
						Fw.Form.showPinLabel($(this), data.MSG, true);
						return;
					 }
			     });
			}else {
				Fw.Layer.hideWaitPanel(); //关闭等待层
				Fw.Form.showPinLabel($(this), data0.MSG, true);
				return;
			 }
		    
		});

	}

};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);