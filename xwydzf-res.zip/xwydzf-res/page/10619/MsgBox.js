;(function() {
	var TAG = "Fw.MsgBox";
	Fw.log("-----init----", TAG);
	var box = Fw.MsgBox = {
		_forbidLayerId : "backMsgDiv",
		_contentLayerId : "contentMsgDiv",
		_creatCnt : 0,
		_tplMsgBox : null,
		init : function() { 
			box._tplMsgBox =[
			'<div class="ui-dialog show">',//
			'<div class="ui-dialog-cnt">',//
				'<div class="ui-dialog-bd">',//
			  		'<h4>${title}</h4>',//
			  		'<div style="text-align: center;">${msg}</div>',//
			    '</div>',//
			    '<div class="ui-dialog-ft ui-btn-group">',//
			    	'<button type="button" id="msg_box_ok">${okName}</button>',//
					'	 {@if cancleAct}',//
			    	'<button type="button" id="msg_box_cancle">${cancleName}</button>',//
					'	 {@/if}',//
			    '</div>',//
			'</div>', //
			'</div>' ].join("");
			
			Fw.log("-----init-compile-2--", TAG);
		},
		// 弹出窗口
		alertinfo : function(msg, title, okAct) {
			Fw.log("----init-1----", "Fw.alertinfo");
			Fw.MsgBox.openMsgBox(msg, title, okAct || Fw.MsgBox.hideMsgBox);
		},
		//确认框
		confirm : function(msg, title, okAct, cancleAct,okName,cancleName) {
			Fw.log("----init-1----", "Fw.confirm");
			Fw.MsgBox.openMsgBox(msg, title, okAct, cancleAct
					|| Fw.MsgBox.hideMsgBox,okName,cancleName);
		},
		openMsgBox : function(msg, title, okAct, cancleAct,okName,cancleName) {
			Fw.log("---openMsgPanel--", TAG);
			if (this._creatCnt) {
				return;
			}
			this._creatCnt++;
			this.createMsgBoxForbider();
			var layer = document.createElement("div");
			layer.id = this._contentLayerId;
			this._lastLayer = document.body.appendChild(layer);
			layer = $(layer).addClass("msg-layer");
			var tpl = box._tplMsgBox;
			var hasCancle=Fw.isDefined(cancleAct);
			Fw.log("=====cancle====" + hasCancle, TAG);
			var html = juicer(tpl, {
				title : title || '提示',
				msg : msg || '',
				cancleAct : hasCancle,
				okName:okName || "确认",
				cancleName:cancleName || "取消"
			});

			layer.append(html);
			//确定
			$("#msg_box_ok").on("click", function() {
				Fw.log("=====button.ok==1===", TAG);
				okAct && okAct(layer);
			}); 

			if (hasCancle) {
				$("#msg_box_cancle").on("click", function() {
					Fw.log("=====button.cancle==1===", TAG);
					cancleAct && cancleAct(layer);
				});
			}
		},
		hideMsgBox : function() {
			Fw.log("---hideMsgBox--" + box._creatCnt, TAG);
			if (box._creatCnt-- <= 0) {
				box._creatCnt = Math.max(box._creatCnt, 0);
				return;
			}
			try {
				box.closeMsgBoxForbider();
				box.removeDivId(box._contentLayerId);
			} catch (e) {
				Fw.log("---hideMsgPanel-error-", TAG);
			}
		},
		createMsgBoxForbider : function(divId) {
			Fw.log("---createMsgBoxForbider--", TAG);
			divId = divId ? divId : this._forbidLayerId;
			var layer = document.createElement("div");
			layer.id = divId;
			document.body.appendChild(layer);
			layer = $(layer).addClass("forbid-box");
			return layer;
		},
		removeDivId : function(divId) {
			var handle = document.getElementById(divId);
			if (handle) {
				handle.parentNode.removeChild(handle);
			}
		},
		closeMsgBoxForbider : function(divId) {
			divId = divId ? divId : this._forbidLayerId;
			this.removeDivId(divId);
		}
	};
	box.init();
	Fw.log("-----end----", TAG);
})();