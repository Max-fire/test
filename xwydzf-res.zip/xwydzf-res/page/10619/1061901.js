/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.initEvent();
		App.initData();
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", ".apply_btn", App.gotoApply);
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				Fw.redirect("1061900.html",App.data);
		   },false);
		},false)
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	initData : function(){
		var data=App.data;
		if(data && data.list){
			document.title=data.list.productName+'详情';
			var money=parseInt(data.list.maxAmount)+'';
			if(money.length>4){
				money=money.substring(0,money.length-4)+'万';
			}else{
				money=money+'元';
			}
			$("#maxMount").html(money);
			
			$("#rate").html(data.list.minYearRate);
			$("#det_detail").html(data.list.productDescription);
		}
	
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061900.html")},1500);
	},
	gotoApply:function(i){
		var json={
				list:App.data.list
		}
		Fw.redirect("1061902.html",json);
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);