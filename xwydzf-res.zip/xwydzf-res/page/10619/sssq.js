/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.initEvent();
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				Fw.redirect("1061920.html",App.data);
		   },false);
		},false)
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);