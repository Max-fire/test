/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.pageA = $("#pageA");
		App.initEvent();
		App.initData();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		var scale=1/window.devicePixelRatio,deviceWidth=document.documentElement.clientWidth;
		document.documentElement.style.fontSize=deviceWidth/7.5+'px';
		
		App.pageA.on("click","#grzx",App.toGRZX);
		App.pageA.on("click","#close_btn",App.hidePDF);
	},
	/**
	 * iPhone用a标签打开pdf,Android用pdf.js
	 */
	initData:function(){

		//微信返回
		App.pushHistory();
		document.addEventListener("WeixinJSBridgeReady",function(e){
			WeixinJSBridge.call('hideOptionMenu');
			window.addEventListener("popstate",function(e){
				alert("提交成功,页面即将关闭！")
				WeixinJSBridge.call('closeWindow');
			 },false);
		},false)
		
		var loc = document.location;
		var protocol = loc.protocol;
		var host = loc.host;
		var path=protocol + '//' + host
		var pdfUrl=path+App.data.filePath;
		$("#frame_pdf").attr("src",basePath+"/page/10618/css/pdf/web/viewer.html?url="+pdfUrl);
		
	},
	pushHistory:function(){
		var state={
			title:"title",
		}
		window.history.pushState(state,"title");
	},
	sessionTimeOut:function(){
        Fw.Layer.hideWaitPanel();
        Fw.Form.showPinLabel($(this), "会话超时，请重新认证!", true);
        setTimeout(function(){Fw.redirect("1061910.html")},1500);
	},
	/**
	 * 个人征信查看
	 */
	toGRZX:function(){

		$("#black_b").removeClass("hidden");
		$("#close_btn").removeClass("hidden");
		$("#frame_pdf").removeClass("hidden");
		
	},
	hidePDF:function(){
		$("#close_btn").addClass("hidden");
		$("#frame_pdf").addClass("hidden");
		$("#black_b").addClass("hidden");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);