/**
 * 创建应用
 * @author lixiang
 */
var device = 0;
var deviceId = 0;
var App = {
	init : function(require){
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA,[],true);
		// 初始化加载事件
		App.query();
		App.initEvent();
	},
	/**
	 * 加载数据
	 */
	initEvent : function() {
		Fw.Client.hideWaitPanel();
	},
	query:function(){
		
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/checkStaffService");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
			   if(data.housingFund=="0"){
					$("#cgjj").removeClass("hidden")
			}
            if(data.social=="0"){
           	   $("#csb").removeClass("hidden")
			}
            if(data.housingFund=="1"&&data.social=="1"){
            	$("#wu").removeClass("hidden")
            }
          }else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}	
			Fw.Client.hideWaitPanel();
			},function(data){
               Fw.Form.showPinLabel($(this), data.MSG, true);
    			Fw.Layer.hideWaitPanel();
    		});	
	},
	onCGJJ:function(v){
		  Fw.Client.openWaitPanel();
			var url = YT.dataUrl("private/get51AccessUrl");
			YT.ajaxData(url,{type:v},function(data){
				if(data.STATUS == "1"){
					//accessToken  sendURL
					var url=data.sendURL+"?access_token="+data.accessToken
//					url=encodeURI(url);
					Fw.Client.changeWeb(url,false,pageB);//?
				}else{
					Fw.Client.alertinfo(data.MSG,"系统提示");
				}	
				Fw.Client.hideWaitPanel();
			},function(data){
				Fw.Client.hideWaitPanel();
			    Fw.Client.alertinfo(data.MSG,"系统提示");
			});	
	}
};
	/**
	 * 页面加载完，加载
	 */
Fw.onReady(App);