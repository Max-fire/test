﻿/**
 * 创建应用
 * 
 * @author tsf
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.records="";
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#black",App.toCancel);
		App.pageA.on("click","#time",App.toChooseDate);
		App.pageA.attr("title",App.data.title);
		var date=new Date();
		if (App.data && App.data.diffTime) {
			date=new Date(date.getTime()+App.data.diffTime);
		}
		$("#time").html(Fw.util.Format.fmtTrsCreDate(date+"","yyyy.MM"))
		App.query(Fw.util.Format.fmtTrsCreDate(date+"","yyyy-MM"));
	},
	
	query:function(date){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/oneMonthSelfAttendance");
		var param={
			queryTime :date+""
		}
		YT.ajaxData(url,param,function(data){
			if(data.STATUS == "1"){
				if (data.records) {
					App.records=data.records;
					var html="";
					for ( var i in data.records) {
						html+='<div class="yui-dk-flex yui-yqdz-height" onclick="App.showDetail('+i+')">';
						html+='<div>'+Fw.util.Format.fmtTrsCreDate(data.records[i].workDate+"","yyyy.MM.dd")+'<span style="padding-left:10px;">'+App.fmtDate(data.records[i].workDate)+'</span></div>';
						html+='<div style="flex:1;text-align: right;"><img src="../../css/img/rightLink.png" class="yui-dk-rightLink"></div>';
						html+='</div>';
					}
					$("#list").html(html);
					$("#day").html(data.recordsCount);
					YT.showPageArea(App.pageA,[],true);
				}
			}else{
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}	
			Fw.Client.hideWaitPanel();
			},function(data){
               Fw.Form.showPinLabel($(this), data.MSG, true);
               Fw.Client.hideWaitPanel();
    		});
	},
	/**
	 * 展示详情
	 */
	showDetail:function(i){
		$("#startWorkTime").html(App.data.onDutyTime);
		$("#endWorkTime").html(App.data.offDutyTime);
		$("#titleDate").html(Fw.util.Format.fmtTrsCreDate(App.records[i].workDate+"","yyyy.MM.dd"));
		$("#titleWeek").html(App.fmtDate(App.records[i].workDate));
		if (App.records[i].onUserTimeStr) {
			$("#startClickTime").html(App.records[i].onUserTimeStr);
			if (App.records[i].onTimeResult=="1") {
				$("#startStatus").removeClass("hidden");
				$("#startStatusShow").html("迟到");
				$("#startStatusShow").removeClass("yui-dk-normalInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-lateInfo");
			}else{
				$("#startStatus").removeClass("hidden");
				$("#startStatusShow").html("正常");
				$("#startStatusShow").removeClass("yui-dk-lateInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
			}
		}
		if (App.records[i].offUserTimeStr) {
			$("#endShowClick").removeClass("hidden");
			if (App.records[i].offTimeResult=="1") {
				$("#endStatus").removeClass("hidden");
				$("#endStatusShow").html("早退");
				$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
			}else{
				$("#endStatus").removeClass("hidden");
				$("#endStatusShow").html("正常");
				$("#endStatusShow").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
			}
				$("#endClickTime").html(App.records[i].offUserTimeStr);
		}else{
				$("#endStatus").addClass("hidden");
				$("#endStatusShow").html("缺卡");
				$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
		}
		$("#black").removeClass("hidden");
		$("#white").removeClass("hidden");
	},
	toCancel:function(){
		$("#black").addClass("hidden");
		$("#white").addClass("hidden");
	},
	/**
	 * 选择日期
	 */
	toChooseDate:function(){
		var date=($("#time").html()).replace(/\./g, '-');
		var datas = {
				"func" : "App.opData",
				"flag" : "0",
				"date" : date+""
				}
			Fw.Client.showDatePickerSign(Fw.JsonToStr(datas));
	},
	opData : function(date) {
		$("#time").html(date.replace(/-/g, '.'));
		App.query(date);
	},
	/**
	 * 格式化日期
	 */
	fmtDate:function(date){
		var getDate=new Array('(星期日)','(星期一)','(星期二)','(星期三)','(星期四)','(星期五)','(星期六)');
		var time=new Date(Fw.util.Format.fmtTrsCreDate(date+"","yyyy-MM-dd"));
		return getDate[time.getDay()];
	},
	/**
	 * 返回列表界面
	 */
	gotoPage:function(){
		Fw.redirect("1061700.html?userType="+App.func("userType"));
	},
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);