﻿/**
 * 创建应用
 * 
 * @author tsf
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.latitude="";
		App.longitude="";
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		 //App.pageA.on("click","#busBeginTime",App.toTime("busBeginTime"));
		 
		App.pageA.on("click","#btnSubmit",App.btnSubmit);
		App.pageA.on("click","#address",App.addAddress);
		App.query();
	},
	addAddress:function(){
		var json={
				func:"App.getPosition",
				latitude:App.latitude||""+"",
				longitude:App.longitude||""+"",
		}
		Fw.Client.getLocation(json)
	},
	getPosition:function(latitude,longitude,address){
		App.latitude=latitude;
		App.longitude=longitude;
		//App.loadData(App.attendanceAddr);
		$("#address").html(address);
		$("#addr").val(address);
	},
	/**
	 * 加载数据
	 */
	loadData:function(data){
		if (data.attendanceList) {
			if(data.attendanceList[0].onDutyTime){
				$("#beginTime").html(data.attendanceList[0].onDutyTime);
			}
			if(data.attendanceList[0].offDutyTime){
				$("#endTime").html(data.attendanceList[0].offDutyTime);
			}
			if(data.attendanceList[0].attendanceAddr){
				$("#address").html(data.attendanceList[0].attendanceAddr);
				$("#addr").val(data.attendanceList[0].attendanceAddr);
			}
		}
		YT.showPageArea(App.pageA,[],true);
	},
	toTime:function(v){
		App.mark=v
		var json={
				func:"App.getHourMin",
		}
		Fw.Client.getTime(json)
	},
	getHourMin:function(time){
		var time=time+":00";
		if(App.mark=="busBeginTime"){
			$("#beginTime").html(time);
		}else if(App.mark=="busEndTime"){
			$("#endTime").html(time);
		}
		
		
	},
	query:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/setAttendanceRule");
		//alert(App.data.applyNo);
		var params={
			 type:"4"//1、新增，2、修改，3、删除，4、查询
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				App.data=data.attendanceList;
		        App.loadData(data)
		        //alert(YT.JsonToStr(data.attendanceList))
		        if(data.attendanceList&&data.attendanceList[0].latitude){
		        	App.latitude=data.attendanceList[0].latitude||"";
		        }
		        if(data.attendanceList&&data.attendanceList[0].longitude){
		          App.longitude=data.attendanceList[0].longitude||"";
		        }
			    Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
	},
	btnSubmit:function(){
		var beginTime=$("#beginTime").html();
		var endTime=$("#endTime").html();
		var address=$("#addr").val();
		if(beginTime=="请选择上班时间"){
			Fw.Form.showPinLabel($(this), "请选择上班时间", true);
			return false;
		}
		if(endTime=="请选择下班时间"){
			Fw.Form.showPinLabel($(this), "请选择下班时间", true);
			return false;
		}
		if(!address){
			Fw.Form.showPinLabel($(this), "请添加办公地址", true);
			return false;
		}
		/*if(beginTime>endTime){
			Fw.Form.showPinLabel($(this), "下班时间不早于上班时间", true);
			return false;
		}*/
		if (App.data) {
			if (App.data[0].onDutyTime==beginTime && App.data[0].offDutyTime==endTime && App.data[0].attendanceAddr==address) {
				Fw.Form.showPinLabel($(this), "您未做任何修改", true);
				return false;
			}
		}
		Fw.Client.openWaitPanel();
		
		var url = YT.dataUrl("private/setAttendanceRule");
		//alert(App.data.applyNo);
		var params={
			    type:"1",//1、新增，2、修改，3、删除，4、查询
			    groupName:"",
				isDefault:"0",
				longitude:App.longitude+"",
				latitude:App.latitude+"",
				attendanceAddr:address+"",
				distanceRange:"1000",
				className:"",
				onDutyTime:beginTime+"",
				offDutyTime:endTime+"",
		}
		if(App.data && App.data[0].groupId){
			params.type="2";
			params.classId=App.data[0].classId+"";
			params.groupId=App.data[0].groupId+"";
		}
		
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo("保存成功","系统提示","App.toBack()");
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示","App.Fail()");
			}
		})
	},
	toBack:function(){
		Fw.redirect("1061700.html?userType="+App.func("userType"))
	},
	/**
	 * 返回列表界面
	 */
	gotoList:function(){
		Fw.redirect("1061700.html?userType="+App.func("userType"));
	},
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);