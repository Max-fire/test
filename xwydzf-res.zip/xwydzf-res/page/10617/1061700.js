/**
 * 创建应用
 * @author zyq
 */

var App = {
	init : function(require){
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		// 初始化加载事件
		App.date=0;
		App.clickReset="start";
		App.willClick="now";
		App.startParams={};
		App.endParams={};
		App.initEvent();
		Fw.Client.openWaitPanel();
	},
	/**
	 * 加载数据
	 */
	initEvent : function() {
		App.pageA.on("click","#clickTime",App.toChooseDate);
		App.pageA.on("click","#startClick",App.toStartClick);
		App.pageA.on("click","#endClick",App.toEndClick);
		App.pageA.on("click","#startReset",App.toStartReset);
		App.pageA.on("click","#endReset",App.toEndReset);
		App.pageA.on("click","#cancel",App.toCancel);
		App.pageA.on("click","#ok",App.toOk);
		App.pageA.on("click","#count",App.toCount);
		App.toShowCheck();
	},
	toQueryRecord:function(date){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryAttendanceRecord");
		var param={
				workDate:date
		}
		var dates=new Date();
		var now=new Date(Fw.util.Format.fmtTrsCreDate(new Date(dates.getTime()+App.date),"yyyy-MM-dd"));
		var workDate=new Date(date);
		YT.ajaxData(url,param,function(data){
			if(data.STATUS == "1"){
				if (now.getTime()>workDate.getTime()) {
					//当前日期大于选择日期
					App.willClick="past";
					$("#startShow").addClass("hidden");
					$("#startCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
					$("#startShowClick").removeClass("hidden");
					$("#endShow").addClass("hidden");
					$("#endCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
					$("#endShowClick").removeClass("hidden");
					if (data.attendanceRecord) {
						//已打完上班或下班卡处理
						if (data.attendanceRecord.onUserTimeStr) {
								if (data.attendanceRecord.onTimeResult=="1") {
									$("#startStatus").removeClass("hidden");
									$("#startStatusShow").html("迟到");
									$("#startStatusShow").removeClass("yui-dk-normalInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-lateInfo");
								}else{
									$("#startStatus").removeClass("hidden");
									$("#startStatusShow").html("正常");
									$("#startStatusShow").removeClass("yui-dk-lateInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
								}
								$("#startClickTime").html(data.attendanceRecord.onUserTimeStr);
						}else{
							$("#startStatus").addClass("hidden");
							$("#startStatusShow").html("缺卡");
							$("#startStatusShow").removeClass("yui-dk-normalInfo").removeClass("yui-dk-lateInfo").addClass("yui-dk-lostInfo");
						}
						if (data.attendanceRecord.offUserTimeStr) {
							if (data.attendanceRecord.offTimeResult=="1") {
								$("#endStatus").removeClass("hidden");
								$("#endStatusShow").html("早退");
								$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
							}else{
								$("#endStatus").removeClass("hidden");
								$("#endStatusShow").html("正常");
								$("#endStatusShow").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
							}
								$("#endClickTime").html(data.attendanceRecord.offUserTimeStr);
						}else{
								$("#endStatus").addClass("hidden");
								$("#endStatusShow").html("缺卡");
								$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
						}
					}else{
						//未打卡
						$("#startStatus").addClass("hidden");
						$("#startStatusShow").html("缺卡");
						$("#startStatusShow").removeClass("yui-dk-normalInfo").removeClass("yui-dk-lateInfo").addClass("yui-dk-lostInfo");
						$("#endStatus").addClass("hidden");
						$("#endStatusShow").html("缺卡");
						$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
					}
					Fw.Client.hideWaitPanel();
					YT.showPageArea(App.pageA,[],true);
				}else if (now.getTime()==workDate.getTime()) {
					//当前日期和选择日期一样
					App.willClick="now";
					if (data.attendanceRecord) {
						//已打完上班或下班卡处理
						if (data.attendanceRecord.onUserTimeStr) {
							App.clickReset="end";
						}else{
							App.clickReset="start";
						}
						App.showClock(data);
						App.endParams.recordSerial=data.attendanceRecord.recordSerial+"";
					}else{
						//未打卡
						$("#startShow").removeClass("hidden");
						$("#startCircle").removeClass("yui-dk-circleGray").addClass("yui-dk-circleBlue");
						$("#startShowClick").addClass("hidden");
						$("#endShow").addClass("hidden");
						$("#endCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
						$("#endShowClick").addClass("hidden");
					}
					Fw.Client.checkRange(App.json);
				}else{
					//当前日期小于选择日期
					App.willClick="will";
					$("#startShow").removeClass("hidden");
					$("#startCircle").addClass("yui-dk-circleBlue").removeClass("yui-dk-circleGray");
					$("#startShowClick").addClass("hidden");
					$("#endShow").addClass("hidden");
					$("#endCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
					$("#endShowClick").addClass("hidden");
					Fw.Client.hideWaitPanel();
					YT.showPageArea(App.pageA,[],true);
				}
          }else{
        	  	Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}	
			},function(data){
               Fw.Form.showPinLabel($(this), data.MSG, true);
    			Fw.Client.hideWaitPanel();
    		});
	},
	/**
	 * 显示时间
	 */
	toShowCheck:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryAttendanceRule");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				$("#headInfo").html('<img src="'+data.httpUrl+'" onerror="javascript:this.src=\'../../css/img/mrtx-investor.png \'" class="yui-dk-height">');
				$("#userName").html(data.userName);
				App.pageA.attr("title",data.firmName);
				if (App.func("userType") && App.func("userType") !="undefind" && App.func("userType") !="null") {
					App.pageA.attr("data-btnRight","true|设置|App.gotoSet()");
				}
				var date=new Date(App.fmtDates(data.dateTime+""));
				var now=new Date();
				if (data.attendance) {
					App.json={
							longitude:data.attendance.longitude,
							latitude:data.attendance.latitude,
							distance:data.attendance.distanceRange,
							func:"App.checkBack"
					}
					$("#startPostion").removeClass("hidden");
					$("#startWorkTime").html(data.attendance.onDutyTime);
					$("#endWorkTime").html(data.attendance.offDutyTime);
					App.toQueryRecord(date.getFullYear()+"-"+App.fmtTime(date.getMonth()+1+"")+"-"+App.fmtTime(date.getDate()+""));
				}else{
					$("#startPostion").addClass("hidden");
					YT.showPageArea(App.pageA,[],true);
					Fw.Client.hideWaitPanel();
				}
				App.date=date.getTime()-now.getTime();
				App.start=setInterval(App.setTime,1000);
				$("#time").html(date.getFullYear()+"."+App.fmtTime(date.getMonth()+1+"")+"."+App.fmtTime(date.getDate()+""));
			}else{
        	  Fw.Client.hideWaitPanel();
        	  Fw.Client.alertinfo(data.MSG,"系统提示","App.gotoHomePage()");
			}	
			},function(data){
               Fw.Form.showPinLabel($(this), data.MSG, true);
    			Fw.Client.hideWaitPanel();
    		});
	},
	/**
	 * 上班打卡重新定位
	 */
	toStartReset:function(){
		setTimeout(function(){
			App.clickReset="start";
			$("#startTips").html('<span class="yui-dk-loading"></span>');
			Fw.Client.checkRange(App.json);
		},500)
	},
	/**
	 * 下班打卡重新定位
	 */
	toEndReset:function(){
		setTimeout(function(){
			App.clickReset="end";
			$("#endTips").html('<span class="yui-dk-loading"></span>');
			Fw.Client.checkRange(App.json);
		},500)
	},
	/**
	 * 客户端检查打卡范围回调
	 */
	checkBack:function(LocationResult,UserLongitude,UserLatitude,DeviceId,attendanceAddr){
		//返回值 0有效 1无效
			App.startParams.onLocationResult=App.endParams.offLocationResult=LocationResult;
			App.startParams.onUserLongitude=App.endParams.offUserLongitude=UserLongitude;
			App.startParams.onUserLatitude=App.endParams.offUserLatitude=UserLatitude;
			App.startParams.onDeviceId=App.endParams.offDeviceId=DeviceId;
			if (App.clickReset=="start") {
				if (LocationResult==1) {
					App.pageA.off("click","#startClick",App.toStartClick);					
					$("#startTips").html("当前不在考勤范围");
					$("#startTips").addClass("yui-dk-outRange");
					$("#startClick").removeClass("yui-dk-timeCircle").removeClass("yui-dk-timeCircleLate").addClass("yui-dk-timeCircleDisable")
				}else{
					$("#startTips").html("<img src='../../css/img/fwn.png' class='yui-dk-fwIcon'>已进入考勤范围");
					$("#startTips").removeClass("yui-dk-outRange");
					var date=new Date();
					date=new Date(date.getTime()+App.date);
					var arr = $("#startWorkTime").html().split(":");
					var times=date.getHours()*3600+date.getMinutes()*60+date.getSeconds();
					var nowTimes=arr[0]*3600+arr[1]*60+arr[2]*1;
					if (times>nowTimes) {
						$("#startClick").removeClass("yui-dk-timeCircleDisable").removeClass("yui-dk-timeCircle").addClass("yui-dk-timeCircleLate");
					}else{
						$("#startClick").removeClass("yui-dk-timeCircleDisable").removeClass("yui-dk-timeCircleLate").addClass("yui-dk-timeCircle");
					}
				}
			}else{
				if (LocationResult==0) {
					$("#endTips").html("<img src='../../css/img/fwn.png' class='yui-dk-fwIcon'>已进入考勤范围");
					$("#endTips").removeClass("yui-dk-outRange");
					$("#endClick").removeClass("yui-dk-timeCircleDisable").addClass("yui-dk-timeCircle");
				}else{
					App.pageA.off("click","#endClick",App.toStartClick);	
					$("#endTips").html("当前不在考勤范围");
					$("#endTips").addClass("yui-dk-outRange");
					$("#endClick").removeClass("yui-dk-timeCircle").addClass("yui-dk-timeCircleDisable")
				}
			}
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA,[],true);
	},
	/**
	 * 获取服务器时间
	 */
	setTime:function(){
		var date=new Date()
		var now=new Date(date.getTime()+App.date);
		var startWorkTime=$("#startWorkTime").html();
		var startTime = Fw.util.Format.fmtTrsCreDate(date,"yyyy/MM/dd")+" "+startWorkTime;
			startTime=new Date(startTime).getTime();
		if (date.getTime()+App.date>startTime) {
			$("#startClick").removeClass("yui-dk-timeCircleDisable").removeClass("yui-dk-timeCircle").addClass("yui-dk-timeCircleLate");
		}else{
			$("#startClick").removeClass("yui-dk-timeCircleDisable").removeClass("yui-dk-timeCircleLate").addClass("yui-dk-timeCircle");
		}
		$("#startTime").html(App.fmtTime(now.getHours())+":"+App.fmtTime(now.getMinutes())+":"+App.fmtTime(now.getSeconds()))
		$("#endTime").html(App.fmtTime(now.getHours())+":"+App.fmtTime(now.getMinutes())+":"+App.fmtTime(now.getSeconds()))
	},
	fmtTime:function(value){
		var time="";
		if (value<10) {
			time="0"+value;
		}else{
			time=value;
		}
		return time
	},
	showClock:function(data){
		if (data.attendanceRecord.onUserTimeStr) {
			if (data.attendanceRecord.onTimeResult=="1") {
				$("#startStatus").removeClass("hidden");
				$("#startStatusShow").html("迟到");
				$("#startStatusShow").removeClass("yui-dk-lostInfo").removeClass("yui-dk-normalInfo").addClass("yui-dk-lateInfo");
			}else{
				$("#startStatus").removeClass("hidden");
				$("#startStatusShow").html("正常");
				$("#startStatusShow").removeClass("yui-dk-lateInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
			}
			$("#startShow").addClass("hidden");
			$("#startCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
			$("#startClickTime").html(data.attendanceRecord.onUserTimeStr);
			$("#startShowClick").removeClass("hidden");
		}else{
			$("#startShow").removeClass("hidden");
			$("#startStatus").addClass("hidden");
			$("#startCircle").addClass("yui-dk-circleBlue").removeClass("yui-dk-circleGray");
			$("#startShowClick").addClass("hidden");
		}
		if (data.attendanceRecord.offUserTimeStr) {
			if (data.attendanceRecord.offTimeResult=="1") {
				$("#endStatus").removeClass("hidden");
				$("#endStatusShow").html("早退");
				$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
			}else{
				$("#endStatus").removeClass("hidden");
				$("#endStatusShow").html("正常");
				$("#endStatusShow").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
			}
			$("#endShow").addClass("hidden");
			$("#endCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
			$("#endClickTime").html(data.attendanceRecord.offUserTimeStr);
			$("#endShowClick").removeClass("hidden");
		}else{
			if (data.attendanceRecord.onUserTimeStr) {
				$("#endShow").removeClass("hidden");
				$("#endStatus").addClass("hidden");
				$("#endCircle").addClass("yui-dk-circleBlue").removeClass("yui-dk-circleGray");
				$("#endShowClick").addClass("hidden");
			}else{
				$("#endShow").addClass("hidden");
				$("#endShowClick").addClass("hidden");
			}
		}
	},
	/**
	 * 点击上班打卡
	 */
	toStartClick:function(){
		var start=$("#startWorkTime").html();
		var startClick=$("#startTime").html();
		var arr = start.split(":");
		var arrClick = startClick.split(":");
		if (App.willClick=="will") {
			Fw.Client.alertinfo("打卡时间未到","无法打卡")
			return;
		}
		if ($("#startWorkTime").html()=="00:00:00") {
			Fw.Client.alertinfo("管理员未设置打卡时间和打卡地点","无法打卡")
			return;
		}
		if ($("#startClick").hasClass("yui-dk-timeCircleLate")) {
			Fw.Client.confirm("您目前已迟到是否继续打卡？","温馨提示","App.toShowStart()","","确定打卡","")
		}else{
			App.toShowStart();
		}
		
	},
	toShowStart:function(){
		var start=$("#startWorkTime").html();
		var startClick=$("#startTime").html();
		var arr = Fw.util.Format.fmtTrsCreDate(new Date(),"yyyy/MM/dd")+" "+start;
		var arrClick = Fw.util.Format.fmtTrsCreDate(new Date(),"yyyy/MM/dd")+" "+startClick;
		var url = YT.dataUrl("public/getRandomNum");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = YT.dataUrl("private/takeAttendanceRecord");
				App.startParams.type="1";
				App.startParams.onUserTime=startClick;
				App.startParams.onDutyRemark="";
				App.startParams.TOKEN=data.randomNum;
				YT.ajaxData(url,App.startParams,function(data){
					if(data.STATUS == "1"){
						if (new Date(arr).getTime()<new Date(arrClick).getTime()) {
							$("#startStatus").removeClass("hidden");
							$("#startStatusShow").html("迟到");
							$("#startStatusShow").removeClass("yui-dk-normalInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-lateInfo");
						}else{
							$("#startStatus").removeClass("hidden");
							$("#startStatusShow").html("正常");
							$("#startStatusShow").removeClass("yui-dk-lateInfo").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
						}
						$("#startShow").addClass("hidden");
						$("#startCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
						$("#endCircle").addClass("yui-dk-circleBlue").removeClass("yui-dk-circleGray");
						$("#startClickTime").html(startClick);
						$("#startShowClick").removeClass("hidden");
						$("#endShow").removeClass("hidden");
						App.endParams.recordSerial=data.attendanceRecord.recordSerial+"";
						Fw.Client.hideWaitPanel();
					}else{
		        	  Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG,"系统提示");
					}	
					},function(data){
		               Fw.Form.showPinLabel($(this), data.MSG, true);
		    			Fw.Client.hideWaitPanel();
		    		});	
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),data.MSG,true);
				return;
			}
		});
		
	},
	/**
	 * 点击下班打卡
	 */
	toEndClick:function(){
		var date=Fw.util.Format.fmtTrsCreDate(new Date(new Date().getTime()+App.date),"yyyy/MM/dd");
		var start=new Date(date+' '+$("#startWorkTime").html()).getTime();
		var end=new Date(date+' '+$("#endWorkTime").html()).getTime();
		var endClick=new Date(date+' '+$("#endTime").html()).getTime();
		if (start>end) {
			if (end+24*60*60*1000>endClick) {
				$("#endLate").removeClass("hidden");
				$("#black").removeClass("hidden");
				$("#white").removeClass("hidden");
			}else{
				App.toShowEnd();
			}
		}else{
			if (end>endClick) {
				$("#endLate").removeClass("hidden");
				$("#black").removeClass("hidden");
				$("#white").removeClass("hidden");
			}else{
				App.toShowEnd();
			}
		}
	},
	toShowEnd:function(){
		var endClick=$("#endTime").html();
		var url = YT.dataUrl("public/getRandomNum");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = YT.dataUrl("private/takeAttendanceRecord");
				App.endParams.type="2";
				App.endParams.offUserTime=endClick;
				App.endParams.offDutyRemark=$("#memo").val();
				App.endParams.TOKEN=data.randomNum;
				YT.ajaxData(url,App.endParams,function(data){
					if(data.STATUS == "1"){
						clearInterval(App.start);
						if ($("#memo").val()) {
							$("#endStatus").removeClass("hidden");
							$("#endStatusShow").html("早退");
							$("#endStatusShow").removeClass("yui-dk-normalInfo").addClass("yui-dk-lostInfo");
						}else{
							$("#endStatus").removeClass("hidden");
							$("#endStatusShow").html("正常");
							$("#endStatusShow").removeClass("yui-dk-lostInfo").addClass("yui-dk-normalInfo");
						}
						$("#endShow").addClass("hidden");
						$("#endCircle").addClass("yui-dk-circleGray").removeClass("yui-dk-circleBlue");
						$("#endClickTime").html(endClick);
						$("#endShowClick").removeClass("hidden");
		          }else{
						Fw.Client.alertinfo(data.MSG,"系统提示");
					}	
					Fw.Client.hideWaitPanel();
					},function(data){
		               Fw.Form.showPinLabel($(this), data.MSG, true);
		               Fw.Client.hideWaitPanel();
		    		});
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),data.MSG,true);
				return;
			}
		});
	},
	/**
	 * 早退取消
	 */
	toCancel:function(){
		$("#memo").val("");
		$("#black").addClass("hidden");
		$("#white").addClass("hidden");
	},
	/**
	 * 早退确认
	 */
	toOk:function(){
		if (!$("#memo").val()) {
			Fw.Form.showPinLabel($(this),"请输入早退原因", true);
			return;
		}
		$("#black").addClass("hidden");
		$("#white").addClass("hidden");
		App.toShowEnd();
	},
	/**
	 * 选择日期
	 */
	toChooseDate:function(){
		var date=($("#time").html()).replace(/\./g, '-');
		var datas = {
				"func" : "App.opData",
				"flag" : "1",
				"date" : date+""
				}
			Fw.Client.showDatePickerSign(Fw.JsonToStr(datas));
	},
	opData : function(begin) {
		$("#time").html(begin.replace(/-/g, '.'));
		App.toQueryRecord(begin)
	},
	/**
	 * 跳转查看统计界面
	 */
	toCount:function(){
		var json={
				title:App.pageA.attr("title"),
				onDutyTime:$("#startWorkTime").html(),
				offDutyTime:$("#endWorkTime").html(),
				diffTime:App.date
				
		}
		Fw.redirect("1061702.html?userType="+App.func("userType"),json);
	},
	fmtDates:function(v){
		return v.substring(0, 4) +'/' + v.substring(4, 6) + '/' + v.substring(6, 8) +' ' + v.substring(8, 10) + ':' + v.substring(10, 12) + ':' + v.substring(12, 14);
	},
	/**
	 * 跳转管理员设置界面
	 */
	gotoSet:function(){
		clearInterval(App.start);
		Fw.redirect("1061701.html?userType="+App.func("userType"));
	},
	gotoHomePage:function(){
		clearInterval(App.start);
		Fw.Client.gotoHomePage();
	}
	
};
	/**
	 * 页面加载完，加载
	 */
Fw.onReady(App);