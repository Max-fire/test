/**
 * 创建应用
 * @author wangjx
 */
var App = {
	init : function(require){
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.pageC = $("#pageC");
		App.pageD = $("#pageD");
		App.pageE = $("#pageE");
		App.pageF = $("#pageF");
		App.pageG = $("#pageG");
		YT.showPageArea(App.pageA,[],true);
		// 初始化加载事件
		App.initEvent();
		// 初始化录入页面
		//App.initPageA();
	},
	initEvent : function() {
		//头像
		App.pageA.on("click","#photo",App.initPhoto);
		//性别
		App.pageA.on("click","#sex",App.initSex);
		//部门
		App.pageA.on("click","#department",App.initDepartment);
		//职位
		App.pageA.on("click","#position",App.initPosition);
		//电话
		App.pageA.on("click","#phone",App.initPhone);
		//邮箱
		App.pageA.on("click","#mail",App.initPhonemail);
		App.pageC.on("click","#man",App.initMan);
		App.pageC.on("click","#woMan",App.initWoMan);
	},
	//头像
	initPhoto : function(){
		alert("");
	},
	//性别
	initSex : function(){
		sex = $("#sex0").html();
		YT.showPageArea(App.pageC,[App.pageA],true);
		alert(sex);
		if(sex == "男"){
			alert("男");
			$("#nv").removeAttr("class","");
			$("#nan").attr("class","yui-back-url");
		}
		if(sex == "女"){
			alert("女");
			$("#nan").removeAttr("class","");
			$("#nv").attr("class","yui-back-url");
		}
	},
	//选中性别执行
	initMan : function(){
		$("#nv").removeAttr("class","");
		$("#nan").attr("class","yui-back-url");
		sex = $("#sex1").val();
		alert(sex);
	},
	initWoMan : function(){
		$("#nan").removeAttr("class","");
		$("#nv").attr("class","yui-back-url");
		sex = $("#sex2").val();
		alert(sex);
	}, 
	//部门
	initDepartment : function(){
		department = $("#department1").html();
		YT.showPageArea(App.pageD,[App.pageA],true);
		$("#department2").val(department);
	},
	//职位
	initPosition : function(){
		position=$("#position1").html();
		YT.showPageArea(App.pageE,[App.pageA],true);
		$("#position2").val(position);
	},
	//电话
	initPhone : function(){
		phone = $("#phone1").html();
		YT.showPageArea(App.pageF,[App.pageA],true);
		$("#phone2").val(phone);
	},
	//邮箱
	initPhonemail : function(){
		mail = $("#mail1").html()
		YT.showPageArea(App.pageG,[App.pageA],true);
		$("#mail2").val(mail);
	},
	// 初始化录入页面
	initPageA : function(tpl_html) {
		if (tpl_html) {
			Fw.log("---initPageA---", "APP");
			App.pageA.html(tpl_html);
			//自定义错误信息
			App.pageA.find("[data-name='PASS_WORD']").on("validator",function(){
				var item = $(this);
				//校验账号是否正确
				alert(item.val());
				var reg = /^(\d{16}|\d{19})$/.test(item.val());
				if ( reg !=true) {
					Fw.Form.showPinLabel(item, "请输入'正确1密码'", true);
					item.attr("data-check", "false");
				} else {
					item.removeAttr("data-check");
				}
			});
			App.pageA.find("[data-name='NEW_PASS_WORD']").on("validator",function(){
				var item = $(this);
				//校验账号是否正确
				alert(item.val());
				var reg = /^(\d{16}|\d{19})$/.test(item.val());
				if ( reg !=true) {
					Fw.Form.showPinLabel(item, "请输入'正确2密码'", true);
					item.attr("data-check", "false");
				} else {
					item.removeAttr("data-check");
				}
			});
			App.pageA.find("[data-name='AGAIN_NEW_PASS_WORD']").on("validator",function(){
				var item = $(this);
				//校验账号是否正确
				alert(item.val());
				var reg = /^(\d{16}|\d{19})$/.test(item.val());
				if ( reg !=true) {
					Fw.Form.showPinLabel(item, "请输入'正确3密码'", true);
					item.attr("data-check", "false");
				} else {
					item.removeAttr("data-check");
				}
			});
		} else {
			Fw.log("---loadPageA---", "APP");
			$.get("1060301_input.html", {}, App.initPageA);
		}
		YT.showPageArea(App.pageA, null, true);
	},
	// 表单校验
	toConfirm : function() {
		Fw.log("--act-to-confirm-1---", "APP");
		// 表单检查
		alert(Fw.Form.validator(App.pageA));
		if (!Fw.Form.validator(App.pageA)) {
			alert("return"+Fw.Form.validator(App.pageA));
			return;
		}
		App.jsonInput = Fw.Form.getFormJson(App.pageA, {});
		Fw.log("--act-to-confirm-end---", "APP");
		/*App.toSubmit();*/

	},
	// 事务提交
	toSubmit : function() {
		alert("保存");
		/*var url = YT.dataUrl("private/findTaskUnProc");
		var params =  App.jsonInput;// 复制数据
		alert(Fw.JsonToStr(params));
		YT.ajaxData(url, params, App.callback, App.callback);*/
	},
	callback : function(success) {
		alert(Fw.JsonToStr(success));
	},
	callback1 : function(success) {
		alert(Fw.JsonToStr(success));
	},
	
	
	//返回
	backPageB : function(){
		department = $("#department2").val();
		YT.showPageArea(App.pageA,[App.pageD],true);
		$("#department1").html(department);
		
	},
	backPageC : function(){
		alert(sex);
		YT.showPageArea(App.pageA,[App.pageC],true);
		$("#sex0").html(sex);
	},
	backPageD : function(){
		department = $("#department1").val();
		YT.showPageArea(App.pageA,[App.pageD],true);
		$("#department2").html(department);
	},
	backPageE : function(){
		position=$("#position2").val();
		YT.showPageArea(App.pageA,[App.pageE],true);
		$("#position1").html(position);
	},
	backPageF : function(){
		phone = $("#phone2").val();
		YT.showPageArea(App.pageA,[App.pageF],true);
		$("#phone1").html(phone);
	},
	backPageG : function(){
		mail = $("#mail2").val()
		YT.showPageArea(App.pageA,[App.pageG],true);
		$("#mail1").html(mail);
	},
	
}

Fw.onReady(App);