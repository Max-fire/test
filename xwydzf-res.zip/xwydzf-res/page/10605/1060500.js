/**
 * 创建应用
 * 
 * @author lixiang
 */
var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);
		// 初始化加载事件
		App.initEvent();
	},
	initEvent : function(){
		Fw.Client.openWaitPanel();
		var params={}
		var url = YT.dataUrl("private/getUserBiz");
		var temp = [
	      		'{@each datas as item}', 
	      			'<li>',
	      	        '<div class="type2" style="background-image:url(../../css/img/bizIcon_${item.appBiz.bizNo}.png)">',
	      	           '<span style=""></span>',
	      	       '</div>', 
	      	        '<div class="ui-list-info ui-border-t">',
	      	           '<h4 class="yui-font-y">${item.appBiz.bizName}</h4>',
	      	        '</div>',
	      	        '</li>',
	      		'{@/each}',
	   		].join("");
		var temp1 = [
		      		'{@each notAppList as item}', 
		      			'<li>',
		      	        '<div class="type2dis" style="background-image:url(../../css/img/bizIcon_${item.bizNo}_disable.png)">',
		      	           '<span style=""></span>',
		      	       '</div>', 
		      	        '<div class="ui-list-info ui-border-t">',
		      	           '<h4 class="yui-font-n">${item.bizName}</h4>',
		      	        '</div>',
		      	        '</li>',
		      		'{@/each}',
		   		].join("");
		YT.ajaxData(url,params,function(Data){
			console.log(Data);
			if(Data.STATUS=="1"){
				var  html= Fw.template(temp,Data);
				var html1 = Fw.template(temp1,Data);
				var htmls = html+html1;
				App.pageA.find(".yui-ul").html(htmls);
			}
			Fw.Client.hideWaitPanel();
		})
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
