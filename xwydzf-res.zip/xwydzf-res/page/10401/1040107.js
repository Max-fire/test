/**
 * 创建应用
 * 
 * @author yql
 */
var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		Fw.Client.hideWaitPanel(); 
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
		App.onQueryData();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		//公用数据字段  【行内0】【跨行1】
		App.innerBank = Fw.getParameters("_parameters").innerBank;
		//公用列表样式
//		App.temp = [
//					'{@each datas as item}',
//						'<ul class="ui-list swiper-container">',
//					        '<li class="ui-border-b swiper-wrapper">',
//					        	'<div class="swiper-slide swiper-slide-change">',
////					        		'<div class="ui-list-thumb" style=""width:50px;height:50px;margin:10px 10px 10px 0;position:relative>',
//					        		'<div  style="height:50px;margin:10px 20px 10px 0;position:relative">',
//					        			'<span style="background-image:url(../img/100x100.png); background-size: 100% auto"></span>',
//					        		'</div>',
//					        		'<div class="ui-list-info">',
//					        			'<h4 class="ui-nowrap">${item.acctName}</h4>',
//					        			'<p class="yui-word-break " >${item.bankName}(${item.acctNo})</p>',
//					        			'<input type=text  id=hm value="${item.bankName}" class="hidden bankName">',
//					        			'<input type=text  id=hm value="${item.acctName}" class="hidden toAcctName">',
//					        			'<input type=text  id=zh value="${item.acctNo}" class="hidden acctNo">',
//					        			'<input type=text  id=bankCode value="${item.bankCode}" class="hidden bankCode">',
//					        			'<input type=text  id=brCode value="${item.brCode}" class="hidden brCode">',
//					        			'<input type=text  id=cityCode value="${item.cityCode}" class="hidden cityCode">',
//					        		'</div>',
//					        	'</div>',
//					        	'<div class="swiper-slide item-delete" id="${item.acctNo}"><span>删除</span></div>',
//					       '</li>',
//					   ' </ul>',
//					'{@/each}',
//			].join("");
		App.temp1 = [
				'<ul class="ui-list swiper-container">',
			        '<li class="ui-border-b swiper-wrapper">',
			        	'<div class="swiper-slide swiper-slide-change">',
			        		'<div  style="height:50px;margin:10px 20px 10px 0;position:relative">',
			        			'<span style="background-image:url(../img/100x100.png); background-size: 100% auto"></span>',
			        		'</div>',
			        		'<div class="ui-list-info">',
			        			'<h4 class="ui-nowrap">${item.acctName}</h4>',
			        			'<p class="yui-word-break " >${item.bankName}(${item.acctNo})</p>',
			        			'<input type=text  id=hm value="${item.bankName}" class="hidden bankName">',
			        			'<input type=text  id=hm value="${item.acctName}" class="hidden toAcctName">',
			        			'<input type=text  id=zh value="${item.acctNo}" class="hidden acctNo">',
			        			'<input type=text  id=bankCode value="${item.bankCode}" class="hidden bankCode">',
			        			'<input type=text  id=brCode value="${item.brCode}" class="hidden brCode">',
			        			'<input type=text  id=cityCode value="${item.cityCode}" class="hidden cityCode">',
			        		'</div>',
			        	'</div>',
			        	'<div class="swiper-slide item-delete" id="${item.acctNo}"><span>删除</span></div>',
			       '</li>',
			   ' </ul>',
			].join("");
		
		
		App.pageA.on("click", "#deleteData", App.onShowDeleteBtn);
		$(".ui-searchbar-text").tap(function(){
			$(".ui-searchbar-wrap").addClass('focus');
			$(".ui-searchbar-input input").focus();
		});
		$(".ui-searchbar-cancel").tap(function(){
			//发送请求
			App.search();
		});
		$(".ui-icon-close").tap(function(){
			$(".ui-searchbar-wrap").removeClass('focus');
			$(".ui-searchbar-input input").val("");
		});
	},
	
	/**
	 * 模糊查询
	 * type   1:为常用收款人
	 * key:模糊搜索关键字
	 * innerBank:0:行内,1:跨行
	 */
	search:function(){
		App.keys = $(".ui-searchbar-input input").val().replace(/\s/g,"");
		if(App.keys == ""){
			Fw.Form.showPinLabel($(this),"关键字不能为空", true);
			return false;
		}
		App.url = YT.dataUrl("private/blurQuery");
		App.json = {
				type:"1",
				innerBank:App.innerBank,
				key:App.keys
		}
		App.query();
//		Fw.Client.openWaitPanel(); 
//		var params = {
//				type:"1",
//				innerBank:App.innerBank,
//				key:keys
//		}
//		YT.ajaxData(url,params,App.sucSearch,App.failSearch);
	},
	/**
	 * 搜索成功
	 */
//	sucSearch:function( data ){
//		Fw.Client.hideWaitPanel(); 
//		if(data.STATUS == "1"){
//			var html = Fw.template(App.temp, respData);
//			$(".ui-container").html(html);
//			App.HUDONG();
//		}else{
//			Fw.Client.alertinfo(data.MSG,"消息提示");
//		};
//	},
//	failSearch:function( d ){
//		Fw.Client.hideWaitPanel(); 
//		Fw.Client.alertinfo("亲,网络不给力哦!","消息提示");
//	},
	/**
	 * 下拉列表
	 */
	query : function() { 
		Fw.Client.openWaitPanel();
//		var Url = YT.dataUrl("private/blurQuery");
//		var json = {
//				type:"1",
//				innerBank:App.innerBank,
//				key:App.keys
//		}
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "acctList",
			page : true,
			pageSize:20,
			disclosure : true,
			ajax : {
				url : App.url,
				params : App.json
			},
			itemTpl : App.temp1,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showToacctno, this);
		listView.swiper = App.swiper1;
		listView.loadData();
		
	},
	swiper1:function(res){
		return true;
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		Fw.Client.hideWaitPanel();
		if(rst.acctList.length == 0 && App.keys.length != 0){
			Fw.Client.alertinfo("无匹配记录，请重新输入","消息提示","App.onQueryData()");
			return false;
		}
		if(rst.acctList.length == 0 && App.keys.length == 0){
			$(".ui-searchbar-wrap").hide();
			return false;
		}
		var page = pageIndex || 1;
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
//	initData:function(){
//		var html = Fw.template(App.temp, App.data);
//		$(".ui-container").html(html);
//		App.HUDONG();
//	},
	/**
	 * 加载数据
	 */
	onQueryData : function() {
		Fw.Client.openWaitPanel("加载中..."); 
		App.url = YT.dataUrl('private/acctOperate');
		// 【行内0】【跨行1】
		App.json = {
				OperateType:"2",
				innerBank: App.innerBank
		}
		App.keys = "";
		App.query();
//		YT.ajaxData(url, {OperateType:"2",innerBank: App.innerBank}, function(respData) {
//			App.data = respData;
//			if(respData.hasOwnProperty("datas")==0){
//				$(".ui-container").html('<div style="padding:10px; text-align:center; font-size:20px;">暂时没有常用收款账号</div>');
//				Fw.Client.hideWaitPanel(2000);
//				return false;
//			}
//			var html = Fw.template(App.temp, respData);
//			$(".ui-container").html(html);
//			App.HUDONG();
//			Fw.Client.hideWaitPanel(2000);
//		}, function() {
//			alert("查询失败！")
//		});
	},
	
	/**
	 * 账号格式化
	 *	format : function(s) {
	 *		a = s.substring(s.length - 4, s.length);
	 *	},
	 */
	/**
	 * 滑动事件加载
	 */
	HUDONG: function(){
		var swiper = new Swiper('.swiper-container', {
		        slidesPerView: 'auto',
		        freeMode: true,
		        freeModeMomentumBounce: false,
		        spaceBetween: 0
		    });
    	$(".swiper-slide-change").on("click",function(){
    		var e = $(this);
    		//发送接口查询省市开户行判断是否是跨行汇款
    		if(Fw.getParameters("_parameters").innerBank == "1"){
    			var url = YT.dataUrl("private/findAcctInfo");
        		var params = {
        				brCode:$(this).find(".brCode").val(),
        				cityCode:$(this).find(".cityCode").val(),
        		}
        		Fw.Client.openWaitPanel();
        		YT.ajaxData(url,params,function(data){
        				App.datas = data;
        				App.showToacctno(e);
        		});
    		}
    		App.showToacctno($(this));
    	});
    	$(".item-delete").on("click", function (e) {
        	e.stopPropagation();
            console.log('tap:item-delete button');
            mydialog( $(this) );
        });
        function mydialog( elem ) {
        	App.acctNo = elem.attr("id");
        	App.elem = elem
        	Fw.Client.confirm("确认删除该账户","消息提示","App.test()",null,"确定","取消");
        }
	},
	/**
	 * 选择账号后返回
	 */
	showToacctno:function(e){
		var json={}
		if(Fw.getParameters("_parameters").innerBank =="0"){
			 json={
	    			bankName: e.find(".bankName").val(),
	    			bankNo:e.find(".acctNo").val(),
	    			toAcctName:e.find(".toAcctName").val(),
	    			innerBank:"0",
					bank:"0",
					bankId:Fw.getParameters("_parameters").bankId,
					trsNoName:Fw.getParameters("_parameters").trsNoName,
					hkje:Fw.getParameters("_parameters").hkje,
					dxhkje:Fw.getParameters("_parameters").dxhkje,
					inputCheckbox:Fw.getParameters("_parameters").inputCheckbox,
					memo:Fw.getParameters("_parameters").memo,
					SPR:Fw.getParameters("_parameters").SPR,
					SPRID:Fw.getParameters("_parameters").SPRID,
					attch:Fw.getParameters("_parameters").attch,
					url:Fw.getParameters("_parameters").url,
					length:Fw.getParameters("_parameters").length,
					memo:Fw.getParameters("_parameters").memo,
					dealUser:Fw.getParameters("_parameters").dealUser,
					trsNo:Fw.getParameters("_parameters").trsNo
	    		}
		}else{
			 json = {
    				hukuan:Fw.getParameters("_parameters").hukuan,
    				toAcctName:e.find(".toAcctName").val(),//收款户名
    				hkje:Fw.getParameters("_parameters").hkje,//汇款金额
    				HKJE:Fw.getParameters("_parameters").HKJE,
    				capsAmount:Fw.getParameters("_parameters").capsAmount,
    				dxhkje:Fw.getParameters("_parameters").dxhkje,//金额大写
    				bankName:e.find(".bankName").val(),//收款银行
    				bankCode:e.find(".bankCode").val(),
    				bankNo:e.find(".acctNo").val(),
    				brName:App.datas.BRNAME,
    				brCode:App.datas.brCode,
    				attach:Fw.getParameters("_parameters").attach,
					url:Fw.getParameters("_parameters").url,
    				provinceName:App.datas.PROVINCENAME +" "+ App.datas.CITYNAME,
    				provinceCode:App.datas.PROVINCECODE,
    				cityCode:App.datas.cityCode,
    				memo:Fw.getParameters("_parameters").memo,
    				dealUser:Fw.getParameters("_parameters").dealUser,
    				oldDatas:Fw.getParameters("_parameters").oldDatas,
    				back:"1",
    				trsNo:Fw.getParameters("_parameters").trsNo
    		}
		}
		Fw.Client.hideWaitPanel();
		var key = Fw.getParameters("_parameters").bank;
    	switch (key) {
		case '0':
			Fw.redirect("1040106_A.html",json);
			break;
		case '1':
			Fw.redirect("1040106_B.html",json);
			break;
		case '2':
			Fw.redirect("1040106_C.html",json);
			break;
		case '3':
			Fw.redirect("1040100_YTHXG.html",json);
			break;
		case '4':
			Fw.redirect("1040100_XGKH.html",json);
			break;
		default:
			break;
		}
	},
	/**
	 * 删除账号
	 */
	test:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/acctOperate");
		var params = {
				innerBank:Fw.getParameters("_parameters").innerBank,
				ACCT_NO:App.acctNo,
				OperateType:"1"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS == "1"){
				Fw.Form.showPinLabel($(this), "删除账户成功", true);
				App.elem.parent().remove();
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});
	},
	/**
	 * 返回前一页
	 */
	gotoBackTest:function(){
		var json={}
		if(Fw.getParameters("_parameters").innerBank =="0"){
			 json={
	    			toAcctName: Fw.getParameters("_parameters").trsNoName,
	    			bankNo:Fw.getParameters("_parameters").bankId,
	    			innerBank:"0",
					bank:"0",
					bankId:Fw.getParameters("_parameters").bankId,
					trsNoName:Fw.getParameters("_parameters").trsNoName,
					hkje:Fw.getParameters("_parameters").hkje,
					dxhkje:Fw.getParameters("_parameters").dxhkje,
					inputCheckbox:Fw.getParameters("_parameters").inputCheckbox,
					memo:Fw.getParameters("_parameters").memo,
					SPR:Fw.getParameters("_parameters").SPR,
					attch:Fw.getParameters("_parameters").attch,
					url:Fw.getParameters("_parameters").url,
					SPRID:Fw.getParameters("_parameters").SPRID,
					attch:Fw.getParameters("_parameters").attch,
					length:Fw.getParameters("_parameters").length,
					dealUser:Fw.getParameters("_parameters").dealUser,
					trsNo:Fw.getParameters("_parameters").trsNo
	    		}
		}else{
			 json = {
					hukuan:Fw.getParameters("_parameters").hukuan,
    				bankNo: Fw.getParameters("_parameters").bankNo,//收款账号
    				toAcctName:Fw.getParameters("_parameters").toAcctName,//收款户名
    				hkje:Fw.getParameters("_parameters").hkje,//汇款金额
    				HKJE:Fw.getParameters("_parameters").HKJE,
    				capsAmount:Fw.getParameters("_parameters").capsAmount,
    				dxhkje:Fw.getParameters("_parameters").dxhkje,//金额大写
    				bankName:Fw.getParameters("_parameters").bankName,//收款银行
    				bankCode:Fw.getParameters("_parameters").bankCode,
    				brName:Fw.getParameters("_parameters").brName,
    				brCode:Fw.getParameters("_parameters").brCode,
    				attach:Fw.getParameters("_parameters").attach,
					url:Fw.getParameters("_parameters").url,
    				provinceName:Fw.getParameters("_parameters").provinceName,
    				provinceCode:Fw.getParameters("_parameters").provinceCode,
    				cityCode:Fw.getParameters("_parameters").cityCode,
    				memo:Fw.getParameters("_parameters").memo,
    				dealUser:Fw.getParameters("_parameters").dealUser,
    				back:"1",
    				oldDatas:Fw.getParameters("_parameters").oldDatas,
    				trsNo:Fw.getParameters("_parameters").trsNo
    				}
		}
		var key = Fw.getParameters("_parameters").bank;
    	switch (key) {
		case '0':
			Fw.redirect("1040106_A.html",json);
			break;
		case '1':
			Fw.redirect("1040106_B.html",json);
			break;
		case '2':
			Fw.redirect("1040106_C.html",json);
			break;
		case '3':
			Fw.redirect("1040100_YTHXG.html",json);
			break;
		case '4':
			Fw.redirect("1040100_XGKH.html",json);
			break;
		default:
			break;
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
