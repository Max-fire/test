/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.flag = true;
		YT.showPageArea(App.pageA, [], true);
		App.initEvent();
		if(App.func("trsStatus")){
			switch (App.func("trsStatus")) {
			case '1':
				App.onYCL();
				break;
			case '2':
				App.onYTH();
				break;
			default:
				App.onDCL();
				break;
			}
		}else{
			App.onDCL();
		}
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 已处理按钮
		App.pageA.on("click", "#liYCL", App.onYCL);
		// 待处理按钮
		App.pageA.on("click", "#liDCL", App.onDCL);
		// 已作废按钮
		App.pageA.on("click", "#liYTH", App.onYTH);
		// 新建按钮
		App.pageA.on("click", "#btn-show", App.onShow);
		//标题点击事件
		App.pageA.on("click","#icon-top",App.onTop);
		//我处理的点击事件
		App.pageA.on("click","#btnIconc",App.initWCLD);
	},
	
	/**
	 * 标题点击事件,收起展开
	 */
	onTop:function(){
		if(App.flag){
			$("#top-center").addClass("hidden");
			$("#top-bottom").removeClass("yui-background-top").addClass("yui-background-topB");
			$("#tab-navnew").removeClass("yui-ui-tab-navnew").addClass("yui-ui-tab-navnewB");
			$("#top-bg").removeClass("yui-height170").addClass("yui-height70");
			$("#icon-topA").removeClass("yui-background-top1").addClass("yui-background-top2");
			App.flag = false;
		}else{
			$("#top-bg").removeClass("yui-height70").addClass("yui-height170");
			$("#top-bottom").removeClass("yui-background-topB").addClass("yui-background-top");
			$("#tab-navnew").removeClass("yui-ui-tab-navnewB").addClass("yui-ui-tab-navnew");
			$("#top-center").removeClass("hidden");
			$("#icon-topA").removeClass("yui-background-top2").addClass("yui-background-top1");
			App.flag = true;
		};
	},
	/**
	 * 标题我处理的
	 */
	initWCLD:function(){
		$("#btnIconb").removeClass("yui-backgroud-iconb").addClass("yui-backgroud-iconbb");
		$("#colIconb").removeClass("yui-font-col1").addClass("yui-font-col2");
		$("#btnIconc").removeClass("yui-backgroud-iconcc").addClass("yui-backgroud-iconc");
		$("#colIconc").removeClass("yui-font-col2").addClass("yui-font-col1");
		Fw.Client.changePage("1040105.html","0");
	},
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
			}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		switch (App.trsStatus) {
		case '0':
			$.get("10401_LB.html?v=SID", {}, App.query);
			break;
		case '1':
			$.get("10401_LB.html?v=SID", {}, App.query);
			break;
		case '2':
			$.get("10401_LB.html?v=SID", {}, App.query);
			break;

		default:
			break;
		}
	},
	/**
	 * 已处理
	 */
	onYCL : function() {
		Fw.Client.openWaitPanel();
		App.pageA.off("click", "#liYCL", App.onYCL);
		App.pageA.off("click", "#liDCL", App.onDCL).on("click", "#liDCL", App.onDCL);
		App.pageA.off("click", "#liYTH", App.onYTH).on("click", "#liYTH", App.onYTH);
		App.pageA.attr("data-btnRight","true|时间|App.showSendTime()");
		YT.showPageArea(App.pageA, [], true);
		$("#t").attr("class", "yui-background-3 yui-background");
		$("#liYTH").removeClass("current yui-current");
		$("#d").attr("class", "yui-background-4 yui-background");
		$("#liDCL").removeClass("current yui-current");
		$("#y").attr("class", "yui-background-5 yui-background");
		$("#liYCL").addClass("current yui-current");
		App.trsStatus = "1";
		App.beginTime ="";
		App.endTime ="";
		$.get("10401_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 待处理
	 */
	onDCL : function() {
		Fw.Client.openWaitPanel();
		App.pageA.off("click", "#liYCL", App.onYCL).on("click", "#liYCL", App.onYCL);
		App.pageA.off("click", "#liDCL", App.onDCL);
		App.pageA.off("click", "#liYTH", App.onYTH).on("click", "#liYTH", App.onYTH);
		App.pageA.attr("data-btnRight","true|时间|App.showSendTime()");
		YT.showPageArea(App.pageA, [], true);
		$("#t").attr("class", "yui-background-3 yui-background");
		$("#liYTH").removeClass("current yui-current");
		$("#y").attr("class", "yui-background-2 yui-background");
		$("#liYCL").removeClass("current yui-current");
		$("#d").attr("class", "yui-background-1 yui-background");
		$("#liDCL").addClass("current yui-current");
		App.trsStatus = "0";
		App.beginTime ="";
		App.endTime ="";
		$.get("10401_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 已退回
	 */
	onYTH : function() {
		Fw.Client.openWaitPanel();
		App.pageA.off("click", "#liYCL", App.onYCL).on("click", "#liYCL", App.onYCL);
		App.pageA.off("click", "#liDCL", App.onDCL).on("click", "#liDCL", App.onDCL);
		App.pageA.off("click", "#liYTH", App.onYTH);
		$("#pageA").attr("data-btnRight","false||");
		YT.showPageArea(App.pageA, [], true);
		$("#d").attr("class", "yui-background-4 yui-background");
		$("#liDCL").removeClass("current yui-current");
		$("#y").attr("class", "yui-background-2 yui-background");
		$("#liYCL").removeClass("current yui-current");
		$("#t").attr("class", "yui-background-6 yui-background");
		$("#liYTH").addClass("current yui-current");
		App.trsStatus = "2";
		App.beginTime ="";
		App.endTime ="";
		$.get("10401_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 加载列表查询条件【事务类型 】【指令状态】【查询时间】
	 */
	query : function(tpl) {
		var json = {
			trsType : "1",
			trsStatus : App.trsStatus,
			timeBegin : App.beginTime,
			timeEnd :App.endTime
		};
		var url = YT.dataUrl("private/findTaskOfSended");
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "datas",
			page : true,
			pageSize : 5,
			disclosure : true,
			ajax : {
				url : url,
				params : json
			},
			itemTpl : tpl,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(App.trsStatus);
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		var page = pageIndex || 1;
		Fw.Client.hideWaitPanel();
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 显示详情
	 */
	showDetail : function(itemData, itemIndex, itemElem) {
		if(itemData.trsferType=="STAFF_TRANSFER"){
			Fw.Client.changePage('../10406/det15C.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
		}else if(itemData.trsferType=="SALARY_TRANSFER"){
			Fw.Client.changePage('../details/det15C.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
		}else{
			Fw.Client.changePage('../details/det05.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+'',"1");
		}
	},
	/**
	 * 新建
	 */
	onShow : function() {
		var datas = new Array();
		datas.push({
				name : "行内汇款",
				flag:"intside",
				func : "App.showHNHKbtn()"
				});
		datas.push({
			name : "跨行汇款",
			flag:"outside",
			func : "App.showKHHKbtn()"
			});
		datas.push({
			name : "员工汇款",
			flag:"peoside",
			func : "App.showYGHKbtn()"
		});
		datas.push({
			name : "传统代发",
			flag:"tradition",
			func : "App.showCTDFbtn()"
		});
		Fw.Client.showPopupWindow(datas);
	},
	/**
	 * 跳转到行内汇款
	 */
	showHNHKbtn : function(){
		var url = YT.dataUrl("private/isApproval");
	    YT.ajaxData(url,{trsType:"3"},function(Data){
	    	if(Data.IsApproval=="YES"){
	    		Fw.Client.changePage("1040106_C.html?effectiveUserId=1&dealUser=1&trsStatus="+App.trsStatus+"", "1");
	    	}else{
	    		Fw.Client.changePage("1040106_A.html?effectiveUserId=1&dealUser=1&trsStatus="+App.trsStatus+"", "1");
	    	}
	    })	
	},
	/**
	 * 跳转到跨行汇款页面
	 */
	showKHHKbtn : function() {
		Fw.Client.changePage("1040106_B.html?effectiveUserId=1&dealUser=1&trsStatus="+App.trsStatus+"", "1");
	},
	/**
	 * 选择汇款员工
	 * paraFlag 0:失效 1：有效
	 */
	showYGHKbtn : function() {
		var url = YT.dataUrl("private/queryPara");
		var params={paraCode:'100000'};
	    YT.ajaxData(url,params,function(data){
	    	if(data.STATUS=='1'&& data.para.paraFlag=='1'){
	    		Fw.Client.chooseStaff("App.openPeople");
	    	} else {
				Fw.Client.alertinfo('该功能暂停使用，如有不便之处，敬请谅解！',"系统提示");
			}
	    },function(){
	    	Fw.Client.alertinfo('该功能暂停使用，如有不便之处，敬请谅解！',"系统提示");
	    });	
	},
	/**
	 * 跳转到员工汇款页面
	 */
	openPeople:function(data) {
		var datas=YT.JsonEval(data)
		Fw.redirect("../10406/1040607.html?dealUser=1&trsStatus="+App.trsStatus+"",datas.userPcList);
	},
	/**
	 * 选择传统代发
	 * ------------------------------------------------------------------------------------------------------
	 */
	showCTDFbtn : function() {
	  Fw.Client.chooseStaff("App.opentraPeople","1");
	},
	/**
	 * 跳转到传统代发页面
	 */
	opentraPeople:function(data) {
		var datas=YT.JsonEval(data)
		Fw.redirect("../10406/1040612.html?dealUser=1&trsStatus="+App.trsStatus+"",datas.userPcList);
	},
	/**
	 * 返回工作首页
	 */
	gotoHomePage:function(){
		if(App.func('back') && App.func('back')=='1061210'){
			Fw.Client.changePage("../10612/1061210.html");
		}else{
			Fw.Client.gotoHomePage();
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);