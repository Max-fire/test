/**
 * 创建应用
 * 
 * @author yql
 */

var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		Fw.Client.hideWaitPanel();
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, [App.pageB], true);	
		App.attchList = new Array();
		App.attch  = new Array();
		App.memolist=null;
		App.i = 0;
		App.flag = false;
		App.initEvent();
		App.initPageA();

	},
	initEvent : function() {
		// 加载常用按钮-事件
		App.pageA.on("click","#CYSKZH",App.initCYSKZH);
		// 收款银行-事件
		App.pageA.on("click","#SKYH",App.initSKYH);
		// 所在省份-事件
		App.pageA.on("click","#SZSS",App.initSZSS);
		// 开户支行-事件
		App.pageA.on("click","#KHZH",App.initKHZH);
		// 添加附件-事件
		App.pageA.on("click",".TJFJ",App.initTJFJ);
		// 选择审批人-事件
		App.pageA.on("click","#SPR",App.initSPR);
		//调用金额键盘
		App.pageA.on("click","#hkje",App.showMoneyPicker);
		// 校验后提交-事件
		App.pageA.on("click", "#btnSubmit", App.initSubmit);
		//初始化办结事件
		App.pageA.on("click","#bj",App.changeBj);
		//初始化转办事件
		App.pageA.on("click","#zb",App.changeZb);
		//点击我知道了
		App.pageA.on("click","#iknow",App.toIknow);
		//备注控制字节
		App.pageA.on("porpertychanger","#memo",App.toMemo);
		App.pageA.on("click","#CYs",App.initCYs);
		//取单个常用用途
		App.pageA.on("click",".yui-newCover-item",App.commonItem);
		
		App.pageA.on("input","#memo",App.toMemo);
	},
	/**
	 * 落地审核提示显示
	 */
	initTS:function(){
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#black_b").attr("style","height:"+height+"px;");
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black_b").removeClass("hidden");
		$("#white_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	/**
	 * 取消弹窗提示
	 */
	toIknow:function(){
		App.pageA.unbind("touchmove");
		$("#black_b").addClass("hidden");
		$("#white_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 备注控制字节
	 */
	toMemo:function(){
		Fw.util.Format.checkNum("memo",60);
	},
	/**
	 * 初始化加载页面数据
	 */
	initPageA: function(){
		
		if(Fw.getParameters("_parameters") == null){
			if(App.func("status")){
				Fw.Client.openWaitPanel();
				var url = YT.dataUrl("private/getTaskDetail");
				var params = {
						trsNo:App.func("json"),
						trsType:"1"
				}
				YT.ajaxData(url,params,function(data){
					if(data.STATUS == "1"){
						App.data = App.func("json");
						if(data.trsTrsfr[0].trsferType){
							$("input:radio[value="+data.trsTrsfr[0].trsferType+"]").attr("checked","true");
						}
						$("#bankId").val(data.trsTrsfr[0].toAcctNo);
						$("#toAcctNo").val(data.trsTrsfr[0].toAcctNo);
						$("#toAcctName").val(data.trsTrsfr[0].toAcctName);
						$("#hkje").val("\u00A5"+Fw.util.Format.fmtAmt(data.trsTrsfr[0].amount.toString()));
						$("#HKJE").val(data.trsTrsfr[0].amount);
						$("#capsAmount").html(Fw.util.Format.fmtNumber2Chinese(data.trsTrsfr[0].amount.toString()));
						$("#toBank").val(data.trsTrsfr[0].toBankName);
						$("#toBankId").val(data.trsTrsfr[0].toBankCode);
						$("#shen").val(data.trsTrsfr[0].toExchngCity);
						$("#shenId").val(data.trsTrsfr[0].toProvinceCode);
						$("#shiId").val(data.trsTrsfr[0].toCityCode);
						$("#khzhName").val(data.trsTrsfr[0].toBrName);
						$("#bank").val(data.trsTrsfr[0].toBrName);
						$("#khzh").val(data.trsTrsfr[0].toBrCode);
						$("#memo").val(data.trsTrsfr[0].memo);
						$("#bankId").blur();
						$("#toAcctName").blur();
						$("#khzhName").blur();
						$("#bank").blur();
						$("#memo").blur();
						Fw.Client.hideWaitPanel();
					}else{
						Fw.Client.hideWaitPanel();
					}
				});
			}
		};
		if(Fw.getParameters("_parameters")){
			App.data = Fw.getParameters("_parameters").trsNo;
			$("input:radio[value="+Fw.getParameters("_parameters").hukuan+"]").attr("checked","true");
			$("#bankId").val(Fw.getParameters("_parameters").bankNo);
			$("#toAcctNo").val(Fw.getParameters("_parameters").bankNo);
			$("#toAcctName").val(Fw.getParameters("_parameters").toAcctName);
			$("#hkje").val(Fw.getParameters("_parameters").hkje);
			$("#HKJE").val(Fw.getParameters("_parameters").HKJE);
			$("#capsAmount").html(Fw.getParameters("_parameters").capsAmount);
			$("#toBank").val(Fw.getParameters("_parameters").bankName);
			$("#toBankId").val(Fw.getParameters("_parameters").bankCode);
			if(Fw.getParameters("_parameters").provinceName){
				$("#shen").val(Fw.getParameters("_parameters").provinceName);
				$("#shenId").val(Fw.getParameters("_parameters").provinceCode);
				$("#shiId").val(Fw.getParameters("_parameters").cityCode);
			}
			$("#khzhName").val(Fw.getParameters("_parameters").brName);
			$("#bank").val(Fw.getParameters("_parameters").brName);
			$("#khzh").val(Fw.getParameters("_parameters").brCode);
			$("#memo").val(Fw.getParameters("_parameters").memo);
			if(Fw.getParameters("_parameters").back == "2" && Fw.getParameters("_parameters").bankName != Fw.getParameters("_parameters").bankNameA){
				$("#shen").val("");
				$("#shenId").val("");
				$("#shiId").val("");
				$("#khzhName").val("");
				$("#khzh").val("");
			}
			var attach = Fw.getParameters("_parameters").attach;
			var url = Fw.getParameters("_parameters").url;
			for ( var k = 0; k < attach.length; k++) {
				if(attach[k] != null){
					App.showAttcchment(attach[k].name,url);
				}
				
			}
		}

		$("#bankId").blur();
		$("#toAcctName").blur();
		$("#bank").blur();
		$("#khzhName").blur();
		$("#memo").blur();
		
		var url = YT.dataUrl("private/isApproval");
		YT.ajaxData(url,{trsType:"3"},function(data){
			if(data.STATUS == "1"){
				if(data.IsApproval == "YES"){
					$("#CZAN").removeClass("hidden");
					$("#XZSPR").attr("hidden","");
				}else{
					$("#XZSPR").removeAttr("hidden","");
				}
			}
		},function(){});
	},
	changeBj : function() {
		$("#bj").removeClass("yui-backgroud-a");
		$("#bj").addClass("yui-backgroud-a1");
		$("#zb").removeClass("yui-backgroud-b1");
		$("#zb").addClass("yui-backgroud-b");
		$("#XZSPR").attr("hidden","");
		$("#trsStatus").val("0");
	},
	changeZb : function() {
		$("#zb").removeClass("yui-backgroud-b");
		$("#zb").addClass("yui-backgroud-b1");
		$("#bj").removeClass("yui-backgroud-a1");
		$("#bj").addClass("yui-backgroud-a");
		$("#XZSPR").removeAttr("hidden","");
		$("#trsStatus").val("1");
	},
	/**
	 * 夹页面数据放到session中
	 */
	addSession: function(key){
		var json = {
				bank:"4",
				innerBank:"1",
				hukuan:$("input[type='radio']:checked").val(),
				bankNo: $("#toAcctNo").val(),//收款账号
				toAcctName:$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),//收款户名
				hkje:$("#hkje").val(),//汇款金额
				HKJE:$("#HKJE").val(),
				capsAmount:$("#capsAmount").html(),
				bankName: $("#toBank").val(),//收款银行
				bankNameA:$("#toBank").val(),
				bankCode: $("#toBankId").val(),
				attach:App.attch,
				url:App.url,
				provinceName:$("#shen").val(),
				provinceCode:$("#shenId").val(),
				cityCode:$("#shiId").val(),
				brName:$("#khzhName").val(),
				brCode:$("#khzh").val(),
				memo:$("#memo").val(),
				BankData:App.BankData,
				gotoBack:"2",
				trsNo:App.data
				}
		switch (key) {
		case '1':
			Fw.redirect("1040107.html",json);
			break;
		case '2':
			Fw.redirect("1040108.html",json);
			break;
		case '3':
			Fw.redirect("1040110.html",json);
			break;
		default:
			break;
		}
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker: function(){
		Fw.Client.showMoneyPicker($("#hkje"));
	},
	/**
	 * 常用按钮
	 */
	initCYSKZH : function(){
		App.addSession('1');
	},
	/**
	 * 收款银行
	 */
	initSKYH : function(){
		var json = {
				bank:"4",
				innerBank:"1",
				hukuan:$("input[type='radio']:checked").val(),
				bankNo: $("#toAcctNo").val(),//收款账号
				toAcctName:$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),//收款户名
				hkje:$("#hkje").val(),//汇款金额
				HKJE:$("#HKJE").val(),
				capsAmount:$("#capsAmount").html(),
				bankName: $("#toBank").val(),//收款银行
				bankNameA:$("#toBank").val(),
				bankCode: $("#toBankId").val(),
				attach:App.attch,
				url:App.url,
				provinceName:$("#shen").val(),
				provinceCode:$("#shenId").val(),
				cityCode:$("#shiId").val(),
				brName:$("#khzhName").val(),
				brCode:$("#khzh").val(),
				memo:$("#memo").val(),
				BankData:App.BankData,
				gotoBack:"2",
				trsNo:App.data
				}
		Fw.redirect("1040101.html",json);
//		App.addSession('2')
	},
	/**
	 * 所在省份
	 */
	initSZSS : function(){
		var bankCode=$("#toBankId").val();
		if(bankCode!=""){
			Fw.Client.openProvince("App.showProvince");
		}else{
			Fw.Form.showPinLabel($(this), "请选择收款银行", true);
			return;
		}
		
	},
	/**
	 * 省份回掉函数
	 */
	showProvince: function(name1,id1,name2,id2){
		if(name1+"　"+name2 != $("#shen").val()){
			$("#shen").val(name1+"　"+name2);
			$("#shenId").val(id1);
			$("#shiId").val(id2);
			$("#khzhName").val("");
			$("#khzh").val("");
		}
	},
	/**
	 * 开户支行
	 */
	initKHZH : function(){
		if($("#shenId").val() !="" && $("#shiId").val() !="" && $("#toBankId").val()!=""){
			Fw.Client.openWaitPanel();
			var url = YT.dataUrl("private/findBranch");
			var json = {
					provinceCode:$("#shenId").val(),
					cityCode:$("#shiId").val(),
					bankCode:$("#toBankId").val()
			}
			YT.ajaxData(url,json,function(data){
				Fw.Client.hideWaitPanel();
				if(data.LIST.length!= "0"){
					App.BankData = data;
					App.showBank();
				}else{
					Fw.Form.showPinLabel($(this), "所在省市暂无支行", true);
					return;
				}
			});
		}else{
			Fw.Form.showPinLabel($(this), "请选择收款银行和所在省市", true);
			return;
		}
	},
	showBank : function(){
		App.addSession("3");
	},
	/**
	 * 添加附件
	 */
	initTJFJ : function(){
		if(App.attch.length >5){
			Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
			return;
		}
		Fw.Client.openAttcchment("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		//调用附件添加函数Fw.util.attach.addAttach(name,url);
		Fw.util.attach.addAttach(name,url);
	},
	/**
	 * 选择审批人
	 */
	initSPR : function(){
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name,id,co){
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	
	/**
	 * 打开常用用途弹框
	 */
	initCYs:function(){

		Fw.Client.openWaitPanel();
		var height=document.body.clientHeight+500;
		var html="";
		var url=YT.dataUrl("private/commonMemo");
		YT.ajaxData(url,{type:'2'},function(json){
			if(json.STATUS == '1'){
				var list=[];
				list=(json.last).concat(json.history).concat(json.deft);
				App.memolist = list;
				for ( var d in list) {
					var l;
					list[d] = list[d].replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
					if(list[d].length>10){
						 l = list[d].substring(0,10)+"...";
					}else{
						 l = list[d];
					}
					html+='<div class="yui-newCover">';
					if(json.last.length!=0){ //有历史记录
						if(d<json.last.length){
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/historymemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}else{
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}
					}else{
						html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
					}
					
					html+='<div>';
				}
				$("#memorys").html(html);
				$("#black_b").attr("style","height:"+height+"px;");
				$("#black_b").attr("style","position:fixed");
				
				$("#black_b").removeClass("hidden");
				$("#white_c").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), json.MSG, true);
			}
		})
		
	},
	/**
	 * 取单个常用用途
	 */
	commonItem:function(index){
		App.pageA.unbind("touchmove");
		var commonMemo = App.memolist[index];
		commonMemo = commonMemo.replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
		if($("#memo").html()==""){
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}else{
			$("#memo").html();
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}
		$("#black_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	
	/**
	 * 事务提交
	 */
	initSubmit:function(){
		var trsferType = $("input[type='radio']:checked").val();
		var toAcctNo = $("#bankId").val().replace(/\s/g,"");
		var toAcctName =$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var amount = $("#HKJE").val();
		var toBankCode = $("#toBank").val();
		var toBankCodeId = $("#toBankId").val();
		var shenId = $("#shenId").val();
		var shiId = $("#shiId").val();
		var toBankName = $("#khzhName").val();
		var brCode = $("#khzh").val();
		var attach = App.attch;
		var memo = $("#memo").val().replace(/\s/g,"");
		var dealUserName = $("#dealUserName").val();
		var dealUserId = $("#dealUserId").val();
		var communicateId = $("#communicateId").val();
		if (toAcctNo.trim() == "") {
			Fw.Form.showPinLabel($(this), "请输入收款账号", true);
			return;
		}
		var reg = /^[0-9a-zA-Z-_\s]*$/.test(toAcctNo);
		if(!reg){
			Fw.Form.showPinLabel($(this), "收款账号不合法", true);
			return;
		}
		//收款户名
		if (toAcctName == null || toAcctName == "") {
			Fw.Form.showPinLabel($(this), "请输入有效的收款户名", true);
			return;
		}
		//校验户名是否包含emoji表情
		if(Fw.util.proofTest.proolEmoji(toAcctName)){
			Fw.Form.showPinLabel($(this), "收款户名包含特殊字符", true);
			return;
		}
		//会看金额是否大于零
		if(!(amount > 0)){
			Fw.Form.showPinLabel($(this), "汇款金额必须大于0", true);
			return;
		}
		if(toBankCodeId == ""){
			Fw.Form.showPinLabel($(this), "请选择收款银行", true);
			return;
		}
		//校验开户支行是否选择
		if(brCode == ""){
			Fw.Form.showPinLabel($(this), "请选择开户支行", true);
			return;
		}
		//备注
		if(Fw.util.proofTest.proolEmoji(memo)){
			Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
			return;
		}
		if(!($("#CZAN").hasClass("hidden"))){
			if($("#trsStatus").val() == ""){
				Fw.Form.showPinLabel($(this), "请选择操作类型", true);
				return;
			}
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel();
		if($("#CZAN").hasClass("hidden")){
			App.toConfirm();
		}else{
			if($("#trsStatus").val() == ""){
				App.flag = false;
				Fw.Form.showPinLabel($(this), "请选择操作类型", true);
				return;
			}
			if($("#trsStatus").val() == "0"){
				var url = YT.dataUrl("private/isEffective");
				var json = {
					trsType:"3",
					amount:$("#HKJE").val(),
					bizNo:"3",
					flag:"2"
				}
				YT.ajaxData(url, json, function(suc) {
					if(suc.isAmount == "YES"){
						if (suc.isEffective == "YES") {
								Fw.Client.hideWaitPanel();
								App.initComplete();
						} else {
							App.flag = false;
							Fw.Form.showPinLabel($(this), "您的权限不足,请转办", true);
							Fw.Client.hideWaitPanel();
							return;
						}
					}else{
						App.flag = false;
						Fw.Form.showPinLabel($(this), "汇款金额不得大于渠道限额("+suc.listAmount.toFixed(2)+")", true);
						Fw.Client.hideWaitPanel();
						return;
					}
				}, App.call);
		}else{
			App.toConfirm();
		}
		}
	},
	/**
	 * 办结
	 */
	initComplete:function(){
		var url = YT.dataUrl("public/getRandomNum");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = "private/transferTask.json";
				var params ={
						type:"1",
						trsType:"1",
						innerBank:"2",
						trsferType : $("input[type='radio']:checked").val(),
						toAcctNo : $("#bankId").val().replace(/\s/g,""),
						toAcctName :$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
						amount : $("#HKJE").val(),
						toBankName:$("#toBank").val(),
						toBankCode : $("#toBankId").val(),
						toProvinceCode : $("#shenId").val(),
						toCityCode : $("#shiId").val(),
						toExchngCity:$("#shen").val(),
						toBrName : $("#khzhName").val(),
						toBrCode : $("#khzh").val(),
						FileNameList:App.attch,
						FileUrl:App.url,
						memo : $("#memo").val().replace(/\s/g,""),
						dealUserName : $("#dealUserName").val(),
						dealUserId : $("#dealUserId").val(),
						toCommunicateId:$("#communicateId").val(),
						isComplete:"1",
						TOKEN:data.randomNum
				};
				Fw.Client.post(url, params, "App.initCommonAcct", "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),dataMSG,true);
				return;
			}
		});
	},
	/**
	 * 添加常用收款账号
	 */
	initCommonAcct:function(data){
		if(data.STATUS == "1"){
			if($("#inputCheckbox").is(":checked")){
				App.acctOperate();
			}
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo:data.trsNo,
					FileUrl:App.url,
					FileNameList:App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			var json={
					purpose:$("#memo").val(),
					toAcctName:$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"")
					};
			var amount = Fw.util.Format.replaceDouble("1",$("#HKJE").val());
			Fw.Client.hideWaitPanel();
			Fw.redirect("1040109.html?trsId="+""+"&trsStatus=2&innerBank=1&trsNo="+data.trsNo+"&JYLS="+data.trsNo+"&amount="+amount+"&toAcctNo="+$("#bankId").val().replace(/\s/g,"")+"",json);
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	/**
	 * 转办
	 */
	toConfirm : function() {
		
		if($("#dealUserId").val() == ""){
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Form.showPinLabel($(this), "请选择审批人", true);
			return;
		}
		var url = YT.dataUrl("public/getRandomNum");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = "private/transferTask.json";
				var params ={
						type:"1",
						trsType:"1",
						innerBank:"2",
						trsferType : $("input[type='radio']:checked").val(),
						toAcctNo : $("#toAcctNo").val().replace(/\s/g,""),
						toAcctName :$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
						amount : $("#HKJE").val(),
						toBankName:$("#toBank").val(),
						toBankCode : $("#toBankId").val(),
						toProvinceCode : $("#shenId").val(),
						toCityCode : $("#shiId").val(),
						toExchngCity:$("#shen").val(),
						toBrName : $("#khzhName").val(),
						toBrCode : $("#khzh").val(),
						FileNameList : App.attch,
						FileUrl:App.url,
						memo : $("#memo").val(),
						dealUserName : $("#dealUserName").val(),
						dealUserId : $("#dealUserId").val(),
						toCommunicateId:$("#communicateId").val(),
						TOKEN:data.randomNum
				};
				Fw.Client.post(url, params, "App.callSuccess", "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),dataMSG,true);
				return;
			}
		});
	},
	callSuccess: function(success){
		if(success.STATUS == "1"){
			if($("#inputCheckbox").is(":checked")){
				App.acctOperate();
			};
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo:success.trsNo,
					FileUrl:App.url,
					FileNameList:App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人："+$("#dealUserName").val(),"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(success.MSG,"消息提示");
			return false;
		}
	},
	callback:function(data){
		Fw.Client.alertinfo(data,"消息提示");
		return false;
	},
	/**
	 * 添加常用收款账号
	 */
	acctOperate:function(){
		var url1 = YT.dataUrl("private/acctOperate");
		var param = {
				OperateType : "0",
				ACCT_NO : $("#bankId").val().replace(/\s/g,""),
				innerBank : "1",
				ACCT_NAME : $("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
				BANK_NAME : $("#toBank").val(),
				BANK_CODE:$("#toBankId").val(),
				BR_CODE:$("#khzh").val(),
				CITY_CODE:$("#shiId").val()
		};
		YT.ajaxData(url1, param, function(data){
		}, function(){
			Fw.Client.alertinfo("网络异常","消息提示");
		});
	},
	test:function(){
		Fw.Client.hideWaitPanel();
		Fw.Client.changePage("1040100.html", true);
	},
	toBack:function(){
		Fw.Client.changePage("../details/det05.html?trsNo="+App.data+"&trsStatus="+"2"+"", true);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
