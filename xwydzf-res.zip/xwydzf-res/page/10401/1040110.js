/**
 * 创建应用
 * 
 * @author wjx
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
	},
	/**
	 * 加载数据,及相关事件
	 */
    initEvent : function(){
    	App.pageA.on("click",".yui-border-radius-re",App.getMsg);
    	App.pageA.on("click","#bankCode",App.getMsg);
		var temp = [
		            ' <ul class="ui-list ui-border-tb">',
		            	'{@each LIST as item}', 
			                '<li class="ui-border-radius ui-border-t yui-border-radius-re">',
			                	'<div class="yui-list-thumb-s" style="width: 1px;">',
//			                		'<span class="yui-yinhang-icon"></span>',
			                	'</div>',
			                	'<div class="ui-list-info  ui-border-t ui-border-t ">',
			                		'<h4 id="bankName" class="brName">${item.brName}</h4>',
			                		'<input id="${item.brName}" class="hidden" value="${item.brCode}"/>',
			                	'</div>',
			                '</li>',
			              '{@/each}',
		            '</ul>',
		            ].join("");
		var html = Fw.template(temp,Fw.getParameters("_parameters").BankData);
		App.pageA.find("#remen").html(html);
		$(".ui-searchbar-text").click(function(){
			$(".ui-searchbar-wrap").addClass('focus');
			$(".ui-searchbar-input input").focus();
		});
		$(".ui-searchbar-cancel").click(function(){
			//发送请求
			App.search();
		});
		$(".ui-icon-close").click(function(){
			$(".ui-searchbar-wrap").removeClass('focus');
			$(".ui-searchbar-input input").val("");
			$("#remen").show();
			$("#mhcx").hide();
		});
    	Fw.Client.hideWaitPanel();
    },
    /**
	 * 模糊查询
	 * type   1:为常用收款人 2:收款支行
	 * key:模糊搜索关键字
	 * innerBank:0:行内,1:跨行
	 */
	search:function(){
		var url = YT.dataUrl("private/blurQuery");
		App.keys = $(".ui-searchbar-input input").val().replace(/\s/g,"");
		if(App.keys == ""){
			Fw.Form.showPinLabel($(this),"关键字不能为空", true);
			return false;
		}
		Fw.Client.openWaitPanel(); 
		var data = Fw.getParameters("_parameters");
		var bankCode = data.banCode;
		var provinceCode = data.provinceCode;
		var cityCode = data.cityCode;
		var key = $(".ui-searchbar-input input").val();
		var params = {
				type:"2",
				bankCode:bankCode,
				provinceCode:provinceCode,
				cityCode:cityCode,
				key:key,
		}
		YT.ajaxData(url,params,App.sucSearch,App.failSearch);
	},
	/**
	 * 搜索成功
	 */
	sucSearch:function( data ){
		Fw.Client.hideWaitPanel(); 
		if(data.STATUS == "1"){
			$("#remen").hide();
			var html = '<div style="width: 100%; height: 44px; line-height: 44px; color: #017ef3; font-size: 18px; text-align: center;">没有数据</div>';
			if(data.branchList.length != 0){
				var temp = [
				            ' <ul class="ui-list ui-border-tb">',
				            	'{@each branchList as item}', 
					                '<li class="ui-border-radius ui-border-t yui-border-radius-re">',
					                	'<div class="yui-list-thumb-s" style="width: 1px;">',
					                	'</div>',
					                	'<div class="ui-list-info  ui-border-t ui-border-t ">',
					                		'<h4 id="bankName" class="brName">${item.br_name}</h4>',
					                		'<input id="${item.br_Name}" class="hidden" value="${item.br_code}"/>',
					                	'</div>',
					                '</li>',
					              '{@/each}',
				            '</ul>',
				            ].join("");
				html = Fw.template(temp,data);
			}
			$("#mhcx").html(html).show();
		}else{
			Fw.Client.alertinfo(data.MSG,"消息提示");
		};
	},
	failSearch:function( d ){
		Fw.Client.hideWaitPanel(); 
		Fw.Client.alertinfo("网路连接失败请重试","消息提示");
	},
    
    
    
    
    
    
    /**
     * 得到相应数据
     */
    getMsg : function(){
    	var brName = $(this).find(".brName").html();
    	var brCode = $(this).find(".hidden").val();
    	var json = {
				bankName : Fw.getParameters("_parameters").bankName,
				bankNameA:Fw.getParameters("_parameters").bankNameA,
				bankCode : Fw.getParameters("_parameters").banCode,
				hukuan:Fw.getParameters("_parameters").hukuan,
				bankNo: Fw.getParameters("_parameters").bankNo,//收款账号
				toAcctName:Fw.getParameters("_parameters").toAcctName,//收款户名
				hkje:Fw.getParameters("_parameters").hkje,//汇款金额
				HKJE:Fw.getParameters("_parameters").HKJE,
				capsAmount:Fw.getParameters("_parameters").capsAmount,
				dxhkje:Fw.getParameters("_parameters").dxhkje,//金额大写
				brName: brName,
				brCode:brCode,
				attach:Fw.getParameters("_parameters").attach,
				url:Fw.getParameters("_parameters").url,
				provinceName:Fw.getParameters("_parameters").provinceName,
				provinceCode:Fw.getParameters("_parameters").provinceCode,
				cityCode:Fw.getParameters("_parameters").cityCode,
				memo:Fw.getParameters("_parameters").memo,
				dealUser:Fw.getParameters("_parameters").dealUser,
				oldDatas:Fw.getParameters("_parameters").oldDatas,
				back:"2",
				trsNo:Fw.getParameters("_parameters").trsNo,
				gotoBack :Fw.getParameters("_parameters").gotoBack
    	}
    		Fw.redirect("1040101.html",json);
    },
    /**
     * 返回前一页 
     */
    gotoBackTest : function(){
    	var json = {
    			hukuan:Fw.getParameters("_parameters").hukuan,
				bankNo: Fw.getParameters("_parameters").bankNo,//收款账号
				toAcctName:Fw.getParameters("_parameters").toAcctName,//收款户名
				hkje:Fw.getParameters("_parameters").hkje,//汇款金额
				HKJE:Fw.getParameters("_parameters").HKJE,
				capsAmount:Fw.getParameters("_parameters").capsAmount,
				dxhkje:Fw.getParameters("_parameters").dxhkje,//金额大写
				bankName:Fw.getParameters("_parameters").bankName,//收款银行
				bankCode:Fw.getParameters("_parameters").banCode,
				brName:Fw.getParameters("_parameters").brName,
				brCode:Fw.getParameters("_parameters").brCode,
				attach:Fw.getParameters("_parameters").attach,
				url:Fw.getParameters("_parameters").url,
				provinceName:Fw.getParameters("_parameters").provinceName,
				provinceCode:Fw.getParameters("_parameters").provinceCode,
				cityCode:Fw.getParameters("_parameters").cityCode,
				memo:Fw.getParameters("_parameters").memo,
				dealUser:Fw.getParameters("_parameters").dealUser,
				oldDatas:Fw.getParameters("_parameters").oldDatas,
				back:"1",
				trsNo:Fw.getParameters("_parameters").trsNo,
				gotoBack :Fw.getParameters("_parameters").gotoBack
    	}
    	Fw.redirect("1040101.html",json);
    }
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
