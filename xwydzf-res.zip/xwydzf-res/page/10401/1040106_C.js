/**
 * 创建应用
 * 
 * @author wangjx
 */

var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		Fw.Client.hideWaitPanel();
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);
		App.attchList = new Array();
		App.attch = new Array();
		App.memolist=null;
		App.i = 0;
		App.flag = false;
		App.initEvent();
		App.initPageA();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 加载常用-事件
		App.pageA.on("click", "#CY", App.initCY);
		// 加载取户名-事件
		App.pageA.on("click", "#QHM", App.initQHM);
		// 加载点击添加附件-事件
		App.pageA.on("click", "#TJFJ", App.initTJFJ);
		// 加载点击选择审批人-事件
		App.pageA.on("click", "#dealUserName", App.initSPR);
		// 金额键盘
		App.pageA.on("click", "#hkje", App.showMoneyPicker);
		// 初始化办结事件
		App.pageA.on("click", "#bj", App.changeBj);
		// 初始化转办事件
		App.pageA.on("click", "#zb", App.changeZb);
		// 提交事件-提交
		App.pageA.on("click", "#btnSubmit", App.toConfirm);
		//落地审核提示显示
		App.pageA.on("click","#ts",App.initTS);
		//点击我知道了
		App.pageA.on("click","#iknow",App.toIknow);
		//备注控制字节
		App.pageA.on("porpertychanger","#memo",App.toMemo);
		App.pageA.on("input","#memo",App.toMemo);	
		App.pageA.on("click","#CYs",App.initCYs);
		//取单个常用用途
		//App.pageA.on("click",".yui-newCover-item",App.commonItem);	
	},
	/**
	 * 落地审核提示显示
	 */
	initTS:function(){
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#black_b").attr("style","height:"+height+"px;");
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black_b").removeClass("hidden");
		$("#white_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	/**
	 * 取消弹窗提示
	 */
	toIknow:function(){
		App.pageA.unbind("touchmove");
		$("#black_b").addClass("hidden");
		$("#white_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 备注控制字节
	 */
	toMemo:function(){
		Fw.util.Format.checkNum("memo",60);
	},
	/**
	 * 初始化页面数据
	 */
	initPageA : function(tpl_html) {
		if (Fw.getParameters("_parameters")) {
			$("#bankId").val(Fw.getParameters("_parameters").bankNo);
			$("#bankId").blur();
			$("#toAcctName").val(Fw.getParameters("_parameters").toAcctName);
			$("#toAcctName").blur();
			if (Fw.getParameters("_parameters").hkje) {
				$("#hkje").val(
						"\u00A5"
								+ Fw.util.Format.fmtMoney(Fw
										.getParameters("_parameters").hkje
										.toString()));
			}
			$("#HKJE").val(Fw.getParameters("_parameters").hkje);
			$("#capsAmount").html(Fw.getParameters("_parameters").dxhkje);
			$("#memo").val(Fw.getParameters("_parameters").memo);
			$("#memo").blur();
			$("#SPR").val(Fw.getParameters("_parameters").SPR);
			$("#SPRID").val(Fw.getParameters("_parameters").SPRID);
			if (Fw.getParameters("_parameters").SPRID) {
			}
			var attach = Fw.getParameters("_parameters").attch;
			var url = Fw.getParameters("_parameters").url;
			for ( var k = 0; k < Fw.getParameters("_parameters").length; k++) {
				App.showAttcchment(attach[k].name, url);
			}
		}
		App.fujian();
	},
	/**
	 * 选择常用账号
	 */
	initCY : function() {
		var dealUser = "";
		if(App.func("dealUser")){
			dealUser = App.func("dealUser");
		}else{
			dealUser = Fw.getParameters("_parameters").dealUser;
		};
		var json = {
			bank : "2",
			innerBank : "0",
			bankId : $("#bankId").val(),
			trsNoName : $("#toAcctName").val(),
			hkje : $("#HKJE").val(),
			dxhkje : $("#capsAmount").html(),
			inputCheckbox : $("#inputCheckbox").is(":Checked"),
			memo : $("#memo").val(),
			SPR : $("#SPR").val(),
			SPRID : $("#SPRID").val(),
			attch : App.attch,
			url : App.url,
			dealUser:dealUser,
			length : App.attch.length
		}
		Fw.redirect("1040107.html", json);
	},
	initCYs:function(){

		Fw.Client.openWaitPanel();
		var height=document.body.clientHeight+500;
		var html="";
		var url=YT.dataUrl("private/commonMemo");
		YT.ajaxData(url,{type:'1'},function(json){
			if(json.STATUS == '1'){
				var list=[];
				list=(json.last).concat(json.history).concat(json.deft);
				App.memolist = list;
				for ( var d in list) {
					var l;
					list[d] = list[d].replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
					if(list[d].length>10){
						 l = list[d].substring(0,10)+"...";
					}else{
						 l = list[d];
					}
					html+='<div class="yui-newCover">';
					if(json.last.length!=0){ //有历史记录
						if(d<json.last.length){
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/historymemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}else{
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}
					}else{
						html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
					}
					
					html+='<div>';
				}
				$("#memorys").html(html);
				$("#black_b").attr("style","height:"+height+"px;");
				$("#black_b").attr("style","position:fixed");
				
				$("#black_b").removeClass("hidden");
				$("#white_c").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), json.MSG, true);
			}
		})
		
	},
	/**
	 * 取单个常用用途
	 */
	commonItem:function(index){
		App.pageA.unbind("touchmove");
		var commonMemo = App.memolist[index];
		commonMemo = commonMemo.replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
		if($("#memo").html()==""){
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}else{
			$("#memo").html();
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}
		$("#black_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 取消弹窗
	 */
	toCancel:function(){
		$("#black_b").addClass("hidden");
		$("#white_c").addClass("hidden");
		
	},
	/**
	 * 选取户名
	 */
	initQHM : function() {
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("normal/tr1699");
		var trsNo = $("#bankId").val().replace(/\s/g,"");
		var params = {
			zhdh : trsNo,
			sfbz : "0"
		}
		YT.ajaxData(url, params, function(datas) {
			if (datas.STATUS == "1") {
				Fw.Client.hideWaitPanel();
				$("#toAcctName").val(datas.LIST.khmc);
				$("#toAcctName").blur();
				$("#toAcctName").focus();
			} else {
				$("#toAcctName").val("");
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), datas.MSG, true);
			}

		});
	},
	/**
	 * 选择添加附件
	 */
	initTJFJ : function() {
		if (App.attch.length > 5) {
			Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
			return;
		}
		Fw.Client.openAttcchment("App.showAttcchment");
	},
	showAttcchment : function(name, url) {
		//调用附件添加函数Fw.util.attach.addAttach(name,url);
		Fw.util.attach.addAttach(name,url);
	},
	/**
	 * 选择审批人
	 */
	initSPR : function() {
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id, co) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker : function() {
		Fw.Client.showMoneyPicker($("#hkje"));
	},
	/**
	 * 办结
	 */
	changeBj : function() {
		$("#bj").removeClass("yui-backgroud-a");
		$("#bj").addClass("yui-backgroud-a1");
		$("#zb").removeClass("yui-backgroud-b1");
		$("#zb").addClass("yui-backgroud-b");
		$("#XZSPR").attr("hidden", "");
		$("#trsStatus").val("0");
	},
	/**
	 * 转办
	 */
	changeZb : function() {
		$("#zb").removeClass("yui-backgroud-b");
		$("#zb").addClass("yui-backgroud-b1");
		$("#bj").removeClass("yui-backgroud-a1");
		$("#bj").addClass("yui-backgroud-a");
		$("#XZSPR").removeAttr("hidden", "");
		$("#trsStatus").val("1");
	},
	/**
	 * 事务提交
	 */
	toConfirm : function() {
		var toAcctNo = $("#bankId").val().replace(/\s/g,"");
		var toAcctName = $("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var amount = $("#HKJE").val();
		var memo = $("#memo").val().replace(/\s/g,"");
		var dealUserName = $("#dealUserName").val();
		var dealUserId = $("#dealUserId").val();
		var dealMsg = $("#dealMsg").val();
		var communicateId = $("#communicateId").val();
		if (dealMsg) {
			App.dealMsg = dealMsg;
		} else {
			App.dealMsg = "同意"
		}
		if (toAcctNo.trim() == "") {
			Fw.Form.showPinLabel($(this), "请输入收款账号", true);
			return;
		}
		var reg = /^[0-9a-zA-Z-_\s]*$/.test(toAcctNo);
		if (!reg) {
			Fw.Form.showPinLabel($(this), "收款账号不合法", true);
			return;
		}
		// 校验户名是否为空
		if (toAcctName == null || toAcctName == "") {
			Fw.Form.showPinLabel($(this), "请输入收款户名", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji(toAcctName)){
			Fw.Form.showPinLabel($(this), "收款户名不合法", true);
			return;
		}
		// 校验金额是否为空
		if (!(amount > 0)) {
			Fw.Form.showPinLabel($(this), "汇款金额必须大于0", true);
			return;
		}
		//备注是否包含表情
		if(Fw.util.proofTest.proolEmoji(memo)){
			Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
			return;
		}
		// 校验是否选择操作类型
		if ($("#trsStatus").val() == "") {
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		if ($("#trsStatus").val() == "1") {
			if (dealUserId == "") {
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
		}
		// 防止重复提交
		
		if (App.flag) {
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel("提交中...");
		//添加常用收款人
		if ($("#inputCheckbox").is(":checked")) {
			App.acctOperate();
		}
		// 判断发起人是不是有效必经人
		if ($("#trsStatus").val() == "0") {
			var url = YT.dataUrl("public/getRandomNum");
			YT.ajaxData(url, {}, function(data) {
				if (data.STATUS == "1") {
					var url = YT.dataUrl("private/isEffective");
					var json = {
						trsType : "3",
						amount : amount,
						bizNo : "3",
						TOKEN : data.randomNum,
						flag : "2"
					}
					YT.ajaxData(url, json, function(suc) {
						if (suc.isAmount == "YES") {
							if (suc.isEffective == "YES") {
								App.initComplete();
							} else {
								App.flag = false;
								Fw.Form.showPinLabel($(this), "您的权限不足,请转办",
										true);
								Fw.Client.hideWaitPanel();
								return;
							}
						} else {
							App.flag = false;
							Fw.Form.showPinLabel($(this), "汇款金额不得大于渠道限额("+suc.listAmount.toFixed(2)+")",
									true);
							Fw.Client.hideWaitPanel();
							return;
						}
					}, App.call);
				} else {
					App.flag = false;
					Fw.Client.alertinfo(data.MSG, "消息提示");
				}
			});
		}
		// 转办
		if ($("#trsStatus").val() == "1") {
			var url = YT.dataUrl("public/getRandomNum");
			YT.ajaxData(url, {}, function(data) {
				if (data.STATUS == "1") {
					var url = "private/transferTask.json";
					var jsons = {
						type:"1",
						trsType : "1",
						innerBank : "1",
						trsferType : "CIB_TRANSFER",
						toAcctNo : toAcctNo,
						toAcctName : toAcctName,
						toBankCode : "309",
						toBankName : "兴业银行",
						amount : amount,
						memo : memo,
						FileNameList : App.attch,
						FileUrl : App.url,
						dealUserName : dealUserName,
						dealUserId : dealUserId,
						toCommunicateId : communicateId,
						TOKEN : data.randomNum
					}
					Fw.Client.post(url, jsons, "App.success","App.failuriBack");
				} else {
					App.flag = false;
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG, "消息提示");
				}
			});
		}
	},
	// 办结
	initComplete : function() {
		App.flag = false;
		var toAcctNo = $("#bankId").val().replace(/\s/g,"");
		var toAcctName = $("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var amount = $("#HKJE").val();
		var memo = $("#memo").val().replace(/\s/g,"");
		var dealUserName = $("#dealUserName").val();
		var dealUserId = $("#dealUserId").val();
		var communicateId = $("#communicateId").val();
		var url = "private/transferTask.json";
		var params = {
			type:"1",
			trsType : "1",
			innerBank : "1",
			trsferType : "CIB_TRANSFER",
			toAcctNo : toAcctNo,
			toAcctName : toAcctName,
			toBankCode : "309",
			toBankName : "兴业银行",
			amount : amount,
			memo : memo,
			FileNameList : App.attch,
			FileUrl : App.url,
			dealMsg : App.dealMsg,
			isComplete : "1"
		}
		Fw.Client.post(url, params, "App.initCommonAcct", "App.failuriBack");
	},
	/**
	 * 办结成功
	 */
	initCommonAcct : function(data) {
		if (data.STATUS == "1") {
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo : data.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			var json={
					purpose:$("#memo").val(),
					toAcctName:$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"")
					};
			var amount = Fw.util.Format.replaceDouble("1", $("#HKJE").val());
			var toAcctNo = $("#bankId").val().replace(/\s/g,"");
			Fw.redirect(
					"1040109.html?trsId="+""+"&trsStatus=2&dealMsg="+""+"&innerBank=1&trsNo="+data.trsNo+"&JYLS="
							+ data.trsNo + "&amount=" + amount + "&toAcctNo="
							+ toAcctNo + "", json);
			Fw.Client.hideWaitPanel();
		} else {
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG, "消息提示");
			return;
		}
	},
	/**
	 * 转办新建成功后
	 */
	success : function(datas) {
		if (datas.STATUS == "1") {
			var url = YT.dataUrl("private/oprtFile");
			var params = {
				trsNo : datas.trsNo,
				FileUrl : App.url,
				FileNameList : App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人：" + $("#dealUserName").val(), "提交成功","App.test()");
		} else {
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(datas.MSG, "消息提示");
			return;
		}
	},
	/**
	 * 添加常用收款账号
	 */
	acctOperate:function(){
		var url = YT.dataUrl("private/acctOperate");
		var param = {
			OperateType : "0",
			ACCT_NO : $("#bankId").val().replace(/\s/g,""),
			innerBank : "0",
			ACCT_NAME : $("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
			BANK_NAME : "兴业银行",
		};
		YT.ajaxData(url, param, function(data) {});
	},
	/**
	 * 转办成功后
	 */
	test : function() {
		Fw.Client.changePage("1040100.html", true);
	},
	/**
	 * 显示pageA
	 */
	showPageA : function() {
		YT.showPageArea(App.pageA, [ App.pageB ], true);
	},
	/**
	 * 显示pageB
	 */
	showPageB : function() {
		YT.showPageArea(App.pageB, [ App.pageA ], true);
	},
	/**
	 * 返回
	 */
	gotoBackB : function() {
		if (App.func("dealUser") == "1" || (App.func("dealUser")?App.func("dealUser"):Fw.getParameters("_parameters").dealUser) == "1") {
			Fw.Client.changePage("1040100.html?trsStatus="+ App.func("trsStatus") + "", "1");
		}

		if (App.func("dealUser") == "2" || (App.func("dealUser")?App.func("dealUser"):Fw.getParameters("_parameters").dealUser) == "2") {
			Fw.Client.changePage("1040105.html?trsStatus="+ App.func("trsStatus") + "", "1");
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
