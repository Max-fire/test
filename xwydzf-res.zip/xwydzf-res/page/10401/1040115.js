/**
 * 创建应用
 * 
 * @author wjx
 */
var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data=Fw.getParameters();
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
	},
	/**
	 * 加载数据
	 */
	initEvent : function (){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findTrsfrPwd");
		var trsNos = App.data.trsNo;
		var params = {
				trsNo:trsNos,
				trsType:"1"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS == "1"){
				if(data.trs[0].innerBank == "1"){
					$("#innerBank").html(data.trs[0].expectedDate?"行内汇款(次日到账)":"行内汇款");
					$("#time").html(Fw.util.Format.fmtTrsCreDate(App.data.trsDate,"yyyy-MM-dd HH : mm :ss"));
				}
				if(data.trs[0].innerBank == "2"){
					$("#innerBank").html(data.trs[0].expectedDate?"跨行汇款(次日到账)":"跨行汇款");
					$("#time").html(Fw.util.Format.fmtTrsCreDate(App.data.trsDate,"yyyy-MM-dd HH : mm :ss"));
				}
				if(data.trs[0].trsferType=="STAFF_TRANSFER"){
					$("#innerBank").html(data.trs[0].expectedDate?"员工汇款(次日到账)":"员工汇款");
					$("#time").html(Fw.util.Format.fmtTrsCreDate(App.data.trsDate,"yyyy-MM-dd HH : mm :ss"));
					$("#skdw").html("收款户名");
				}
				if(data.trs[0].trsferType=="SALARY_TRANSFER"){
					$("#innerBank").html(data.trs[0].expectedDate?"代发工资(次日到账)":"代发工资");
					$("#time").html(Fw.util.Format.fmtTrsCreDate(App.data.trsDate,"yyyy-MM-dd HH : mm :ss"));
					$("#skdw").html("收款户名");
					$("#showZY").removeClass('hidden');
					if(data.trs[0].brief=='006'){
						$("#ZYType").html("代发工资");
					}else if(data.trs[0].brief=='022'){
						$("#ZYType").html("奖金");
					}else if(data.trs[0].brief=='023'){
						$("#ZYType").html("津贴");
					}else if(data.trs[0].brief=='047'){
						$("#ZYType").html("福利");
					}else if(data.trs[0].brief=='048'){
						$("#ZYType").html("费用报销");
					}
				}
				$("#trsNo").html(Fw.util.Format.subTrsNo(data.trs[0].trsNo));
				$("#fromAcctNo").html(data.trs[0].fromAcctNo);
				$("#fromAcctName").html(data.trs[0].fromAcctName);
				$("#fromBankName").html(data.trs[0].fromBankName);
				App.bs = data.trs.length;
				var amount = 0;
			  	for(var i=0;i<App.bs;i++){
			  		amount+=(data.trs[i].amount)*1;
			  	}
				$("#amount").html('\u00A5'+Fw.util.Format.fmtAmt(amount.toString()));
				$("#JEDX").html(Fw.util.Format.fmtNumber2Chinese(amount.toString()));
				if(data.trs.length>1){
					$("#toAcctNo").html(data.trs[0].toAcctNo+" 等");
					if(data.trs[0].trsferType=="STAFF_TRANSFER"){
						$("#toBankName").html(data.trs[0].toBankName+" 等");
					}else{
						$("#toBankName").html(data.trs[0].toBrName || data.trs[0].toBankName+" 等");
					}
					$("#toAcctName").html(data.trs[0].toAcctName+" 等");
				}else{
					$("#toAcctNo").html(data.trs[0].toAcctNo);
					if(data.trs[0].trsferType=="STAFF_TRANSFER"){
						$("#toBankName").html(data.trs[0].toBankName);
					}else{
						$("#toBankName").html(data.trs[0].toBrName || data.trs[0].toBankName);
					}
					$("#toAcctName").html(data.trs[0].toAcctName);
				}
				$("#purpose").html(data.trs[0].purpose);	
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		});
	},
	/**
	 * 保存凭证
	 */
	initBC: function(){
		var cfg = "App.initSuccess"
		Fw.Client.openScrrenShot(cfg);
	},
	initSuccess:function(success){
		if(success){
			Fw.Form.showPinLabel($(this), "回单成功保存到相册", true);
			return;
		}else{
			Fw.Form.showPinLabel($(this), "回单保存失败", true);
			return;
		}
	},
	/**
	 * 返回列表
	 */
	gotoBackTest:function(){
		if ( App.data.page) {
			Fw.redirect(App.data.page, App.data);
		}else{
			if(App.data.trsId != ""){
				Fw.Client.dealMessage("2",Fw.getParameters("_parameters").trsId);
			}else{
				Fw.Client.changePage("1040105.html",true);
			}
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);