/**
 * 创建应用
 * 
 * @author yql
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.datas=null;
		App.next=0;
		App.i=0;
		App.flag=false;
		App.initEvent();
		Fw.Client.hideWaitPanel();
		
	},
    initEvent : function(){
    	// 收款银行-事件
		App.pageA.on("click","#SKYH",App.initSKYH);
		// 所在省份-事件
		App.pageA.on("click","#SZSS",App.initSZSS);
		// 开户支行-事件
		App.pageA.on("click","#KHZH",App.initKHZH);
		// 模糊搜索
		App.pageA.on("click","#ss",App.initMMSS1);
		// 确定
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click", "#more", App.onMore);
		
		App.pageA.on("input","#tocheck",App.toCheck);
		App.pageA.on("porpertychanger","#tocheck",App.toCheck);
		
    	$('#sd').on('click',function(){
    		$("#mh").removeClass("yui-hmss-fontc");
    		$("#mhc").removeClass("yui-hmss-color");
    		$("#sd").addClass("yui-hmss-fontc");
    		$("#sdc").addClass("yui-hmss-color");
    		$("#mmss").addClass("hidden");
    		$("#sdxz").removeClass("hidden");
    		App.showSD();
		})
		$('#mh').on('click',function(){
			$("#sd").removeClass("yui-hmss-fontc");
    		$("#sdc").removeClass("yui-hmss-color");
    		$("#mh").addClass("yui-hmss-fontc");
    		$("#mhc").addClass("yui-hmss-color");
    		$("#sdxz").addClass("hidden");
    		$("#mmss").removeClass("hidden");
		})
		$("#toBank").val(App.data.bankName);
		$("#toBankId").val(App.data.bankCode);
		if(App.data.back){
    		$("#mh").removeClass("yui-hmss-fontc");
    		$("#mhc").removeClass("yui-hmss-color");
    		$("#mmss").addClass("hidden");
    		$("#sdxz").removeClass("hidden");
    		$("#sd").addClass("yui-hmss-fontc");
    		$("#sdc").addClass("yui-hmss-color");
    		$("#sdxz").removeClass("hidden");
    	}else{
    		$("#mmss").removeClass("hidden");
    	}
		App.showSD();
		
    },
    toCheck:function(){
    	App.next=0;
    },
    initMMSS1:function(){
    	App.next=0;
    	App.initMMSS();
    },
    showSD:function(){
    	if(App.data.back){
    		$("#mh").removeClass("yui-hmss-fontc");
    		$("#mhc").removeClass("yui-hmss-color");
    		$("#mmss").addClass("hidden");
    		$("#sdxz").removeClass("hidden");
    		$("#sd").addClass("yui-hmss-fontc");
    		$("#sdc").addClass("yui-hmss-color");
    		
    	}
    	if(App.data.provinceName && App.data.provinceCode){
			$("#shen").val(App.data.provinceName);
			$("#shenId").val(App.data.provinceCode);
			$("#shiId").val(App.data.cityCode);
		}
		$("#khzhName").val(App.data.brName);
		$("#khzh").val(App.data.brCode);
		if(App.data.back == "2" && App.data.bankName != App.data.bankNameA){
			$("#shen").val("");
			$("#shenId").val("");
			$("#shiId").val("");
			$("#khzhName").val("");
			$("#khzh").val("");
		}
		YT.showPageArea(App.pageA, [], true);
		$("#toBank").blur();
		$("#shen").blur();
		$("#khzhName").blur();
    },
    /**
	 * 收款银行
	 */
	initSKYH : function(){
		App.addSession('2')
	},
	/**
	 * 所在省份
	 */
	initSZSS : function(){
		var bankCode=$("#toBankId").val();
		if(bankCode!=""){
			Fw.Client.openProvince("App.showProvince");
		}else{
			Fw.Form.showPinLabel($(this), "请选择收款银行", true);
			return;
		}
		
	},
	showProvince: function(name1,id1,name2,id2){
		if(name1+"　"+name2 != $("#shen").val()){
			$("#shen").val(name1+"　"+name2);
			$("#shenId").val(id1);
			$("#shiId").val(id2);
			$("#khzhName").val("");
			$("#khzh").val("");
		}
		$("#toBank").blur();
		$("#shen").blur();
		$("#khzhName").blur();
		
	},
	/**
	 * 选择开户支行
	 */
	initKHZH : function(){
		var provinceCode = $("#shenId").val();
		var cityCode= $("#shiId").val();
		var bankCode=$("#toBankId").val();
		if(provinceCode !="" && cityCode !="" && bankCode !=""){
			Fw.Client.openWaitPanel();
			var url = YT.dataUrl("private/findBranch");
			var json = {
					provinceCode:provinceCode,
					cityCode:cityCode,
					bankCode:bankCode
			}
			YT.ajaxData(url,json,function(data){
				Fw.Client.hideWaitPanel();
				if(data.LIST.length!= "0"){
					App.BankData = data;
					App.showBank();
				}else{
					Fw.Form.showPinLabel($(this), "所在省市暂无支行", true);
					return;
				}
				
			});
		}else{
			Fw.Form.showPinLabel($(this), "请选择收款银行和所在省市", true);
			return;
		}
	},
	/**
	 * 调用函数
	 */
	showBank : function(name,id){
		App.addSession("3");
	},
	/**
	 * 加载页面数据到session中
	 */
	addSession: function(key){
		var dealUser = "";
		if(App.func("dealUser")){
			dealUser = App.func("dealUser");
		}else{
			dealUser = Fw.getParameters("_parameters").dealUser;
		}
		App.data.bankName=$("#toBank").val();
		App.data.bankNameA=$("#toBank").val();
		App.data.banCode=$("#toBankId").val();
		App.data.provinceName=$("#shen").val();
		App.data.provinceCode=$("#shenId").val();
		App.data.cityCode=$("#shiId").val();
		App.data.brName=$("#khzhName").val();
		App.data.brCode=$("#khzh").val();
		App.data.BankData=App.BankData;
		App.data.dealUser=dealUser;
		App.data.brCode=$("#khzh").val();
		switch (key) {
		case '2':
			Fw.redirect("1040108.html",App.data);
			break;
		case '3':
			Fw.redirect("1040110.html",App.data);
			break;
		default:
			break;
		}
	},
	onMore:function(){
		App.i++;
		Fw.Client.openWaitPanel();
		var msg=$("#tocheck").val();
		var bs=Math.ceil(App.datas.length/10)
		var html="";
		var index=App.i*10;
		var deg=App.datas.length-index
		if(deg>10){
			for(var d=index;d<index+10;d++){
				  html+='<div class="yui-hmss-lis ui-border-t" onclick="App.toChoose('+d+')">'+App.datas[d].brName.trim().replace(new RegExp("("+msg+")","g"),"<font color=orange>"+msg+"</font>")+'</div>'
			}
		}else{
			for(var d=index;d<App.datas.length;d++){
				  html+='<div class="yui-hmss-lis ui-border-t" onclick="App.toChoose('+d+')">'+App.datas[d].brName.trim().replace(new RegExp("("+msg+")","g"),"<font color=orange>"+msg+"</font>")+'</div>'
			}
		}
		
		$("#list").append(html);
		if(App.i<bs-1){
			$("#more").show();
			$("#end").hide();
		}else{
			$("#more").hide();
			$("#end").show();
		}
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 模糊搜索
	 */
	initMMSS : function(){
		App.i=0;
		$("#ss").attr("style","background-color: #017EF3;color: #ffffff")
		setTimeout(function(){
			$("#ss").attr("style","background-color: rgba(59,118,217,91);color: #ffffff")
		},700)
		var msg=$("#tocheck").val();
		var html="";
		if (msg=="") {
			Fw.Form.showPinLabel($(this), "请输入收款行名或行号查询", true);
			return;
		}
		if (isNaN(msg)){
			//输入收款行名大于4位
			if (msg.length<4) {
				Fw.Form.showPinLabel($(this), "搜索关键字不能小于4位", true);
				return;
			}
			Fw.Client.openWaitPanel();
			//输入银行名称
			var url = YT.dataUrl("private/searchBranch");
			var params = {
					field : "brName",
					value : msg,
			}
			YT.ajaxData(url, params, function(data) {
				if (data.STATUS=="1") {
					App.datas=data.lbranch;
					if (!App.datas) {
						html = '<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:16px;color: gray;">未查询到结果</div>';
						$("#list").html(html);
						$("#more").hide();
						$("#end").hide();
					}else{
						if(App.datas.length>10){
							for(var d=0;d<10;d++){
								html+='<div class="yui-hmss-lis ui-border-t" onclick="App.toChoose('+d+')">'+App.datas[d].brName.trim().replace(new RegExp("("+msg+")","g"),"<font color=orange>"+msg+"</font>")+'</div>'
							}
							
						}else{
							for ( var d in App.datas) {
								html+='<div class="yui-hmss-lis ui-border-t" onclick="App.toChoose('+d+')">'+App.datas[d].brName.trim().replace(new RegExp("("+msg+")","g"),"<font color=orange>"+msg+"</font>")+'</div>'
							}
						}
						$("#list").html(html);
					}
					Fw.Client.hideWaitPanel();
					
					if(App.datas.length>10){
						$("#more").show();
						$("#end").hide();
					}else{
						$("#more").hide();
						$("#end").hide();
					}
					
				}else{
					html = '<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:16px;color: gray;">未查询到结果</div>';
					$("#list").html(html);
					$("#more").hide();
					$("#end").hide();
					Fw.Client.hideWaitPanel();
				}
			},function(data){
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(success.MSG,"消息提示");
			});
		}else{
			//输入收款行名或行号查询
			if (msg.length!="12") {
				Fw.Form.showPinLabel($(this), "请输入正确收款行号", true);
				return;
			}else{
				Fw.Client.openWaitPanel();
				var url = YT.dataUrl("private/searchBranch");
				var params={
						field : "brCode",
						value : msg	,
				}
			    YT.ajaxData(url,params,function(data){
			    	if (data.STATUS=="1") {
			    		App.datas=data.lbranch;
			    		if (!App.datas) {
			    			html = '<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:16px;color: gray;">未查询到结果</div>';
			    			$("#list").html(html);
			    			$("#more").hide();
							$("#end").hide();
			    		}else{
			    			if(App.datas.length>10){
								for(var d=0;d<10;d++){
									html+='<div class="yui-hmss-lis ui-border-t" onclick="App.toChoose('+d+')">'+App.datas[d].brName.trim().replace(new RegExp("("+msg+")","g"),"<font color=orange>"+msg+"</font>")+'</div>'
								}
							}else{
								for ( var d in App.datas) {
									html+='<div class="yui-hmss-lis ui-border-t" onclick="App.toChoose('+d+')">'+App.datas[d].brName.trim().replace(new RegExp("("+msg+")","g"),"<font color=orange>"+msg+"</font>")+'</div>'
								}
							}
							$("#list").html(html);
			    		}
			    		Fw.Client.hideWaitPanel();
			    		if(App.datas.length>10){
							$("#more").show();
							$("#end").hide();
						}else{
							$("#more").hide();
							$("#end").hide();
						}
					}else{
						html = '<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:16px;color: gray;">未查询到结果</div>';
						$("#list").html(html);
						$("#more").hide();
						$("#end").hide();
						Fw.Client.hideWaitPanel();
					}
			    },function(data){
			    	Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG,"消息提示");
			    })	
			}
		}
	},
	toSubmit:function(){
		var toBank = $("#toBank").val();
		var shenId = $("#shen").val();
		var brName = $("#khzhName").val();
		if(toBank == ""){
			Fw.Form.showPinLabel($(this), "请选择收款银行", true);
			return;
		}
		if(shenId == ""){
			Fw.Form.showPinLabel($(this), "请选择所在省市", true);
			return;
		}
		//校验开户支行是否选择
		if(brName == ""){
			Fw.Form.showPinLabel($(this), "请选择开户支行", true);
			return;
		}
		if (brName.indexOf("不对外")==-1) {
			if(App.data.gotoBack == "1"){
				Fw.redirect("1040106_B.html",App.data);
			}else{
				Fw.redirect("1040100_XGKH.html",App.data);
			}
		}else{
			Fw.Client.confirm("您所选的收款行不对外,请和收款方确认后汇划,如果确认汇往请点击下方“确认”按钮","温馨提示","App.toSure()","App.toCanCle()","确定","取消");
		}
	},
	toChoose : function(i){
		var brCode=App.datas[i].brCode.trim();
		var brName=App.datas[i].brName.trim();
		var bankName=App.datas[i].bankName.trim();
		var bankCode=App.datas[i].bankCode.trim();
		var cityCode=App.datas[i].cityCode?App.datas[i].cityCode.trim():"";
		App.data.brCode=brCode;
		App.data.brName=brName;
		App.data.bankName=bankName;
		App.data.bankNameA=bankName;
		App.data.bankCode=bankCode;
		App.data.cityCode=cityCode;
		App.data.provinceCode="";
		App.data.provinceName="";
		if (App.datas[i].provinceCode) {
			App.data.provinceCode=App.datas[i].provinceCode;
		}
		if (App.datas[i].provinceName) {
			App.data.provinceName=App.datas[i].provinceName+" "+App.datas[i].cityName;
		}
		if (brName.indexOf("不对外")==-1) {
			if(App.data.gotoBack == "1"){
				Fw.redirect("1040106_B.html",App.data);
			}else{
				Fw.redirect("1040100_XGKH.html",App.data);
			}
		}else{
			Fw.Client.confirm("您所选的收款行不对外,请和收款方确认后汇划,如果确认汇往请点击下方“确认”按钮","温馨提示","App.toSure()","App.toCanCle()","确定","取消");
		}
		
	},
	/**
	 * 不对外营业确认
	 */
	toSure:function(){
		if(App.data.gotoBack == "1"){
			Fw.redirect("1040106_B.html",App.data);
		}else{
			Fw.redirect("1040100_XGKH.html",App.data);
		}
	},
	/**
	 * 不对外营业取消
	 */
	toCanCle:function(){
		return;
	},
	 /**
     * 返回前一页
     */
    goBack:function(){
    	var json=YT.JsonEval(App.data.oldDatas);
    	if(App.data.gotoBack == "1"){
    		Fw.redirect("1040106_B.html",json);
    	}else{
    		Fw.redirect("1040100_XGKH.html",json);
    	}
    }
    
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
