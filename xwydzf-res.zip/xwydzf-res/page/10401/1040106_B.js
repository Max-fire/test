/**
 * 创建应用
 * 
 * @author yql
 */
var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		Fw.Client.hideWaitPanel();
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);	
		App.flag = false;
		App.attchList = new Array();
		App.attch  = new Array();
		App.i = 0;
		App.initEvent();
		App.initPageA();
		App.memolist = null;
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 加载常用按钮-事件
		App.pageA.on("click","#CYSKZH",App.initCYSKZH);
		// 收款银行-事件
		App.pageA.on("click","#SKYH",App.initSKYH);
		// 所在省份-事件
		App.pageA.on("click","#SZSS",App.initSZSS);
		// 开户支行-事件
		App.pageA.on("click","#KHZH",App.initKHZH);
		// 添加附件-事件
		App.pageA.on("click",".TJFJ",App.initTJFJ);
		// 选择审批人-事件
		App.pageA.on("click","#SPR",App.initSPR);
		//调用金额键盘
		App.pageA.on("click","#hkje",App.showMoneyPicker);
		// 校验后提交-事件
		App.pageA.on("click", "#btnSubmit", App.toConfirm);
		//数字键盘
//		App.pageA.on("click","#bankId",App.showNumberPicker);
		//办结按钮
		App.pageA.on("click","#bj",App.initBJ);
		//转办按钮
		App.pageA.on("click","#zb",App.initZB);
		//落地审核提示显示
		App.pageA.on("click","#ts",App.initTS);
		//点击我知道了
		App.pageA.on("click","#iknow",App.toIknow);
		//备注控制字节
		App.pageA.on("porpertychanger","#memo",App.toMemo);
		App.pageA.on("input","#memo",App.toMemo);	
		App.pageA.on("click","#CYs",App.initCYs);
//		App.pageA.on("click",".yui-newCover-item",App.commonItem);	
	},
		
	/**
	 * 落地审核提示显示
	 */
	initTS:function(){
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#black_b").attr("style","height:"+height+"px;");
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black_b").removeClass("hidden");
		$("#white_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	/**
	 * 取消弹窗提示
	 */
	toIknow:function(){
		App.pageA.unbind("touchmove");
		$("#black_b").addClass("hidden");
		$("#white_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 备注控制字节
	 */
	toMemo:function(){
		Fw.util.Format.checkNum("memo",60);
	},
	/**
	 * 办结
	 */
	initBJ:function(){
		$("#bj").removeClass("yui-backgroud-a");
		$("#bj").addClass("yui-backgroud-a1");
		$("#zb").removeClass("yui-backgroud-b1");
		$("#zb").addClass("yui-backgroud-b");
		$("#XZSPR").attr("hidden","");
		$("#trsStatus").val("0");
	},
	/**
	 * 转办
	 */
	initZB:function(){
		$("#zb").removeClass("yui-backgroud-b");
		$("#zb").addClass("yui-backgroud-b1");
		$("#bj").removeClass("yui-backgroud-a1");
		$("#bj").addClass("yui-backgroud-a");
		$("#XZSPR").removeAttr("hidden","");
		$("#trsStatus").val("1");
	},
	/**
	 * 初始化加载页面数据
	 */
	initPageA: function(){
		if(Fw.getParameters("_parameters")){
			$("input:radio[value="+Fw.getParameters("_parameters").hukuan+"]").attr("checked","true");
			$("#bankId").val(Fw.getParameters("_parameters").bankNo);
			$("#bankId").blur();
			$("#toAcctName").val(Fw.getParameters("_parameters").toAcctName);
			$("#toAcctName").blur();
			$("#hkje").val(Fw.getParameters("_parameters").hkje);
			$("#HKJE").val(Fw.getParameters("_parameters").HKJE);
			$("#capsAmount").html(Fw.getParameters("_parameters").capsAmount);
			$("#toBank").val(Fw.getParameters("_parameters").bankName);
			$("#toBankId").val(Fw.getParameters("_parameters").bankCode);
			if(Fw.getParameters("_parameters").provinceName){
				$("#shen").val(Fw.getParameters("_parameters").provinceName);
				$("#shenId").val(Fw.getParameters("_parameters").provinceCode);
				$("#shiId").val(Fw.getParameters("_parameters").cityCode);
			}
			
			$("#khzhName").val(Fw.getParameters("_parameters").brName);
			$("#bank").val(Fw.getParameters("_parameters").brName);
			$("#khzh").val(Fw.getParameters("_parameters").brCode);
			$("#memo").val(Fw.getParameters("_parameters").memo);
			$("#memo").blur();
			if(Fw.getParameters("_parameters").back == "2" && Fw.getParameters("_parameters").bankName != Fw.getParameters("_parameters").bankNameA){
				$("#shen").val("");
				$("#shenId").val("");
				$("#shiId").val("");
				$("#khzhName").val("");
				$("#khzh").val("");
			}
			var attach = Fw.getParameters("_parameters").attach;
			var url = Fw.getParameters("_parameters").url;
			for ( var k = 0; k < attach.length; k++) {
				if(attach[k] != null){
					App.showAttcchment(attach[k].name,url);
				}
			}
		}
		
		$("#khzhName").blur();
		$("#bank").blur();
		
			var url = YT.dataUrl("private/isApproval");
			var params = {
					trsType:"3"
			}
			YT.ajaxData(url,params,function(data){
				if(data.IsApproval == "YES"){
					$("#CZAN").removeClass("hidden");
					$("#XZSPR").attr("hidden","");
				}else{
					$("#XZSPR").removeAttr("hidden","");
				}
			});
	},
	/**
	 * 加载页面数据到session中
	 */
	addSession: function(key){
		var dealUser = "";
		if(App.func("dealUser")){
			dealUser = App.func("dealUser");
		}else{
			dealUser = Fw.getParameters("_parameters").dealUser;
		}
		var json = {
				bank:"1",
				innerBank:"1",
				hukuan:$("input[type='radio']:checked").val(),
				bankNo: $("#bankId").val(),//收款账号
				toAcctName:$("#toAcctName").val(),//收款户名
				hkje:$("#hkje").val(),//汇款金额
				HKJE:$("#HKJE").val(),
				capsAmount:$("#capsAmount").html(),
				bankName: $("#toBank").val(),//收款银行
				bankNameA:$("#toBank").val(),
				bankCode: $("#toBankId").val(),
				attach:App.attch,
				url:App.url,
				provinceName:$("#shen").val(),
				provinceCode:$("#shenId").val(),
				cityCode:$("#shiId").val(),
				brName:$("#khzhName").val(),
				brCode:$("#khzh").val(),
				memo:$("#memo").val(),
				BankData:App.BankData,
				dealUser:dealUser,
				gotoBack:"1"
				}
		switch (key) {
		case '1':
			Fw.redirect("1040107.html",json);
			break;
		case '2':
			Fw.redirect("1040108.html",json);
			break;
		case '3':
			Fw.redirect("1040110.html",json);
			break;
		default:
			break;
		}
	},
	initCYs:function(){

		Fw.Client.openWaitPanel();
		var height=document.body.clientHeight+500;
		var html="";
		var url=YT.dataUrl("private/commonMemo");
		YT.ajaxData(url,{type:'2'},function(json){
			if(json.STATUS == '1'){
				var list=[];
				list=(json.last).concat(json.history).concat(json.deft);
				App.memolist = list;
				for ( var d in list) {
					var l;
					list[d] = list[d].replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
					if(list[d].length>10){
						 l = list[d].substring(0,10)+"...";
					}else{
						 l = list[d];
					}
					html+='<div class="yui-newCover">';
					if(json.last.length!=0){ //有历史记录
						if(d<json.last.length){
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/historymemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}else{
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}
					}else{
						html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
					}
					
					html+='<div>';
				}
				$("#memorys").html(html);
				$("#black_b").attr("style","height:"+height+"px;");
				$("#black_b").attr("style","position:fixed");
				
				$("#black_b").removeClass("hidden");
				$("#white_c").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), json.MSG, true);
			}
		})
		
	},
	/**
	 * 取单个常用用途
	 */
	commonItem:function(index){
		App.pageA.unbind("touchmove");
		var commonMemo = App.memolist[index];
		commonMemo = commonMemo.replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
		if($("#memo").html()==""){
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}else{
			$("#memo").html();
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}
		$("#black_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 取消弹窗
	 */
	toCancel:function(){
		$("#black_b").addClass("hidden");
		$("#white_c").addClass("hidden");
		
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker: function(){
		Fw.Client.showMoneyPicker($("#hkje"));
	},
	/**
	 * 常用按钮
	 */
	initCYSKZH : function(){
		App.addSession('1');
	},
	/**
	 * 收款银行
	 */
	initSKYH : function(){
		var dealUser = "";
		if(App.func("dealUser")){
			dealUser = App.func("dealUser");
		}else{
			dealUser = Fw.getParameters("_parameters").dealUser;
		}
		var json = {
				bank:"1",
				innerBank:"1",
				hukuan:$("input[type='radio']:checked").val(),
				bankNo: $("#bankId").val(),//收款账号
				toAcctName:$("#toAcctName").val(),//收款户名
				hkje:$("#hkje").val(),//汇款金额
				HKJE:$("#HKJE").val(),
				capsAmount:$("#capsAmount").html(),
				bankName: $("#toBank").val(),//收款银行
				bankNameA:$("#toBank").val(),
				bankCode: $("#toBankId").val(),
				attach:App.attch,
				url:App.url,
				provinceName:$("#shen").val(),
				provinceCode:$("#shenId").val(),
				cityCode:$("#shiId").val(),
				brName:$("#khzhName").val(),
				brCode:$("#khzh").val(),
				memo:$("#memo").val(),
				BankData:App.BankData,
				dealUser:dealUser,
				gotoBack:"1"
				}
		var data=YT.JsonToStr(json);
			json.oldDatas=data;
			Fw.redirect("1040101.html",json);
//		App.addSession('2')
	},
	/**
	 * 所在省份
	 */
	initSZSS : function(){
		var bankCode=$("#toBankId").val();
		if(bankCode!=""){
			Fw.Client.openProvince("App.showProvince");
		}else{
			Fw.Form.showPinLabel($(this), "请选择收款银行", true);
			return;
		}
		
	},
	showProvince: function(name1,id1,name2,id2){
		if(name1+"　"+name2 != $("#shen").val()){
			$("#shen").val(name1+"　"+name2);
			$("#shenId").val(id1);
			$("#shiId").val(id2);
			$("#khzhName").val("");
			$("#khzh").val("");
		}
		
	},
	/**
	 * 选择开户支行
	 */
	initKHZH : function(){
		var provinceCode = $("#shenId").val();
		var cityCode= $("#shiId").val();
		var bankCode=$("#toBankId").val();
		if(provinceCode !="" && cityCode !="" && bankCode !=""){
			Fw.Client.openWaitPanel();
			var url = YT.dataUrl("private/findBranch");
			var json = {
					provinceCode:provinceCode,
					cityCode:cityCode,
					bankCode:bankCode
			}
			YT.ajaxData(url,json,function(data){
				Fw.Client.hideWaitPanel();
				if(data.LIST.length!= "0"){
					App.BankData = data;
					App.showBank();
				}else{
					Fw.Form.showPinLabel($(this), "所在省市暂无支行", true);
					return;
				}
				
			});
		}else{
			Fw.Form.showPinLabel($(this), "请选择收款银行和所在省市", true);
			return;
		}
	},
	/**
	 * 调用函数
	 */
	showBank : function(name,id){
		App.addSession("3");
	},
	/**
	 * 添加附件
	 */
	initTJFJ : function(){
		if(App.attch.length > 5){
			Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
			return;
		}
		Fw.Client.openAttcchment("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		//调用附件添加函数Fw.util.attach.addAttach(name,url);
		Fw.util.attach.addAttach(name,url);
	},
	/**
	 * 选择审批人
	 */
	initSPR : function(){
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name,id,co){
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 事务提交
	 */
	toConfirm:function(){
		var trsferType = $("input[type='radio']:checked").val();
		var toAcctNo = $("#bankId").val().replace(/\s/g,"");
		var toAcctName =$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
		var amount = $("#HKJE").val();
		var toBankCode = $("#toBank").val();
		var toBankCodeId = $("#toBankId").val();
		var shenId = $("#shenId").val();
		var shiId = $("#shiId").val();
		var toBankName = $("#khzhName").val();
		var brCode = $("#khzh").val();
		var attach = App.attch;
		var memo = $("#memo").val();
		var dealUserName = $("#dealUserName").val();
		var dealUserId = $("#dealUserId").val();
		var communicateId = $("#communicateId").val();
		//收款账号随便输限制为32为
		if (toAcctNo.trim() == "") {
			Fw.Form.showPinLabel($(this), "请输入收款账号", true);
			return;
		}
		var reg = /^[0-9a-zA-Z-_\s]*$/.test(toAcctNo);
		if(!reg){
			Fw.Form.showPinLabel($(this), "收款账号不合法", true);
			return;
		}
		//收款户名
		if (toAcctName == null || toAcctName == "") {
			Fw.Form.showPinLabel($(this), "请输入收款户名", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji(toAcctName)){
			Fw.Form.showPinLabel($(this), "收款户名包含特殊字符", true);
			return;
		}
		//会看金额是否大于零
		if(!(amount > 0)){
			Fw.Form.showPinLabel($(this), "汇款金额必须大于0", true);
			return;
		}
		if(toBankCodeId == ""){
			Fw.Form.showPinLabel($(this), "请选择收款银行", true);
			return;
		}
		//校验开户支行是否选择
		if(brCode == ""){
			Fw.Form.showPinLabel($(this), "请选择开户支行", true);
			return;
		}
		//备注
		if(Fw.util.proofTest.proolEmoji(memo)){
			Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
			return;
		}
		if(!($("#CZAN").hasClass("hidden"))){
			if($("#trsStatus").val() == ""){
				Fw.Form.showPinLabel($(this), "请选择操作类型", true);
				return;
			}
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		//添加常用收款人
		if ($("#inputCheckbox").is(":checked")) {
			App.acctOperate();
		}
		if(!$("#CZAN").hasClass("hidden")){
			var trsStatus = $("#trsStatus").val();
			if(trsStatus == "0"){
				var url = YT.dataUrl("private/isEffective");
				var json = {
					trsType:"3",
					amount:$("#HKJE").val(),
					bizNo:"3",
					flag:"2"
				}
				YT.ajaxData(url, json, function(suc) {
					//先验证是否为有效必经人，调用授权棒，验证通过后，
					//填写汇款信息，完成后调用新建，成功后办结，走核心汇款，生成汇款凭证，
					if(suc.isAmount == "YES"){
						if (suc.isEffective == "YES") {
								Fw.Client.hideWaitPanel();
								App.initSubmitBJ();
						} else {
							App.flag = false;
							Fw.Form.showPinLabel($(this), "您的权限不足,请转办", true);
							Fw.Client.hideWaitPanel();
							return;
						}
					}else{
						App.flag = false;
						Fw.Form.showPinLabel($(this), "汇款金额不得大于渠道限额("+suc.listAmount.toFixed(2)+")", true);
						Fw.Client.hideWaitPanel();
						return;
					}
				}, App.call);
			}
			if(trsStatus == "1"){
				if($("#dealUserId").val() == ""){
					App.flag = false;
					Fw.Form.showPinLabel($(this), "请选择下一审批人", true);
					return;
				}
				App.initSubmit();
			}
		}else{
			if($("#dealUserId").val() == ""){
				App.flag = false;
				Fw.Form.showPinLabel($(this), "请选择下一审批人", true);
				return;
			}
			App.initSubmit();
		}
	},
	/**
	 * 办结函数
	 */
	initSubmitBJ:function(){
		//新建事务
		
		var url = YT.dataUrl("public/getRandomNum");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = "private/transferTask.json";
				var params ={
						type:"1",
						trsType:"1",
						innerBank:"2",
						trsferType : $("input[type='radio']:checked").val(),
						toAcctNo : $("#bankId").val().replace(/\s/g,""),
						toAcctName :$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
						amount : $("#HKJE").val(),
						toBankName:$("#toBank").val(),
						toBankCode : $("#toBankId").val(),
						toProvinceCode : $("#shenId").val(),
						toCityCode : $("#shiId").val(),
						toExchngCity:$("#shen").val(),
						toBrName : $("#khzhName").val(),
						toBrCode : $("#khzh").val(),
						FileNameList:App.attch,
						FileUrl:App.url,
						memo : $("#memo").val(),
						dealUserName : $("#dealUserName").val(),
						dealUserId : $("#dealUserId").val(),
						toCommunicateId:$("#communicateId").val(),
						isComplete:"1",
						TOKEN:data.randomNum
				};
				Fw.Client.post(url, params, "App.initCommonAcct", "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),data.MSG,true);
				return;
			}
		});
	},
	/**
	 * 新建事务成功后添加常用账号，并跳转到付款信息界面
	 */
	initCommonAcct:function(data){
		if(data.STATUS == "1"){
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo:data.trsNo,
					FileUrl:App.url,
					FileNameList:App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			var json={
					purpose:$("#memo").val(),
					toAcctName:$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"")
			}
			var amount = Fw.util.Format.replaceDouble("1",$("#HKJE").val());
			var toAcctNo = $("#bankId").val().replace(/\s/g,"");
			Fw.redirect("1040109.html?trsId="+""+"&trsStatus=2&innerBank=1&dealMsg="+""+"&trsNo="+data.trsNo+"&JYLS="+data.trsNo+"&amount="+amount+"&toAcctNo="+toAcctNo+"",json);
			App.flag = false;
			Fw.Client.hideWaitPanel();
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	
	/**
	 * 普通提交转办
	 */
	initSubmit : function() {
		Fw.Client.openWaitPanel("提交中...");
		var url = YT.dataUrl("public/getRandomNum");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = "private/transferTask.json";
				var params ={
						type:"1",
						trsType:"1",
						innerBank:"2",
						trsferType : $("input[type='radio']:checked").val(),
						toAcctNo : $("#bankId").val().replace(/\s/g,""),
						toAcctName :$("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
						amount : $("#HKJE").val(),
						toBankName:$("#toBank").val(),
						toBankCode : $("#toBankId").val(),
						toProvinceCode : $("#shenId").val(),
						toCityCode : $("#shiId").val(),
						toExchngCity:$("#shen").val(),
						toBrName : $("#khzhName").val(),
						toBrCode : $("#khzh").val(),
						FileNameList:App.attch,
						FileUrl:App.url,
						memo : $("#memo").val(),
						dealUserName : $("#dealUserName").val(),
						dealUserId : $("#dealUserId").val(),
						toCommunicateId:$("#communicateId").val(),
						TOKEN:data.randomNum
				};
				Fw.Client.post(url, params, "App.callSuccess", "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.showPinLabel($(this),dataMSG,true);
				return;
			}
		});
	},
	/**
	 * 转办成功
	 */
	callSuccess: function(success){
		if(success.STATUS == "1"){
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo:success.trsNo,
					FileUrl:App.url,
					FileNameList:App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人："+$("#dealUserName").val(),"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(success.MSG,"消息提示");
		}
	},
	/**
	 * 添加常用收款账号
	 */
	acctOperate:function(){
		var url1 = YT.dataUrl("private/acctOperate");
		var param = {
				OperateType : "0",
				ACCT_NO : $("#bankId").val().replace(/\s/g,""),
				innerBank : "1",
				ACCT_NAME : $("#toAcctName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
				BANK_NAME : $("#toBank").val(),
				BANK_CODE:$("#toBankId").val(),
				BR_CODE:$("#khzh").val(),
				CITY_CODE:$("#shiId").val()
		};
		YT.ajaxData(url1, param, function(data){
		}, function(){
			App.flag = false;
			Fw.Client.alertinfo("网络异常","消息提示");
		});
	},
	/**
	 * 返回处理列表
	 */
	test:function(){
		Fw.Client.hideWaitPanel();
		Fw.Client.changePage("1040100.html", true);
	},
	/**
	 * 返回
	 */
	gotoBackB:function(){
		if(App.func("dealUser") == "1" || (App.func("dealUser")?App.func("dealUser"):Fw.getParameters("_parameters").dealUser) == "1"){
			Fw.Client.changePage("1040100.html?trsStatus="+App.func("trsStatus")+"", "1");
		}
		if(App.func("dealUser") == "2" || (App.func("dealUser")?App.func("dealUser"):Fw.getParameters("_parameters").dealUser) == "2"){
			Fw.Client.changePage("1040105.html?trsStatus="+App.func("trsStatus")+"", "1");
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
