/**
 * 创建应用
 * 
 * @author yql
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, null, true);
		App.initEvent();
		
	},
    initEvent : function(){
    	Fw.Client.openWaitPanel();
    	App.pageA.on("click","#bankName",App.getMsg);
    	App.pageA.on("click","#bankCode",App.getMsg);
        var url = YT.dataUrl("private/findBank");
    	YT.ajaxData(url,{},function(Data){
    		if(Data.STATUS=='1'){
    			var ss = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    			var result = Data.result;
    			for(var i=0; i<ss.length; i++){
    				var key=ss[i];
    				var value=eval("result."+key);
    				/**
					 * create index title
					 */
    				var tites=[
					           '<div id="'+key+'Div">',
					           '<span class="yui-font ui-form-item ">'+key+'</span>' ,
					           		'<ul class="ui-list ui-border-tb" id="'+key+'">',
					           		'</ul>',
					           '</div">'
					          ]
    				if(!value){
    					tites=[
					           '<div id="'+key+'Div" class="hidden">',
					           '<span class="yui-font ui-form-item ">'+key+'</span>' ,
					           		'<ul class="ui-list ui-border-tb" id="'+key+'">',
					           		'</ul>',
					           '</div">'
					          ]
    				}
    				var htmls = Fw.template(tites,"");
					if(i==0){
						App.pageA.find("#remen").after(htmls);
					}else{
						App.pageA.find("#"+ss[i-1]+"Div").after(htmls);
					}
    				if(value){
    					var temp = [
    					            '{@each BankList as item}', 
    					                '<li class="ui-border-radius">',
    					                	'<div class="yui-list-thumb-s">',
    					                	'<span class="yui-yinhang-icon"></span>',
    					                	'</div>',
    					                	'<div class="ui-list-info  ui-border-t" >',
    					                		'<h4 id="bankName">${item.bankName}</h4>',
    					                		'<input id="${item.bankName}" value="${item.bankCode}" hidden/>',
    					                		'</div>',
    					                '</li>', 
    					            '{@/each}',
    					            ].join("");
    					  					
    					
    					var html = Fw.template(temp,value);
    					App.pageA.find("#"+key).html(html);
    					Fw.Client.hideWaitPanel();
    				}
        		}
        	}
    	});
    },
    /**
     * 得到对应的数据返回
     */
    getMsg : function(){
    	var bankName = $(this).html();
    	var bankCode = $("#"+ bankName).val();
    	var json = {
				bankName : bankName,
				bankNameA:Fw.getParameters("_parameters").bankNameA,
				bankCode : bankCode,
				hukuan:Fw.getParameters("_parameters").hukuan,
				bankNo: Fw.getParameters("_parameters").bankNo,//收款账号
				toAcctName:Fw.getParameters("_parameters").toAcctName,//收款户名
				hkje:Fw.getParameters("_parameters").hkje,//汇款金额
				HKJE:Fw.getParameters("_parameters").HKJE,
				capsAmount:Fw.getParameters("_parameters").capsAmount,
				dxhkje:Fw.getParameters("_parameters").dxhkje,//金额大写
				brName:Fw.getParameters("_parameters").brName,
				brCode:Fw.getParameters("_parameters").brCode,
				attach:Fw.getParameters("_parameters").attach,
				url:Fw.getParameters("_parameters").url,
				provinceName:Fw.getParameters("_parameters").provinceName,
				provinceCode:Fw.getParameters("_parameters").provinceCode,
				cityCode:Fw.getParameters("_parameters").cityCode,
				memo:Fw.getParameters("_parameters").memo,
				dealUser:Fw.getParameters("_parameters").dealUser,
				oldDatas:Fw.getParameters("_parameters").oldDatas,
				back:"2",
				trsNo:Fw.getParameters("_parameters").trsNo,
				gotoBack :Fw.getParameters("_parameters").gotoBack
    	}
    		Fw.redirect("1040101.html",json);
    	
    },
    /**
     * 返回前一页
     */
    gotoBackTest:function(){
    	var json = {
    			hukuan:Fw.getParameters("_parameters").hukuan,
				bankNo: Fw.getParameters("_parameters").bankNo,//收款账号
				toAcctName:Fw.getParameters("_parameters").toAcctName,//收款户名
				hkje:Fw.getParameters("_parameters").hkje,//汇款金额
				HKJE:Fw.getParameters("_parameters").HKJE,
				capsAmount:Fw.getParameters("_parameters").capsAmount,
				dxhkje:Fw.getParameters("_parameters").dxhkje,//金额大写
				bankName:Fw.getParameters("_parameters").bankName,//收款银行
				bankCode:Fw.getParameters("_parameters").banCode,
				brName:Fw.getParameters("_parameters").brName,
				brCode:Fw.getParameters("_parameters").brCode,
				attach:Fw.getParameters("_parameters").attach,
				url:Fw.getParameters("_parameters").url,
				provinceName:Fw.getParameters("_parameters").provinceName,
				provinceCode:Fw.getParameters("_parameters").provinceCode,
				cityCode:Fw.getParameters("_parameters").cityCode,
				memo:Fw.getParameters("_parameters").memo,
				dealUser:Fw.getParameters("_parameters").dealUser,
				oldDatas:Fw.getParameters("_parameters").oldDatas,
				back:"1",
				trsNo:Fw.getParameters("_parameters").trsNo,
				gotoBack :Fw.getParameters("_parameters").gotoBack
    	}
    		Fw.redirect("1040101.html",json);
    }
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
