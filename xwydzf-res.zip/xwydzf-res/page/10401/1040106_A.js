/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
			App.func = window['_getParameter'];
			Fw.Client.hideWaitPanel();
			//显示pageA
			App.pageA = $("#pageA");
			YT.showPageArea(App.pageA, [ App.pageB ], true);
			App.attchList = new Array();
			App.attch = new Array();
			App.memolist = null;
			App.i = 0;
			App.flag = false;
			App.initEvent();
			App.initPageA();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 输入收款账号
		App.pageA.on("click", "#bankId", App.show);
		// 加载常用-事件
		App.pageA.on("click", "#CY", App.initCY);
		// 加载取户名-事件
		App.pageA.on("click", "#QHM", App.initQHM);
		// 加载点击添加附件-事件
		App.pageA.on("click", "#TJFJ", App.initFJ);
		// 加载点击选择审批人-事件
		App.pageA.on("click", "#SPR", App.initSPR);
		// 调用金额键盘
		App.pageA.on("click", "#hkje", App.showMoneyPicker);
		// 登录事件-提交
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		// 调数字键盘
		// App.pageA.on("click", "#bankId", App.showNumberPicker);
		//落地审核提示显示
		App.pageA.on("click","#ts",App.initTS);
		//点击我知道了
		App.pageA.on("click","#iknow",App.toIknow);
		//备注控制字节
		App.pageA.on("porpertychanger","#memo",App.toMemo);
		App.pageA.on("input","#memo",App.toMemo);
		App.pageA.on("click","#CYs",App.initCYs);
		//取单个常用用途
		//App.pageA.on("click",".yui-newCover-item",App.commonItem);
		
	},
	
	/**
	 * 落地审核提示显示
	 */
	initTS:function(){
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#black_b").attr("style","height:"+height+"px;");
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black_b").removeClass("hidden");
		$("#white_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	/**
	 * 取消弹窗提示
	 */
	toIknow:function(){
		App.pageA.unbind("touchmove");
		$("#black_b").addClass("hidden");
		$("#white_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 备注控制字节
	 */
	toMemo:function(){
		Fw.util.Format.checkNum("memo",60);
	},
	/**
	 * 初始化页面数据
	 */
	initPageA : function() {
		if (Fw.getParameters("_parameters")) {
			$("#bankId").val(Fw.getParameters("_parameters").bankNo);
			$("#trsNoName").blur();
			$("#trsNoName").val(Fw.getParameters("_parameters").toAcctName);
			$("#trsNoName").blur();
			if(Fw.getParameters("_parameters").hkje){
				$("#hkje").val("￥"+Fw.util.Format. fmtAmt(Fw.getParameters("_parameters").hkje.toString()));
				$("#HKJE").val(Fw.getParameters("_parameters").hkje);
				$("#capsAmount").html(Fw.util.Format.fmtNumber2Chinese(Fw.getParameters("_parameters").hkje.toString()));
			}
			$("#memo").val(Fw.getParameters("_parameters").memo);
			$("#memo").blur();
			$("#SPR").val(Fw.getParameters("_parameters").SPR);
			$("#SPRID").val(Fw.getParameters("_parameters").SPRID);
			
			if (Fw.getParameters("_parameters").SPRID) {
			}
			var attach = Fw.getParameters("_parameters").attch;
			var url = Fw.getParameters("_parameters").url;
			for ( var k = 0; k < Fw.getParameters("_parameters").length; k++) {
				if(attach[k] != null){
					App.showAttcchment(attach[k].name,url);
				}
			}
		}
	},
	/**
	 * 金额键盘
	 */
	showMoneyPicker : function() {
		Fw.Client.showMoneyPicker($("#hkje"));
	},
	/**
	 * 常用按钮
	 */
	initCY : function() {
		var dealUser = "";
		if(App.func("dealUser")){
			dealUser = App.func("dealUser");
		}else{
			dealUser = Fw.getParameters("_parameters").dealUser;
		}
		var json = {
			innerBank : "0",
			bank : "0",
			bankId : $("#bankId").val(),
			trsNoName : $("#trsNoName").val(),
			hkje : $("#HKJE").val(),
			dxhkje : $("#dxhkje").val(),
			inputCheckbox : $("#inputCheckbox").is(":Checked"),
			memo : $("#memo").val(),
			SPR : $("#SPR").val(),
			SPRID : $("#SPRID").val(),
			attch : App.attch,
			url:App.url,
			length : App.attch.length,
			dealUser:dealUser
		}
		Fw.redirect("1040107.html", json);
	},
	/**
	 * 打开常用用途弹框
	 */
	initCYs:function(){

		Fw.Client.openWaitPanel();
		var height=document.body.clientHeight+500;
		var html="";
		var url=YT.dataUrl("private/commonMemo");
		YT.ajaxData(url,{type:'1'},function(json){
			if(json.STATUS == '1'){
				var list=[];
				list=(json.last).concat(json.history).concat(json.deft);
				App.memolist = list;
				for ( var d in list) {
					var l;
					list[d] = list[d].replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
					if(list[d].length>10){
						 l = list[d].substring(0,10)+"...";
					}else{
						 l = list[d];
					}
					html+='<div class="yui-newCover">';
					if(json.last.length!=0){ //有历史记录
						if(d<json.last.length){
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/historymemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}else{
							html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
						}
					}else{
						html+='<div class="yui-newCover-item" onclick="App.commonItem('+d+')"><img src="../../css/img/commonmemo.png"/>'+'<div class="yui-item-content">'+l+'</div>'+'</div>';
					}
					
					html+='<div>';
				}
				$("#memorys").html(html);
				$("#black_b").attr("style","height:"+height+"px;");
				$("#black_b").attr("style","position:fixed");
				
				$("#black_b").removeClass("hidden");
				$("#white_c").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), json.MSG, true);
			}
		})
		
	},
	/**
	 * 取单个常用用途
	 */
	commonItem:function(index){
		App.pageA.unbind("touchmove");
		var commonMemo = App.memolist[index];
		commonMemo = commonMemo.replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"").replace(/\r\n/g,"");
		if($("#memo").html()==""){
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}else{
			$("#memo").html();
			$("#memo").html(commonMemo);
			$("#memo").val(commonMemo);
		}
		$("#black_b").addClass("hidden");
		$("#white_c").addClass("hidden");
	},
	/**
	 * 取户名
	 */
	initQHM : function() {
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("normal/tr1699");
		var trsNo = $("#bankId").val().replace(/\s/g, "");
		var params = {
			zhdh : trsNo,
			sfbz : "0"
		}
		YT.ajaxData(url, params, function(datas){
			Fw.Client.hideWaitPanel();
			if(datas.STATUS == "1"){
				$("#trsNoName").val(datas.LIST.khmc);
				$("#trsNoName").blur();
				$("#trsNoName").focus();
			}else{
				$("#trsNoName").val("");
				Fw.Form.showPinLabel($(this), datas.MSG, true);
				return;
			}
		}, App.initFail);
	},
	/**
	 * 添加附件
	 */
	initFJ : function() {
		if(App.attch.length > 5){
			Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
			return;
		}
		Fw.Client.openAttcchment("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		//调用附件添加函数Fw.util.attach.addAttach(name,url);
		Fw.util.attach.addAttach(name,url);
	},
	/**
	 * 选择审批人
	 */
	initSPR : function() {
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id,co) {
		$("#SPR").val(name);
		$("#SPRID").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 事务提交
	 */
	toSubmit : function() {
		var toAcctNo = $("#bankId").val().replace(/\s/g,"");
		var toAcctName = $("#trsNoName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"")
		var amount = $("#HKJE").val();
		var memo = $("#memo").val();
		var dealUserName = $("#SPR").val();
		var dealUserId = $("#SPRID").val();
		var communicateId = $("#communicateId").val();
		if (toAcctNo.trim() == "") {
			Fw.Form.showPinLabel($(this), "请输入收款账号", true);
			return;
		}
		var reg = /^[0-9a-zA-Z-_\s]*$/.test(toAcctNo);
		if(!reg || Fw.util.proofTest.proolEmoji(toAcctNo)){
			Fw.Form.showPinLabel($(this), "收款账号不合法", true);
			return;
		}
		// 校验户名是否为空
		if (toAcctName == null || toAcctName == "") {
			Fw.Form.showPinLabel($(this), "请输入收款户名", true);
			return;
		}
		//校验户名是否包含emoji表情
		if(Fw.util.proofTest.proolEmoji(toAcctName)){
			Fw.Form.showPinLabel($(this), "收款户名包含特殊字符", true);
			return;
		}
		// 校验金额是否为空
		if(!( amount > 0)){
			Fw.Form.showPinLabel($(this), "汇款金额必须大于0", true);
			return;
		}
		//备注
		if(Fw.util.proofTest.proolEmoji(memo)){
			Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
			return;
		}
		// 审批人是否为空
		if (dealUserId == null || dealUserId == "") {
			Fw.Form.showPinLabel($(this), "请选择审批人", true);
			return;
		}
		// 防止重复提交
		
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel("提交中...");
		var url = YT.dataUrl("public/getRandomNum");
		YT.ajaxData(url, {}, function(success) {
			if (success.STATUS == "1") {
				var url = "private/transferTask.json";
				var params = {
					type:"1",//新建事务
					trsType : "1",
					innerBank : "1",
					trsferType : "CIB_TRANSFER",
					toAcctNo : toAcctNo,
					toAcctName : toAcctName,
					toBankCode:"309",
					toBankName:"兴业银行",
					amount : amount,
					memo : memo,
					dealUserName : dealUserName,
					dealUserId : dealUserId,
					toCommunicateId:communicateId,
					TOKEN : success.randomNum
				}
				Fw.Client.post(url, params, "App.callSuccess", "App.failuriback");
			}else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(success.MSG, "消息提示");
			}
		});
	},
	callSuccess : function(success) {
		if (success.STATUS == "1") {
			if ($("#inputCheckbox").is(":checked")) {
				var url1 = YT.dataUrl("private/acctOperate");
				var param = {
					OperateType : "0",
					ACCT_NO : $("#bankId").val().replace(/\s/g,""),
					innerBank : "0",
					ACCT_NAME : $("#trsNoName").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
					BANK_NAME : "兴业银行"
				}
				YT.ajaxData(url1, param, App.callback1, App.callback1);
			}
			var url = YT.dataUrl("private/oprtFile");
			var params = {
					trsNo:success.trsNo,
					FileUrl:App.url,
					FileNameList:App.attch
			}
			YT.ajaxData(url, params, function(success) {
			});
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人："+$("#SPR").val(),"提交成功","App.test()");
		} else {
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(success.MSG, "消息提示");
		}
	},
	/**
	 * 失败回调函数
	 */
	failuriback:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 * 成功返回
	 */
	test:function(){
		Fw.Client.changePage("1040100.html", true);
	},
	callback : function(success) {
		Fw.Client.alertinfo(success.MSG, "消息提示");
	},
	/**
	 * 添加常用账号回调函数
	 */
	callback1 : function(data) {
		if (data.STATUS == "1") {
		} else {
			Fw.Form.showPinLabel($(this),data.MSG, true);
		}
	},
	/**
	 * 返回
	 * 
	 */
	gotoBackB:function(){
		if(App.func("dealUser") == "1" || (App.func("dealUser")?App.func("dealUser"):Fw.getParameters("_parameters").dealUser) == "1"){
			Fw.Client.changePage("1040100.html?trsStatus="+App.func("trsStatus")+"", "1");
		}
		if(App.func("dealUser") == "2" || (App.func("dealUser")?App.func("dealUser"):Fw.getParameters("_parameters").dealUser) == "2"){
			Fw.Client.changePage("1040105.html?trsStatus="+App.func("trsStatus")+"", "1");
		}
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
