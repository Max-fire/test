/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		YT.showPageArea(App.pageA, [], true);
		App.flag = true;
		App.initEvent();
		if(Fw.getParameters("_parameters")){
			if(Fw.getParameters("_parameters").trsStatus == "1"){
				App.onYCL();
			}else{
				App.onDCL();
			}
		}else{
			App.onDCL();
		}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function(){
		// 已处理按钮
		App.pageA.on("click","#liYCL",App.onYCL);
		// 待处理按钮
		App.pageA.on("click","#liDCL",App.onDCL);
		// 新建按钮
		App.pageA.on("click", "#btn-show", App.onShow);
		//标题点击事件
		App.pageA.on("click","#icon-top",App.onTop);
		//我申请的点击事件
		App.pageA.on("click","#btnIconb",App.initWSQD);
	},
	/**
	 * 标题点击事件,收起展开
	 */
	onTop:function(){
		if(App.flag){
			$("#top-center").addClass("hidden");
			$("#top-bottom").removeClass("yui-background-top").addClass("yui-background-topB");
			$("#tab-navnew").removeClass("yui-ui-tab-navnew").addClass("yui-ui-tab-navnewB");
			$("#top-bg").removeClass("yui-height170").addClass("yui-height70");
			$("#icon-topA").removeClass("yui-background-top1").addClass("yui-background-top2");
			App.flag = false;
		}else{
			$("#top-bg").removeClass("yui-height70").addClass("yui-height170");
			$("#top-bottom").removeClass("yui-background-topB").addClass("yui-background-top");
			$("#tab-navnew").removeClass("yui-ui-tab-navnewB").addClass("yui-ui-tab-navnew");
			$("#top-center").removeClass("hidden");
			$("#icon-topA").removeClass("yui-background-top2").addClass("yui-background-top1");
			App.flag = true;
		};
	},
	/**
	 * 标题我申请的
	 * 点击样式变为蓝色，跳转到我处理的列表
	 */
	initWSQD:function(){
		$("#btnIconb").removeClass("yui-backgroud-iconbb").addClass("yui-backgroud-iconb");
		$("#colIconb").removeClass("yui-font-col2").addClass("yui-font-col1");
		$("#btnIconc").removeClass("yui-backgroud-iconc").addClass("yui-backgroud-iconcc");
		$("#colIconc").removeClass("yui-font-col1").addClass("yui-font-col2");
		Fw.Client.changePage("1040100.html","0");
	},
	
	
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
		}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		switch (App.trsStatus) {
		case '0':
			url = YT.dataUrl("private/findTaskUnProc");
			$.get("10401_LB.html?v=SID", {}, App.query);
			break;
		case '1':
			url = YT.dataUrl("private/findTaskProced");
			$.get("10401_LB.html?v=SID", {}, App.query);
			break;
		default:
			break;
		}
	},
	/**
	 * 已处理
	 */
	onYCL : function(){
		App.pageA.off("click","#liYCL",App.onYCL);
		App.pageA.off("click","#liDCL",App.onDCL).on("click","#liDCL",App.onDCL);
		$("#d").attr("class","yui-background-2 yui-background");
		$("#liDCL").removeClass("current yui-current");
		$("#y").attr("class","yui-background-1 yui-background");
		$("#liYCL").addClass("current yui-current");
		App.trsStatus = "1";
		App.beginTime ="";
		App.endTime ="";
		App.url = YT.dataUrl("private/findTaskProced");
		$.get("10401_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 待处理
	 */
	onDCL : function(){
		App.pageA.off("click","#liYCL",App.onYCL).on("click","#liYCL",App.onYCL);
		App.pageA.off("click","#liDCL",App.onDCL);
		$("#y").attr("class","yui-background-4 yui-background");
		$("#liYCL").removeClass("current yui-current");
		$("#d").attr("class","yui-background-5 yui-background");
		$("#liDCL").addClass("current yui-current");
		App.trsStatus = "0";
		App.beginTime ="";
		App.endTime ="";
		App.url = YT.dataUrl("private/findTaskUnProc");
		$.get("10401_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 加载列表
	 */
	query : function(tpl) { 
		Fw.Client.openWaitPanel();
		var json = {
				trsType:"1",
				trsStatus:App.trsStatus,
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				webTrsStatus:"4"
		};
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "datas",
			page : true,
			pageSize:5,
			disclosure : true,
			ajax : {
				url : App.url,
				params : json
			},
			itemTpl : tpl,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(App.trsStatus);
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		var page = pageIndex || 1;
		Fw.Client.hideWaitPanel();
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 显示详情
	 */
	showDetail : function(itemData, itemIndex, itemElem) {
		if(App.trsStatus == "1"){
			if(itemData.trsferType=="STAFF_TRANSFER"){
				Fw.Client.changePage('../10406/det15B.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
			}else if(itemData.trsferType=="SALARY_TRANSFER"){
				Fw.Client.changePage('../details/det15B.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
			}else{
				Fw.Client.changePage('../details/det06.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
			}
			
		}
		if(App.trsStatus == "0"){
			if(itemData.trsStatus=="4"){
				Fw.Client.changePage('../details/det15D.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
			}else if(itemData.trsferType=="STAFF_TRANSFER"){
				Fw.Client.changePage('../10406/det15A.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
			}else if(itemData.trsferType=="SALARY_TRANSFER"){
				Fw.Client.changePage('../details/det15A.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+"","1");
			}else{
				Fw.Client.changePage('../details/det07.html?changeBz=2&trsNo='+itemData.trsNo+'&effective_user_id='+itemData.effectiveUserId+'&trsStatus='+itemData.trsStatus+"","1");
			}
			
		}
	},
	/**
	 * 新建
	 */
	onShow : function() {
		var datas = new Array();
		datas.push({
				name : "行内汇款",
				flag:"intside",
				func : "App.showHNHKbtn()"
				});
		datas.push({
			name : "跨行汇款",
			flag:"outside",
			func : "App.showKHHKbtn()"
			});
		datas.push({
			name : "员工汇款",
			flag:"peoside",
			func : "App.showYGHKbtn()"
		});
		datas.push({
			name : "传统代发",
			flag:"tradition",
			func : "App.showCTDFbtn()"
		});
		Fw.Client.showPopupWindow(datas);
	},
	/**
	 * 选择汇款员工
	 */
	showYGHKbtn : function() {
		Fw.Client.chooseStaff("App.openPeople");
	},
	/**
	 * 跳转到员工汇款页面
	 */
	openPeople:function(data) {
		var datas=YT.JsonEval(data)
		Fw.redirect("../10406/1040607.html?dealUser=2&trsStatus="+App.trsStatus+"",datas.userPcList);
	},
	/**
	 * 选择传统代发
	 * ------------------------------------------------------------------------------------------------------
	 */
	showCTDFbtn : function() {
	  Fw.Client.chooseStaff("App.opentraPeople","1");
	},
	/**
	 * 跳转到传统代发页面
	 */
	opentraPeople:function(data) {
		var datas=YT.JsonEval(data)
		Fw.redirect("../10406/1040612.html?dealUser=1&trsStatus="+App.trsStatus+"",datas.userPcList);
	},
	/**
	 * 跳转到行内汇款界面
	 */
	showHNHKbtn : function(){
		var url = YT.dataUrl("private/isApproval");
	    YT.ajaxData(url,{trsType:"3"},function(Data){
	    	if(Data.IsApproval=="YES"){
	    		Fw.Client.changePage("1040106_C.html?effectiveUserId=1&dealUser=2&trsStatus="+App.trsStatus+"", "1");
	    	}else{
	    		Fw.Client.changePage("1040106_A.html?effectiveUserId=1&dealUser=2&trsStatus="+App.trsStatus+"", "1");
	    	}
	    })	
	},
	/**
	 * 跳转到跨行界面
	 */
	showKHHKbtn : function() {
		Fw.Client.changePage("1040106_B.html?effectiveUserId=1&dealUser=2&trsStatus="+App.trsStatus+"", "1");
	},
	/**
	 * 返回工作首页
	 */
	gotoHomePage:function(){
		Fw.Client.gotoHomePage();
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);