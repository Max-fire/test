/**
 * 创建应用
 * @author 
 */
var App = {
	requires : ['Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
			Fw.Client.hideWaitPanel();
			App.func = window['_getParameter'];
			App.pageA = $("#pageA");
			App.pageB = $("#pageB");
			YT.showPageArea(App.pageA,[App.pageB], true);
			App.flag = false;
			App.flag1 = false;
			App.zfb=false;
			App.flags="NO";
			App.type="";
			App.attach = new Array();
			App.initEvent();
			App.initUserInfo();
			App.data = Fw.getParameters();
			$("#purpose").val(App.data.purpose);
			$("#purpose").blur();
			if (App.data.back) {
				$("#fromAcctNo").val(App.data.fromAcctNo);
				$("#fromAcctName").val(App.data.fromAcctName);
				$("#KYYE").html(App.data.amount);
			}
	},
	initUserInfo:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/findUserInfo");
		YT.ajaxData(url,{},function(data){
			if (data.STATUS == "1") {
				App.mobile = data.mobile;
				App.userName = data.userName;
				App.initCY();
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		});
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("input","#fromAcctName",App.onKeypress);
		App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
		App.pageA.on("input","#purpose",App.onKeypress);
		App.pageA.on("porpertychanger","#purpose",App.onKeypress);
		App.pageA.on("click", "#btnSubmit", App.payType);
		App.pageA.on("click", "#HKZH", App.initZH);
		App.pageA.on("click", "#paySwitchOn", App.paySwitchOn);
		App.pageA.on("click", "#black_b", App.paySwitchOff);
		App.pageB.on("click","#qkmm",App.showPwdPicker);
		App.pageB.on("click","#meg_code",App.showNumberPicker);
		App.pageB.on("click","#btnSubmit1",App.toSubmit1);
	},
	/**
	 * 数字键盘
	 */
	showNumberPicker:function(){
		Fw.Client.showNumberPicker($("#meg_code"));
	},
	/**
	 * 密码键盘
	 */
	showPwdPicker:function(){
		Fw.Client.showPwdPicker($("#qkmm"));
	},
	/**
	 * 汇款账户
	 */
	initCY : function() {
		App.datas = new Array();
		App.acct1 = new Array();
		App.acct2 = new Array();
		App.acct3 = new Array();
		var url1 = YT.dataUrl("private/findAcctList");
		YT.ajaxData(url1, {}, function(data) {
			if (data.STATUS == "1") {
				for ( var i = 0; i < data.datels.length; i++) {
					App.datas.push({
						account : data.datels[i].account.acctNo,
						balance : data.datels[i].response.kyye,
						accountName:data.datels[i].response.khmc
					});
					App.acct1.push(data.datels[i].account.acctNo);
				}
				App.toFindPersonalAcct();
			}else{
				App.toFindPersonalAcct();
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		},function(data){
			App.toFindPersonalAcct();
			Fw.Form.showPinLabel($(this), data.MSG, true);
		});
	},
	/**
	 * 查询个人账号
	 */
	toFindPersonalAcct:function(){
		var url2 = YT.dataUrl("private/findPersonalAcct");
		YT.ajaxData(url2, {"type":"1"}, function(data) {
			if (data.STATUS == "1") {
				if(data.innerList!=null&&data.innerList!=""){
					App.innerList=data.innerList;
					for ( var i = 0; i < data.innerList.length; i++) {
						if(data.innerList[i].amount!=null){
							App.datas.push({
								account : data.innerList[i].cardNo,
								balance : data.innerList[i].amount,
								accountName:App.userName
							});
							App.acct2.push(data.innerList[i].cardNo);
						}
					}
				}
				App.onKeypress();
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
				return;
			}
		});
	},
	/**
	 * 显示账户
	 */
	initZH : function() {
		var json = {
				jsonArray : App.datas,
				"func" : "App.showCommonlyUsedAccount"
			};
		Fw.Client.hideWaitPanel();
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	/**
	 * 账户回显
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		App.flag = false;
		var balance = parseFloat(balances);
		$("#fromAcctNo").val(account);
		$("#fromAcctName").val(name);
		$("#KYYE").html("可用余额" + balance + "元");
		Fw.Client.hideWaitPanel();
		App.onKeypress();
	},
	/**
	 * 判断是否信息都填写完整
	 */
	onKeypress : function() {
		Fw.util.Format.checkNum("purpose",60);
		var SKR = $("#fromAcctName").val().trim();
		var YT = $("#purpose").val().trim();
		var SKZH = $("#fromAcctNo").val().trim();
		if (SKR != "" && YT != "" && SKZH !="" ) {
			$("#btnSubmit").removeAttr("disabled", "");
		} else {
			$("#btnSubmit").attr("disabled", "disabled");
		};
		if(App.acct2.indexOf(SKZH)==-1){
			//对公
			$("#ts1").removeClass("hidden");
			$("#ts2").addClass("hidden");
			$(".CRDZ").removeClass("hidden");
		}else{
			//个人卡
			$("#ts2").removeClass("hidden");
			$("#ts1").addClass("hidden");
			$(".CRDZ").addClass("hidden");
			for ( var i = 0; i < App.innerList.length; i++) {
				if (App.innerList[i].cardNo == SKZH) {
					if (!(App.innerList[i].authenticated && App.innerList[i].authenticated=="6")) {
						$("#KYYE").html("可用余额" + App.innerList[i].amount + "元");
					}else{
						$("#KYYE").html("");
					}
					break;
				}
			}
		}
	},
	/**
	 * 转账支付判断
	 */
	toPaySwitch:function(){
		var SKZH = $("#fromAcctNo").val().trim();
		var width=(document.body.clientWidth-290)/2;
		var widthimg=(document.body.clientWidth-95)/2;
		for ( var i = 0; i < App.innerList.length; i++) {
			if (App.innerList[i].cardNo==SKZH) {
				//未验证通过
				if (App.innerList[i].authenticated && App.innerList[i].authenticated=="6") {
					App.type="2";
					App.data.wageFlag=App.innerList[i].wageFlag;
					$("#mc").html("个人银行卡（*"+SKZH.substring(SKZH.length-4,SKZH.length)+"）支付功能");
					$("#white_b").attr("style","width: 290px;left:"+width+"px;");
					$("#img_b").attr("style","left:"+widthimg+"px;");
					$("#black_b").removeClass("hidden");
					$("#img_b").removeClass("hidden");
					$("#white_b").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
				}else if (!(App.innerList[i].paySwitch && App.innerList[i].paySwitch=="7")) {
					//验证通过未开启支付功能
					App.type="1";
					$("#mc").html("个人银行卡（*"+SKZH.substring(SKZH.length-4,SKZH.length)+"）支付功能");
					$("#white_b").attr("style","width: 290px;left:"+width+"px;");
					$("#img_b").attr("style","left:"+widthimg+"px;");
					$("#black_b").removeClass("hidden");
					$("#img_b").removeClass("hidden");
					$("#white_b").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
				}
				return App.type;
				break;
			}
		}
		return App.type;
	},
	/**
	 * 支付开关
	 * 确认按钮
	 */
	paySwitchOn:function(){
		if (App.type=="1") {
			//直接开通
				var url = YT.dataUrl("private/cardPaySwitch");
				var params={
						cardNo:	$("#fromAcctNo").val().trim(),
						authenticated : "1",
						switchStatus : "7"
				}
				YT.ajaxData(url,params,function(data){
					if (data.STATUS=="1") {
						App.type=""
						App.acct3.push($("#fromAcctNo").val().trim());
						App.pageA.unbind("touchmove");
						$("#black_b").addClass("hidden");
						$("#img_b").addClass("hidden");
						$("#white_b").addClass("hidden");
						App.payType();
					}else{
						App.pageA.unbind("touchmove");
						$("#black_b").addClass("hidden");
						$("#img_b").addClass("hidden");
						$("#white_b").addClass("hidden");
						Fw.Client.alertinfo(data.MSG,"消息提示");
					}
					Fw.Client.hideWaitPanel();
				},function(data){
					App.pageA.unbind("touchmove");
					$("#black_b").addClass("hidden");
					$("#img_b").addClass("hidden");
					$("#white_b").addClass("hidden");
					Fw.Client.alertinfo(data.MSG,"消息提示");
					Fw.Client.hideWaitPanel();
				});
		}else{
			//验证信息开通
				App.data.fromAcctName=$("#fromAcctName").val().trim();
				App.data.fromAcctNo=$("#fromAcctNo").val().trim();
				App.data.purpose=$("#purpose").val();
				App.data.amount=$("#KYYE").html();
				App.data.back="1040609";
				App.pageA.unbind("touchmove");
				$("#black_b").addClass("hidden");
				$("#img_b").addClass("hidden");
				$("#white_b").addClass("hidden");
				Fw.redirect("../10406/1040611.html?amount="+App.func("amount")+"&trsNo="+App.func("trsNo")+"&toAcctNo="+App.func("toAcctNo")+"&dealMsg="+App.func("dealMsg")+"&count="+App.func("count")+"&trsId="+App.func("trsId")+"&trsStatus="+App.func("trsStatus")+"",App.data);
		}
	},
	/**
	 * 支付开关
	 * 取消按钮
	 */
	paySwitchOff:function(){
		$("#black_b").addClass("hidden");
		$("#img_b").addClass("hidden");
		$("#white_b").addClass("hidden");
	},
	payType:function(){
		var card = $("#fromAcctNo").val();
		if(App.acct2.indexOf(card)==-1){
			App.onNext();
		}else{
			if (App.acct3.indexOf(card)==-1) {
				if (App.toPaySwitch()!="") {
					return;
				}
			}
			Fw.Client.openWaitPanel();
			var paramss = {
					"type":"4",
					"cardNo":card.substring(card.length-4,card.length),
					"mobile":App.mobile,
					"amount":Fw.util.Format.replaceDouble("2",App.func("amount"))
			};
			Fw.util.Format.openTimerListener("yzm",paramss);
			//判断是否是无支付棒且小于5万
			var url = YT.dataUrl("private/avoidKeyAuth");
			var params = {
					cardNo :$("#fromAcctNo").val(),//付款账号
					amount:Fw.util.Format.replaceDouble("2",App.func("amount")),//金额
			};
			if (App.acct1.length<1) {
				YT.ajaxData(url,params,function(data){
					if(data.STATUS=="1"){
						App.flags=data.flag;
						if (data.flag=="YES") {
							App.zfb=true;
						}else{
							App.zfb=false;
						}
						Fw.Client.hideWaitPanel();
						YT.showPageArea(App.pageB,[App.pageA], true);
					}else{
						App.zfb=false;
						Fw.Client.alertinfo(data.MSG,"消息提示");
						Fw.Client.hideWaitPanel();
					}
				},function(data){
					Fw.Client.alertinfo(data.MSG,"消息提示");
					Fw.Client.hideWaitPanel();});
			}else{
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageB,[App.pageA], true);
			}
		}
	},
	toSubmit1:function(){
		if($("#qkmm").val()==""){
			Fw.Form.showPinLabel($(this), "取款密码不能为空", true);
			return;
		}
		if($("#meg_code").val()==""){
			Fw.Form.showPinLabel($(this), "验证码不能为空", true);
			return;
		}
		if($("#meg_code").val().length!="6"){
			Fw.Form.showPinLabel($(this), "验证码必须为6位", true);
			return;
		}
		if(App.flag2){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		Fw.Client.openWaitPanel("提交中...");
		var url = YT.dataUrl("private/personAcctCheck");
		var params = {
				type:"2",
				trsNo : App.func("trsNo"),
				fromAcctNo : $("#fromAcctNo").val(),
				fromAcctName : $("#fromAcctName").val(),
				fromBankName : "兴业银行",
				purpose : $("#purpose").val(),
				memo : $("#purpose").val(),
				dealMsg:decodeURI(App.func("dealMsg")),
				amount:Fw.util.Format.replaceDouble("2",App.func("amount")),
				count:App.func("count"),
				password  :$("#qkmm").attr("data-value"),
				mobile    :App.mobile,
				MSG :$("#meg_code").val(),
				futureArrivFlag:$("input[type='radio']:checked").val()
		};
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				App.pzdh = data.pzdh;
				App.onNext();
			}else if(data.STATUS=="B5020"){
				Fw.Client.alertinfo(data.MSG,"消息提示","App.successBackB()");
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		});
	},
	/**
	 * 事务办结(B5020)
	 */
	successBackB:function(data){
		var json = {
				trsStatus:"1"
		};
		Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
		Fw.redirect("1040105.html",json);
	},
	/**
	 * 下一步事务提交(支付棒)
	 */
	onNext : function() {
		var purpose = $("#purpose").val();
		if(Fw.util.proofTest.proolEmoji(purpose)){
			Fw.Form.showPinLabel($(this), "付款用途包含特殊字符", true);
			return;
		};
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel("提交中...");
		var json = {
				func : "App.initComplete",
				funcAndroid:"App.initCompleteAndroid",
				type : "2",
				toName:App.data.toAcctName,//收款人名称
				toAcc:App.func("toAcctNo"),//收款账号
				fromName:$("#fromAcctName").val(),//付款名称
				fromAcc:$("#fromAcctNo").val(),//付款账号
				purpose:$("#purpose").val(),//用途
				xmlMoney:Fw.util.Format.replaceDouble("2",App.func("amount")),//金额
				xmlNo:App.func("trsNO")//流水账号
			};
		if (App.zfb) {
			var fromAcctNo = $("#fromAcctNo").val();
			var fromAcctName = $("#fromAcctName").val();
			var purpose = $("#purpose").val();
			//判断是否直接办结
			if(App.func("trsStatus")=="1"){
				App.trsNo = App.func("trsNo");
				App.initXQBJ("","",fromAcctNo,fromAcctName,purpose);
			}else{
				App.initBJ("","",fromAcctNo,fromAcctName,purpose);
			}
		}else{
			Fw.Client.showBB(json);
		}
		Fw.Client.hideWaitPanel();
		App.flag = false;
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.pageA.off("input","#fromAcctName",App.onKeypress);
		App.pageA.off("porpertychanger","#fromAcctName",App.onKeypress);
		App.pageA.off("input","#purpose",App.onKeypress);
		App.pageA.off("porpertychanger","#purpose",App.onKeypress);
		App.pageA.off("click", "#HKZH", App.initZH);
		$("#btnSubmit").attr("disabled","disabled");
		var fromAcctNo = $("#fromAcctNo").val();
		var fromAcctName = $("#fromAcctName").val();
		var purpose = $("#purpose").val();
		if(fromAcctNo.trim() == ""){
			Fw.Form.showPinLabel($(this), "请选择付款账号", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款户名
		if(fromAcctName.trim()== ""){
			Fw.Form.showPinLabel($(this), "请填写付款款户名", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款用途
		if(purpose.trim() == ""){
			Fw.Form.showPinLabel($(this), "请输入付款用途", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		App.flag = false;
		App.flag2 = true;
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
		App.pageA.off("input","#fromAcctName",App.onKeypress);
		App.pageA.off("porpertychanger","#fromAcctName",App.onKeypress);
		App.pageA.off("input","#purpose",App.onKeypress);
		App.pageA.off("porpertychanger","#purpose",App.onKeypress);
		App.pageA.off("click", "#HKZH", App.initZH);
		$("#btnSubmit").attr("disabled","disabled");
		if(fromAcctNo.trim() == ""){
			Fw.Form.showPinLabel($(this), "请选择付款账号", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款户名
		if(fromAcctName.trim()== ""){
			Fw.Form.showPinLabel($(this), "请填写付款款户名", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		//校验付款用途
		if(purpose.trim() == ""){
			Fw.Form.showPinLabel($(this), "请输入付款用途", true);
			App.pageA.on("input","#fromAcctName",App.onKeypress);
			App.pageA.on("porpertychanger","#fromAcctName",App.onKeypress);
			App.pageA.on("input","#purpose",App.onKeypress);
			App.pageA.on("porpertychanger","#purpose",App.onKeypress);
			App.pageA.on("click", "#HKZH", App.initZH);
			return;
		}
		App.flag = false;
		App.flag2 = true;
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	/**
	 * 直接办结
	 */
	initBJ:function(a,b,frAcctNo,frAcctName,ppose){
			var fromAcctNo = frAcctNo;
			var fromAcctName = frAcctName;
			var purpose = ppose;
			App.trsNo = App.func("trsNo");
			var params = {
				type:"2",
				trsNo : App.trsNo,
				fromAcctNo : fromAcctNo,
				fromAcctName : fromAcctName,
				fromBankName : "兴业银行",
				purpose : purpose,
				memo : purpose,
				signData:a,
				signSrc:b,
				dealMsg:decodeURI(App.func("dealMsg")),
				amount:Fw.util.Format.replaceDouble("2",App.func("amount")),
				count:App.func("count"),
				password  :$("#qkmm").attr("data-value"),
				futureArrivFlag:$("input[type='radio']:checked").val()
			};
			if(App.acct2.indexOf(fromAcctNo)==-1){
				params.acctType="00";//对公
			}else{
				params.acctType="01";//个人
				params.password=$("#qkmm").attr("data-value");
				params.pzdh = App.pzdh;
			}
			params.key=App.flags;
			params.readFlag=App.data.readFlag;
			Fw.Client.openWaitPanel();
			var url = "private/batchTransfer.json";
			Fw.Client.post(url,params,"App.success","App.failuri");
			
	},
	/**
	 * 直接办结成功回调函数
	 */
	success:function(data){
			if (data.STATUS == "1") {
				if(App.data.FileUrl){
					var url = YT.dataUrl("private/oprtFile");
					var params = {
						trsNo : App.data.trsNo,
						FileUrl : App.data.FileUrl,
						FileNameList : App.data.FileNameList
					};
					YT.ajaxData(url, params, function(success) {});
				}
				
				var json = {
						trsType : "1",
						trsNo : App.func("trsNo"),
						trsId:App.func("trsId"),
						trsDate:data.trsDate
					};
				App.json = json;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.successBack()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"系统提示","App.initFail()");
			}
	},
	/**
	 * 办结成功返回
	 */
	successBack:function(){
		Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
		Fw.redirect("1040115.html", App.json);
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 * 转账失败回到待办列表
	 */
	initFail: function(){
		var json = {
				trsStatus:"0"
		};
		if(App.func("trsId") == ""){
			Fw.redirect("1040105.html", json);
		}else{
			Fw.Client.dealMessage("1",App.func("trsId"),App.trsNo);
		}
		
	},
	toBackA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	/**
	 * 返回待办列表
	 */
	gotoBackTest:function(){
		if(App.func("trsId") == ""||App.func("trsId")=="null"||App.func("trsId")==null){
			Fw.Client.changePage("1040105.html","0");
		}else{
			Fw.Client.dealMessage("1",App.func("trsId"),App.trsNo);
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
