/**
 * 创建应用
 * 
 * @author tsf
 */
var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;
		App.flag=false;
//		Fw.Client.hideWaitPanel();
//		YT.showPageArea(App.pageA, [], true);
		App.initEvent();
		App.showFj();
	},
	/**
	 * 显示附件
	 */
	showFj:function(){
		if(App.data && App.data.attch){
			var attch=App.data.attch;
			var url=App.data.url;
			var attach=new Array();
			App.attach_url = '';
			for(var i in attch){
				attach.push({
					attachName:attch[i].name,
					attachUrl:url+attch[i].name
					})
			}
			Fw.util.attach.showAttach( attach );
			$("#fjCount").html(App.data.attch.length)//附件数量
		}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#submit",App.toSubmit);
		try{
	  if(App.data&&App.data.coreC){	   
		  var coreC=App.data.coreC;
		  var item='';
		  for(var tkey in coreC){
			  item+='<span style="padding-top: 10px;font-size: 12px;color: #8F9DAD;display:block">'+App.formatToName(tkey)+'</span>'+
				 '<span style="color: #5D6574;font-size: 14px;min-height:20px;display:block">'+coreC[tkey]+'</span>'
		  }
		  var htmlcore='<div style="">'+
							'<span style="font-size: 16px;font-weight:bold;color:#355169;">变更前</span>'+item+
						'</div>';
		 
		  $("#listCore").html(htmlcore);
	  }
	  	 
	  if(App.data&&App.data.diffC){	   
		  var diffC=App.data.diffC;
		  var item='';
		  for(var tkey in diffC){
			  item+='<span style="padding-top: 10px;font-size: 12px;color: #8F9DAD;display:block">'+App.formatToName(tkey)+'</span>'+
				 '<span style="font-size: 14px;color: #FF7F00;min-height:20px;display:block;word-break: break-all;word-wrap: break-word;">'+diffC[tkey]+'</span>'
		  }
		  var htmldiff='<div>'+
						'<span style="font-size: 16px;font-weight:bold;color:#FF7F00;">变更后</span>'+item+
					'</div>';
		 
		  $("#listDiff").html(htmldiff);
	  }
	  
	  if(App.data&&App.data.applyMsg){
		  $("#resonly").html(App.data.applyMsg);
	  }
	   Fw.Client.hideWaitPanel();
	   YT.showPageArea(App.pageA, [], true);
		}catch(e){alert(e)}
	},
	formatToName:function(str){
		switch(str){
		case 'dayAmtLmt':
			return '日累计限额';
		case 'dayCntLmt':
			return '日累计笔数';
		case 'yearAmtLmt':
			return '年累计限额';
		default:
			break;
		}
	},
   
	toSubmit:function(){	
		if(App.flag==true){
			Fw.Form.showPinLabel($(this),"请勿重复提交！", true);
	    	return;
		}
		var xml='<M><k>日累计限额</k><v>'+App.data.diff.dayAmtLmt+'</v></M><M><k>日累计笔数</k><v>'+App.data.diff.dayCntLmt+'</v></M><M><k>年累计限额</k><v>'+App.data.diff.yearAmtLmt+'</v></M>';
		
		Fw.Client.openWaitPanel();
		YT.ajaxData(YT.dataUrl("private/getCounterNo"), {}, function(data) {
			if (data.STATUS == "1") {
				App.counterNo=data.counterNo;
				var json = {
						type : "4",
						func : "App.initComplete",
						funcAndroid:"App.initCompleteAndroid",
						XML : '<?xml version="1.0" encoding="utf-8"?><T><D>'+xml+'</D></T>'
				};
				Fw.Client.showBB(json);
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});
		
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * 支付棒确认提交
	 */
	initSubmit:function(a,b){	
		App.flag=true;
		var diff1=new Array();
		var core1=new Array();
		diff1.push(App.data.diff);
		core1.push(App.data.core);		
	    Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/commitToCheck");
		var json = {
				signData:a,
				signSrc:b,
				core:core1,
				diff:diff1,
				busiType:"2",
				counterNo:App.counterNo,
				acctNo:App.data.diff.acctNo,
				applyMsg:App.data.diff.applyMsg,
		};
		YT.ajaxData(url, json, function(data) {
			if (data.STATUS == "1") {
//				alert(YT.JsonToStr(App.data.attch));
				if(App.data.attch){
					var url1 = YT.dataUrl("private/oprtFile");
					var params = {
						trsNo : data.counterNo,
						FileUrl : App.data.url,
						FileNameList : App.data.attch,
					    counterFlag:"true"
					};
					YT.ajaxData(url1, params, function(success) {
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo("已提交申请，待银行审核通过后即可受理成功","消息提示","App.successBack()");
//						Fw.Form.showPinLabel($(this),"已提交申请，待银行审核", true);
//						setTimeout(Fw.redirect("1090100.html",""),1500)
					});
				}
				
			} else {
				App.flag=false;
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});
	},
	successBack:function(){
		Fw.redirect("1090100.html","")
	},
	/**
	 * 返回
	 */
	back:function(){
		Fw.redirect("10901022.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);