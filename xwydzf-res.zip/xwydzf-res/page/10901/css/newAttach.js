﻿/**
 * 附件列表
 * 
 */


attach = {
		/**
		 * 新建附件列表
		 * Fw.util.attach.addAttach(name,url)
		 */
		addAttach:function(name,url,clickId,showId,length){
			if(name.length < 3 || name == null){
				Fw.Form.showPinLabel(null, "附件上传失败", true);
				return;
			}
			var type=name.indexOf("?token");
			var nameType=name;
			if (type>-1) {
				nameType=nameType.substring(0, type);
			}
			var types = nameType.substring(nameType.length - 3, nameType.length);
			App.attch[App.i++] = {
				name : name,
				clickId:clickId,
				showId:showId,
				length:length
			};
			App.url = url;
			
			if (types == "jpg") {
				var html = '<div class="swiper-slide" style="width: 120px;margin-right:6px">'+ 
								' <div class="ui-pic pic"  style="background-image:url('+ url + name+ '); background-size: 100% auto" data-url="'+ url + name + '">' + '</div>'+ 
								'<span class="delectPic" id="' + App.i+ '" data-name="'+ name +'" ></span>'+ 
							'</div>';
			}
			if (types == "amr" || types == "m4a") {
				Fw.Form.showPinLabel(null, "请上传正确附件", true);
				return;
			}
			$("#"+clickId).after(html);
			var picLength=$("#"+clickId).siblings().length;
			if (length && length>1) {
				if(picLength==length){
					$("#"+clickId).css("display","none");
				}else{
					$("#"+clickId).css("display","block");
				}
			}else{
				$("#"+clickId).css("display","none");
			}
			$("#pic"+clickId).html(picLength);
			attach.initFJ(clickId,showId);
			App.isOK();
		},
		/**
		 * 详情显示附件
		 * Fw.util.attach.showAttach(data);
		 * 
		 */
		showAttach:function( d,showId ){
			var html='';
			var a=0;
			$.each(d,function(i,n){
				var attachType = n.attachName.substring(n.attachName.length-3,n.attachName.length);
				if(attachType=="amr" || attachType == "m4a"){
					html += '<div class="swiper-slide swiper-slide-active" style="width: 104px;">'+
			              '<div class="ui-files audio" data-src='+ App.attach_url + n.attachUrl + '>' +
			              '</div>'+
		              '</div>';
				}else if(attachType=="jpg" ){
					App.attchList[a++] = {
							name:App.attach_url + n.attachUrl
					}
					html += '<div class="swiper-slide swiper-slide-active" style="width: 104px;">'+
			              '<div class="ui-pic pic" style="background-image:url('+ App.attach_url + n.attachUrl +'); background-size: 100% auto" data-url='+ App.attach_url + n.attachUrl +'>'+
			              '</div>'+
		              '</div>';      	
				}
			});
			$('#'+showId).html(html);
			if(d.length > 0){
				$("#"+showId).css("display","block");
			}
			attach.initFJ("",showId);
		},
		/**
		 * 附件加载项
		 * Fw.util.attach.initFJ();
		 */
		initFJ : function(clickId,showId) {
			var swiper = new Swiper('.swiper-container', {
				slidesPerView : 'auto',
				freeMode : true,
				freeModeMomentumBounce : true,
				spaceBetween : 0
			});
			$('#'+showId).off('click').on('click', '.delectPic', function() {
				var name = $(this).data("name");
				for(var j = 0; j < App.attch.length; j++){
					var obj = App.attch[j].name;
					if(obj == name){
						App.attch.splice(j,1);
						App.i = App.i - 1;
						$(this).parent().remove();
					}
				}
				$("#pic"+clickId).html($("#"+clickId).siblings().length);
				$("#"+clickId).css("display","block");
				App.isOK();
				try{
					$("#imgCount").html(App.attch.length)
				}catch(e){}
				
			}).on('click', '.audio', function() {
				if ($(this).hasClass('active')) {
					attach.audioPause($(this));
				} else {
					attach.audioPlay($(this));
				}
			}).on("click", ".pic", function() {
				attach.picView($(this));
			});
			var layer = document.createElement("div");
			layer.id = "pageX";
			layer.title = "查看附件";
			layer.setAttribute("data-btnLeft","true|返回|back()");
			layer.setAttribute("data-center","");
			layer.setAttribute("data-btnRight","false");
			this._lastLayer = document.body.appendChild(layer);
			var layer = document.createElement("div");
			layer.id = "pageX";
			this._lastLayer = document.body.appendChild(layer);
		},
		audio : document.getElementById("mainAudio"),
		audioActive : '',
		audioPlay : function(elem) {
			var loc = document.location;
			var protocol = loc.protocol;
			var host = loc.host;
			var path=protocol + '//' + host;
			var url=elem.data("src");
			if (url.indexOf(path) == -1) {
				url=path+url;
			}
			Fw.Client.openAudio(url);
		},
		picView : function(elem) {
			$('#picView').attr('src', url);
			var url = elem.data('url');
			var jpgList = new Array();
			var j = 0;
			if(App.attchList.length > 0){
				for(var i = 0; i < App.attchList.length; i++){
					var name = App.attchList[i].name;
					var type=name.indexOf("?token");
					var nameType=name;
					if (type>-1) {
						nameType=nameType.substring(0, type);
					}
					var types = nameType.substring(nameType.length - 3, nameType.length);
					if(types == "jpg"){
						jpgList[j] = {
								name : name
						}
						j++;
					}
				}
			}
			if(App.attch.length > 0){
				for(var i = 0; i < App.attch.length; i++){
					var name = App.attch[i].name;
					var type=name.indexOf("?token");
					var nameType=name;
					if (type>-1) {
						nameType=nameType.substring(0, type);
					}
					var types = nameType.substring(nameType.length - 3, nameType.length);
					if(types == "jpg"){
						jpgList[j] = {
								name : App.url + name
						}
						j++;
					}
				}
			}
			var h = 0;
			var loc = document.location;
			var protocol = loc.protocol;
			var host = loc.host;
			var path=protocol + '//' + host;
			for(var k = 0; k < jpgList.length; k++){
				var name = jpgList[k].name;
				if(url == name){
					h = k;
				}
				if (jpgList[k].name.indexOf(path) == -1) {
					jpgList[k].name=path+jpgList[k].name;
				}
			}
			var json = {
					place:h,//当前图片位置
					currentUrl:url,//当前图片路径
					jpg:jpgList//所有图片路径
			}
			if (url.indexOf(".jpg">-1)) {
				attach.h5ShowImg(Fw.JsonToStr(json));
			}else{
				Fw.Client.openImage(Fw.JsonToStr(json));
			}
		},
		h5ShowImg:function(json){
			var url =basePath+"/page/showImg.html?json="+encodeURI(json);
			Fw.Client.changeWeb(url,false,pageX)

		}
		
};