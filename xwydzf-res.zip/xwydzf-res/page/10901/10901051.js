/**
 * 在线柜台 变更记录
 * @author zhenghy
 */

var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;
		
		App.initEvent();
		App.loadData();
		
//		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
	},
	initEvent : function() {
		
	},
	loadData:function(){
		try{
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/counterCompare");
		var params={
				counterNo:App.data.list.counterNo,
				busiType:App.data.list.busiType
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				App.operateData(data);
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
		}catch(e){alert(e)}
	},
	operateData:function(data){
		
		$("#ywlx").html(App.formatBusiType(data.busiType));
		$("#yqlsh").html(data.counterNo);
		$("#sqr").html(data.applyMan);
		$("#sqrq").html(data.applyTime);
		$("#shzt"+data.status).removeClass("hidden");
		if(data.status=='3'){
			$("#jjyy").removeClass("hidden");
			$("#reason").html(data.refuseMsg);
		}
		App.attach_url = data.attach_url;
		Fw.util.attach.showAttach(data.attach );
		$("#fjCount").html(data.attach.length)//附件数量
		
		var coreC=data.coreC;
		var diffC=data.diffC;
		
		for(var i in coreC){
			if(!diffC[i]){
				diffC[i]="";
			}
		}
		for(var i in diffC){
			if(!coreC[i]){
				coreC[i]="";
			}
		}
		
		var dateData=["zzjgdmdqr","jgxydmdqr","zjdqr","jgzmwjqsrq","jgzmwjdqrq","gsdjhdqr","dsdjhdqr"]; 
		var htmlcore='';
		var item="";
		 for (var tKey in coreC) {
			 var tempItem = Fw.util.Format.dataConversion(tKey);
			 if(tempItem!=""){
				 coreTkey=coreC[tKey];
				 if(dateData.indexOf(tempItem)!=-1){//日期格式化
					 coreTkey=Fw.util.Format.fmtYear(coreTkey);
				 }
				 if(tempItem=="zjzl" ){//证件种类 |
					 coreTkey=Fw.util.Format.formarDocumentsToStr(coreTkey); 
				  }
				  if(tempItem=="zmwj"){//证明文件类型
					  coreTkey=Fw.util.Format.formarEvidenceToStr(coreTkey); 
				  }
				  if(tempItem=="jgfzrlx"){//机构负责人类型
					  coreTkey=Fw.util.Format.formarInsPersion(coreTkey); 
				  }
				  if(tempItem=="sfbzzczj"){//是否标注注册资金
					  if(coreTkey=="0"){
						  coreTkey="否"
					  }else if(coreTkey=="1"){
						  coreTkey="是"
					  }else{
						  coreTkey=""
					  }
				  }
				  if(tempItem=="zczj"){
					  coreTkey=parseFloat(Number(coreTkey)).toFixed(2);
				  }
				  if(tempItem=="bz"){//币种
					  coreTkey=Fw.util.Format.formatCurrencyToStr(coreTkey); 
				  }
				  if(tempItem=="gb"){//国别
					  if(coreTkey=="CHN" || coreTkey=="156"){
						  coreTkey='中国';
					  }
				  }
				 item+='<span style="padding-top: 10px;font-size: 12px;color: #8F9DAD;display:block">'+Fw.util.Format.formatIdToName(tKey)+'</span>'+
				 '<span id="'+tempItem+'" style="color: #5D6574;font-size: 14px;min-height:20px;display:block">'+coreTkey+'</span>'
			 }
			
		 }
		 htmlcore+='<div style="">'+
			'<span style="font-size: 16px;font-weight:bold;color:#355169;clear:both;">变更前</span>'+item+
			'</div>';
		 $("#listCore").html(htmlcore);
		 
		 

		var htmldiff = "";
		var item1 = "";
		for ( var tKey in diffC) {
			var tempItem1 = Fw.util.Format.dataConversion(tKey);
			if (tempItem1 != "") {
				diffTkey = diffC[tKey];
				if (dateData.indexOf(tempItem1) != -1) {// 日期格式化
					diffTkey = Fw.util.Format.fmtYear(diffTkey);
				}
				if (tempItem1 == "zjzl") {// 证件种类 |
					diffTkey = Fw.util.Format.formarDocumentsToStr(diffTkey);
				}
				if (tempItem1 == "zmwj") {// 证明文件类型
					diffTkey = Fw.util.Format.formarEvidenceToStr(diffTkey);
				}
				if (tempItem1 == "jgfzrlx") {// 机构负责人类型
					diffTkey = Fw.util.Format.formarInsPersion(diffTkey);
				}
				if (tempItem1 == "sfbzzczj") {// 是否标注注册资金
					if (diffTkey == "0") {
						diffTkey = "否"
					} else if (diffTkey == "1") {
						diffTkey = "是"
					} else {
						diffTkey = ""
					}
				}
				 if(tempItem1=="zczj"){
					 diffTkey=parseFloat(Number(diffTkey)).toFixed(2);
				  }
				if (tempItem1 == "bz") {// 币种
					diffTkey = Fw.util.Format.formatCurrencyToStr(diffTkey);
				}
				if (tempItem1 == "gb") {// 国别
//					diffTkey = diffTkey == "CHN" ? '中国' : '';
					 if(diffTkey=="CHN" || diffTkey=="156"){
						 diffTkey='中国';
					  }
				}
				item1 += '<span style="padding-top: 10px;font-size: 12px;color: #8F9DAD;display:block">'+ Fw.util.Format.formatIdToName(tKey)+ '</span>'
						+ '<span id="'+ tempItem1+ '1'+ '" style="font-size: 14px;color: #FF7F00;min-height:20px;display:block;word-break: break-all;word-wrap: break-word;">'
						+ diffTkey + '</span>'
			}
		}

		htmldiff += '<div>'
				+ '<span style="font-size: 16px;font-weight:bold;color:#FF7F00;clear:both;">变更后</span>'
				+ item1 + '</div>';
		$("#listDiff").html(htmldiff);
		 
		YT.showPageArea(App.pageA, [], true);
		//预览高度一致
		 for (var tKey in diffC) {
			 var tempItem = Fw.util.Format.dataConversion(tKey);
			 var maxHeight=$("#"+tempItem+"1").height()>$("#"+tempItem).height()?$("#"+tempItem+"1").height():$("#"+tempItem).height();
			 $("#"+tempItem).css("height",maxHeight);
			 $("#"+tempItem+"1").css("height",maxHeight);
		 }
		
		Fw.Client.hideWaitPanel(); 
		
	},
	formatBusiType:function(str){
		switch(str){
			case '1':
				return '企业对公信息管理';
			case '2':
				return '账户限额信息管理';
			case '3':
				return '对账联系信息管理';
			case '4':
				return '签约客户信息管理';
			default:
				return '';
		}
	},
	/**
	 * 返回
	 */
	back:function(){
		if(App.data&&App.data.page){
			Fw.redirect(App.data.page,"");
		}else{
			Fw.redirect("1090105.html","");
		}
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
