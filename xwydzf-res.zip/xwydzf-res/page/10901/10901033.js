/**
 * 在线柜台 签约企业客户信息管理
 * @author zhenghy
 */

var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;
		
		App.flag=false;
		App.initEvent();
		App.operateData(App.data);
		App.showFj();
	},
	initEvent : function() {
		App.pageA.on("click","#submit",App.toSubmit);
		
		
	},
	/**
	 * 显示附件
	 */
	showFj:function(){
		if(App.data && App.data.attch){
			var attch=App.data.attch;
			var url=App.data.url;
			var attach=new Array();
			App.attach_url = '';
			for(var i in attch){
				attach.push({
					attachName:attch[i].name,
					attachUrl:url+attch[i].name
					})
			}
			Fw.util.attach.showAttach( attach );
			$("#fjCount").html(App.data.attch.length)//附件数量
		}
	},
	operateData:function(data){
		try{
//		alert(YT.JsonToStr(App.data.coreC));
		var dateData=["zzjgdmdqr","jgxydmdqr","zjdqr","jgzmwjqsrq","jgzmwjdqrq","gsdjhdqr","dsdjhdqr"]; 
		
		var htmlcore="";
		if(data.coreC){
			var core=data.coreC;
			var item="";
			 for (var tKey in core) {
				 var tempItem = Fw.util.Format.dataConversion(tKey);
				 if(tempItem!=""){
					 coreTkey=core[tKey];
					 if(dateData.indexOf(tempItem)!=-1){//日期格式化
						 coreTkey=Fw.util.Format.fmtYear(coreTkey);
					 }
					 if(tempItem=="zjzl" ){//证件种类 |
						 coreTkey=Fw.util.Format.formarDocumentsToStr(coreTkey); 
					  }
					  if(tempItem=="zmwj"){//证明文件类型
						  coreTkey=Fw.util.Format.formarEvidenceToStr(coreTkey); 
					  }
					  if(tempItem=="jgfzrlx"){//机构负责人类型
						  coreTkey=Fw.util.Format.formarInsPersion(coreTkey); 
					  }
					  if(tempItem=="sfbzzczj"){//是否标注注册资金
						  if(coreTkey=="0"){
							  coreTkey="否"
						  }else if(coreTkey=="1"){
							  coreTkey="是"
						  }else{
							  coreTkey=""
						  }
					  }
					  if(tempItem=="zczj"){
						  coreTkey=parseFloat(Number(coreTkey)).toFixed(2);
					  }
					  if(tempItem=="bz"){//币种
						  coreTkey=Fw.util.Format.formatCurrencyToStr(coreTkey); 
					  }
					  if(tempItem=="gb"){//国别
						  coreTkey=coreTkey=="CHN"?'中国':'';
					  }
					 item+='<span style="padding-top: 10px;font-size: 12px;color: #8F9DAD;display:block">'+Fw.util.Format.formatIdToName(tKey)+'</span>'+
					 '<span id="'+tempItem+'" style="color: #5D6574;font-size: 14px;min-height:20px;display:block">'+coreTkey+'</span>'
				 }
				
			 }
			
			 htmlcore+='<div style="">'+
					'<span style="font-size: 16px;font-weight:bold;color:#355169;">变更前</span>'+item+
		         '</div>';
		}
		$("#listCore").html(htmlcore);
		
		var htmldiff="";
		if(data.diffC){
			var diff=data.diffC;
			var item="";
			 for (var tKey in diff) {
				 var tempItem = Fw.util.Format.dataConversion(tKey);
				 if(tempItem!=""){
					 diffTkey=diff[tKey];
					 if(dateData.indexOf(tempItem)!=-1){//日期格式化
						 diffTkey=Fw.util.Format.fmtYear(diffTkey);
					 }
					 if(tempItem=="zjzl" ){//证件种类 |
						 diffTkey=Fw.util.Format.formarDocumentsToStr(diffTkey); 
					  }
					  if(tempItem=="zmwj"){//证明文件类型
						  diffTkey=Fw.util.Format.formarEvidenceToStr(diffTkey); 
					  }
					  if(tempItem=="jgfzrlx"){//机构负责人类型
						  diffTkey=Fw.util.Format.formarInsPersion(diffTkey); 
					  }
					  if(tempItem=="sfbzzczj"){//是否标注注册资金
						  if(diffTkey=="0"){
							  diffTkey="否"
						  }else if(diffTkey=="1"){
							  diffTkey="是"
						  }else{
							  diffTkey=""
						  }
					  }
					  if(tempItem=="zczj"){
						  diffTkey=parseFloat(Number(diffTkey)).toFixed(2);
					  }
					  if(tempItem=="bz"){//币种
						  diffTkey=Fw.util.Format.formatCurrencyToStr(diffTkey); 
					  }
					  if(tempItem=="gb"){//国别
						  diffTkey=diffTkey=="CHN"?'中国':'';
					  }
					 item+='<span style="padding-top: 10px;font-size: 12px;color: #8F9DAD;display:block">'+Fw.util.Format.formatIdToName(tKey)+'</span>'+
					 '<span id="'+tempItem+'1'+'" style="font-size: 14px;color: #FF7F00;min-height:20px;display:block;word-break: break-all;word-wrap: break-word;">'+diffTkey+'</span>'
				 }
			 }
			
			 htmldiff+='<div>'+
					'<span style="font-size: 16px;font-weight:bold;color:#FF7F00;">变更后</span>'+item+
		         '</div>';
		}
		$("#listDiff").html(htmldiff);
		
		YT.showPageArea(App.pageA, [], true);
		//预览高度一致
		 for (var tKey in data.diffC) {
			 var tempItem = Fw.util.Format.dataConversion(tKey);
			 var maxHeight=$("#"+tempItem+"1").height()>$("#"+tempItem).height()?$("#"+tempItem+"1").height():$("#"+tempItem).height();
			 $("#"+tempItem).css("height",maxHeight);
			 $("#"+tempItem+"1").css("height",maxHeight);
		 }
		
		Fw.Client.hideWaitPanel();
		}catch(e){alert(e)}
	},
	toSubmit : function() {
		if(App.flag==true){
			Fw.Form.showPinLabel($(this),"请勿重复提交！", true);
	    	return;
		}
		var pageDiff=App.data.diffC;
		var html="";
		var dateData=["zzjgdmdqr","jgxydmdqr","zjdqr","jgzmwjqsrq","jgzmwjdqrq","gsdjhdqr","dsdjhdqr"]; 
		for(var item in pageDiff){
			 var tempItem = Fw.util.Format.dataConversion(item);
			 var diffTkey=pageDiff[item]
			 if(tempItem!=''){
				 if(dateData.indexOf(tempItem)!=-1){//日期格式化
					 diffTkey=Fw.util.Format.fmtYear(diffTkey);
				 }
				 if(tempItem=="zjzl" ){//证件种类 |
					 diffTkey=Fw.util.Format.formarDocumentsToStr(diffTkey); 
				  }
				  if(tempItem=="zmwj"){//证明文件类型
					  diffTkey=Fw.util.Format.formarEvidenceToStr(diffTkey); 
				  }
				  if(tempItem=="jgfzrlx"){//机构负责人类型
					  diffTkey=Fw.util.Format.formarInsPersion(diffTkey); 
				  }
				  if(tempItem=="sfbzzczj"){//是否标注注册资金
					  diffTkey=diffTkey=="0"?"否":"是"; 
				  }
				  if(tempItem=="bz"){//币种
					  diffTkey=Fw.util.Format.formatCurrencyToStr(diffTkey); 
				  }
				  if(tempItem=="gb"){//国别
					  diffTkey=diffTkey=="CHN"?'中国':diffTkey;
				  }
				html+='<M><k>'+Fw.util.Format.formatIdToName(item)+':</k><v>'+diffTkey+'</v></M>';
			 }
		}
//		App.xml='<?xml version="1.0" encoding="utf-8"?><T><D>'+html+'</D></T>';
		Fw.Client.openWaitPanel();
		YT.ajaxData(YT.dataUrl("private/getCounterNo"), {}, function(data) {
			if (data.STATUS == "1") {
				App.counterNo=data.counterNo;
				var json = {
						type : "4",
						func : "App.initComplete",
						funcAndroid:"App.initCompleteAndroid",
						XML : '<?xml version="1.0" encoding="utf-8"?><T><D><M><k>请确认是否提交企业信息变更申请</k><v></v></M><M><k>业务流水号：</k><v>'+data.counterNo +'</v></M></D></T>'
				};
				Fw.Client.showBB(json);
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});
		
		
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b){
		App.initSubmit(a,b);
	},
	/**
	 * 支付棒确认提交
	 */
	initSubmit:function(a,b){
//		alert(YT.JsonToStr(a));
//		alert(YT.JsonToStr(b));
		App.flag=true;
	    Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/commitToCheck");
		var json = {
				signData:a,
				signSrc:b,
				core:App.data.core,
				diff:App.data.diff,
				counterNo:App.counterNo,
				busiType:"1"
		};
		YT.ajaxData(url, json, function(data) {
			if (data.STATUS == "1") {
				if(App.data.attch){
					var url1 = YT.dataUrl("private/oprtFile");
					var params = {
						trsNo : data.counterNo,
						FileUrl : App.data.url,
						FileNameList : App.data.attch,
						counterFlag:"true"
					};
					YT.ajaxData(url1, params, function(success) {
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo("已提交申请，待银行审核通过后即可受理成功","消息提示","App.successBack()");
//						Fw.Form.showPinLabel($(this),"已提交申请，待银行审核通过后即可受理成功", true);
//						setTimeout(Fw.redirect("1090100.html",""),1500)
					});
				}
			} else {
				App.flag=false;
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Client.hideWaitPanel();
			}
		});

	},
	successBack:function(){
		Fw.redirect("1090100.html","") 
	},
	/**
	 * 返回
	 */
	back:function(){
		Fw.redirect("10901031.html", App.data);
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
