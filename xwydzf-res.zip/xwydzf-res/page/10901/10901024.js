/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		YT.showPageArea(App.pageA, [], true);
		App.attchList = new Array();
		App.attch  = new Array();
		App.i = 0;
		App.clickId="";
		App.showId="";
		App.picLength="";
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#licenceClick", function(){App.toAddAttcchment('licenceClick','licenceShow')});
		App.pageA.on("click", "#idCardSideClick", function(){App.toAddAttcchment('idCardSideClick','idCardSideShow')});
		App.pageA.on("click", "#idCardReverseClick", function(){App.toAddAttcchment('idCardReverseClick','idCardReverseShow')});
		App.pageA.on("click", "#otherClick", function(){App.toAddAttcchment('otherClick','otherShow',5)});
	},
	toAddAttcchment:function(clickId,showId,picLength){
		App.clickId=clickId;
		App.showId=showId;
		App.picLength=picLength;
		Fw.Client.openAttcchment("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		Fw.util.attach.addAttach(name,url,App.clickId,App.showId,App.picLength);
	},
	
	isOK:function(){
		var licence=$("#licenceClick").siblings().length;
		var idCardSide=$("#idCardSideClick").siblings().length;
		var idCardReverse=$("#idCardReverseClick").siblings().length;
		if (licence>0 && idCardSide>0 && idCardReverse>0) {
			$("#submit").removeAttr("disabled");
		}else{
			$("#submit").attr("disabled","disabled");
		}
	},
	/**
	 * 
	 */
	back:function(){
		Fw.Client.gotoHomePage();
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);