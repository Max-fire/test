/**
 * 创建应用
 * 
 * @author tsf
 */

var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.data = Fw.getParameters();
		App.initEvent();
		App.list="";
		App.queryData();//请求数据
		
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		
	},
	/**
	 * 请求数据
	 */
	
	queryData:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryAcctList");
		var url2 = YT.dataUrl("private/queryCounterFirmStatus");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS=="1"){
				var acctList=new Array();
				if(data.acctNoList && data.acctNoList.length>0){
					for(var i in data.acctNoList){
						 acctList[i]=data.acctNoList[i].zhdh;
					}
					var json = {
							busiType :'2',
						    acctNoL:acctList,
					};
					YT.ajaxData(url2,json,function(datas){
						if(datas.STATUS=="1"){		
						   if(datas.counterInfoL){
							   for(var i in datas.counterInfoL){
								   for(var j in data.acctNoList){
									   if(data.acctNoList[j].zhdh==datas.counterInfoL[i].acctNo){
										   data.acctNoList[j].updTime=datas.counterInfoL[i].updTime;
										   data.acctNoList[j].checkStatus=datas.counterInfoL[i].checkStatus;
										   data.acctNoList[j].viewStatus=datas.counterInfoL[i].viewStatus;
										   data.acctNoList[j].counterNo=datas.counterInfoL[i].counterNo;
										   data.acctNoList[j].busiType=datas.counterInfoL[i].busiType;
									   }
								   }
							   }
						   }
						   App.loadData(data.acctNoList)
						
						}else{
							Fw.Client.hideWaitPanel();
							Fw.Form.showPinLabel($(this), data.MSG, true);
						}
					
					});
					
				}else{
					App.loadData(data);
				}
				
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		
		});
	},
	
	loadData:function(data){
		
		App.list=data;
		var list="";
		var html="";
		var jx="";
		if(data.length>0){
			for (var i in data) {
				  if(data[i].checkStatus){
					    list+= '<div class="pageItem" onClick="App.toDetail('+i+')">';
						list+=  '<div class="auditInfo">';   
						list+=	 ' <span class="auditTitle">审核状态</span>' ; 					
					    list+=	 '<span class="auditStatus'+data[i].checkStatus+'">'+App.getStatus(data[i].checkStatus)+'</span>';  												  
						list+=   '</div>';  
						list+=    '<div style=" padding: 12px 16px;">'; 
						list+=	  '<span class="cardAcct">'+data[i].zhdh+'</span>';   
						list+=	 '<span class="acctCurrency">'+Fw.util.Format.fmtbzmc(data[i].currency)+'</span>' ; 
						if(data[i].jlzt=="1"){
							list+=    '<span class="acctStatus" style="float:right;">'+App.getAcctStatus(data[i].jlzt)+'</span>';
						}else{
							list+=    '<span class="auditStatus" style="float:right;">'+App.getAcctStatus(data[i].jlzt)+'</span>';
						}
						list+=   ' </div>' ;
						list+=   ' <div class="lineBorder"></div>' ; 
						list+=   '<div class="timeCon">';  
						list+=   '<span>最近更新时间</span>' ;     
						list+=   '<span class="updateTime">'+Fw.util.Format.fmtTrsCreDate(data[i].updTime,'yyyy年MM月dd日  HH : mm')+'</span>';      
						list+=    '</div>';  
						list+=  '</div>';
					
				  }else{
					  if(data[i].jlzt=="1"){
						  jx+= '<div class="pageList" style="margin-top: 16px;" onClick="App.toDetail('+i+')">';
						  jx+=   '<span class="cardAcct">'+data[i].zhdh+'</span>' ;
						  jx+=	 '<span class="acctCurrency">'+Fw.util.Format.fmtbzmc(data[i].currency)+'</span>';
						  jx+=    '<span class="acctStatus">'+App.getAcctStatus(data[i].jlzt)+'</span>';
						  jx+=  '</div>';

					  }else if(data[i].jlzt!="H"){
						  jx+= '<div class="pageList" style="margin-top: 16px;" onClick="App.toDetail('+i+')">';
						  jx+=   '<span class="cardAcct">'+data[i].zhdh+'</span>' ;
						  jx+=	 '<span class="acctCurrency">'+Fw.util.Format.fmtbzmc(data[i].currency)+'</span>';
						  jx+=    '<span class="auditStatus">'+App.getAcctStatus(data[i].jlzt)+'</span>';
						  jx+=  '</div>';
					  }
				  }
				  			  
				  if(data[i].jlzt=="H"){
					  html+= '<div>';
					  html+=   '<span class="cardAcct">'+data[i].zhdh+'</span>' ;
					  html+=	 '<span class="acctCurrency">'+Fw.util.Format.fmtbzmc(data[i].currency)+'</span>';
					  html+=    '<span class="auditStatus4">久悬</span>'; 
					  html+= '</div>';			
				  }
			}
			$("#pageItem").html(list+jx);
			if (html) {
				 $("#JXZH").removeClass("hidden");
				 $("#pageList").removeClass("hidden");	
				 $("#pageList").html(html);
			}
			
		YT.showPageArea(App.pageA, [App.pageB], true);
		}else{
			YT.showPageArea(App.pageB, [App.pageA], true);
		}
		Fw.Client.hideWaitPanel();		
	},
	
	toDetail:function(i){
		Fw.redirect("10901021.html",App.list[i]);
	},
	getStatus:function(checkStatus){
		switch (checkStatus) {
		case '1':
			var checkStatus = "待审核";
			return checkStatus;
		case '2':
			var checkStatus = "通过"
			return checkStatus;
		case '3':
			var checkStatus = "拒绝"
				return checkStatus;
		default:
			break;
		}
	},
	getAcctStatus:function(status){
		switch (status) {
		case '1':
			var status = "有效";
			return status;
		case '2':
			var status = "销户"
			return status;
		case '3':
			var status = "挂失"
				return status;
		case '4':
			var status = "冻结";
			return status;
		case 'H':
			var status = "久悬";
			return status;
		case 'I':
			var status = "开户暂封"
				return status;
		default:
			break;
		}
	},

	/**
	 * 返回工作主页
	 */
	back:function(){
		Fw.Client.hideWaitPanel();
		Fw.redirect("1090100.html","");
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);