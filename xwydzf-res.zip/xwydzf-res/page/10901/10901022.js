/**
 * 创建应用
 * 
 * @author tsf
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.data = Fw.getParameters();	
		
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;

		App.clickId="";
		App.showId="";
		App.picLength="";
		
//		Fw.Client.hideWaitPanel();
//		YT.showPageArea(App.pageA, [App.pageB], true);
		App.initEvent();
		App.loadData();

	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#rljxe", App.showMoneyPicker1);
		App.pageA.on("click", "#rljbs", App.showNumberPicker);
		App.pageA.on("click", "#nljxe", App.showMoneyPicker);
		
		App.pageA.on("input", "#sqly", App.applyMsg);
		// 添加附件-事件
		App.pageA.on("click","#TJFJ",App.initTJFJ);
		App.pageA.on("click", "#submit", App.toSubmit);	
		
		App.pageB.on("click", "#licenceClick", function(){App.toAddAttcchment('licenceClick','licenceShow')});
		App.pageB.on("click", "#idCardSideClick", function(){App.toAddAttcchment('idCardSideClick','idCardSideShow')});
		App.pageB.on("click", "#idCardReverseClick", function(){App.toAddAttcchment('idCardReverseClick','idCardReverseShow')});
		App.pageB.on("click", "#otherClick", function(){App.toAddAttcchment('otherClick','otherShow',5)});
		
		App.pageB.on("click","#submit1",App.toSubmit1);
		
		
		
		
	},
	
	loadData:function(){
		
		if(App.data && App.data.attch){
			var attch = App.data.attch;
			var url = App.data.url;
			for ( var k = 0; k < attch.length; k++) {
				App.clickId=attch[k].clickId;
				App.showId=attch[k].showId;
				App.picLength=attch[k].length;
				App.showAttcchment(attch[k].name, url);
			}
		}
		
		var core={};
		if(App.data && App.data.diff){
			 core=App.data.diff;//预览界面返回
		}else{
			 core=App.data.list;
		}
        $("#rljxe").val(core.dayAmtLmt);
		$("#rljbs").val(core.dayCntLmt);
		$("#nljxe").val(core.yearAmtLmt);	
		if(App.data&&App.data.applyMsg){
			$("#sqly").val(App.data.applyMsg)
			$("#count").html(App.data.applyMsg.length);
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [App.pageB], true);
	},
	/**
	 * 添加附件
	 */
	initTJFJ : function(){
		YT.showPageArea(App.pageB, [App.pageA], true)
	},
	toAddAttcchment:function(clickId,showId,picLength){
		App.clickId=clickId;
		App.showId=showId;
		App.picLength=picLength;
		Fw.Client.chooseAccessory("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		attach.addAttach(name,url,App.clickId,App.showId,App.picLength);
	},
	isOK:function(){
		var licence=$("#licenceClick").siblings().length;
		var idCardSide=$("#idCardSideClick").siblings().length;
		var idCardReverse=$("#idCardReverseClick").siblings().length;
		if (licence>0 && idCardSide>0 && idCardReverse>0) {
			$("#imgTip").addClass("hidden");
			$("#mgt").css("margin-top","20px");
			$("#submit1").removeAttr("disabled");
		}else{
			$("#imgTip").removeClass("hidden");
			$("#mgt").css("margin-top","4px");
			$("#submit1").attr("disabled","disabled");
		}
	},
	applyMsg:function(){
		var msg=$("#sqly").val();
		$("#count").html(msg.length);
	},
	/**
	 * 图片界面返回
	 */
	gotoback:function(){
		YT.showPageArea(App.pageA, [App.pageB], true)
	},
	toSubmit1:function(){
		YT.showPageArea(App.pageA, [App.pageB], true)
	},
	/**
	 * 调用金额键盘
	 */
	showMoneyPicker:function(){
		$("#nljxe").val("");
		Fw.Client.showMoneyPicker($("#nljxe"),true);
	},
	/**
	 * 调用数字键盘
	 */
	showNumberPicker:function(){
		$("#rljbs").val("");
		Fw.Client.showNumberPicker($("#rljbs"));
	},
	/**
	 * 调用金额键盘
	 */
	showMoneyPicker1:function(){
		$("#rljxe").val("");
		Fw.Client.showMoneyPicker($("#rljxe"),true);
	},
	toSubmit:function(){
		try{
	    if($("#rljxe").val()!='' && $("#rljxe").val().length<5){
	    	Fw.Form.showPinLabel($(this),"日累计限额最少输入2位数！", true);
	    	return;
	    }
	    if($("#nljxe").val()!='' &&　$("#nljxe").val().length<5){
	    	Fw.Form.showPinLabel($(this),"年累计限额最少输入2位数！", true);
	    	return;
	    }
	    if($("#sqly").val().trim()==''){
	    	Fw.Form.showPinLabel($(this),"请输入申请理由！", true);
	    	return;
	    }
		if(App.attch.length==0){
			Fw.Form.showPinLabel($(this),"请上传附件！", true);
			return;
		}
		var attach=App.attch;
		var yyzz=frzm=frfm='';
		for(var i=0;i<attach.length;i++){
			if(attach[i].clickId=='licenceClick'){yyzz=attach[i].clickId}
			if(attach[i].clickId=='idCardSideClick'){frzm=attach[i].clickId}
			if(attach[i].clickId=='idCardReverseClick'){frfm=attach[i].clickId}
		}
		if(yyzz=='' || frzm=='' || frfm=='' ){
			Fw.Form.showPinLabel($(this),"上传证件类型不完整！", true);
			return;
		}
		
		var diff={
				"acctNo":App.data.list.acctNo,
				"oneLmt":App.data.list.oneLmt,
				"gzsLmt":App.data.list.gzsLmt,
				"lmtPay":App.data.list.lmtPay,				
			    "dayAmtLmt":$("#rljxe").val().replace(/,/g,''),
		        "dayCntLmt":$("#rljbs").val().replace(/,/g,''),
		        "yearAmtLmt":$("#nljxe").val().replace(/,/g,''),
		        "applyMsg":$("#sqly").val()
		};
		var core=App.data.list;
		var coreC={};
		var diffC={};
		
		if(core.dayAmtLmt!=diff.dayAmtLmt){
			coreC.dayAmtLmt=core.dayAmtLmt
			diffC.dayAmtLmt=diff.dayAmtLmt
		}
		if(core.dayCntLmt!=diff.dayCntLmt){
			coreC.dayCntLmt=core.dayCntLmt
			diffC.dayCntLmt=diff.dayCntLmt
		}
		if(core.yearAmtLmt!=diff.yearAmtLmt){
			coreC.yearAmtLmt=core.yearAmtLmt
			diffC.yearAmtLmt=diff.yearAmtLmt
		}
		
		if( YT.JsonToStr(diffC)=="{}"){
			Fw.Form.showPinLabel($(this),"当前未修改数据，请修改后再提交！", true);
			return;
		}
//		alert(YT.JsonToStr(diff))
		var json={
				core:core,
				diff:diff,
				coreC:coreC,
				diffC:diffC,
				applyMsg:diff.applyMsg,
				list:App.data.list,
				zhdh:App.data.zhdh,
				url:App.url,
				attch:App.attch
		}
		
		Fw.redirect("10901023.html",json);
		}catch(e){alert(e)}
	},

	/**
	 * 返回
	 */
	back : function() {
		Fw.redirect("10901021.html", App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);