/**
 * 在线柜台 变更记录
 * @author zhenghy
 */

var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.value='';
		App.next=0;
		App.initEvent();
		App.queryData();
		
//		Fw.Client.hideWaitPanel();
//		YT.showPageArea(App.pageA, [], true);
	},
	initEvent : function() {
		App.pageA.on('click',"#all",App.showAll)
		
		App.pageA.on("click",".sel_item",App.chooseItem);		
		App.pageA.on("click",".list_item",App.gotoDetail);//详情
		
		App.pageA.on("click", "#more", App.queryData);
		
	},
	showAll:function(){
		$("#black_b").removeClass("hidden");
		$("#sel_show").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	hideAll:function(){
		$("#black_b").addClass("hidden");
		$("#sel_show").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	chooseItem:function(){
		var item=$(this)[0].innerText;
		$("#selVal").html(item);
		
		if(App.value!=$(this).data("value")){
			App.value=$(this).data("value");
			App.next='0';
			App.queryData();
		}
		
		$(this).addClass("blueColor");
		$(this).siblings().removeClass("blueColor");
		
		$("#black_b").addClass("hidden");
		$("#sel_show").addClass("hidden");
		App.pageA.unbind("touchmove");
		
	},
	/**
	 * 查询列表
	 */
	queryData:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/counterModifyRecord");
		var params={
				busiType :App.value+"",
				NEXT_KEY:App.next+"",
        		PAGE_SIZE:"10"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				if(data.list&&data.list.length>0){
					App.loadData(data)
				}else{
					App.loadData([]);
				}
			
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		})
		
	},
	/**
	 * 处理数据
	 */
	loadData:function(data){
		try{
		if(data.list){
			App.list=data.list;
			var list=data.list
			var html='';
			for(var i=0;i<list.length;i++){
				var fields=list[i].fields;
				var fieldsHtml='';
				var color='';
				var borderColor='';
				if(list[i].checkStatus=='1'){
					color="color:#2574D2;";
				}else if(list[i].checkStatus=='2'){
					color="color:#00A74C;";
				}else{
					color="color:#FF3B30;";
				}
				if(list[i].checkStatus=='1'){
					borderColor="border-right:4px solid #2574D2";
				}else if(list[i].checkStatus=='2'){
					borderColor="border-right:4px solid #00A74C";
				}else{
					borderColor="border-right:4px solid #FF3B30";
				}
				if(fields.length==1){
					fieldsHtml+='<span>'+Fw.util.Format.formatIdToName(fields[0])+'</span>';
				}else if(fields.length==2){
					fieldsHtml+='<span>'+Fw.util.Format.formatIdToName(fields[0])+'</span>'+'、'+'<span>'+Fw.util.Format.formatIdToName(fields[1])+'</span>';
				}else{
					fieldsHtml+='<span>'+Fw.util.Format.formatIdToName(fields[0])+'</span>'+'、'+'<span>'+Fw.util.Format.formatIdToName(fields[1])+'</span>'+'等';
				}
				
				html+='<div class="cgrecord_item" onClick="App.gotoDetail('+i+')">'+
						'<div style="padding:13px 0;padding-left:16px;font-size: 12px; color:#8F9DAD;">'+
							'<span style="display:inline-block;width:70px;float:left">业务类型：</span>'+
							'<span style="color:#365169;font-weight:bold;">'+App.formatBusiType(list[i].busiType)+'</span>'+
							'<span style="float:right;padding-right:16px;'+color+''+borderColor+'">'+App.formatStatus(list[i].checkStatus)+'</span>'+
						'</div>'+
						'<div style="padding: 10px 16px; color:#365169; font-weight:bold;min-height:22px;">'+
							'<span style="display:inline-block;width:70px;float:left">变更项目：</span><span style="width:70%;display:inline-block;">'+fieldsHtml+
						'</span></div>'+
						'<div style="height:1px;background:#F2F4F8;clear:both"></div>'+
						'<div style="padding: 0 15px;font-size:12px; color:#5D6574;">'+
							'<div style="padding-top:12px;"><span style="">申请人</span><span style="float: right;">'+list[i].applyMan+'</span></div>'+
							'<div  style="padding:12px 0; "><span style="">申请日期</span><span style="float: right;">'+Fw.util.Format.fmtTrsCreDate(list[i].applyTime)+'</span></div>'+
						'</div>'+
					'</div>'
			}
			if(App.next=='0'){
				$("#list").html(html);
			}else{
				$("#list").append(html);
			}
			$("#noData").addClass("hidden");
		}else{
			$("#more").hide()
			$("#end").hide();
			$("#list").html("");
			$("#noData").removeClass("hidden");
		}
		
		if(data.NEXT_PAGE){
			$("#more").show();
			$("#end").hide();
			App.next=data.NEXT_KEY/1+10;
		}else{
			if (App.next>0) {
				$("#more").hide();
				$("#end").show();
			}else{
				$("#more").hide();
				$("#end").hide();
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
		}catch(e){alert(e)}
	},
	formatBusiType:function(str){
		switch(str){
			case '1':
				return '企业对公信息管理';
			case '2':
				return '账户限额信息管理';
			case '3':
				return '对账联系信息管理';
			case '4':
				return '签约客户信息管理';
			default:
				return '';
		}
	},
	formatStatus:function(str){
		switch(str){
			case '1':
				return '待审核';
			case '2':
				return '通过';
			case '3':
				return '拒绝';
			default:
				return '';
		}
	},
	gotoDetail:function(i){
		var json={
				page:'1090105.html',
				list:App.list[i]
			}
		Fw.redirect("10901051.html",json);
	},
	/**
	 * 返回
	 */
	back:function(){
		Fw.redirect("1090100.html", "");
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
