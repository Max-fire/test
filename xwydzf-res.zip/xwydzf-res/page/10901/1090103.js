/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.updTime='';
		App.FirmStatus='';
//		Fw.Client.hideWaitPanel();
//		YT.showPageArea(App.pageA, [], true);
		App.queryHX();//核心数据
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		App.pageA.on("click", ".xxgl_list_head", App.toggleHead);
		App.pageA.on("click",".search_span",App.gotoDetail);//查看详情
		
//		$("#qyzjxx").slideDown(0);
//		$("#iconSpan1").parent().addClass("blueColor");
//		$("#iconSpan1").addClass("sel_iconUp");
		//默认展开首项
		
//		$("#pageA").attr("data-btnRight","true|信息变更|App.gotoXXBG()");
		
	},
	/**
	 *获取核心客户信息 
	 */
	queryHX:function(){
		try{
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryCounterFirmStatus");
		var json = {
				busiType :'1'
		};
		YT.ajaxData(url,json,function(data1){
			var params={};
			if(data1.counterInfo){
				App.counterInfo=data1.counterInfo;
				//审核状态
				if(data1.counterInfo.checkStatus=="1"){//审核中
//					if(data1.counterInfo.viewStatus=='0'){
						$("#zxgt_toptipSH").removeClass("hidden");
						$("#zjxx").css("margin-top","0");
//					}
					params.counterNo=data1.counterInfo.counterNo;
					//信息变更按钮置灰无法点击
					$("#pageA").attr("data-btnRight","false");
					
				}else if(data1.counterInfo.checkStatus=="2"){//已完成
					if(data1.counterInfo.viewStatus=='0'){
						$("#zxgt_toptipTG").removeClass("hidden");
						$("#zjxx").css("margin-top","0");
					}
					 $("#pageA").attr("data-btnRight","true|信息变更|App.gotoXXBG()");
				}else if(data1.counterInfo.checkStatus=="3"){//被拒绝
					if(data1.counterInfo.viewStatus=='0'){
						$("#zxgt_toptipJJ").removeClass("hidden");
						$("#zjxx").css("margin-top","0");
					}
					 $("#pageA").attr("data-btnRight","true|信息变更|App.gotoXXBG()");
				}
				if(data1.counterInfo.updTime){//最近更新时间
					App.updTime=Fw.util.Format.fmtTrsCreDate(data1.counterInfo.updTime);
					$("#zxgt_btmTime").removeClass("hidden");
					$("#last_upTime").html(App.updTime);
				}
				
				App.FirmStatus=data1.counterInfo.checkStatus;
				params.status=data1.counterInfo.checkStatus;
			}else{
				$("#pageA").attr("data-btnRight","true|信息变更|App.gotoXXBG()");
			}
			 
			YT.ajaxData(YT.dataUrl("private/queryCounterFirmInfo"),params,function(data){
				if(data.STATUS == "1"){
					App.operateHXData(data);
		    	}else{
		    		Fw.Form.showPinLabel($(this),data.MSG, true);
		    		Fw.Client.hideWaitPanel();
		    		$("#pageA").attr("data-btnright","false");
		    		YT.showPageArea(App.pageA, [], true);
		    		return;
		    	}
			});
		});
		}catch(e){alert(e)}
	},
	/**
	 * 处理核心数据和变更差异
	 */
	operateHXData:function(data){
		try{
	  App.data=data;
	  var dateData=["zzjgdmdqr","jgxydmdqr","zjdqr","jgzmwjqsrq","jgzmwjdqrq","gsdjhdqr","dsdjhdqr"]; 
	  var core=data.core;
	  for (var tKey in core) {
		  var tempItem = Fw.util.Format.dataConversion(tKey);
		  if(tempItem!=""){
			  var item = core[tKey]
			  if(dateData.indexOf(tempItem)!=-1){//日期格式化
				  item=Fw.util.Format.fmtYear(core[tKey]); 
			  }
			  if(tempItem=="zjzl" || tempItem=="zjlx"){//证件种类 | 证件类型
				  item=Fw.util.Format.formarDocumentsToStr(core[tKey]);
			  }
			  if(tempItem=="zmwj"){//证明文件类型
				  item=Fw.util.Format.formarEvidenceToStr(core[tKey]); 
			  }
			  if(tempItem=="jgfzrlx"){//机构负责人类型
				  item=Fw.util.Format.formarInsPersion(core[tKey]); 
			  }
			  if(tempItem=="sfbzzczj"){//是否标注注册资金
				  item=core[tKey]=="0"?"否":"是";
			  }
			  if(tempItem=="bz"){//币种
				  item=Fw.util.Format.formatCurrencyToStr(core[tKey]); 
			  }
			  if(tempItem=="gb"){//国别
				  item=core[tKey]=="156"?'中国':'';
			  }
			  $("#"+tempItem+"").html(item);
		  }
 	  }
	  if(data.diff){//差异
//		  alert("chayi ");
		  var diff=data.diff;
		  if(diff.firmName ||　diff.inchargeMan||　diff.inchargeManType||　diff.inchargeManCertType||　diff.inchargeManCertNo){
			  $("#zxgt_header").removeClass("hidden");
			  //信息变更按钮置灰无法点击
			  $("#pageA").attr("data-btnRight","false");
			  $("#zjxx").css("margin-top",'0')
		  }
		  
		  if(App.FirmStatus=='1'){
			  for (var tKey in diff) {
				  var tempItem = Fw.util.Format.dataConversion(tKey);
				  if(tempItem!=""){
						  var item=diff[tKey];
						  if(dateData.indexOf(tempItem)!=-1){//日期格式化
							 item=Fw.util.Format.fmtYear(diff[tKey]); 
						  }
						  if(tempItem=="zjzl" || tempItem=="zjlx"){//证件种类 | 证件类型
							  item=Fw.util.Format.formarDocumentsToStr(diff[tKey]); 
						  }
						  if(tempItem=="zmwj"){//证明文件类型
							  item=Fw.util.Format.formarEvidenceToStr(diff[tKey]); 
						  }
						  if(tempItem=="jgfzrlx"){//机构负责人类型
							  item=Fw.util.Format.formarInsPersion(diff[tKey]); 
						  }
						  if(tempItem=="sfbzzczj"){//是否标注注册资金
							  if(diff[tKey]=="0"){
								  item="否";
							  }else if(core[tKey]=="1"){
								  item="是";
							  }else{
								  item="";
							  }
						  }
						  if(tempItem=="bz"){//币种
							  item=Fw.util.Format.formatCurrencyToStr(diff[tKey]); 
						  }
						  if(tempItem=="gb"){//国别
							  if(diff[tKey]=="CHN" || diff[tKey]=="156"){
								  item='中国';
							  }else{
								  item=diff[tKey];
							  }
						  }
					  var html='<div style="background-color: #fff;padding:0 20px;color: #FF7F00;clear:both;display: flex;">'+
						  			'<label style="line-height: 22px;">申请变更为</label>'+
									'<span style="flex: 1;text-align: right;padding-left:10px">'+item+'</span>'+
								'</div>';
					  if (item&&item.length>100) {
						  html='<div style="background-color: #fff;padding:0 20px;color: #FF7F00;clear:both;display: flex;flex-direction: column;">'+
				  			'<label style="line-height: 22px;">申请变更为</label>'+
							'<div style="flex: 1;text-align: left;word-break: break-all;word-wrap: break-word;">'+item+'</div>'+
							'</div>';
					  }
					  $("#"+tempItem+"").parent().after(html);
					 
			  }
		   }
	 }
		  
	 if(App.FirmStatus=='2' || App.FirmStatus=='3'|| App.FirmStatus==''){
		  for (var tKey in diff) {
			  var tempItem = Fw.util.Format.dataConversion(tKey);
			  if(tempItem!=""){
					  var item=diff[tKey];
					  if(dateData.indexOf(tempItem)!=-1){//日期格式化
						 item=Fw.util.Format.fmtYear(diff[tKey]); 
					  }
					  if(tempItem=="zjzl" || tempItem=="zjlx"){//证件种类 | 证件类型
						  item=Fw.util.Format.formarDocumentsToStr(diff[tKey]); 
					  }
					  if(tempItem=="zmwj"){//证明文件类型
						  item=Fw.util.Format.formarEvidenceToStr(diff[tKey]); 
					  }
					  if(tempItem=="jgfzrlx"){//机构负责人类型
						  item=Fw.util.Format.formarInsPersion(diff[tKey]); 
					  }
					  if(tempItem=="sfbzzczj"){//是否标注注册资金
						  if(diff[tKey]=="0"){
							  item="否";
						  }else if(diff[tKey]=="1"){
							  item="是";
						  }else{
							  item="";
						  }
					  }
					  if(tempItem=="zczj"){//注册资金
							 item=diff[tKey]*10000;
						}
					  if(tempItem=="bz"){//币种
						  item=Fw.util.Format.formatCurrencyToStr(diff[tKey]); 
					  }
					  if(tempItem=="gb"){//国别
						  if(diff[tKey]=="CHN" || diff[tKey]=="156"){
							  item='中国';
						  }else{
							  item=diff[tKey];
						  }
					  }
					  var html='<div style="background-color: #fff;padding:0 20px;color: #FF7F00">'+
						  			'<label style="margin-top:-10px;width: 52%;display: inline-block;float: left;word-break: break-all;word-wrap: break-word;clear: both;">工商最新信息</label>'+
									'<span style="margin-top:-10px;width: 48%;display: inline-block;word-break: break-all;word-wrap: break-word;text-align: right;">'+item+'</span>'+
								'</div>';
					  $("#"+tempItem+"").parent().after(html);
				
		  }
	   }
	  }
	  }
	  
	  YT.showPageArea(App.pageA, [], true);
	  Fw.Client.hideWaitPanel();
		}catch(e){
			alert(e)
		}
	},
	/**
	 * 页面切换动画
	 */
	toggleHead:function(){
		
		var name=$(this).data("name");
		var span=$(this).data("span");
		var arr=["qyzjxx","jgfzrxx","qyzmwj","swxx","lxxx"];
		var arr1=["iconSpan1","iconSpan2","iconSpan3","iconSpan4","iconSpan5"]
		var _this=$(this);
		_this.addClass("blueColor");//立即改变消除300ms延时
		$("#"+span+"").removeClass("sel_iconDown").addClass("sel_iconUp");
		
		for(var i=0;i<arr.length;i++){//控制显示
			if(name==arr[i]){
				$("#"+name+"").slideToggle(200);
				setTimeout(function(){
					var disp=$("#"+name+"").css("display");
					if(disp=="block"){
						_this.addClass("blueColor");
						$("#"+span+"").removeClass("sel_iconDown").addClass("sel_iconUp");
//						if(name=="lxxx"){
//							$($(".list_head")[4]).removeClass("bd_none").addClass("bd");//添加最后一项border
//						}
					}else{
						_this.removeClass("blueColor");
						$("#"+span+"").removeClass("sel_iconUp").addClass("sel_iconDown");
//						if(name=="lxxx"){
//							$($(".list_head")[4]).addClass("bd_none").removeClass("bd");//移除最后一项border
//						}
					}
				},300)
			}else{
				$("#"+arr[i]+"").slideUp(200);
				$($(".xxgl_list_head")[i]).removeClass("blueColor");
				$("#"+arr1[i]+"").removeClass("sel_iconUp").addClass("sel_iconDown");
//				$($(".list_head")[4]).addClass("bd_none").removeClass("bd");//移除最后一项border
			}
		}
		
	},
	/**
	 * 信息变更
	 */
	gotoXXBG:function(){
		var json={
				list:App.data,
				updTime:App.updTime,
				FirmStatus:App.FirmStatus
		}
		Fw.redirect("10901031.html",json);
	},
	/**
	 * 查看详情
	 */
	gotoDetail:function(){
		var json={
				page:'1090103.html',
				list:{
					counterNo:App.counterInfo.counterNo,
					busiType:App.counterInfo.busiType
				}
		};
		Fw.redirect("10901051.html",json);
		
	},
	back:function(){
		Fw.redirect("1090100.html","");
	}
    
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);