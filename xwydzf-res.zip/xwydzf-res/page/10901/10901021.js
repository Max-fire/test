/**
 * 创建应用
 * 
 * @author tsf
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		Fw.Client.hideWaitPanel();
		App.data = Fw.getParameters();
		
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		Fw.Client.openWaitPanel();
		var url= YT.dataUrl("private/counterAcctDetail");
		var params={
				acctNo:App.data.zhdh,
				acctType:"4"
		};
		YT.ajaxData(url,params,function(data){
			//App.loadData(data)
			if(data.STATUS=="1"){
				App.loadData(data);
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
			Fw.Client.hideWaitPanel();
		},function(data){
			Fw.Form.showPinLabel($(this), data.MSG, true);
			Fw.Client.hideWaitPanel();}
		);
		
		if (App.data) {
			if (App.data.updTime) {
				$(".lastUpdateTime").removeClass("hidden")
				$("#time").html(Fw.util.Format.fmtTrsCreDate(App.data.updTime,'yyyy年MM月dd日  HH : mm'))			
			}
			if (App.data.checkStatus) {
				if (App.data.checkStatus=="1") {
					$("#check").removeClass("hidden")
					App.pageA.on("click",".limitDetail",App.gotoDetail);//查看详情
					$("#pageA").attr("data-btnRight","false");
					$("#limitInfo").css("margin-top","-16px");
				}
				if (App.data.checkStatus=="2") {
					if(App.data.viewStatus=="0"){
						$("#success").removeClass("hidden");
						$("#limitInfo").css("margin-top","-16px");
					}
				}
				if (App.data.checkStatus=="3") {
					if(App.data.viewStatus=="0"){
						$("#refuse").removeClass("hidden")
						App.pageA.on("click",".limitDetail",App.gotoDetail);//查看详情
						$("#limitInfo").css("margin-top","-16px");
					}
				}
			}
			
		}
		
	},
	loadData:function(data){
		YT.showPageArea(App.pageA, [], true);
		App.list=data.data;
		var list="";
		var item=data.data;
		list+= '<div class="limitInfo" >'; 
		list+='<div><i>账号</i><span>'+(item.acctNo?item.acctNo:"--")+'</span></div>';
		list+= '<div><i>单笔限额</i><span>'+(item.oneLmt?item.oneLmt:"--")+'</span></div>'; 
		list+='<div><i>公转私单笔限额</i><span>'+(item.gzsLmt?item.gzsLmt:"--")+'</span></div>';   
		list+=' <div><i>强制落地审核</i><span>'+(item.lmtPay?"是":"否")+'</span></div>' ;
		list+= '</div>';
		list+= '<div class="limitInfo" style="margin-top:16px;">';   
		list+= ' <div id="dayAmtLmt"><i>日累计限额</i><span>'+(item.dayAmtLmt?item.dayAmtLmt:"--")+'</span></div>';
		list+= ' <div id="dayCntLmt"><i>日累计笔数</i><span>'+(item.dayCntLmt?item.dayCntLmt:"--")+'</span></div>';
		list+=' <div id="yearAmtLmt"><i>年累计限额</i><span>'+(item.yearAmtLmt?item.yearAmtLmt:"--")+'</span></div>';   	     		       	     
		list+= '</div>';
		$("#limitInfo").html(list)
		for(var i in data.initLmt){
           if(!data.modifyLmt[i]){
              data.modifyLmt[i]="";
		   }
		}
		for(var j in data.modifyLmt){
           if(!data.initLmt[j]){
              data.initLmt[j]="";
		   }
		}
		if(App.data.checkStatus=="1" && data.modifyLmt){
			var initLmt=data.initLmt;//以前
			var modifyLmt=data.modifyLmt;//变更后
			for(var key in modifyLmt){
				if(modifyLmt[key]!=initLmt[key]){
					  var html='<div style="background-color: #fff;padding:0;color: #FF7F00">'+
			  			'<label style="margin-top: -10px;width: 52%;display: inline-block;float: left;word-break: break-all;word-wrap: break-word;clear: both;">申请变更为</label>'+
						'<span style="margin-top: -10px;width: 48%;color: #FF7F00;display: inline-block;word-break: break-all;word-wrap: break-word;text-align: right;">'+(key=="dayAmtLmt"||key=="yearAmtLmt"?(parseFloat(Number(modifyLmt[key])).toFixed(2)):modifyLmt[key]==""?"--":modifyLmt[key])+'</span>'+
					'</div>';
					  $("#"+key).after(html);
					  $("#pageA").attr("data-btnRight","false");
				}
			}
		}
	},
	/**
	 * 变更页面
	 */
	gotoXXBG:function(){
		var json={
				zhdh:App.data.zhdh,
				list:App.list
		}
		Fw.redirect("10901022.html",json);
	},
	
	gotoDetail:function(){
		var json={
				page:'10901021.html',
				list:{}
		}
		for(var i in App.data){
			json.list[i]=App.data[i];
			json[i]=App.data[i];
		}
		Fw.redirect("10901051.html",json);
		
	},

	/**
	 * 返回
	 */
	back:function(){
		Fw.redirect("1090102.html");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);