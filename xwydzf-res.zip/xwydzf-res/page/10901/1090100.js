/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		Fw.Client.hideWaitPanel();
		App.initEvent();
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#signCus", App.toQYKH);//签约客户
		App.pageA.on("click", "#accLimit", App.toZHXE);//账户限额
		App.pageA.on("click", "#enterPrise", App.toQTXX);//企业信息
		App.pageA.on("click", "#accLink", App.toDZLX);//对账联系
		
		$("#pageA").attr("data-btnRight","true|变更记录|App.toChangeList()");
	},

    /**
     * 签约客户
     */
	toQYKH:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1090101.html","");
	},
	/**
	 * 账户限额
	 */
	toZHXE:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1090102.html","");
	},
	/**
	 * 企业信息
	 */
	toQTXX:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1090103.html","");
	},
	/**
	 * 对账联系
	 */
	toDZLX:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1090104.html","");
	},
	/**
	 * 变更记录
	 */
	toChangeList:function(){
		Fw.Client.openWaitPanel();
		Fw.redirect("1090105.html","");
	},
	back:function(){
		Fw.Client.gotoHomePage();
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);