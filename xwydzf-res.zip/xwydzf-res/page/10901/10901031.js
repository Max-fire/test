/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.data = Fw.getParameters();
		
		App.attchList = new Array();
		App.attch = new Array();
		App.i=0;
//		App.url='';
		App.clickId="";
		App.showId="";
		App.picLength="";
		YT.showPageArea(App.pageA, [App.pageB], true);
		App.initEvent();
//		Fw.Client.hideWaitPanel();
		App.list=App.data.list;
		App.operateHXData(App.data.list);//核心数据
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		
		//初始化时间插件
		App.pageA.on("click","#qr",App.toQR);
		App.pageA.on("click","#black",App.toQX);
		
		App.pageA.on("input",".textInput",App.checkLength);// 控制输入字节数
		App.pageA.on("porpertychanger",".textInput",App.checkLength);
		
		App.pageA.on("blur","#zczj",App.zczjBlur);
		
		App.pageA.on("click", ".xxgl_list_head", App.toogleHead);
		App.pageA.on("click","#submit",App.toSubmit);//提交审核
		
//		App.pageA.on("click",".dateInput",App.showNumberPicker);//日期键盘
		// 添加附件-事件
		App.pageA.on("click","#TJFJ",App.initTJFJ);
		
		App.pageB.on("click", "#licenceClick", function(){App.toAddAttcchment('licenceClick','licenceShow')});
		App.pageB.on("click", "#idCardSideClick", function(){App.toAddAttcchment('idCardSideClick','idCardSideShow')});
		App.pageB.on("click", "#idCardReverseClick", function(){App.toAddAttcchment('idCardReverseClick','idCardReverseShow')});
		App.pageB.on("click", "#baseClick", function(){App.toAddAttcchment('baseClick','baseShow')});
		App.pageB.on("click", "#orgClick", function(){App.toAddAttcchment('orgClick','orgShow')});
		App.pageB.on("click", "#otherClick", function(){App.toAddAttcchment('otherClick','otherShow',5)});
		
		App.pageB.on("click","#submit1",App.toSubmit1);
		
		if(App.data && App.data.attch){
//			App.attch=App.data.attch;
//			App.url=App.data.url;
			var attch = App.data.attch;
			var url = App.data.url;
			for ( var k = 0; k < attch.length; k++) {
				App.clickId=attch[k].clickId;
				App.showId=attch[k].showId;
				App.picLength=attch[k].length;
				App.showAttcchment(attch[k].name, url);
			}
		}
		
	},
	/**
	 * 取消
	 */
	toQX:function(){
		$("#white").addClass("hidden");
		$("#black").addClass("hidden");
		//取消静止滑动
		App.pageA.unbind("touchmove");
		qdate.resetData();
	},
	/**
	 * 确认
	 */
	toQR:function(){
		$("#white").addClass("hidden");
		$("#black").addClass("hidden");
		//取消静止滑动
		App.pageA.unbind("touchmove");
		$("#"+App.sleDate+"").val(qdate.getDate());
	},
	toAddAttcchment:function(clickId,showId,picLength){
		App.clickId=clickId;
		App.showId=showId;
		App.picLength=picLength;
		Fw.Client.chooseAccessory("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		attach.addAttach(name,url,App.clickId,App.showId,App.picLength);
	},
	
	isOK:function(){
		var licence=$("#licenceClick").siblings().length;
		var idCardSide=$("#idCardSideClick").siblings().length;
		var idCardReverse=$("#idCardReverseClick").siblings().length;
		var baseClick=$("#baseClick").siblings().length;
		if (licence>0 && idCardSide>0 && idCardReverse>0 &&　baseClick>0) {
			$("#imgTip").addClass("hidden");
			$("#mgt").css("margin-top","20px");
			$("#submit1").removeAttr("disabled");
		}else{
			$("#imgTip").removeClass("hidden");
			$("#mgt").css("margin-top","4px");
			$("#submit1").attr("disabled","disabled");
		}
	},
	/**
	 * 
	 */
	gotoback:function(){
		YT.showPageArea(App.pageA, [App.pageB], true)
	},
	toSubmit1:function(){
		YT.showPageArea(App.pageA, [App.pageB], true)
	},
	/**
	 * 控制输入字节数
	 */
	checkLength:function(){
		var inputId=$(this).attr("id");
		var inputData=$(this).val();
		var w=0;//字节数
		var arr={
				zjhm:"32",tyshxydm:'32',zzjgdm:'12',jgxydm:'18',khxkzhm:'16',gszzhm:'32',qtzmwj:'22',djbm:'22',zcdqdm:'8',zzzcdz:'60',
				jyfw:"4000",zczj:'13',gsdjh:'40',dsdjh:'40',bgdz:'60',yzbm:'6',czhm:'20',gjgm:'4',dhhm:'20',ywmc:'35',ywdz:'35'
		}
		var dataLength=arr[inputId];
		if(inputId=="zczj"){
			inputData=parseFloat(Number(inputData)).toFixed(2);
			if(inputData.length>"14"){
				inputData=inputData.substring(0,14);
				$("#"+inputId).val(inputData);
				$("#"+inputId).blur();
				return ;
			}                  
		}
		for(var i=0;i<inputData.length;i++){
			var c=inputData.charCodeAt(i);//获取每一位的值
			if((c>=0x0001&&c<=0x007e)||(0xff60<=c&&c<=0xff9f)){
				w++;
			}else{
				w+=2;
			}
			if(w>dataLength){
				inputData=inputData.substring(0,i);
				$("#"+inputId).val(inputData);
				$("#"+inputId).blur();
				break;
			}
		}
	},
	zczjBlur:function(){
		var value=$("#zczj").val();
		$("#zczj").val(parseFloat(Number(value)).toFixed(2));
	},
	chooseType:function(type){
		App.type=type;
		var arr=[];
		if(type=='zjzl'){
			arr=[{name:'居民身份证或临时身份证',value:'0'},{name:'企业客户营业执照',value:'1'},{name:'企业代码证',value:'2'},{name:'商业登记证（香港）',value:'F'},{name:'SWIFT BIC',value:'S'},{name:'企业客户其他有效证件',value:'3'}
			,{name:'军人身份证',value:'4'},{name:'武警身份证',value:'5'},{name:'港、澳、台居民有效身份证',value:'6'},{name:'外国护照',value:'7'},{name:'个人客户其他有效证件',value:'8'},{name:'中国护照',value:'9'},{name:'港澳居民来往内地通行证',value:'A'}
			,{name:'台湾居民来往大陆通行证',value:'B'},{name:'外国人永久居留证',value:'C'},{name:'户口薄',value:'D'},{name:'公司注册证明书（香港）',value:'G'},{name:'社会团体法人登记证书',value:'I'},{name:'个体工商户营业执照',value:'L'},{name:'事业单位法人登记证',value:'Y'}];
		}else if(type=='zmwj'){
			arr=[{name:'工商营业执照',value:'01'},{name:'批文',value:'02'},{name:'登记证书',value:'03'},{name:'开户证明',value:'04'},{name:'借款合同',value:'06'},{name:'其他结算需要的证明',value:'07'},{name:'财政部门的批复书',value:'08'}
			,{name:'主管部门批文',value:'09'},{name:'相关部门证明',value:'10'},{name:'政府部门文件',value:'11'},{name:'证券从业资格证书',value:'12'},{name:'国家外汇管理局的批文',value:'13'},{name:'建设主管部门核发的许可证',value:'14'},{name:'施工及安装合同',value:'15'}
			,{name:'工商行政管理部门的证明',value:'16'},{name:'其他',value:'17'}];
		}else if(type=='sfbzzczj'){
			arr=[{name:'是',value:'1'},{name:'否',value:'0'}];
		}else if(type=='bz'){
			arr=[{name:'人民币',value:'01'},{name:'欧元',value:'11'},{name:'英镑',value:'12'},{name:'港币',value:'13'},{name:'美元',value:'14'},{name:'瑞士法郎',value:'15'}
			,{name:'瑞典克朗',value:'21'},{name:'丹麦克朗',value:'22'},{name:'挪威克朗',value:'23'},{name:'日元',value:'27'},{name:'加拿大元',value:'28'},{name:'澳大利亚元',value:'29'},{name:'马来西亚林吉特',value:'32'}
			,{name:'巴西雷亚尔',value:'35'},{name:'卢布',value:'36'},{name:'南非兰特',value:'37'},{name:'哈萨克斯坦坚戈',value:'38'},{name:'韩元',value:'39'},{name:'新加坡元',value:'43'},{name:'新西兰',value:'67'}
			,{name:'澳门元',value:'81'},{name:'墨西哥比索',value:'82'},{name:'泰国铢',value:'84'},{name:'新西兰元',value:'87'},{name:'新台币',value:'88'},{name:'越南盾',value:'99'}];
		}
		var jsonArray=new Array();
		for(var i=0;i<arr.length;i++){
			jsonArray.push({
				account : arr[i].name,
				balance : arr[i].value,
				accountName:''
			});
		}
		var json = {
				jsonArray : jsonArray,
				"func" : "App.showCommonlyUsedAccount",
				"title":''
			};
		Fw.Client.hideWaitPanel();
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	/**
	 * 回显
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		var id=App.type
		$("#"+id).val(account);
		$("#"+id).attr("data-value",balances)
	},
	/**
	 * 选择日期
	 */
	showSendTime : function(date) {
		App.date=date
		// 1签发2查询
		var datas = {
			"func" : "App.opData",
			"flag" : "2",
			"title":''
		}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(date) {
		$("#"+App.date+"").val(date);
	},
	/**
	 * 处理核心数据和变更差异
	 */
	operateHXData:function(data){
		
		if(data.updTime){
			$("#zxgt_btmTime").removeClass("zxgt_btmTime1");
			$("#zxgt_btmTime").html(data.updTime);
		}
		var core={};
		if(App.data && App.data.pageDiff){
			 core=App.data.pageDiff;//预览界面返回
		}else{
			 core=data.core;
		}
		
	  Fw.Client.openWaitPanel();
	  var dateData=["zzjgdmdqr","jgxydmdqr","zjdqr","jgzmwjqsrq","jgzmwjdqrq","gsdjhdqr","dsdjhdqr"]; 
	 try{
	  for (var tKey in core) {
		  var tempItem = Fw.util.Format.dataConversion(tKey);
		  if(tempItem!=""){
			  var item=core[tKey];
			  if(dateData.indexOf(tempItem)!=-1){//日期格式化
				 item=Fw.util.Format.fmtYear(core[tKey]); 
			  }
			  if(tempItem=="zjzl" ){//证件种类 
				  item=Fw.util.Format.formarDocumentsToStr(core[tKey]);
				  $("#zjzl").attr("data-value",core[tKey]);
			  }
			  if(tempItem=="zmwj"){//证明文件类型
				  item=Fw.util.Format.formarEvidenceToStr(core[tKey]); 
				  $("#zmwj").attr("data-value",core[tKey]);
			  }
			  if(tempItem=="jgfzrlx"){//机构负责人类型
				  item=Fw.util.Format.formarInsPersion(core[tKey]); 
			  }
			  if(tempItem=="sfbzzczj"){//是否标注注册资金
				  if(core[tKey]=="0"){
					  item="否";
				  }else if(core[tKey]=="1"){
					  item="是";
				  }else{
					  item="";
				  }
				  $("#sfbzzczj").attr("data-value",core[tKey]);
			  }
			  if(tempItem=="bz"){//币种
				  item=Fw.util.Format.formatCurrencyToStr(core[tKey]); 
				  $("#bz").attr("data-value",core[tKey]);
			  }
			  if(tempItem=="gb"){//国别
				  if(core[tKey]=="CHN" || core[tKey]=="156"){
					  item='中国';
				  }else{
					  item=core[tKey];
				  }
				  $("#"+tempItem+"").attr("data-value",core[tKey])
			  }
			  $("#"+tempItem+"").val(item);
//			  $("#" + tempItem).focus();
//			  $("#" + tempItem+"").blur();
		  }
 	  }
	 }catch(e){alert(e)}
	  if(!core.certificateFile){$("#zmwj").val("");}//证明文件赋空
	  if(!core.currency){$("#bz").val("");}//币种赋空
	  if(!core.country){$("#gb").val("");}//国别赋空
	  if(!core.registerCapitalFlag){$("#sfbzzczj").val("");}//是否标注注册资金
	  
	  try{
		
	  if(data.diff){//工商差异
//		  alert("diff");
		 var diff=data.diff;
		 if(App.data.FirmStatus!='1'){//App.data.FirmStatus!='0'
			  for (var tKey in diff) {
				  var tempItem = Fw.util.Format.dataConversion(tKey);
				  if(tempItem!=""){
						  var item=diff[tKey];
						  if(dateData.indexOf(tempItem)!=-1){//日期格式化
							 item=Fw.util.Format.fmtYear(diff[tKey]); 
						  }
						  if(tempItem=="zjzl" ){//证件种类 |
							  item=Fw.util.Format.formarDocumentsToStr(diff[tKey]); 
						  }
						  if(tempItem=="zmwj"){//证明文件类型
							  item=Fw.util.Format.formarEvidenceToStr(diff[tKey]); 
						  }
						  if(tempItem=="jgfzrlx"){//机构负责人类型
							  item=Fw.util.Format.formarInsPersion(diff[tKey]); 
						  }
						  if(tempItem=="sfbzzczj"){//是否标注注册资金
							  if(diff[tKey]=="0"){
								  item="否";
							  }else if(diff[tKey]=="1"){
								  item="是";
							  }else{
								  item="";
							  }
						  }
						  if(tempItem=="zczj"){//注册资金
							  item=diff[tKey]*10000;
						  }
						  if(tempItem=="bz"){//币种
							  item=Fw.util.Format.formatCurrencyToStr(diff[tKey]); 
						  }
						  if(tempItem=="gb"){//国别
							  if(diff[tKey]=="CHN" || diff[tKey]=="156"){
								  item='中国';
							  }else{
								  item=diff[tKey];
							  }
							  $("#"+tempItem+"").attr("data-value",diff[tKey])
						  }
						
					  var html='<div  style="background-color: #fff;padding:0 20px;color: #FF7F00;min-height:21px;">'+
						  			'<label style="width: 40%;display: inline-block;float: left;word-break: break-all;word-wrap: break-word;clear: both;">工商最新信息</label>'+
						  			'<span class="rectangle" onClick="App.Rectangle('+"'"+tempItem+"'"+','+"'"+diff[tKey]+"'"+')" ></span>'+
									'<span style="width: 45%;display: inline-block;word-break: break-all;word-wrap: break-word;text-align: right;float:right;">'+item+'</span>'+
								'</div>';
//						 if(tempItem=="zczj" ||　tempItem=="bz"){
//							 $("#"+tempItem+"").parent().parent().after(html);
//						 }else{
							 $("#"+tempItem+"").parent().after(html);
//						 }
					  
			  }
		   }
		  }
	  }
	  }catch(e){alert(e)}
	  Fw.Client.hideWaitPanel();
	  YT.showPageArea(App.pageA, [App.pageB], true);
	  
	},
	Rectangle:function(tempItem,item1){
//		alert(tempItem);
//		alert(item1);
//		var name = $(this).data("name"), value = $(this).data("value");
		var dateData = [ "zzjgdmdqr", "jgxydmdqr", "zjdqr", "jgzmwjqsrq",
				"jgzmwjdqrq", "gsdjhdqr", "dsdjhdqr" ];
		var item = item1;
		if (dateData.indexOf(tempItem) != -1) {// 日期格式化
			 item=Fw.util.Format.fmtYear(item1); 
//			item = item1.replace(/-/g,'');
		}
		if (tempItem == "zjzl") {// 证件种类 |
			$("#zjzl").attr("data-value",item1);
			item = Fw.util.Format.formarDocumentsToStr(item1);
		}
		if (tempItem == "zmwj") {// 证明文件类型
			$("#zmwj").attr("data-value",item1);
			item = Fw.util.Format.formarEvidenceToStr(item1);
		}
		if (tempItem == "jgfzrlx") {// 机构负责人类型
			$("#jgfzrlx").attr("data-value",item1);
			item = Fw.util.Format.formarInsPersion(item1);
		}
		if (tempItem == "sfbzzczj") {// 是否标注注册资金
			$("#sfbzzczj").attr("data-value",item1);
			if(item1 == "0"){
				item="否";
			}else if(item1 == "1"){
				item="是";
			}else{
				item="";
			}
		}
		if(tempItem=="zczj"){//注册资金
			 item=item1*10000;
		}
		if (tempItem == "bz") {// 币种
			$("#bz").attr("data-value",item1);
			item = Fw.util.Format.formatCurrencyToStr(item1);
		}
		if (tempItem == "gb") {// 国别
			$("#gb").attr("data-value",item1);
			 if(item1=="CHN" || item1=="156"){
				  item='中国';
			  }else{
				  item=item1;
			  }
		}
		
		$("#" + tempItem).val(item);
		$("#" + tempItem).focus()
		 $("#" + tempItem).blur();
	},
	/**
	 * 页面切换动画
	 */
	toogleHead : function() {
		var name = $(this).data("name");
		var span = $(this).data("span");
		var arr = [ "qyzjxx", "jgfzrxx", "qyzmwj", "swxx", "lxxx" ];
		var arr1 = [ "iconSpan1", "iconSpan2", "iconSpan3", "iconSpan4",
				"iconSpan5" ]
		var _this = $(this);
		_this.addClass("blueColor");// 立即改变消除300ms延时
		$("#" + span + "").removeClass("sel_iconDown").addClass("sel_iconUp");

		for ( var i = 0; i < arr.length; i++) {// 控制显示
			if (name == arr[i]) {
				$("#" + name + "").slideToggle(200);
				setTimeout(function() {
					var disp = $("#" + name + "").css("display");
					if (disp == "block") {
						if(name=="qyzmwj"){
							$("#gszzhm").blur();
							$("#qtzmwj").blur();
							$("#djbm").blur();
							$("#zzzcdz").blur();
							$("#jyfw").blur();
						}
						if(name=="swxx"){
							$("#gsdjh").blur();
							$("#dsdjh").blur();
						}
						if(name=="lxxx"){
							$("#bgdz").blur();
							$("#ywmc").blur();
							$("#ywdz").blur();
						}
						_this.addClass("blueColor");
						$("#" + span + "").removeClass("sel_iconDown").addClass("sel_iconUp");
					} else {
						_this.removeClass("blueColor");
						$("#" + span + "").removeClass("sel_iconUp").addClass("sel_iconDown");
					}
				}, 300);
			} else {
				$("#" + arr[i] + "").slideUp(200);
				$($(".xxgl_list_head")[i]).removeClass("blueColor");
				$("#" + arr1[i] + "").removeClass("sel_iconUp").addClass("sel_iconDown");
			}
		}

	},
	/**
	 * 数字键盘
	 */
	showNumberPicker : function() {
		
		App.sleDate=$(this).attr("id");
		
		$("#white").removeClass("hidden");
		$("#black").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	/**
	 * 添加附件
	 */
	initTJFJ : function(){
		YT.showPageArea(App.pageB, [App.pageA], true)
//		var diff1=App.saveData();
//		var core=App.data.list.core;
//		
//		var json={
//				core:core,
//				pageDiff:diff1,//变更后数据
//				list:App.data.list,
//				url:App.url,
//				attch:App.attch
//		}
//		Fw.redirect("10901032.html");
//		if(App.attch.length > 9){
//			Fw.Form.showPinLabel($(this), "附件最多添加10个", true);
//			return;
//		}
//		Fw.Client.openAttcchment("App.showAttcchment");
	},
//	showAttcchment: function(name,url){
//		
//		if(name.substring(name.length - 3, name.length)!='jpg'){
//			Fw.Form.showPinLabel(null, "只能上传图片", true);
//			return;
//		}
//		Fw.util.attach.addAttach(name,url);
//		setTimeout($("#imgCount").html(App.attch.length),500)
//	},
	/**
	 * 提交审核
	 */
	toSubmit : function() {
		try{
		/*if($("#zzhm").val()==""){
			Fw.Form.showPinLabel($(this),"证件号码不能为空", true);
			return;
		}
		if($("#yzbm").val()==""){
			Fw.Form.showPinLabel($(this),"邮政编码不能为空", true);
			return;
		}
		if($("#bgdz").val()==""){
			Fw.Form.showPinLabel($(this),"办公地址不能为空", true);
			return;
		}*/
		if(App.attch.length==0){
			Fw.Form.showPinLabel($(this),"请上传附件！", true);
			return;
		}
		var attach=App.attch;
		var yyzz=jbkh=frzm=frfm='';
		for(var i=0;i<attach.length;i++){
			if(attach[i].clickId=='licenceClick'){yyzz=attach[i].clickId}
			if(attach[i].clickId=='baseClick'){jbkh=attach[i].clickId}
			if(attach[i].clickId=='idCardSideClick'){frzm=attach[i].clickId}
			if(attach[i].clickId=='idCardReverseClick'){frfm=attach[i].clickId}
		}
		if(yyzz=='' || jbkh=='' || frzm=='' || frfm=='' ){
			Fw.Form.showPinLabel($(this),"上传证件类型不完整！", true);
			return;
		}
		var core=new Array();
		core.push(App.data.list.core);
		Fw.Client.openWaitPanel();
		
		
		var diff1=App.saveData();
		var diff=new Array();
		diff.push(diff1);
		var url = YT.dataUrl("private/counterCompare");
		var json = {
				"core":core,
				"diff":diff,
				"busiType":"1"
		};
		YT.ajaxData(url,json,function(data){
			try{
			if( YT.JsonToStr(data.diffC)=="{}"){
				Fw.Form.showPinLabel($(this),"当前未修改数据，请修改后再提交！", true);
				Fw.Client.hideWaitPanel();
				return;
			}
			
			var coreC=data.coreC;
			var diffC=data.diffC;
			 for (var tKey in diffC) {//diffC coreC对比   不存赋空
				if(!coreC[tKey]){
					coreC[tKey]="";
				}
			 }
			var corec={};
			for(var key in diffC){
				corec[key]=coreC[key];
			}
			coreC=corec;
			 
			var json={
					core:core,
					diff:diff,
					coreC:coreC,
					diffC:diffC,
					pageDiff:diff1,//变更后数据
					list:App.data.list,
					url:App.url,
					attch:App.attch
			}
			//预览提交
			Fw.redirect("10901033.html",json);
			}catch(e){alert(e)}
		})
		}catch(e){alert(e)}
	},
	
	saveData:function(){
		var diff1={
				"firmName":App.list.core.firmName,
				"inchargeMan":App.list.core.inchargeMan,
				"inchargeManType":App.list.core.inchargeManType,
				"inchargeManCertType":App.list.core.inchargeManCertType,
				"inchargeManCertNo":App.list.core.inchargeManCertNo,
				"firmIdType":$("#zjzl").data("value")+'',//证件种类================
				"firmIdNo":$("#zjhm").val().trim().toString(),//证件号码
				"unifiedCreditcode":$("#tyshxydm").val().trim().toString(),//统一社会信用代码
				"orgcode":$("#zzjgdm").val().trim().toString(),//组织机构代码
				"orgcodeExpireDate":$("#zzjgdmdqr").val().replace(/-/g,''),//组织机构代码到期日
				"creditcode":$("#jgxydm").val().trim().toString(),//机构信用代码
				"creditcodeExpireDate":$("#jgxydmdqr").val().replace(/-/g,''),//机构信用代码到期日
				"openLicenseCode":$("#khxkzhm").val().toString(),//开户许可证号码
				"certificateExpireDate":$("#zjdqr").val().replace(/-/g,''),//证件到期日
				"certificateFile":$("#zmwj").data("value")+'',//证明文件=================
				"busiLicenseNo":$("#gszzhm").val().trim().toString(),//工商执照号码
				"OCertifyFile":$("#qtzmwj").val().trim().toString(),//其他证明文件
				"reAuthorities":$("#djbm").val().trim().toString(),//登记部门
				"certFileEffectDate":$("#jgzmwjqsrq").val().replace(/-/g,''),//机构证明文件起始日期
				"certFileExpireDate":$("#jgzmwjdqrq").val().replace(/-/g,''),//机构证明文件到期日期
				"registerRegionCode":$("#zcdqdm").val().trim().toString(),//注册地区代码
				"licenseRegisterAddr":$("#zzzcdz").val().toString(),//执照注册地址
				"busiScope":$("#jyfw").val().toString(),//经营范围
				"registerCapitalFlag":$("#sfbzzczj").data("value")+'',//是否标注注册资金===============
				"registerCapital":$("#zczj").val().trim().toString(),//注册资金
				"currency":$("#bz").data("value")+'',//币种=====================
				"country":$("#gb").data("value").toString(),//国别
				"nationTaxNum":$("#gsdjh").val().trim().toString(),//国税登记号
				"naTaxExpireDate":$("#gsdjhdqr").val().replace(/-/g,''),//国税登记号到期日
				"localTaxNum":$("#dsdjh").val().trim().toString(),//地税登记号
				"loTaxExpireDate":$("#dsdjhdqr").val().replace(/-/g,''),//地税登记号到期日
				"busiAddr":$("#bgdz").val().toString(),//办公地址
				"postcode":$("#yzbm").val().trim().toString(),//邮政编码
				"faxNum":$("#czhm").val().trim().toString(),//传真号码
				"internationalCallPrefix":$("#gjgm").val().trim().toString(),//国际冠码
				"telPhone":$("#dhhm").val().trim().toString(),//电话号码
				"enName1":$("#ywmc").val().toString(),//英文名称
				"enAddr1":$("#ywdz").val().toString(),//英文地址
				
			};
		return diff1
	},
	/**
	 * 返回
	 */
	back : function() {
		Fw.redirect("1090103.html", "");
	}
    
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);