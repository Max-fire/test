/**
 * 创建应用
 * 
 * @author cuijh
 */
var App = {
	datas:{},
	attach_url : "",
	requires : ['Fw.util.attach'],
	init : function(require){
		App.pageA = $("#pageA");
		App.pageB = $("#pageB"); 
		App.attch = new Array();
		App.attchList = new Array();
		App.func = window['_getParameter'];
		App.addData();
		App.initCH();
	},
	showPageA:function(){
		YT.showPageArea(App.pageA, [App.pageB], true);
	},
	showPageB:function(){
		YT.showPageArea(App.pageB, [App.pageA], true);
	},
	//显示产品协议书
	onCpxys:function(){
		var html=protocol.productCode(App.cpdm);
		Fw.redirect(html+"?No=1040508&trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
	},
	/**
	 * 判断是否可以撤销
	 */
	initCH:function(){
		var trsStatus = App.func("trsStatus");
		if(trsStatus=="1"){
			$("#TJ").removeClass("hidden");
			$("#slbh").removeClass("hidden");
		}else{
			$("#TJ").addClass("hidden");
			$("#scsj").addClass("hidden");
			$("#slbh").addClass("hidden")
		}
		
	},
	//撤销操作
	onTJ:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/financeDeal");
		var json = {
				trsNo:App.func("trsNo"),
				type:"1",
				ywslbh:App.ywslbh,
				zhdh:App.zh,
				cpdm:App.cpdm
		};
		YT.ajaxData(url,json,function(data){
			if(data.STATUS == "1"){
				Fw.Client.alertinfo(data.MSG,"消息提示","App.test()");
				Fw.Client.hideWaitPanel();
	    	}else{
	    		Fw.Client.alertinfo(data.MSG,"消息提示","App.test()");
	    		Fw.Client.hideWaitPanel();
	    	}
		});
	},
	//查看凭证
	toCKPZ:function(){
		var datas=App.data.product
		datas.page="1040508.html?trsNo="+App.func("trsNo")+"&trsStatus=1";
		datas.cpmc=datas.productName;
		datas.amount=App.data.trsFinance[0].amount;
		datas.trsNo=App.data.trsFinance[0].trsNo;
		datas.ywslbh=App.data.trsFinance[0].acceptNo;
		datas.acctNo=App.data.trsFinance[0].fromAcctNo;
		datas.transDate=App.data.trsInfo[0].finishTime;
		Fw.redirect("1040502_gmpz.html", datas);
	},
	test:function(){
		Fw.Client.changePage("1040506.html?trsStatus=1","");
	},
	//加载数据
	addData:function(){
		var trsNo = App.func("trsNo");
		if(trsNo){
			if(App.func("trsStatus") == "2"){
				$("#pageA").attr("data-btnRight","true| 修改|App.initXG()");
			}else{
				$("#pageA").attr("data-btnRight","false| 修改|App.initXG()");
			}
			var trsStatus = App.func("trsStatus");
			if(trsStatus=="1"){
				$("#scsj").removeClass("hidden");
			}else{
				$("#scsj").addClass("hidden");
			}
			var url = YT.dataUrl("private/getTaskDetail");
			var json = {
					trsNo:trsNo,
					trsType:"5"
			};
			YT.ajaxData(url,json,function(data){
				App.data = data;
				//产品名称
				App.cpdm = data.trsFinance[0].productCode;
				//付款账号
				App.zh = data.trsFinance[0].fromAcctNo;
				//业务受理编号
				if(data.trsFinance[0].acceptNo){
					App.ywslbh = data.trsFinance[0].acceptNo;
					$("#ywslbh").html(App.ywslbh);
				}else{
					$("#slbh").addClass("hidden");
					$("#TJ").addClass("hidden");
				}
				//处理结果类型
				if(data.dealLog!=""){
					App.lx = data.dealLog[0].dealType;
					if(App.lx=="4"||App.lx=="3"){
						$("#TJ").addClass("hidden");
					}
					if (App.lx=="2") {
						$("#ckpz").removeClass("hidden");
					}
				}
//				$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
				if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
					$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.yieldRate));
				}else{
					$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
				}
				if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
					$("#yieldRate").html("七日年化收益率");
				}
				$("#ZDAmount").html(Fw.util.Format.fmtAmt(App.data.product.purAmountMin+"")+"元");
				$("#ZGAmount").html(Fw.util.Format.fmtAmt(App.data.product.holdShareMax+"")+"元");
				$("#jylx").html("理财申购");
				$("#dz").html(Fw.util.Format.fmtAmt(App.data.product.purAmountInc+"")+"元");
				$("#MC").html(App.data.trsFinance[0].shortName);
				$("#bz").html(Fw.util.Format.fmtbz(App.data.product.salesCurrency)+"理财");
				$('#trsNo').html( Fw.util.Format.subTrsNo(data.trsFinance[0].trsNo));
				$('#jyls').html( App.func("trsNo") );
				$("#zh").html(data.trsFinance[0].fromAcctNo);
				$('#je').html(Fw.util.Format.fmtAmt(data.trsFinance[0].amount+"")+"元");
				$("#HKJE").html(data.trsFinance[0].amount);
				$("#memo").html(data.trsFinance[0].memo);
				$("#sj").html(Fw.util.Format.fmtTrsCreDate(data.trsFinance[0].sendTime,"yyyy-MM-dd HH : mm :ss"));
				App.attach_url = data.attach_url;
				App.showFj(data.attach);
				Fw.Client.hideWaitPanel();
				var html='',html1='',html2='';
				var temp = [
			      			'{@each dealLog as item}',
			      			'{@if item.dealUserId != ""}',
					      			'<div class="yui_div_hm" >',
						 				'<div class="ui_01_div2">',
							 				'<div class="ui_01_div3 ui-list">',
							 					'<div class="ui_01_img1"></div>',
							 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
							 				'</div>',					 				
							 				'<div class="ui-bg-ss1">',
							 				'{@if item.dealType == 0}',
								 				'<div class="ui_01_phoneBack">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey">退　回</div>',
						 						'</div>',
						 					'{@else if item.dealType == 1}',
							 					'<div class="ui_01_phoneTongYi ui-list">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
						 						'</div>',
						 					'{@else if item.dealType == 2}',
							 					'<div class="ui_01_phoneTongYi">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
						 						'</div>',
						 						'{@else if item.dealType == 3}',
							 					'<div class="ui_01_phoneBack">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey">撤　销</div>',
						 						'</div>',
						 						'{@else if item.dealType == 4}',
							 					'<div class="ui_01_phoneBack">',
							 						'<div class="ui_01_phone1"><img src="../../css/img/XTtouxiang.png" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey ">拒　绝</div>',
						 						'</div>',	
							 				'{@/if}',
							 					'{@if item.dealType == 4}',
							 					'<div class="ui_01_div4">系统用户</div>',
							 					'{@else}',
							 					'<div class="ui_01_div4">${item.dealUserName}</div>',
							 					'<div class="ui_01_div5">(审批人)</div>',
							 					'{@/if}',
							 					'{@if item.dealMsg}',
							 						'{@if item.dealType == 4}',
									 				'<div class="ui-bg-ss2">',
									 					　'拒绝原因:&nbsp;&nbsp;${item.dealMsg}',
									 				'</div>',	 
									 				'{@else}',
									 				'<div class="ui-bg-ss2">',
								 					　	'${item.dealMsg}',
								 					 '</div>',	 
									 				'{@/if}',	 
							 					'{@/if}',
							 				'</div>',
						 				'</div>',
					 				'</div>',
				 				'{@/if}',
			      			'{@/each}',
		   			].join("");
		   			
					html = Fw.template(temp,data);
					html1 = 
							'<div class="yui_div_hm" >'+
			 				'<div class="ui_01_div2">'+
				 				'<div class="ui_01_div3 ui-list">'+
				 					'<div class="ui_01_img1"></div>'+
				 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].trsCreTime)+'</div>'+
				 				'</div>'+
				 				'<div class="ui-bg-ss1">'+
				 					'<div class="ui_01_phoneTongYi">'+
				 						'<div class="ui_01_phone1"><img src="'+data.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
				 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
				 					'</div>'+
				 					'<div class="ui_01_div4">'+data.trsInfo[0].creUserName+'</div>'+
				 					'<div class="ui_01_div5">(申请人)</div>'+
				 				'</div>'+
			 				'</div>'+
			 			'</div>';
					if(data.trsInfo[0].trsStatus == "0"){
						html2 = 
							'<div class="yui_div_hm" >'+
							'<div class="ui_01_div2">'+
			 				'<div class="ui_01_div3 ui-list">'+
			 					'<div class="ui_01_img1"></div>'+
			 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].sendTime)+'</div>'+
			 				'</div>'+
			 				
			 				'<div class="ui-bg-ss1">'+
			 					'<div class="ui_01_phoneTongYi">'+
			 						'<div class="ui_01_phone1"><img src="'+data.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
			 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
			 					'</div>'+
			 					'<div class="ui_01_div4">'+data.trsInfo[0].dealUserName+'</div>'+
			 					'<div class="ui_01_div5">(审批人)</div>'+
			 				'</div>'+
							'</div>'+
						'</div>';
						$("#DQCLR").html(html2);
					}
					$("#SQR").html(html1);
					$("#CLR").html(html);
					App.setTimeout();
			});
			App.initEvent();
			App.showPageA();
		}
	},
	
	// 绑定事件
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.onTJ);	
		App.pageA.on("click","#ckpz",App.toCKPZ);	
		App.pageA.on("click","#cpxys",App.onCpxys);	
			// 处理按钮事件
	  	$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  		$('#trsStatus').val( $(this).data('status') );
	  	});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	query:function(){
		App.showPageB();
	},
	// 加载修改页面
	initXG:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/isApproval");
	    YT.ajaxData(url,{trsType:"5"},function(Data){
	    	if(Data.STATUS == "1"){
	    		if(Data.IsApproval=="YES"){
		    		Fw.redirect("1040508_gxgb.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"",App.data);
		    	}else{
		    		Fw.redirect("1040508_gxgf.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"",App.data);
		    	}
	    	}else{
	    		Fw.Client.alertinfo(Data.MSG,"消息提示");
	    		Fw.Client.hideWaitPanel();
	    		return;
	    	}
	    })	
	},
	
	// 延迟 10ms 高亮第一个处理事件
	setTimeout: function(){
		if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
			if($('.ui_01_phoneBack').length>0){
				return false;
			}
			$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
			$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
		}
		if($("#DQCLR").html()!=''){
			$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
			$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
		}
		
	},
 // 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},
	
	// 返回前一页
	toBack:function(){
		Fw.Client.changePage("1040506.html?trsStatus="+App.func("trsStatus")+"","");
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);