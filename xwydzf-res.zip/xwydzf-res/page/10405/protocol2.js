var App = {
		init:function(){
			App.pageA = $("#pageA");
			App.data = Fw.getParameters();
			App.func = window['_getParameter'];
			Fw.Client.hideWaitPanel();
			YT.showPageArea(App.pageA, [], true);
		},
		toBack:function(){
			//Fw.Client.toLogin();
			if (App.func("No")=="det14") {
				Fw.redirect("../details/det14.html?&trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"&trsId="+App.func("trsId")+"",App.data);
			}else{
				Fw.redirect(App.func("No")+".html?&trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"",App.data);
			}
		}
};
Fw.onReady(App);