var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		init : function(require) {
			App.data = Fw.getParameters();
			App.func = window['_getParameter'];
			App.pageA = $("#pageA");
			App.attch = new Array();
			App.attchList = new Array();
			App.i=0;
			App.initEvent();
			App.initData();
		},
		initData:function(){
			$("#MC").html(App.data.trsFinance[0].shortName);
			$("#accNo").html(App.data.trsFinance[0].fromAcctNo);
//			$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
			if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.yieldRate));
			}else{
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
			}
			if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
				$("#yieldRate").html("七日年化收益率");
			}
			//最低持有
			$("#zdcy").html(Fw.util.Format.fmtAmt(App.data.product.holdShareMin+""));
			//赎回递增份额
			$("#shdz").html(Fw.util.Format.fmtAmt(App.data.product.redShareInc+""));
			//起赎份额
			if(App.data.product.redShareMin==0){
				$("#jyxq").removeClass("yui-lc-alltitle").addClass("yui-lc-alltitleA");
				$("#qsfeA").addClass("hidden");
			}else{
				$("#qsfe").html(Fw.util.Format.fmtAmt(App.data.product.redShareMin+""));
			}
			$("#jysj").html(Fw.util.Format.fmtDate(App.data.product.transStartDate)+"-"+Fw.util.Format.fmtDate(App.data.product.transEndDate));
			//赎回份额
			$("#shfe").val(App.data.trsFinance[0].financeShare);
			$("#HKJE").val(App.data.trsFinance[0].financeShare);
			//备注
			$("#memo").html(App.data.trsFinance[0].memo);
			YT.showPageArea(App.pageA, [], true);
			$("#memo").blur();
			if(!App.data.product.redeemRate){
				App.data.product.redeemRate=0;
			}			
			Fw.Client.hideWaitPanel();
		},
		// 显示附件
		showFj:function( d ){
			Fw.util.attach.showAttach( d );
		},
		
		initEvent : function() {
			// 添加附件-事件
			App.pageA.on("click",".TJFJ",App.initTJFJ);
			// 加载点击选择审批人-事件
			App.pageA.on("click", "#SPR", App.initSPR);
			//赎回
			App.pageA.on("click", "#btnSubmit", App.submit);
			//数字键盘
			App.pageA.on("click", "#shfe", App.initShowNumberPicker);
		},
		/**
		 * 数字键盘
		 */
		initShowNumberPicker:function(){
			Fw.Client.showNumberPickerOne($("#shfe"));
		},
		submit:function(){
			var memo = $("#memo").val().replace(/\s/g,"");
			//最低赎回份额
			var zd = App.data.product.redShareMin;
			//持有份额
			var cy = App.data.kyfe;
			//最低起购金额
			var zdqg = App.data.product.purAmountMin;
			var gmAmount = $("#shfe").val();
			var dealUserName = $("#dealUserName").val();
			var dealUserId = $("#dealUserId").val();
			var dealMsg = $("#dealMsg").val();
			var communicateId = $("#communicateId").val();
			var billNo = $("#accNo").html();
			if(gmAmount==null||gmAmount==""){
				Fw.Form.showPinLabel($(this), "请输入赎回份额", true);
				return;
			}
			if(gmAmount=="0"){
				Fw.Form.showPinLabel($(this), "赎回份额不能为零", true);
				return;
			}
			if(gmAmount<zd){
				Fw.Form.showPinLabel($(this), "赎回份额小于最低赎回份额", true);
				return;
			}
			if((gmAmount/cy)>1){
				Fw.Form.showPinLabel($(this), "赎回份数超自身持有量", true);
				return;
			}
			if(Fw.util.proofTest.proolEmoji(memo)){
				Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
				return;
			}
			
			// 审批人是否为空
			if (dealUserId == null || dealUserId == "") {
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			var url = YT.dataUrl("public/getRandomNum");
			YT.ajaxData(url, {}, function(success) {
				if (success.STATUS == "1") {
					var params = {
							"type":"1",
							"share":gmAmount,
							"rate":App.data.product.redeemRate+"",
							"transCode":"REDEEN",
							"financeType":"3",
							"trsType":"5",
							"closingDate":"",
							"memo" : memo,
							"acctName":App.data.product.fromAcctName,
							"acctNo":billNo,
							"bankName":"",
							"dealUserName" : dealUserName,
							"dealUserId" : dealUserId,
							"toCommunicateId":communicateId,
							"TOKEN" : success.randomNum,
							"maturityDate":App.data.product.maturityDate,
							"productCode":App.data.product.productCode,
							"amount":gmAmount,
							"fehzls":App.data.trsFinance[0].volSumSerno
					};
					Fw.Client.openWaitPanel();
					var url = YT.dataUrl("private/financtTask");
				    YT.ajaxData(url,params,App.success,App.failure);
				}else {
					App.flag = false;
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(success.MSG, "消息提示");
				}
			});
		},
		/**
		 * 提交成功
		 * 
		 */
		success:function(data){
			if(data.STATUS == "1"){
				var url = YT.dataUrl("private/oprtFile");
				var params = {
						trsNo:data.trsNo,
						FileUrl:App.url,
						FileNameList:App.attch
				};
				YT.ajaxData(url, params, function(success) {
				});
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo("已提交下一个处理人：" + $("#dealUserName").val(), "提交成功","App.test()");
				
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示","App.test()");
			}
		},
		test:function(){
			Fw.redirect("1040506.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
		},
		/**
		 * 请求失败
		 */
		failure:function(e){
			Fw.Client.alertinfo(e,"消息提示");
		},
		/**
		 * 金额键盘
		 */ 
		showMoneyPicker : function() {
			Fw.Client.showMoneyPicker($("#shfe"));
		},
		/**
		 * 选择审批人
		 */
		initSPR : function() {
			Fw.Client.openPersonnel("App.openPeople");
		},
		openPeople : function(name, id, co) {
			$("#dealUserName").val(name);
			$("#dealUserId").val(id);
			$("#communicateId").val(co);
		},
		/**
		 * 添加附件
		 */
		initTJFJ : function(){
			if(App.attch.length > 5){
				Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
				return;
			}
			Fw.Client.openAttcchment("App.showAttcchment");
		},
		showAttcchment: function(name,url){
			Fw.util.attach.addAttach(name,url);
		},
		toBack:function(){
			Fw.redirect("1040508A.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
		}
};
Fw.onReady(App);