var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		/**
		 * 应用入口
		 */
		init:function(require){
			App.pageA= $("#pageA");
			App.result = Fw.getParameters();
			if (App.result.back=="1040501") {
				App.data=App.result;
			}else{
				App.data=App.result.data.data[0];
			}
			App.initEvent();
			App.attchList = new Array();
			App.attch = new Array();
			App.i=0;
			App.initData();
			App.initCY();
		},
		initEvent:function(){
			//金额
			App.pageA.on("click", "#amount", App.showMoneyPicker);
			//数字键盘
			App.pageA.on("click", "#billNo", App.initShowNumberPicker);
			//提交
			App.pageA.on("click","#btnSubmit",App.submit);
			// 添加附件-事件
			App.pageA.on("click",".TJFJ",App.initTJFJ);
			//初始化办结事件
			App.pageA.on("click","#bj",App.changeBj);
			//初始化转办事件
			App.pageA.on("click","#zb",App.changeZb);
			// 加载点击选择审批人-事件
			App.pageA.on("click", "#XZSPR", App.initSPR);
			App.pageA.on("click", "#HKZH", App.initZH);
			//产品协议书
			App.pageA.on("click", "#cpxys", App.onCpxys);
		},
		onCpxys:function(){
			App.result.go="1040502";
			var html=protocol.productCode(App.data.productCode);
			var json = {
					amount:$("#amount").val(),
					HKJE:$("#HKJE").val(),
					memo:$("#memo").val(),
					KYYE:$("#KYYE").html(),
					fromAcctName:$("#fromAcctName").val(),
					fromAcctNo:$("#fromAcctNo").val(),
					attach:App.attch,
					url:App.url,
					length:App.attch.length,
					dealUserName:$("#dealUserName").val(),
					dealUserId:$("#dealUserId").val(),
					checked:$("#ty").is(":checked")
				};
			App.result.json=json;
			Fw.redirect(html+"?No=1040502B",App.result);
		},
		/**
		 * 汇款账户
		 */
		initCY : function() {
			var url = YT.dataUrl("private/findAcctList");
			YT.ajaxData(url, {}, function(data) {
				if (data.STATUS == "1") {
					App.datas = new Array();
					for ( var i = 0; i < data.datels.length; i++) {
						App.datas.push({
							account : data.datels[i].account.acctNo,
							balance : data.datels[i].response.kyye,
							accountName:data.datels[i].response.khmc
							
						});
					}
					Fw.Client.hideWaitPanel();
				}else{
					Fw.Client.hideWaitPanel();
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
				}
			}, function() {
				alert("");
			});
		},
		/**
		 * 显示账户
		 */
		initZH : function() {
			var gmAmount = $("#HKJE").val().replace(/\s/g,"");
			if(gmAmount==""||gmAmount==null){
				Fw.Form.showPinLabel($(this), "购买金额不能为空", true);
				return;
			}
			var json = {
					jsonArray : App.datas,
					"func" : "App.showCommonlyUsedAccount"
				};
			Fw.Client.hideWaitPanel();
			Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
		},
		/**
		 * 账户回显
		 */
		showCommonlyUsedAccount : function(account,balances,name) {
			var balance = parseFloat(balances);
			$("#fromAcctNo").val(account);
			$("#KYYE").html("可用余额" + Fw.util.Format.fmtAmt(balance+"") + "元");
			$("#fromAcctName").val(name);
			Fw.Client.hideWaitPanel();
		},
		/**
		 * 加载数据
		 */
		initData:function(){
			App.result = Fw.getParameters();
			App.data=App.result;
			if (App.data.go=="1040502") {
				$("#amount").val(App.data.json.amount);
				$("#capsAmount").html(Fw.util.Format.fmtNumber2Chinese(App.data.json.HKJE));
				$("#HKJE").val(App.data.json.HKJE);
				$("#fromAcctNo").val(App.data.json.fromAcctNo);
				$("#KYYE").html(App.data.json.KYYE);
				$("#fromAcctName").val(App.data.json.fromAcctName);
				$("#memo").val(App.data.json.memo);
				$("#dealUserId").val(App.data.json.dealUserId);
				$("#dealUserName").val(App.data.json.dealUserName);
				var attach = App.data.json.attach;
				var url = App.data.json.url;
				for ( var k = 0; k < App.data.json.length; k++) {
					if(attach[k] != null){
						App.showAttcchment(attach[k].name,url);
					}
				}
				App.data.go=="";
				if(App.data.json.checked){
					$("#ty").attr("checked","checked");
				}else{
					$("#ty").removeAttr("checked");
				}
			}
			if (App.data.back=="1040503") {
				App.data=App.result.data.data[App.result.i];
			}
			if(protocol.productCode(App.data.productCode)=='protocol4.html'){
				$("#yieldRate").html("七日年化收益率");
			}
			if(protocol.productCode(App.data.productCode)=='protocol4.html'){
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.yieldRate));
			}else{
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.referYieldRate));
			}
//			$("#sy").html(Fw.util.Format.fmtPercent(App.data.referYieldRate));
			$("#ZDAmount").html(Fw.util.Format.fmtAmt(App.data.purAmountMin+"")+"元");
			$("#ZGAmount").html(Fw.util.Format.fmtAmt(App.data.holdShareMax+"")+"元");
			$("#dz").html(Fw.util.Format.fmtAmt(App.data.purAmountInc+"")+"元");
			$("#MC").html(App.data.productName);
			$("#bz").html(Fw.util.Format.fmtbz(App.data.salesCurrency)+"理财");
			if(!App.data.purchaseRate){
				App.data.purchaseRate=0;
			}
			YT.showPageArea(App.pageA, [], true);
			$("#memo").blur();
			Fw.Client.hideWaitPanel();
		},
		/**
		 * 选择审批人
		 */
		initSPR : function() {
			Fw.Client.openPersonnel("App.openPeople");
		},
		openPeople : function(name, id, co) {
			$("#dealUserName").val(name);
			$("#dealUserId").val(id);
			$("#communicateId").val(co);
		},
		/**
		 * 金额键盘
		 */ 
		showMoneyPicker : function() {
			Fw.Client.showMoneyPicker($("#amount"));
		},
		/**
		 * 办结
		 */
		changeBj : function() {
			$("#bj").removeClass("yui-backgroud-a");
			$("#bj").addClass("yui-backgroud-a1");
			$("#zb").removeClass("yui-backgroud-b1");
			$("#zb").addClass("yui-backgroud-b");
			$("#XZSPR").addClass("hidden");
			$("#trsStatus").val("0");
			
		},
		/**
		 * 转办
		 */
		changeZb : function() {
			$("#zb").removeClass("yui-backgroud-b");
			$("#zb").addClass("yui-backgroud-b1");
			$("#bj").removeClass("yui-backgroud-a1");
			$("#bj").addClass("yui-backgroud-a");
			$("#XZSPR").removeClass("hidden");
			$("#trsStatus").val("1");
			
		},
		/**
		 * 添加附件
		 */
		initTJFJ : function(){
			if(App.attch.length > 5){
				Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
				return;
			}
			Fw.Client.openAttcchment("App.showAttcchment");
		},
		showAttcchment: function(name,url){
			Fw.util.attach.addAttach(name,url);
		},
		
		submit:function(){
			//校验页面数据
			var SKR = $("#fromAcctName").val();
			var SKZH = $("#fromAcctNo").val();
			var zdAmount = App.data.purAmountMin;
			var dzAmount = App.data.purAmountInc;
			var zgAmount = App.data.holdShareMax;
			var gmAmount =$("#HKJE").val().replace(/\s/g,"");
			var memo = $("#memo").val().replace(/\s/g,"");
			var dealUserName = $("#dealUserName").val();
			var dealUserId = $("#dealUserId").val();
			var closingDate = "";
			var communicateId = $("#communicateId").val();
			if(gmAmount==""||gmAmount==null){
				Fw.Form.showPinLabel($(this), "购买金额不能为空", true);
				return;
			}
			if(gmAmount==0){
				Fw.Form.showPinLabel($(this), "最低购买金额不能为0", true);
				return;
			}
			if(zgAmount<gmAmount){
				Fw.Form.showPinLabel($(this), "购买金额超过购买上限", true);
				return;
			}
			if(SKZH==""||SKR==""){
				Fw.Form.showPinLabel($(this), "选择购买账号", true);
				return;
			}
			
			//备注是否包含表情
			if(Fw.util.proofTest.proolEmoji(memo)){
				Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
				return;
			}
			
			//产品说明书
			if($("#ty:checked").val()==null){
				Fw.Form.showPinLabel($(this), "请勾选理财产品协议书", true);
				return;
			}
			if($("#trsStatus").val()==""||$("#trsStatus").val()==null){
				Fw.Form.showPinLabel($(this), "请选择操作类型", true);
				return;
			}
			if ($("#trsStatus").val() == "1") {
				if (dealUserId == "") {
					Fw.Client.hideWaitPanel();
					Fw.Form.showPinLabel($(this), "请选择审批人", true);
					return;
				}
			}
			
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			Fw.Client.openWaitPanel("提交中...");

			// 判断发起人是不是有效必经人
			if ($("#trsStatus").val() == "0") {
				var url = YT.dataUrl("public/getRandomNum");
				YT.ajaxData(url, {}, function(data) {
					if (data.STATUS == "1") {
						var url = YT.dataUrl("private/isEffective");
						var json = {
							trsType : "5",
							amount : gmAmount,
							bizNo : "5",
							TOKEN : data.randomNum,
							flag : "2"
						};
						YT.ajaxData(url, json, function(suc) {
								if (suc.isEffective == "YES") {
									//办结
									App.initComplete1();
								} else {
									App.flag = false;
									Fw.Form.showPinLabel($(this), "您的权限不足,请转办",
											true);
									Fw.Client.hideWaitPanel();
									return;
								}
						}, App.call);
					} else {
						App.flag = false;
						Fw.Client.alertinfo(data.MSG, "消息提示");
					}
				});
			}
			// 转办
			if ($("#trsStatus").val() == "1") {
				var url = YT.dataUrl("public/getRandomNum");
				YT.ajaxData(url, {}, function(data) {
					if (data.STATUS == "1") {
						var url = "private/financtTask.json";
						var jsons = {
								"type":"1",
								"share":gmAmount,
								"rate":App.data.purchaseRate+"",
								"transCode":"SUB",
								"financeType":"2",
								"trsType":"5",
								"closingDate":"",
								"memo" : memo,
								"acctName":SKR,
								"acctNo":SKZH,
								"bankName":"",
								"dealUserName" : dealUserName,
								"dealUserId" : dealUserId,
								"toCommunicateId":communicateId,
								"TOKEN" : data.randomNum,
								"maturityDate":App.data.maturityDate,
								"productCode":App.data.productCode,
								"amount":gmAmount
						};
						Fw.Client.post(url, jsons, "App.success","App.failuriBack");
					} else {
						App.flag = false;
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG, "消息提示");
					}
				});
			}
		},
		/**
		 * 转办新建成功后
		 */
		success : function(datas) {
			if (datas.STATUS == "1") {
				var url = YT.dataUrl("private/oprtFile");
				var params = {
					trsNo : datas.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
				};
				YT.ajaxData(url, params, function(success) {
				});
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo("已提交下一个处理人：" + $("#dealUserName").val(), "提交成功","App.test()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(datas.MSG, "消息提示");
				return;
			}
		},
		/**
		 * 转办成功后
		 */
		test : function() {
			Fw.Client.changePage("1040506.html", true);
		},
		// 办结
		initComplete1 : function() {
			App.flag = false;
			var params = {
					"type":"1",
					"share":$("#HKJE").val().replace(/\s/g,""),
					"rate":App.data.purchaseRate+"",
					"transCode":"SUB",
					"financeType":"2",
					"trsType":"5",
					"closingDate":"",
					"memo" : $("#memo").val().replace(/\s/g,""),
					"acctName":$("#fromAcctName").val(),
					"acctNo":$("#fromAcctNo").val(),
					"bankName":"",
					"maturityDate":App.data.maturityDate,
					"productCode":App.data.productCode,
					"amount":$("#HKJE").val().replace(/\s/g,""),
					"FileNameList" : App.attch,
					"FileUrl" : App.url,
					"isComplete" : "1"
					
			};
			var url = "private/financtTask.json";
			Fw.Client.post(url, params, "App.initCommonAcct");
		},
		/**
		 * 办结成功
		 */
		initCommonAcct : function(data) {
			if (data.STATUS == "1") {
				App.trsNo = data.trsNo;
				var url = YT.dataUrl("private/oprtFile");
				var params = {
					trsNo : data.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
				};
				YT.ajaxData(url, params, function(success) {
				});
				var amount = Fw.util.Format.replaceDouble("1", $("#HKJE").val());
				App.onNext();
				Fw.Client.hideWaitPanel();
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG, "消息提示");
				return;
			}
		},
		onNext : function() {
			var json = {
					func : "App.initComplete",
					funcAndroid:"App.initCompleteAndroid",
					type : "2",
					toName:"兴业银行",
					toAcc:"",
					fromName:$("#fromAcctName").val(),//付款名称
					fromAcc:$("#fromAcctNo").val(),//付款账号
					purpose:"",//用途
					xmlMoney:$("#HKJE").val().replace(/\s/g,""),//金额
					xmlNo:App.trsNo,//流水账号
					funcBack:"App.tobackList"
				};
			Fw.Client.hideWaitPanel();
			Fw.Client.showBB(json);
//			App.initBJ("","",$("#fromAcctNo").val(),$("#fromAcctName").val(),$("#purpose").val());
		},
		/**
		 * PIN 码验证通过iphon
		 */
		initComplete:function(a,b){
			var fromAcctNo = $("#fromAcctNo").val();
			var fromAcctName = $("#fromAcctName").val();
			var purpose = $("#purpose").val();
				Fw.Client.openWaitPanel();
				App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
			
		},
		/**
		 * PIN 码验证通过Android
		 */
		initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
			var fromAcctNo = $("#fromAcctNo").val();
			var fromAcctName = $("#fromAcctName").val();
			var purpose = $("#purpose").val();
			App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
		},
		tobackList:function(){
			Fw.Client.changePage("1040506.html","0");
		},
		/**
		 * 直接办结
		 */
		initBJ:function(a,b,acctNo,acctName,purpos){
				var params = {
					type:"2",
					transCode:"PUR",
					trsNo : App.trsNo,
					cpdm:App.data.productCode,
					fromAcctNo:acctNo,
					fromAcctName:acctName,
					zhdh:acctNo,
					jyje:$("#HKJE").val().replace(/\s/g,""),
					yddh:"",
					dealMsg:"",
					purpose : purpos,
					signData:a,
					signSrc:b
				};
				var url = "private/financtTask.json";
				Fw.Client.openWaitPanel();
				Fw.Client.post(url,params,"App.success1","App.failuri");
		},
		/**
		 * 直接办结成功回调函数
		 */
		success1:function(data){
				if (data.STATUS == "1") {
					App.data.cpmc = App.data.productName;
					App.data.acctNo = data.fromAcctNo;
					App.data.trsNo = data.trsNo;
					App.data.amount = data.jyje;
					App.data.ywslbh = data.ywslbh;
					App.data.transDate = data.transDate;
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG,"消息提示","App.testA()");
				} else {
					App.flag = false;
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(data.MSG,"消息提示","App.testB()");
				}
		},
		testA:function(){
			Fw.redirect("1040502_gmpz.html",App.data);
		},
		/**
		 * 失败回调函数
		 */
		failuri:function(e){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(e,"消息提示");
		},
		testB:function(){
			Fw.redirect("1040506.html","");
		},
		
		/**
		 * 返回函数
		 */
		toBack:function(){
			App.result.go="";
			if (App.result.back=="1040503") {
				Fw.redirect("1040503.html",App.result);
			}else{
				Fw.redirect("1040501.html",App.result);
			}
		}
};
Fw.onReady(App);