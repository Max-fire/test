/**
 * 创建应用
 * 
 * @author cuijunhui
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, [], true);
		App.flag = true;
		// 初始化事件
		App.initEvent();
		// 初始化默认加载数据
		if(App.func("trsStatus")){
			switch (App.func("trsStatus")) {
			case '0':
				App.onCLZ();
				break;
			case '1':
				App.onYBJ();
				break;
			case '2':
				App.onYTH();
				break;
			default:
				break;
			}
			
		}else{
			App.onCLZ();
		}
	},
	// 初始化事件
	initEvent : function() {
		// 已办结按钮
		App.pageA.on("click", "#liYBJ", App.onYBJ);
		// 处理中按钮
		App.pageA.on("click", "#liCLZ", App.onCLZ);
		// 已退回按钮
		App.pageA.on("click", "#liYTH", App.onYTH);
		//标题点击事件
		App.pageA.on("click","#icon-top",App.onTop);
		//我处理的点击事件
		App.pageA.on("click","#btnIconc",App.initWCLD);
	},
	/**
	 * 标题点击事件,收起展开
	 */
	onTop:function(){
		if(App.flag){
			$("#top-center").addClass("hidden");
			$("#top-bottom").removeClass("yui-background-top").addClass("yui-background-topB");
			$("#tab-navnew").removeClass("yui-ui-tab-navnew").addClass("yui-ui-tab-navnewB");
			$("#top-bg").removeClass("yui-height170").addClass("yui-height70");
			$("#icon-topA").removeClass("yui-background-top1").addClass("yui-background-top2");
			App.flag = false;
		}else{
			$("#top-bg").removeClass("yui-height70").addClass("yui-height170");
			$("#top-bottom").removeClass("yui-background-topB").addClass("yui-background-top");
			$("#tab-navnew").removeClass("yui-ui-tab-navnewB").addClass("yui-ui-tab-navnew");
			$("#top-center").removeClass("hidden");
			$("#icon-topA").removeClass("yui-background-top2").addClass("yui-background-top1");
			App.flag = true;
		};
	},
	/**
	 * 标题我处理的
	 */
	initWCLD:function(){
		$("#btnIconb").removeClass("yui-backgroud-iconb").addClass("yui-backgroud-iconbb");
		$("#colIconb").removeClass("yui-font-col1").addClass("yui-font-col2");
		$("#btnIconc").removeClass("yui-backgroud-iconcc").addClass("yui-backgroud-iconc");
		$("#colIconc").removeClass("yui-font-col2").addClass("yui-font-col1");
		Fw.Client.changePage("1040507.html","0");
	},
	
	// 查询日期
	showSendTime : function() {
		// 0查询1签发
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
		};
		// 查询
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		App.query();
	},
	// 已办结
	onYBJ : function() {
		Fw.Client.openWaitPanel();
		App.pageA.off("click", "#liYBJ", App.onYBJ);
		App.pageA.off("click", "#liCLZ", App.onCLZ).on("click", "#liCLZ", App.onCLZ);
		App.pageA.off("click", "#liYTH", App.onYTH).on("click", "#liYTH", App.onYTH);
		App.pageA.attr("data-btnRight","true|时间|App.showSendTime()");
		$("#t").attr("class", "yui-background-3 yui-background");
		$("#liYTH").removeClass("current yui-current");
		//处理中
		$("#d").attr("class", "yui-background-4 yui-background");
		$("#liCLZ").removeClass("current yui-current");
		//已办结
		$("#y").attr("class", "yui-background-5 yui-background");
		$("#liYBJ").addClass("current yui-current");
		App.trsStatus = "1";
		App.beginTime ="";
		App.endTime ="";
		App.query();
	},
	// 处理中
	onCLZ : function() {
		Fw.Client.openWaitPanel();
		App.pageA.off("click", "#liYBJ", App.onYBJ).on("click", "#liYBJ", App.onYBJ);
		App.pageA.off("click", "#liCLZ", App.onCLZ);
		App.pageA.off("click", "#liYTH", App.onYTH).on("click", "#liYTH", App.onYTH);
		App.pageA.attr("data-btnRight","true|时间|App.showSendTime()");
		//已退回
		$("#t").attr("class", "yui-background-3 yui-background");
		$("#liYTH").removeClass("current yui-current");
		//已办结
		$("#y").attr("class", "yui-background-2 yui-background");
		$("#liYBJ").removeClass("current yui-current");
		//处理中
		$("#d").attr("class", "yui-background-1 yui-background");
		$("#liCLZ").addClass("current yui-current ");
		App.trsStatus = "0";
		App.beginTime ="";
		App.endTime ="";
		App.query();
		
	},
	// 已退回
	onYTH : function() {
		Fw.Client.openWaitPanel();
		App.pageA.off("click", "#liYBJ", App.onYBJ).on("click", "#liYBJ", App.onYBJ);
		App.pageA.off("click", "#liCLZ", App.onCLZ).on("click", "#liCLZ", App.onCLZ);
		App.pageA.off("click", "#liYTH", App.onYTH);
		App.pageA.attr("data-btnRight","false|时间|App.showSendTime()");
		//处理中
		$("#d").attr("class", "yui-background-4 yui-background");
		$("#liCLZ").removeClass("current yui-current");
		//已办结
		$("#y").attr("class", "yui-background-2 yui-background");
		$("#liYBJ").removeClass("current yui-current");
		//已退回
		$("#t").attr("class", "yui-background-6 yui-background");
		$("#liYTH").addClass("current yui-current");
		App.trsStatus = "2";
		App.beginTime ="";
		App.endTime ="";
		App.query();
	},
	query : function() {
		var html = "";
		html+='<div class="ui-form yui-ma yui-boder-radu yui-bg-backgrount">';
		html+='<div class="yui-list-01" >';
		html+='<b style="display: inline-block; width: 70%;border-color: red; white-space:  nowrap; overflow: hidden; "  class="ui-nowrap">${item.productName}</b>';
		html+=' <span class="yui-cBlue${item.trsStatus}">${item.trsStatus|fmtStatus}</span>';
		html+='</div> ';
		html+='<div class="yui-list-05">';
		html+='{@if item.finaType==1}';
		html+=' <span>理财认购</span>';
		html+='{@else if item.finaType==2}';
		html+=' <span>理财申购</span>';
		html+='{@else if item.finaType==3}';
		html+=' <span>理财赎回</span>';
		html+='{@/if}';
		html+='	 <i class="yui-cOrange"><b class="yui-cOrange">${item.amountFina+""|fmtAmt}元</b></i>';
		html+='</div> ';
		html+='<div class="yui-list-04">';
		html+='	 <div class="ui-bg-ss3">${item.dealMsg}</div>';
		html+='</div>	';
		html+='	<div class="yui-list-03" >';
		html+='	<i>${item.trsCreTime|fmtTrsCreDate}</i>';
		html+='	<span>当前处理人:${item.dealUserName}</span>';
		html+='</div> ';
		html+='</div>';
		var json = {
			trsType: "5",
			trsStatus: App.trsStatus,
			timeBegin : App.beginTime,
			timeEnd :App.endTime
		};
		var url = YT.dataUrl("private/findTaskOfSended");
		var listView = App.listView = new Fw.ListView({
			contentEl : "list",
			dataField : "datas",
			page : true,
			pageSize:5,
			disclosure : true,
			ajax : {
				url : url,
				params : json
			},
			itemTpl : html,
			custFmtFuncs : {	
				showMonth : App.showMonth,
				fmtMonth : App.fmtMonth
			}
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(App.trsStatus);
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		var page = pageIndex || 1;
		Fw.Client.hideWaitPanel();
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	// 显示详情
	showDetail : function(itemData, itemIndex, itemElem) {
		if(itemData.finaType=="1"||itemData.finaType=="2"){
			Fw.Client.changePage("1040508.html?trsNo="+itemData.trsNo+"&trsStatus="+itemData.trsStatus+"");
		}else{
			Fw.Client.changePage("1040508A.html?trsNo="+itemData.trsNo+"&trsStatus="+itemData.trsStatus+"");
			
		}
	},
	toBack:function(){
		Fw.Client.changePage("1040500.html","0");
	}
};


Fw.onReady(App);