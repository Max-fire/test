var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		/**
		 * 应用入口
		 */
		init:function(require){
			App.pageA= $("#pageA");
			App.data = Fw.getParameters();
			App.initData();
		
		},
		initData:function(){
			$("#MC").html(App.data.cpmc);
			if (App.data.product) {
				if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
					$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.yieldRate));
				}else{
					$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
				}
				if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
					$("#yieldRate").html("七日年化收益率");
				}
//				$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
				//最低持有
				$("#zdcy").html(Fw.util.Format.fmtAmt(App.data.product.holdShareMin+""));
				//递增份额
				$("#dzfe").html(Fw.util.Format.fmtAmt(App.data.product.redShareInc+""));
				//起赎份额
				if(App.data.product.redShareMin==0){
					$("#jyxq").removeClass("yui-lc-alltitle").addClass("yui-lc-alltitleA");
					$("#qsfeA").addClass("hidden");
				}else{
					$("#qsfe").html(Fw.util.Format.fmtAmt(App.data.product.redShareMin+""));
				}
				$("#jysj").html(Fw.util.Format.fmtDate(App.data.product.transStartDate)+"-"+Fw.util.Format.fmtDate(App.data.product.transEndDate));
			}else{
				if(protocol.productCode(App.data.productCode)=='protocol4.html'){
					$("#sy").html(Fw.util.Format.fmtPercent(App.data.yieldRate));
				}else{
					$("#sy").html(Fw.util.Format.fmtPercent(App.data.referYieldRate));
				}
				if(protocol.productCode(App.data.productCode)=='protocol4.html'){
					$("#yieldRate").html("七日年化收益率");
				}
//				$("#sy").html(Fw.util.Format.fmtPercent(App.data.referYieldRate));
				//最低持有
				$("#zdcy").html(Fw.util.Format.fmtAmt(App.data.holdShareMin+""));
				//递增份额
				$("#dzfe").html(Fw.util.Format.fmtAmt(App.data.redShareInc+""));
				//起赎份额
				if(App.data.redShareMin==0){
					$("#jyxq").removeClass("yui-lc-alltitle").addClass("yui-lc-alltitleA");
					$("#qsfeA").addClass("hidden");
				}else{
					$("#qsfe").html(Fw.util.Format.fmtAmt(App.data.redShareMin+""));
				}
				$("#jysj").html(Fw.util.Format.fmtDate(App.data.transStartDate)+"-"+Fw.util.Format.fmtDate(App.data.transEndDate));
				
			}
			
			$("#ze").html(Fw.util.Format.fmtAmt(App.data.shfe));
			$("#shfe1").html(Fw.util.Format.fmtAmt(App.data.shfe));
			$("#ywls").html(Fw.util.Format.subTrsNo(App.data.trsNo));
			$("#slbh").html(App.data.ywslbh);
			$("#jylx").html("赎回");
			$("#toAcctNo").html(App.data.acctNo);
			$("#jysj1").html(Fw.util.Format.fmtTrsCreDate(App.data.transDate,"yyyy-MM-dd HH : mm :ss"));
			YT.showPageArea(App.pageA, [], true);
			Fw.Client.hideWaitPanel();
		},
		/**
		 * 保存凭证
		 */
		initBC: function(){
			var cfg = "App.initSuccess";
			Fw.Client.openScrrenShot(cfg);
		},
		initSuccess:function(success){
			if(success){
				Fw.Form.showPinLabel($(this), "凭证成功保存到相册", true);
				return;
			}else{
				Fw.Form.showPinLabel($(this), "凭证保存失败", true);
				return;
			}
		},
		toBack:function(){
			if (App.data.page) {
				Fw.redirect(App.data.page,App.data);
			}else{
				if(App.data.trsId!= undefined&&App.data.trsId != ""&&App.data.trsId!=null){
					Fw.Client.dealMessage("2",App.data.trsId);
				}else if(App.data.no=="07"){
					Fw.Client.changePage("1040507.html",true);
				}else{
					Fw.Client.changePage("1040506.html",true);
					
				}
			}
		}
};
Fw.onReady(App);	