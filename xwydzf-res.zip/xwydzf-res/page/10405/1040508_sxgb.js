var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		/**
		 * 应用入口
		 */
		init:function(require){
			App.pageA= $("#pageA");
			App.data = Fw.getParameters();
			App.func = window['_getParameter'];
			App.attch = new Array();
			App.attchList = new Array();
			App.i=0;
			App.initEvent();
			App.initData();
		},
		initEvent:function(){
			//初始化办结事件
			App.pageA.on("click","#bj",App.changeBj);
			//初始化转办事件
			App.pageA.on("click","#zb",App.changeZb);
			// 加载点击选择审批人-事件
			App.pageA.on("click", "#XZSPR", App.initSPR);
			// 添加附件-事件
			App.pageA.on("click",".TJFJ",App.initTJFJ);
			//赎回
			App.pageA.on("click", "#btnSubmit", App.submit);
			//数字键盘
			App.pageA.on("click", "#shfe", App.initShowNumberPicker);
		},
		/**
		 * 数字键盘
		 */
		initShowNumberPicker:function(){
			Fw.Client.showNumberPickerOne($("#shfe"));
		},
		/**
		 * 加载数据
		 */
		initData:function(){
			App.cpmc = App.data.trsFinance[0].shortName;
			$("#MC").html(App.data.trsFinance[0].shortName);
			$("#accNo").html(App.data.trsFinance[0].fromAcctNo);
//			$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
			if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.yieldRate));
			}else{
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.product.referYieldRate));
			}
			if(protocol.productCode(App.data.product.productCode)=='protocol4.html'){
				$("#yieldRate").html("七日年化收益率");
			}
			//最低持有
			$("#zdcy").html(Fw.util.Format.fmtAmt(App.data.product.holdShareMin+""));
			//赎回递增份额
			$("#shdz").html(Fw.util.Format.fmtAmt(App.data.product.redShareInc+""));
			//起赎份额
			if(App.data.product.redShareMin==0){
				$("#jyxq").removeClass("yui-lc-alltitle").addClass("yui-lc-alltitleA");
				$("#qsfeA").addClass("hidden");
			}else{
				$("#qsfe").html(Fw.util.Format.fmtAmt(App.data.product.redShareMin+""));
			}
			$("#jysj").html(Fw.util.Format.fmtDate(App.data.product.transStartDate)+"-"+Fw.util.Format.fmtDate(App.data.product.transEndDate));
			//备注
			$("#memo").html(App.data.trsFinance[0].memo);
			//赎回份额
			$("#shfe").val(App.data.trsFinance[0].financeShare);
			$("#HKJE").val(App.data.trsFinance[0].financeShare);
			if(!App.data.product.redeemRate){
				App.data.product.redeemRate=0;
			}
			YT.showPageArea(App.pageA, [], true);
			$("#memo").blur();
			Fw.Client.hideWaitPanel();
		},
		// 显示附件
		showFj:function( d ){
			Fw.util.attach.showAttach( d );
		},
		/**
		 * 选择审批人
		 */
		initSPR : function() {
			Fw.Client.openPersonnel("App.openPeople");
		},
		openPeople : function(name, id, co) {
			$("#dealUserName").val(name);
			$("#dealUserId").val(id);
			$("#communicateId").val(co);
		},
		/**
		 * 办结
		 */
		changeBj : function() {
			$("#bj").removeClass("yui-backgroud-a");
			$("#bj").addClass("yui-backgroud-a1");
			$("#zb").removeClass("yui-backgroud-b1");
			$("#zb").addClass("yui-backgroud-b");
			$("#XZSPR").addClass("hidden");
			$("#trsStatus").val("0");
		},
		/**
		 * 转办
		 */
		changeZb : function() {
			$("#zb").removeClass("yui-backgroud-b");
			$("#zb").addClass("yui-backgroud-b1");
			$("#bj").removeClass("yui-backgroud-a1");
			$("#bj").addClass("yui-backgroud-a");
			$("#XZSPR").removeClass("hidden");
			$("#trsStatus").val("1");
		},
		/**
		 * 添加附件
		 */
		initTJFJ : function(){
			if(App.attch.length > 5){
				Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
				return;
			}
			Fw.Client.openAttcchment("App.showAttcchment");
		},
		showAttcchment: function(name,url){
			Fw.util.attach.addAttach(name,url);
		},
		
		submit:function(){
			//校验页面数据
			var memo = $("#memo").val().replace(/\s/g,"");
			//最低赎回份额
			var zd = App.data.product.redShareMin;
			//持有份额
			var cy = App.data.kyfe;
			//最低起购金额
			var zdqg = App.data.product.purAmountMin;
			var gmAmount = $("#shfe").val().replace(/\s/g,"");
			var dealUserName = $("#dealUserName").val();
			var dealUserId = $("#dealUserId").val();
			var closingDate = "";
			var communicateId = $("#communicateId").val();
			var billNo = $("#accNo").html();
			if(gmAmount==null||gmAmount==""){
				Fw.Form.showPinLabel($(this), "请输入赎回份额", true);
				return;
			}
			if(gmAmount=="0"){
				Fw.Form.showPinLabel($(this), "赎回份额不能为零", true);
				return;
			}
			if(gmAmount<zd){
				Fw.Form.showPinLabel($(this), "赎回份额小于最低赎回份额", true);
				return;
			}
			if((gmAmount/cy)>1){
				Fw.Form.showPinLabel($(this), "赎回份数超自身持有量", true);
				return;
			}
			if(Fw.util.proofTest.proolEmoji(memo)){
				Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
				return;
			}
			// 校验是否选择操作类型
			if ($("#trsStatus").val() == "") {
				Fw.Form.showPinLabel($(this), "请选择操作类型", true);
				return;
			}
			// 审批人是否为空
			if ($("#trsStatus").val() == "1") {
				if (dealUserId == "") {
					Fw.Form.showPinLabel($(this), "请选择审批人", true);
					return;
				}
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			Fw.Client.openWaitPanel("提交中...");

			// 判断发起人是不是有效必经人
			if ($("#trsStatus").val() == "0") {
				var url = YT.dataUrl("public/getRandomNum");
				YT.ajaxData(url, {}, function(data) {
					if (data.STATUS == "1") {
						var url = YT.dataUrl("private/isEffective");
						var json = {
							trsType : "5",
							amount : gmAmount,
							bizNo : "5",
							TOKEN : data.randomNum,
							flag : "2"
						};
						YT.ajaxData(url, json, function(suc) {
								if (suc.isEffective == "YES") {
									//办结
									App.initComplete1();
								} else {
									App.flag = false;
									Fw.Form.showPinLabel($(this), "您的权限不足,请转办",
											true);
									Fw.Client.hideWaitPanel();
									return;
								}
						}, App.call);
					} else {
						App.flag = false;
						Fw.Client.alertinfo(data.MSG, "消息提示");
					}
				});
			}
			// 转办
			if ($("#trsStatus").val() == "1") {
				var url = YT.dataUrl("public/getRandomNum");
				YT.ajaxData(url, {}, function(data) {
					if (data.STATUS == "1") {
						var jsons = {
								"type":"1",
								"share":gmAmount,
								"rate":App.data.product.redeemRate+"",
								"transCode":"REDEEN",
								"financeType":"3",
								"trsType":"5",
								"closingDate":"",
								"memo" : memo,
								"acctName":App.data.trsFinance[0].fromAcctName,
								"acctNo":billNo,
								"bankName":"",
								"dealUserName" : dealUserName,
								"dealUserId" : dealUserId,
								"toCommunicateId":communicateId,
								"TOKEN" : data.randomNum,
								"maturityDate":App.data.product.maturityDate,
								"productCode":App.data.product.productCode,
								"amount":gmAmount,
								"fehzls":App.data.trsFinance[0].volSumSerno
								
						};
						var url = YT.dataUrl("private/financtTask");
						YT.ajaxData(url,jsons,App.success,App.failuriBack);
					} else {
						App.flag = false;
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG, "消息提示");
					}
				});
			}
		},
		/**
		 * 转办新建成功后
		 */
		success : function(datas) {
			if (datas.STATUS == "1") {
				var url = YT.dataUrl("private/oprtFile");
				var params = {
					trsNo : datas.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
				};
				YT.ajaxData(url, params, function(success) {
				});
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo("已提交下一个处理人：" + $("#dealUserName").val(), "提交成功","App.test()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(datas.MSG, "消息提示");
				return;
			}
		},
		/**
		 * 转办成功后
		 */
		test : function() {
			Fw.redirect("1040506.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
		},
		// 办结
		initComplete1 : function() {
			var params = {
					"type":"1",
					"share":$("#shfe").val().replace(/\s/g,""),
					"rate":App.data.product.redeemRate+"",
					"transCode":"REDEEN",
					"financeType":"3",
					"trsType":"5",
					"closingDate":"",
					"memo" : $("#memo").val().replace(/\s/g,""),
					"acctName":App.data.trsFinance[0].fromAcctName,
					"acctNo":$("#accNo").html(),
					"bankName":"",
					"maturityDate":App.data.product.maturityDate,
					"productCode":App.data.product.productCode,
					"FileNameList" : App.attch,
					"FileUrl" : App.url,
					"isComplete" : "1",
					"amount":"0",
					"fehzls":App.data.trsFinance[0].volSumSerno
			};
			var url = YT.dataUrl("private/financtTask");
			YT.ajaxData(url,params,App.initCommonAcct);
		},
		/**
		 * 办结成功
		 */
		initCommonAcct : function(data) {
			if (data.STATUS == "1") {
				var url = YT.dataUrl("private/oprtFile");
				App.trsNo =data.trsNo;
				var params = {
					trsNo : data.trsNo,
					FileUrl : App.url,
					FileNameList : App.attch
				};
				YT.ajaxData(url, params, function(success) {
				});
				var amount = Fw.util.Format.replaceDouble("1", $("#HKJE").val());
				var dealMsg = $("#dealMsg").val();
				if(dealMsg){
					App.dealMsg = dealMsg;
				}else{
					App.dealMsg="同意";
				}
				App.initBJ();
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG, "消息提示");
				return;
			}
		},
		/**
		 * 直接办结
		 */
		initBJ:function(){
				var params = {
					type:"2",
					transCode:"REDEEN",
					trsNo : App.trsNo,
					cpdm:App.data.product.productCode,
					fromAcctNo:App.data.trsFinance[0].fromAcctNo,
					fromAcctName:App.data.trsFinance[0].fromAcctName,
					zhdh:App.data.trsFinance[0].fromAcctNo,
					shfe:$("#shfe").val().replace(/\s/g,""),
					yddh:"",
					dealMsg:"",
					fehzls:App.data.trsFinance[0].volSumSerno
				};
				var url = YT.dataUrl("private/financtTask");
				Fw.Client.openWaitPanel();
				YT.ajaxData(url,params,App.success1,App.failuri);
				
		},
		/**
		 * 直接办结成功回调函数
		 */
		success1:function(data){
				if (data.STATUS == "1") {
					App.data.cpmc = App.cpmc;
					App.data.trsNo = data.trsNo;
					App.data.shfe = data.shfe;
					App.data.ywslbh = data.ywslbh;
					App.data.acctNo = data.fromAcctNo;
					App.data.transDate = data.transDate;
					Fw.Client.alertinfo(data.MSG,"消息提示","App.test1()");
					Fw.Client.hideWaitPanel();
				} else {
					App.flag = false;
					Fw.Client.alertinfo(data.MSG,"消息提示","App.initFail()");
					Fw.Client.hideWaitPanel();
				}
		},
		/**
		 * 失败回调函数
		 */
		failuri:function(e){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(e,"消息提示");
			Fw.redirect("1040506.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
		},
		/**
		 * 办结成功
		 */
		test1:function(){
			Fw.Client.hideWaitPanel();
			Fw.redirect("1040505_shpz.html",App.data);
		},
		/**
		 * 失败回到待办列表
		 */
		initFail: function(){
			Fw.redirect("1040506.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
		},
		/**
		 * 返回函数
		 */
	    toBack:function(){
			Fw.redirect("1040508A.html?trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
			
		}
};
Fw.onReady(App);