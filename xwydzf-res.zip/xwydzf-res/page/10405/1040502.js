var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		/**
		 * 应用入口
		 */
		init:function(require){
			App.pageA= $("#pageA");
			App.attchList = new Array();
			App.attch = new Array();
			App.i=0;
			App.initEvent();
			App.initData();
			App.initCY();
		},
		initEvent:function(){
			//金额
			App.pageA.on("click", "#amount", App.showMoneyPicker);
			//提交
			App.pageA.on("click","#btnSubmit",App.submit);
			// 添加附件-事件
			App.pageA.on("click",".TJFJ",App.initTJFJ);
			//初始化办结事件
			App.pageA.on("click","#bj",App.changeBj);
			//初始化转办事件
			App.pageA.on("click","#zb",App.changeZb);
			// 加载点击选择审批人-事件
			App.pageA.on("click", "#SPR", App.initSPR);
			App.pageA.on("click", "#HKZH", App.initZH);
			//产品协议书
			App.pageA.on("click", "#cpxys", App.onCpxys);
		},
		onCpxys:function(){
			var html=protocol.productCode(App.data.productCode);
			App.result.go="1040502";
			var json = {
					amount:$("#amount").val(),
					HKJE:$("#HKJE").val(),
					memo:$("#memo").val(),
					KYYE:$("#KYYE").html(),
					fromAcctName:$("#fromAcctName").val(),
					fromAcctNo:$("#fromAcctNo").val(),
					attach:App.attch,
					url:App.url,
					length:App.attch.length,
					dealUserName:$("#dealUserName").val(),
					dealUserId:$("#dealUserId").val(),
					checked:$("#ty").is(":checked")
				};
			App.result.json=json;
			Fw.redirect(html+"?No=1040502",App.result);
		},
		/**
		 * 加载数据
		 */
		initData:function(){
			App.result = Fw.getParameters();
			App.data=App.result;
			if (App.data.go=="1040502") {
				$("#amount").val(App.data.json.amount);
				$("#HKJE").val(App.data.json.HKJE);
				$("#fromAcctNo").val(App.data.json.fromAcctNo);
				$("#KYYE").html(App.data.json.KYYE);
				$("#fromAcctName").val(App.data.json.fromAcctName);
				$("#memo").val(App.data.json.memo);
				$("#dealUserId").val(App.data.json.dealUserId);
				$("#dealUserName").val(App.data.json.dealUserName);
				var attach = App.data.json.attach;
				var url = App.data.json.url;
				for ( var k = 0; k < App.data.json.length; k++) {
					if(attach[k] != null){
						App.showAttcchment(attach[k].name,url);
					}
				}
				App.data.go=="";
				if(App.data.json.checked){
					$("#ty").attr("checked","checked");
				}else{
					$("#ty").removeAttr("checked");
				}
			}
			if (App.data.back=="1040503") {
				App.data=App.result.data.data[App.result.i];
			}
			if(protocol.productCode(App.data.productCode)=='protocol4.html'){
				$("#yieldRate").html("七日年化收益率");
			}
			if(protocol.productCode(App.data.productCode)=='protocol4.html'){
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.yieldRate));
			}else{
				$("#sy").html(Fw.util.Format.fmtPercent(App.data.referYieldRate));
			}
//			$("#sy").html(Fw.util.Format.fmtPercent(App.data.referYieldRate));
			$("#ZDAmount").html(Fw.util.Format.fmtAmt(App.data.purAmountMin+"")+"元");
			$("#ZGAmount").html(Fw.util.Format.fmtAmt(App.data.holdShareMax+"")+"元");
			$("#dz").html(Fw.util.Format.fmtAmt(App.data.purAmountInc+"")+"元");
			$("#MC").html(App.data.productName);
			$("#bz").html(Fw.util.Format.fmtbz(App.data.salesCurrency)+"理财");
			if(!App.data.purchaseRate){
				App.data.purchaseRate=0;
			}
			YT.showPageArea(App.pageA, [], true);
			$("#memo").blur();
			Fw.Client.hideWaitPanel();
		},
		/**
		 * 汇款账户
		 */
		initCY : function() {
			var url = YT.dataUrl("private/findAcctList");
			YT.ajaxData(url, {}, function(data) {
				if (data.STATUS == "1") {
					App.datas = new Array();
					for ( var i = 0; i < data.datels.length; i++) {
						App.datas.push({
							account : data.datels[i].account.acctNo,
							balance : data.datels[i].response.kyye,
							accountName:data.datels[i].response.khmc
						});
					}
					Fw.Client.hideWaitPanel();
				}else{
					Fw.Client.hideWaitPanel();
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
				}
			}, function() {
				Fw.Form.showPinLabel($(this), data.MSG, true);
			});
		},
		/**
		 * 显示账户
		 */
		initZH : function() {
			var gmAmount = $("#HKJE").val().replace(/\s/g,"");
			if(gmAmount==""||gmAmount==null){
				Fw.Form.showPinLabel($(this), "购买金额不能为空", true);
				return;
			}
			var json = {
					jsonArray : App.datas,
					"func" : "App.showCommonlyUsedAccount"
				};
			Fw.Client.hideWaitPanel();
			Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
		},
		/**
		 * 账户回显
		 */
		showCommonlyUsedAccount : function(account,balances,name) {
			var balance = parseFloat(balances);
			$("#fromAcctNo").val(account);
			$("#KYYE").html("可用余额" + Fw.util.Format.fmtAmt(balance+"") + "元");
			$("#fromAcctName").val(name);
			Fw.Client.hideWaitPanel();
		},
		/**
		 * 选择审批人
		 */
		initSPR : function() {
			Fw.Client.openPersonnel("App.openPeople");
		},
		openPeople : function(name, id, co) {
			$("#dealUserName").val(name);
			$("#dealUserId").val(id);
			$("#communicateId").val(co);
		},
		/**
		 * 金额键盘
		 */ 
		showMoneyPicker : function() {
			Fw.Client.showMoneyPicker($("#amount"));
		},
		/**
		 * 办结
		 */
		changeBj : function() {
			$("#bj").removeClass("yui-backgroud-a");
			$("#bj").addClass("yui-backgroud-a1");
			$("#zb").removeClass("yui-backgroud-b1");
			$("#zb").addClass("yui-backgroud-b");
			$("#XZSPR").addClass("hidden");
			$("#trsStatus").val("0");
		},
		/**
		 * 转办
		 */
		changeZb : function() {
			$("#zb").removeClass("yui-backgroud-b");
			$("#zb").addClass("yui-backgroud-b1");
			$("#bj").removeClass("yui-backgroud-a1");
			$("#bj").addClass("yui-backgroud-a");
			$("#XZSPR").removeClass("hidden");
			$("#trsStatus").val("1");
		},
		/**
		 * 添加附件
		 */
		initTJFJ : function(){
			if(App.attch.length > 5){
				Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
				return;
			}
			Fw.Client.openAttcchment("App.showAttcchment");
		},
		showAttcchment: function(name,url){
			Fw.util.attach.addAttach(name,url);
		},
		
		submit:function(){
			//校验页面数据
			var billNo = $("#fromAcctNo").val();
			var zdAmount = App.data.purAmountMin;
			var dzAmount = App.data.purAmountInc;
			var zgAmount = App.data.holdShareMax;
			var gmAmount =$("#HKJE").val().replace(/\s/g,"");
			var memo = $("#memo").val().replace(/\s/g,"");
			var dealUserName = $("#dealUserName").val();
			var dealUserId = $("#dealUserId").val();
			var dealMsg = $("#dealMsg").val();
			var closingDate = "";
			var communicateId = $("#communicateId").val();
			if(gmAmount==0){
				Fw.Form.showPinLabel($(this), "最低购买金额不能为0", true);
				return;
			}
			if(zgAmount<gmAmount){
				Fw.Form.showPinLabel($(this), "购买金额超过购买上限", true);
				return;
			}
			//账号
			if(billNo == ""||billNo==null){
				Fw.Form.showPinLabel($(this), "选择购买账号", true);
				return;
			}
			//备注是否包含表情
			if(Fw.util.proofTest.proolEmoji(memo)){
				Fw.Form.showPinLabel($(this), "备注包含非法字符", true);
				return;
			}
			//产品说明书
			if($("#ty:checked").val()==null){
				Fw.Form.showPinLabel($(this), "请勾选理财产品协议书", true);
				return;
			}
			// 审批人是否为空
			if (dealUserId == null || dealUserId == "") {
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			Fw.Client.openWaitPanel("提交中...");
			var url = YT.dataUrl("public/getRandomNum");
			YT.ajaxData(url, {}, function(success) {
				if (success.STATUS == "1") {
					var url = "private/financtTask.json";
					var params = {
						"type":"1",
						"share":gmAmount,
						"rate":App.data.purchaseRate+"",
						"transCode":"SUB",
						"financeType":"2",
						"trsType":"5",
						"closingDate":"",
						"memo" : memo,
						"acctName":$("#fromAcctName").val(),
						"acctNo":billNo,
						"bankName":"",
						"dealUserName" : dealUserName,
						"dealUserId" : dealUserId,
						"toCommunicateId":communicateId,
						"TOKEN" : success.randomNum,
						"maturityDate":App.data.maturityDate,
						"productCode":App.data.productCode,
						"amount":gmAmount
					};
					Fw.Client.openWaitPanel();
					Fw.Client.post(url, params, "App.success","App.failure");
					
				}else {
					App.flag = false;
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo(success.MSG, "消息提示");
				}
			});
		},
		/**
		 * 提交成功
		 * 
		 */
		success:function(data){
			if(data.STATUS == "1"){
				var url = YT.dataUrl("private/oprtFile");
				var params = {
						trsNo:data.trsNo,
						FileUrl:App.url,
						FileNameList:App.attch
				};
				YT.ajaxData(url, params, function(success) {
				});
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo("已提交下一个处理人：" + $("#dealUserName").val(), "提交成功","App.test()");
				
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示","App.test()");
			}
		},
		test:function(){
			Fw.Client.changePage("1040506.html","");
		},
		/**
		 * 请求失败
		 */
		failure:function(e){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(e,"消息提示");
		},
		/**
		 * 返回函数
		 */
		toBack:function(){
			App.result.go="";
			if (App.result.back=="1040503") {
				Fw.redirect("1040503.html",App.result);
			}else{
				Fw.redirect("1040501.html",App.result);
			}
		}
};
Fw.onReady(App);