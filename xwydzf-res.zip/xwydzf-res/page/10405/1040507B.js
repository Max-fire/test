/**
 * 创建应用
 * 
 * @author cuijh
 */
var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	datas:{},
	init : function(require){
		App.func = window['_getParameter'];
		App.attch = new Array();
		App.attchList = new Array();
		App.i=0;
		App.pageA = $("#pageA");
		App.pageB = $("#pageB"); 
		App.showPageA();
		App.flag = false;
		var url = YT.dataUrl("private/getTaskDetail");
		var params = {
				trsNo:App.func("trsNo"),
				trsType:"5"
		};
		YT.ajaxData(url,params,function(data){
			if(data.STATUS == "1"){
				App.initEvent();
				App.showDatas(data);
				App.showChuli(data);
				App.initBJRPD(data);
			}
		});
	},
	/**
	 * 显示pageA
	 */ 
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	/**
	 * 显示pageB
	 */
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	onCpxys:function(){
		var html=protocol.productCode(App.cpdm);
		Fw.redirect(html+"?No=1040507B&trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"","");
	},
	/**
	 * 绑定事件
	 */ 
	initEvent:function(){
		//产品协议书
		App.pageA.on("click","#cpxys",App.onCpxys);
		// 办结
		App.pageA.on("click","#BJ",App.initBJ);
		// 转办
		App.pageA.on("click","#ZB",App.initZB);
		// 退回
		App.pageA.on("click","#TH",App.initTH);
		// 转办2
		App.pageA.on("click","#ZB2",App.initZB2);
		// 退回2
		App.pageA.on("click","#TH2",App.initTH2);
		// 提交
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		// 选择审批人
		App.pageA.on("click","#SPR",App.initSPR);
		// 处理按钮事件
	  	$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  		$('#trsStatus').val( $(this).data('status') );
	  		if($("#BJ").hasClass('active')){
				$("#spr").addClass('hidden');
			}else if($("#TH").hasClass('active')){
				$("#spr").addClass('hidden');
			}
			else{
				$("#spr").removeClass('hidden');
			}
	  		
	  		if($("#TH2").hasClass('active')){
				$("#XZSPR").attr('hidden',"");
				$("#trsStatus").val("0");
			}
			if($("#ZB2").hasClass('active')){
				$("#XZSPR").removeAttr('hidden','');
				$("#trsStatus").val("1");
			}
	  	});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	/**
	 * 显示数据
	 */
	showDatas:function( data ){
		App.data = data;
		App.dealUserId1 = data.trsInfo[0].dealUserId;
		App.cpdm = data.trsFinance[0].productCode;
		App.fromAcctNo = data.trsFinance[0].fromAcctNo;
		App.fromAcctName = data.trsFinance[0].fromAcctName;
		App.shfe = data.trsFinance[0].financeShare;
		App.trsNo = data.trsFinance[0].trsNo;
		App.cpmc = data.trsFinance[0].shortName;
		$("#MC").html(data.trsFinance[0].shortName);
//		$("#sy").html(Fw.util.Format.fmtPercent(data.product.referYieldRate));
		if(protocol.productCode(data.product.productCode)=='protocol4.html'){
			$("#sy").html(Fw.util.Format.fmtPercent(data.product.yieldRate));
		}else{
			$("#sy").html(Fw.util.Format.fmtPercent(data.product.referYieldRate));
		}
		if(protocol.productCode(data.product.productCode)=='protocol4.html'){
			$("#yieldRate").html("七日年化收益率");
		}
		//最低持有
		$("#zdcy").html(Fw.util.Format.fmtAmt(data.product.holdShareMin+""));
		//起赎份额
		if(data.product.redShareMin==0){
			$("#jyxq").removeClass("yui-lc-alltitle").addClass("yui-lc-alltitleA");
			$("#qsfeA").addClass("hidden");
		}else{
			$("#qsfe").html(Fw.util.Format.fmtAmt(data.product.redShareMin+""));
		}
		$("#jysj").html(Fw.util.Format.fmtDate(data.product.transStartDate)+"-"+Fw.util.Format.fmtDate(data.product.transEndDate));
		$("#jslx").html("赎回");
		$('#trsNo').html( Fw.util.Format.subTrsNo(data.trsFinance[0].trsNo) );
		$('#ywls').html( App.func("trsNo") );
		$("#zh").html(data.trsFinance[0].fromAcctNo);
		$('#shfe').html(Fw.util.Format.fmtAmt(data.trsFinance[0].financeShare+""));
		$("#memo").html(data.trsFinance[0].memo);
		App.attach_url = data.attach_url;
		App.showFj(data.attach);
	},
	/**
	 * 加载处理意见
	 */
  showChuli:function( d ){
 		var html='',html1='',html2='';
 		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else if item.dealType == 2}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
				 						'</div>',
				 						'{@else if item.dealType == 3}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">撤　销</div>',
				 						'</div>',
				 						'{@else if item.dealType == 4}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="../../css/img/XTtouxiang.png" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey ">拒　绝</div>',
				 						'</div>',	
					 				'{@/if}',
					 					'{@if item.dealType == 4}',
					 					'<div class="ui_01_div4">系统用户</div>',
					 					'{@else}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@/if}',
					 					'{@if item.dealMsg}',
					 						'{@if item.dealType == 4}',
							 				'<div class="ui-bg-ss2">',
							 					　'拒绝原因:&nbsp;&nbsp;${item.dealMsg}',
							 				'</div>',	 
							 				'{@else}',
							 				'<div class="ui-bg-ss2">',
						 					　	'${item.dealMsg}',
						 					 '</div>',	 
							 				'{@/if}',	 
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			Fw.Client.hideWaitPanel();
  },
  	/**
  	 * 判断是否经过必经人
  	 */ 
  	initBJRPD: function(d){ 
  		App.amount=d.trsFinance[0].financeShare;
  		if(d.trsInfo[0].hasOwnProperty("effectiveUserId")){
			App.showJGBJR();
		}else{
			var url = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "5",
					amount : d.trsFinance[0].financeShare+"",
					bizNo: "5",
					flag:"2"
			};
			YT.ajaxData(url,params,function(data){
				if(data.isEffective == "YES"){
					App.showJGBJR();
				}else{
					App.showWJGBJR();
				}
			});
		}
  	},
	
  /**
   * 未经过有效必经人
   */ 
  	showWJGBJR:function(){
  		$("#JGYXBJR").addClass("hidden");
  		$("#WJGYXBJR").removeClass("hidden");
  	},
  /**
   * 经过有效必经人
   */ 
  	showJGBJR:function(){
  		$("#WJGYXBJR").addClass("hidden");
  		$("#JGYXBJR").removeClass("hidden");
  	},
	/**
	 * 办结
	 */ 
	initBJ:function(){
		$("#trsStatus").val("2");
		$("#XZSPR").attr("hidden","");
	},
	/**
	 * 转办
	 */ 
	initZB:function(){
		$("#trsStatus").val("1");
		$("#XZSPR").removeAttr("hidden","");
	},
	/**
	 * 退回
	 */ 
	initTH:function(){
		$("#trsStatus").val("0");
		$("#XZSPR").attr("hidden","");
	},
	// 转办2
	initZB2: function(){
		$("#SPR").removeAttr("hidden","");
		$("#trsStatus").val("1");
	},
	// 退回2
	initTH2: function(){
		$("#SPR").attr("hidden","");
		$("#trsStatus").val("0");
	},
	/**
	 * 选择审批人
	 */ 
	initSPR:function(){
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id,co) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 事务提交
	 */
	toSubmit:function(){
		if($("#trsStatus").val() == ""){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji($("#dealMsg").val())){
			Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
			return;
		}
		if($("#trsStatus").val() == "0"){
			App.dealMsg = $("#dealMsg").val();
			if (App.dealMsg==null||App.dealMsg=="") {
				Fw.Form.showPinLabel($(this), "请输入审批意见", true);
				return;
			}
		}
		if($("#trsStatus").val() == "1"){
			if($("#dealUserId").val() == ""||$("#dealUserId").val()==null){
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel("提交中...");
		if($("#trsStatus").val() == "0"){
			var params =  {
					type:"4",
					trsNo:App.func("trsNo"),
					dealMsg:App.dealMsg
			};
			var url = YT.dataUrl("private/financtTask");
			YT.ajaxData(url, params, App.callbackTrsStatus, App.call);
		}
		if($("#trsStatus").val() == "1"){
			// 转办
			var dealMsg = $("#dealMsg").val();
			if(dealMsg){
				App.dealMsg = dealMsg;
			}else{
				App.dealMsg="同意";
			}
			var params =  {
			 	type:"3",
				trsNo:App.func("trsNo"),
				nextDealUserName:$("#dealUserName").val(),
				nextDealUserId:$("#dealUserId").val(),
				dealMsg:App.dealMsg,
				dealUserId:App.dealUserId1,
				share : $("#shje").html(),
				amount:$("#shje").html(),
				fehzls:App.data.volSumSerno
			};
			var  url = YT.dataUrl("private/financtTask");
			Fw.Client.openWaitPanel();
			YT.ajaxData(url, params, App.callback, App.call);
		}
		
		
		if($("#trsStatus").val() == "2"){
			//办结
			var url = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "5",
					amount : App.amount+"",
					bizNo: "5"
			};
			if(App.data.trsInfo[0].hasOwnProperty("effectiveUserId") && App.data.trsInfo[0].effectiveUserId.trim() != ""){
				params.flag = "1";   // 1.只查权限 2、是否是必经人
			}else{
				params.flag = "2";   // 1.只查权限 2、是否是必经人
				
			}
			YT.ajaxData(url,params,function(data){
				if(data.isEffective == "YES"){
					App.initBJ1();
				}else{
					App.flag=false;
					Fw.Client.hideWaitPanel();
					Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
					return;
				}
			});
		}
	},
	/**
	 * 直接办结
	 */
	initBJ1:function(){
		var dealMsg = $("#dealMsg").val();
		if(dealMsg){
			App.dealMsg = dealMsg;
		}else{
			App.dealMsg="同意";
		}
		var params = {
			type:"2",
			transCode:"REDEEN",
			trsNo : App.trsNo,
			cpdm:App.cpdm,
			fromAcctNo:App.fromAcctNo,
			fromAcctName:App.fromAcctName,
			zhdh:App.fromAcctNo,
			shfe:App.shfe+"",
			yddh:"",
			dealMsg:App.dealMsg,
			fehzls:App.data.volSumSerno
		};
		var url = YT.dataUrl("private/financtTask");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,params,App.success1,App.failuri);
		
	},
	/**
	 * 直接办结成功回调函数
	 */
	success1:function(data){
			if (data.STATUS == "1") {
				App.data.cpmc = App.cpmc;
				App.data.acctNo = App.fromAcctNo;
				App.data.trsNo = data.trsNo;
				App.data.shfe = data.shfe;
				App.data.ywslbh = data.ywslbh;
				App.data.transDate = data.transDate;
				App.data.no = "07";
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.test1()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.initFail()");
			}
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
		Fw.Client.changePage("1040507.html?trsStatus="+App.func("trsStatus")+"","1");
	},
	/**
	 * 办结成功返回凭证类型
	 */
	test1:function(json){
		Fw.Client.dealMessage("3",App.func("trsId"),App.trsNo);
		Fw.redirect("1040505_shpz.html",App.data);
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 失败回到待办列表
	 */
	initFail: function(){
		Fw.Client.changePage("1040507.html?trsStatus="+App.func("trsStatus")+"","1");
		
	},
	callbackTrsStatus:function(data){
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已回退给发起人:"+data.creUserName,"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	// 成功后返回函数
	callback:function(data){
		 var url = YT.dataUrl("private/addLinkUser");
			YT.ajaxData(url,{userId:$("#dealUserId").val()},function(data){
			});
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人:"+$("#dealUserName").val(),"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	test:function(){
		Fw.Client.dealMessage("3",App.func("trsId"),App.trsNo);
		Fw.Client.changePage("1040507.html?trsStatus="+App.func("trsStatus")+"","1");
	},
    /**
     * 显示附件
     */
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},
	/**
	 * 返回前一页
	 */
	toBack:function(){
		if(App.func("trsId")){
			Fw.Client.dealMessage("1",App.func("trsId"));	
		}else{
			Fw.Client.changePage("1040507.html?trsStatus="+App.func("trsStatus")+"","1");
		}
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);