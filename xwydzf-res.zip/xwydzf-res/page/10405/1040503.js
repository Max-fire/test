var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
	init:function(){
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		Fw.Client.initPageTitle("#pageA");
		Fw.Client.openWaitPanel();
		App.flag=true;
		//初始化事件
		App.addData();
	},	
	//明细
	toMX:function(d){
		App.accNo=App.data[d].acctNo;
		App.cpdm=App.data[d].productCode;
		datas = {
				"func" : "App.opData",
				"flag" : "0",
				"date" : "",
				"title":"筛选"
			};
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	/**
	 * 明细查询回调函数
	 */
	opData : function(begin,end) {
		var data = {
				"timeBegin":begin,
				"acctNo":App.accNo,
				"timeEnd":end,
				"cpdm":App.cpdm
		};
		var start=begin.split("-");
		var end1=end.split("-");
		var date1=null;
		var date2=new Date(end1[0],end1[1],end1[2]);
		if (start[1]*1>6) {
			date1=new Date(start[0]*1+1,start[1]*1-6,start[2]);
		}else{
			date1=new Date(start[0],start[1]*1+6,start[2]);
		}
		if (date2-date1>0) {
			Fw.Client.alertinfo("明细时间跨度不能大于6个月","消息提示");
		}else{
			Fw.redirect("1040510.html",data);
		}
	},
	//再次购买
	onBUY:function(i){
		App.result.i=i;
		var url = YT.dataUrl("private/isApproval");
		//请求所需参数
		var params = {
				trsType:"5"
		};
		//调用ajax请求数据
		YT.ajaxData(url, params, App.success, App.failure);
	},
	success:function(Data){
		App.result.back="1040503";
    	if(Data.IsApproval=="YES"){
    		Fw.redirect("1040502B.html",App.result);
    	}else{
    		Fw.redirect("1040502.html",App.result);
    	}
    },
	failure:function(data){
	    Fw.Client.alertinfo(data.MSG,"消息提示");
	},
	//赎回事件
	onSH:function(i){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/isApproval");
		var params = {
				trsType:"5"
		};
		YT.ajaxData(url, params, function(data){
			App.result.i=i;
			if(data.IsApproval=="YES"){
				Fw.redirect("1040505A.html",App.result);
	    	}else{
	    		Fw.redirect("1040505.html",App.result);
	    	}
		});
		
	},
	toCXMX1:function(i){
		
		if (App.flag) {
			$("#cxmx"+i).removeClass("yui-lcgl-dian1");
			$("#cxmx"+i).addClass("yui-lcgl-dian2");
			$("#hidden"+i).attr("style","display:none");
			for ( var s in App.data) {
				if (App.data[s].productCode==App.data[i].productCode && App.data[s].acctNo!=App.data[i].acctNo) {
					$("#"+App.data[s].productCode+App.data[s].acctNo).attr("style","border-left: 1px solid #e0e0e0;margin-left: 13px;display:none")
				}
			}
			App.flag=false;
		}else{
			$("#cxmx"+i).removeClass("yui-lcgl-dian2");
			$("#cxmx"+i).addClass("yui-lcgl-dian1");
			$("#hidden"+i).attr("style","");
			for ( var s in App.data) {
				if (App.data[s].productCode==App.data[i].productCode && App.data[s].acctNo!=App.data[i].acctNo) {
					$("#"+App.data[s].productCode+App.data[s].acctNo).attr("style","border-left: 1px solid #e0e0e0;margin-left: 13px;")
				}
			}
			App.flag=true;
		}
	},
	addData:function(){
		App.result = Fw.getParameters();
		if (App.result!=null) {
			App.success1(App.result); 
		}else{
			var url = YT.dataUrl("private/financeQuery");
			var params = {
					type:"2"
			};
			YT.ajaxData(url,params,App.success1,App.failure1);
		}
	},
	success1:function(data){
		if(data.STATUS=="1"){
			App.data = data.data.data;
			App.result=data;
			var productCode=new Array()
			var product=new Array()
			if(App.data!=null&&App.data!=""){
				
				for ( var j in App.data) {
					if (productCode.indexOf(App.data[j].productCode)==-1) {
						productCode.push(App.data[j].productCode);
						App.data[j].index=j;
						product.push(App.data[j]);
					}
				}
			var acct=0;
				var html="";
				for ( var d in product) {
					acct=0;
					if(product[d]!=null&&product[d]!=""){
						html+='	<div class="yui-lc-list">';
						html+='<div>';
						html+='<div class="yui-cui-t-mc yui-lc-list-bottomA">';
						html+='		<div class="yui-lc-list-flex4A"><span style="font-size: 16px;color: #333333;">'+product[d].productName+'</span></div>';
						html+='	<div class="yui-lc-list-flex1A" onclick="App.onBUY('+product[d].index+')">继续购买</div>';
						html+='	</div>';
						html+='	<div style="padding-left: 15px;">';
						html+='		<span class="yui-bqbj">'+Fw.util.Format.fmtbz(product[d].salesCurrency)+'理财</span>';
						html+='		<span class="yui-bqbj" style="margin-left: 6px;">开放式</span></div>';
						html+='	<div class="yui-lc-list-bottom" >';
						html+='	<div class="yui-lc-list-flex1 yui-lc-list-bor-r">';
						if(protocol.productCode(product[d].productCode)=='protocol4.html'){
							html+='		<div class="yui-lc-list-bor-r-first-div" id="sy">'+Fw.util.Format.fmtPercent(product[d].yieldRate)+'</div>';
						}else{
							html+='		<div class="yui-lc-list-bor-r-first-div" id="sy">'+Fw.util.Format.fmtPercent(product[d].referYieldRate)+'</div>';
						}
//						html+='		<div class="yui-lc-list-bor-r-first-div">'+Fw.util.Format.fmtPercent(product[d].referYieldRate)+'</div>';
						if(protocol.productCode(product[d].productCode)=='protocol4.html'){
							html+='<div style="color: #666666">七日年化收益率</div>';
						}else{
							html+='<div style="color: #666666">参考收益率</div>';
						}
						html+='	</div>';
						html+='	<div class="yui-lc-list-flex2 yui-lc-alltitle">';
						html+='		<div>';
						html+='			<label>递增金额:</label> <span style="color:#666666;">'+Fw.util.Format.fmtAmt(product[d].purAmountInc+"")+'元</span>';
						html+='		</div>';
						html+='		<div>';
						html+='			<label>起购金额:</label> <span style="color:#666666;">'+Fw.util.Format.fmtAmt(product[d].purAmountMin+"")+'元</span>';
						html+='		</div>';
						html+='		<div>';
						html+='			<label>交易时间:</label><span style="color:#666666;"> '+Fw.util.Format.fmtDate(product[d].transStartDate+"")+"-"+Fw.util.Format.fmtDate(product[d].transEndDate+"")+'</span>';
						html+='		</div>';
						html+='	</div>';
						html+='	</div>';
						html+='	</div>';
						html+='<div class="yui-cc-border yui-cui-lc-sxx" style="border-top: 1px solid rgba(11, 11, 11, .1);"> ';
						html+='<div style="color: #909090;">';
						
						for ( var i in App.data) {
						 if (product[d].productCode==App.data[i].productCode) {
							 acct++;
							 	html+='<div class="yui-cc-border" style="border-left: 1px solid #e0e0e0;margin-left: 13px;" id="'+App.data[i].productCode+App.data[i].acctNo+'">';
								html+='<div class="yui-lc-list-bottomA">';
							if(acct>1){
								html+='	<div class="ui-form-item yui-lc-list-flex4AA yui-lcgl-dian">';
							}else{
								html+='	<div class="ui-form-item yui-lc-list-flex4AA yui-lcgl-dian1" onclick="App.toCXMX1('+i+')" id="cxmx'+i+'">';
							}
							
							html+='		<sapn style="margin-left: -11px;">购买账户'+acct+':';
							html+='	     	<span style="color: #333333;">'+App.data[i].acctNo+'</span>';
							html+='		</span>';
							html+='	</div>';
							html+='		<div class="yui-lc-list-flex1Aa" onclick="App.onSH('+i+')">赎回</div>';
							html+='	</div>';
							html+='	<div class="yui-lc-list-bottomA yui-cui-lc-sxx" id="hidden'+i+'">';
							html+='	<div class="yui-lc-list-kyfe1" onclick="App.toMX('+i+')">';
							html+='		<div class="yui-cc-fe-t ">';
							html+='		<label class="yui-cui-lc-fexg">可用份额</label> ';
							html+='	<div style="font-size: 12px;color: #333333;">'+Fw.util.Format.fmtAmt(App.data[i].kyfe+"")+'</div>';
							html+='	<div class="yui-cui-lc-ckmx">点击查看明细</div>';
							html+='	</div>';
							html+='	</div>';
							html+='<div class="yui-lc-list-kyfe2">';
							html+='	<div class="yui-cc-fe-b">';
							html+='	<label class="yui-cui-lc-fexg">在途份额</label> ';
							html+='<div style="font-size: 12px;color: #333333;">'+Fw.util.Format.fmtAmt(App.data[i].ztfe+"")+'</div>';
							html+='</div>';
							html+='</div>';
							html+='</div>';
							html+='</div>';
							}
						}
						html+='</div>';
						html+='</div>';
						html+='</div>';
					}
				}
				$("#list").html(html);
				$("#ze").html(Fw.util.Format.fmtAmt(data.data.total+""));
				YT.showPageArea(App.pageA, [App.pageB], true);
			}else{
				YT.showPageArea(App.pageB, [App.pageA], true);
			}
			Fw.Client.hideWaitPanel();
    	}else{
    		Fw.Client.hideWaitPanel();
    		Fw.Client.alertinfo(data.MSG,"消息提示");
    	}
	},
	failure1:function(e){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(e,"消息提示");
	},
	toBack:function(){
		Fw.Client.changePage("1040500.html","0");
	}
};
Fw.onReady(App);