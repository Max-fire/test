/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	init : function(require){
		App.pageA = $("#pageA");
//		var url = YT.dataUrl("public/getRandomNum");
//		alert(url);
//		YT.ajaxData(url,{},function(data){
//			if(data.STATUS == "1"){
//				$("#list").html("OK");
//			}else{
//				$("#list").html("Error");
//			}
//		});
		$.ajax({
			type:"post",
//			url:"http://localhost:8888/xwydzf/private/prevTamperCodeGetOp.json",
//			url:"http://168.3.20.225:19020/xwydzf/private/prevTamperCodeGetOp.json",
			url:"http://localhost:8888/xwydzf/private/prevTamperCodeGetOp.json",
			data:{},
			datatype:"json",
			success:function(data){
				data = eval("("+ data +")");
				if(data.STATUS == "1"){
					$("#list").html("MSG:"+data.MSG+"　　　OK");
				}else{
					$("#list").html("MSG:"+data.MSG+"　　　Error");
				}
			},
			error:function(){
				alert("eeeee");
			}
		});
	}
};
