var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
//		Fw.Client.hideWaitPanel();
//		App.pageA = $("#pageA");
//		YT.showPageArea(App.pageA, null, true);
//		App.pageA.on("click","#btnIphone",App.initalertI);
//		App.pageA.on("click","#btnAndroid",App.initalertA);
	},
	initalertI:function(){
		Fw.Client.confirm("确定下载iPhone客户端","消息提示","App.initIphone()","","确定","取消");
	},
	initalertA:function(){
		Fw.Client.confirm("确定下载android客户端","消息提示","App.initAndroid()","","确定","取消");
	},
	initIphone:function(){
//		alert("iphone");
		$.ajax({
			type:"method",
			url:"",
			success:function(data){
				alert(data);
			},
			failUri:function(){
				alert("失败");
			}
			
		});
	},
	initAndroid:function(){
//		alert("android");
	}
};
Fw.onReady(App);