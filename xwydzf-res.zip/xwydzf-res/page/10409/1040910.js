/**
 * 创建应用
 * @author wjx
 */
var App = {
	requires : ['Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require) {
		Fw.Client.hideWaitPanel();
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("change", "#ZH", App.onChange);
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		App.pageB.on("click", "#resetSubmit", App.toResetSubmit);
		App.pageA.on("click", "#HKZH", App.initZH);
		App.checkBind();
		App.initCY();
	},
	/**
	/**
	 * 汇款账户
	 */
	initCY : function() {
		App.datas = new Array();
		var url = YT.dataUrl("private/findAcctList");
		YT.ajaxData(url, {}, function(data) {
			if (data.STATUS == "1") {
				for ( var i = 0; i < data.datels.length; i++) {
					App.datas.push({
						account : data.datels[i].account.acctNo,
						balance : data.datels[i].response.kyye,
						accountName:data.datels[i].response.khmc
					});
				}
			}else{
				Fw.Form.showPinLabel($(this), data.MSG, true);
			}
		},function(data){
			Fw.Form.showPinLabel($(this), data.MSG, true);
		});
	},
	/**
	 * 显示账户
	 */
	initZH : function() {
		var json = {
				jsonArray : App.datas,
				"func" : "App.showCommonlyUsedAccount"
			}
		Fw.Client.hideWaitPanel();
		Fw.Client.openCommonlyUsedAccount(Fw.JsonToStr(json));
	},
	/**
	 * 账户回显
	 */
	showCommonlyUsedAccount : function(account, balances,name) {
		$("#fromAcctNo").val(account);
		Fw.Client.hideWaitPanel();
		App.onKeypress();
	},
	/**
	 * 判断是否信息都填写完整
	 */
	onKeypress : function() {
		var SKZH = $("#fromAcctNo").val().trim();
		if (SKZH !="" ) {
			$("#btnSubmit").removeAttr("disabled", "");
		} else {
			$("#btnSubmit").attr("disabled", "disabled");
		};
	},
	/**
	 * 查看是否绑定
	 */
	checkBind:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/queryHfBind");
		YT.ajaxData(url,{},function(data){
			if(data.STATUS=="1"){
				if (data.status=="0") {
					App.toShowMessage(data);
					Fw.Client.hideWaitPanel();
				}else{
					Fw.Client.hideWaitPanel();
					YT.showPageArea(App.pageA, [App.pageB], true);
				}
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		});
	},
	/**
	 * 已绑定显示信息
	 */
	toShowMessage:function(data){
		var html='<div class="yui-hf-bindHeight">您已成功绑定华峰ID</div><div class="yui-hf-height30 yui-hf-color9">三方协议编号</div><div>'+data.data.protocolNo+'</div>'
		$("#showStatus").html(html);
		$("#hfId").html(data.data.hfId);
		$("#acctName").html(data.firmName);
		$("#acctNo").html(data.data.acctNo);
		YT.showPageArea(App.pageB, [App.pageA], true);
	},
	/**
	 * 提交
	 * */
	toSubmit:function(){
		var acct=$("#fromAcctNo").val().trim();
		if(acct==""){
			Fw.Form.showPinLabel($(this), "请选择银行账户", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/hfFirmBind");
		var params = {
				ACCT_NO:acct
		};
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				var html="";
				if (data.state=="0") {
					html='<img src="../../css/img/shoulisuccess.png" class="yui-hf-statusImg"><div class="yui-hf-height30">绑定成功</div><div class="yui-hf-height30 yui-hf-color9">三方协议编号</div><div>'+data.protocolNo+'</div>'
						$("#reset").addClass("hidden");
				}else{
					html='<img src="../../css/img/gzt-fail.png" class="yui-hf-statusImg"><div class="yui-hf-height30">绑定失败</div><div class="yui-hf-height30 yui-hf-color9">'+data.failReason+'</div>'
						$("#reset").removeClass("hidden");
				}
				$("#showStatus").html(html);
				$("#hfId").html(data.hfId);
				$("#acctName").html(data.ACCT_NAME);
				$("#acctNo").html(data.ACCT_NO);
				YT.showPageArea(App.pageB, [App.pageA], true);
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		});
	},
	/**
	 * 重新綁定
	 */
	toResetSubmit:function(){
		YT.showPageArea(App.pageA, [App.pageB], true);
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
