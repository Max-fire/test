/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.flag = true;
		App.trsNo="";
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
//		App.pageA.on("click", "#ddbh", App.toShowHT);
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		App.pageA.on("click","#BJ",App.chooseType);
		App.pageA.on("click","#TH",App.chooseType);
		$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  	});
		App.loadData();
	},
	/**
	 * 加载数据
	 */
	loadData:function(){
		//判断是否是转账业务必经人
		var url = YT.dataUrl("private/isEffective");
		var params = {
				trsType : "3",
				amount : App.data.amount+"",
				bizNo: "3",
				flag:"2"
		}
		if (App.data.detailFlag=="1") {
			$("#dealFlag").addClass("hidden");
			$("#showStatus").removeClass("hidden");
		}else{
			YT.ajaxData(url,params,function(data){
				if(data.isEffective == "YES"){
					$("#dealFlag").removeClass("hidden");
				}else{
					$("#dealFlag").addClass("hidden");
				}
			});
			$("#showStatus").addClass("hidden");
		}
		$("#pageA").attr("title",Fw.util.Format.fmtPayStgCd(App.data.paymentType));
		$("#paymentType").html(Fw.util.Format.fmtPayStgCd(App.data.paymentType));
		$("#orderId").html(App.data.orderId);
		$("#subCtrNo").html(App.data.subCtrNo);
		$("#amount").html(Fw.util.Format.fmtAmt(App.data.amount+""));
		if (App.data.amount) {
			$("#amountChn").html(Fw.util.Format.fmtNumber2Chinese(App.data.amount+""));
		}else{
			$("#amountChn").html("零");
		}
		$("#fromAcctNo").html(App.data.fromAcctNo);
		$("#fromAcctName").html(App.data.fromAcctName);
		$("#fromBankName").html(App.data.fromBankName);
		$("#toAcctNo").html(App.data.toAcctNo);
		$("#toAcctName").html(App.data.toAcctName);
		$("#toBankName").html(App.data.toBankName);
		if (App.data.expMsg) {
			$("#expMsg").html(App.data.expMsg)
		}
		$("#status").html(Fw.util.Format.fmtPymtBsnSt(App.data.status+""));
		if (App.data.status=="0") {
			$("#status").css({"color":"#00A74C"})
			$("#failShow").addClass("hidden")
		}else{
			$("#status").css({"color":"#FF3B30"})
			$("#failShow").removeClass("hidden")
		}
		if (App.data.paymentType=="02") {
			$("#toInfo").addClass("hidden");
		}else if (App.data.paymentType=="04" || App.data.paymentType=="11") {
			$("#sxf").removeClass("hidden");
			$("#platformCharge").html(Fw.util.Format.fmtAmt(App.data.platformCharge+""));
			if (App.data.platformCharge) {
				$("#platformChargeChn").html(Fw.util.Format.fmtNumber2Chinese(App.data.platformCharge+""));
			}else{
				$("#platformCharge").html("0.00");
				$("#platformChargeChn").html("零")
			}
			$("#amountName").html("解控金额");
		}else if (App.data.paymentType=="12" || App.data.paymentType=="13") {
			$(".backAmount").removeClass("hidden");
			if (App.data.paymentType=="12") {
				$("#amountName").html("退款金额")
			}else{
				$("#amountName").attr("style","width:100px");
				$("#amount").attr("style","padding-left:100px");
				$("#amountName").html("原预付款金额")
			}
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 选择操作类型
	 */
	chooseType: function(){
		$("#trsStatus").val($(this).attr("data-status"));
	},
	toSubmit:function(){
		if($("#trsStatus").val() == ""){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		var url = YT.dataUrl("public/getRandomNum");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{},function(data){
			if(data.STATUS == "1"){
				var url = "private/hfTrsInfoTask.json";
				var params ={
						type:"1",
						trsType:"9",
						pymtTxnSeqno:App.data.pymtTxnSeqno,
						paymentType:App.data.paymentType,
						orderId :App.data.orderId,//订单编号
						toProtocolNo :App.data.toProtocolNo,//收款协议编号
						toHfId :App.data.toHfId,//收款id
						subCtrNo:App.data.subCtrNo,//合同编号
						toAcctNo :App.data.toAcctNo,//收款账号、原收款账号
						toAcctName:App.data.toAcctName,//收款户名、原收款户名
						toBankName:App.data.toBankName, //收款开户行、原收款开户行
						amount :App.data.amount+"",//根据业务类型区分（支付金额、控制金额、控制金额、解控金额、解控金额、退款金额、原预付款金额、原预付款金额）
						amountChn :Fw.util.Format.fmtNumber2Chinese(App.data.amount+""),//金额大写
						platformCharge :App.data.platformCharge+"",//平台手续费
						platformChargeChn :App.data.platformCharge?Fw.util.Format.fmtNumber2Chinese(App.data.platformCharge+""):"",//平台手续费金额大写
						fromProtocolNo :App.data.fromProtocolNo,//收款协议编号
						fromHfId :App.data.fromHfId,//收款id
						fromAcctNo :App.data.fromAcctNo,//付款账号、原付款账号
						fromAcctName :App.data.fromAcctName,//付款户名、原付款户名
						fromBankName :App.data.fromBankName,//付款开户行、原付款开户行
						url :App.data.url,//url
						expMsg :App.data.expMsg,//备注
						transType :$("#trsStatus").val(),//0同意  1拒绝
						payTxnTime:App.data.payTxnTime,//日期
						status :App.data.status,
						isComplete:"1",
						TOKEN:data.randomNum
				};
				Fw.Client.post(url, params, "App.initShowBB", "App.callback");
			}else{
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.toBack()")
				return;
			}
		});
	},
	initShowBB:function(data){
		if (data.STATUS=="1") {
			var json = {
					func : "App.initComplete",
					funcAndroid:"App.initCompleteAndroid",
					type : "2",
					toName:App.data.toAcctName,//收款人名称
					toAcc:App.data.toAcctNo,//收款账号
					fromName:App.data.fromAcctName,//付款名称
					fromAcc:App.data.fromAcctNo,//付款账号
					purpose:App.data.expMsg,//用途
					xmlMoney:App.data.amount,//金额
					xmlNo:data.trsNo//流水账号
			}
			App.trsNo=data.trsNo;
			Fw.Client.showBB(json);
		}else{
			App.callback(data);
		}
	},
	callback:function(data){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(data.MSG,"消息提示","App.success()");
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete:function(a,b){
			App.initBJ(a,b);
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
		App.initBJ(a,b,fromAcctNo,fromAcctName,purpose);
	},
	initBJ:function(a,b,frAcctNo,frAcctName,ppose){
		var params={
				type:"2",
				trsNo : App.trsNo,
				pymtTxnSeqno:App.data.pymtTxnSeqno,
				paymentType:App.data.paymentType,
				orderId :App.data.orderId,//订单编号
				toProtocolNo :App.data.toProtocolNo,//收款协议编号
				toHfId :App.data.toHfId,//收款id
				subCtrNo:App.data.subCtrNo,//合同编号
				toAcctNo :App.data.toAcctNo,//收款账号、原收款账号
				toAcctName:App.data.toAcctName,//收款户名、原收款户名
				toBankName:App.data.toBankName, //收款开户行、原收款开户行
				amount :App.data.amount+"",//根据业务类型区分（支付金额、控制金额、控制金额、解控金额、解控金额、退款金额、原预付款金额、原预付款金额）
				amountChn :Fw.util.Format.fmtNumber2Chinese(App.data.amount+""),//金额大写
				platformCharge :App.data.platformCharge+"",//平台手续费
				platformChargeChn :App.data.platformCharge?Fw.util.Format.fmtNumber2Chinese(App.data.platformCharge+""):"",//平台手续费金额大写
				fromProtocolNo :App.data.fromProtocolNo,//收款协议编号
				fromHfId :App.data.fromHfId,//收款id
				fromAcctNo :App.data.fromAcctNo,//付款账号、原付款账号
				fromAcctName :App.data.fromAcctName,//付款户名、原付款户名
				fromBankName :App.data.fromBankName,//付款开户行、原付款开户行
				url :App.data.url,//url
				expMsg :App.data.expMsg,//备注
				transType :$("#trsStatus").val(),//0同意  1拒绝
				payTxnTime:App.data.payTxnTime,//日期
				status :App.data.status,
				signData:a,
				signSrc:b
			}
		var url = YT.dataUrl('private/hfTrsInfoTask');
		Fw.Client.openWaitPanel();
		YT.ajaxData(url, params, function(data) {
			params.STATUS=data.STATUS;
			if(data.STATUS=="1"){
				Fw.redirect("1040902.html",params);
				Fw.Client.hideWaitPanel();
			}else{
				params.MSG=data.MSG;
				Fw.redirect("1040902.html",params);
				Fw.Client.hideWaitPanel();
			}	
		});
	},
//	toShowHT:function(){
//		Fw.Client.changeWeb("https://www.baidu.com",false,pageB);
//	},
	/**
	 * 返回工作首页
	 */
	toBack:function(){
		var trsType="0";
		if (App.data.detailFlag=="1") {
			trsType="1"
		}else{
			trsType="0"
		}
		Fw.redirect("1040900.html?trsType="+trsType);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);