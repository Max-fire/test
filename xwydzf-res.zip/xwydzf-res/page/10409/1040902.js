/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.flag = true;
		App.trsNo="";
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 已处理按钮
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		App.loadData();
	},
	/**
	 * 加载数据
	 */
	loadData:function(){
		$("#paymentType").html(Fw.util.Format.fmtPayStgCd(App.data.paymentType));
		$("#orderId").html(App.data.orderId);
		$("#subCtrNo").html(App.data.subCtrNo);
		$("#amount").html(Fw.util.Format.fmtAmt(App.data.amount+""));
		$("#amountChn").html(Fw.util.Format.fmtNumber2Chinese(App.data.amount+""));
		$("#fromAcctNo").html(App.data.fromAcctNo);
		$("#fromAcctName").html(App.data.fromAcctName);
		$("#fromBankName").html(App.data.fromBankName);
		$("#toAcctNo").html(App.data.toAcctNo);
		$("#toAcctName").html(App.data.toAcctName);
		$("#toBankName").html(App.data.toBankName);
		if (App.data.paymentType=="02") {
			$("#toInfo").addClass("hidden");
		}else if (App.data.paymentType=="04" || App.data.paymentType=="11") {
			$("#sxf").removeClass("hidden");
			$("#platformCharge").html(Fw.util.Format.fmtAmt(App.data.platformCharge+""));
			if (App.data.platformCharge) {
				$("#platformChargeChn").html(Fw.util.Format.fmtNumber2Chinese(App.data.platformCharge+""));
			}else{
				$("#platformChargeChn").html("零")
			}
			$("#amountName").html("解控金额");
		}else if (App.data.paymentType=="12" || App.data.paymentType=="13") {
			$(".backAmount").removeClass("hidden");
			if (App.data.paymentType=="12") {
				$("#amountName").html("退款金额")
			}else{
				$("#amountName").html("原预付款金额")
			}
		}
		var html="";
		if (App.data.STATUS=="1") {
			html='<div class="yui-hf-statusHeight" style="height: 128px;"><img src="../../css/img/shoulisuccess.png" class="yui-hf-statusImg"><div class="yui-hf-height30">交易成功</div></div>'
		}else{
			html='<div class="yui-hf-statusHeight" style="height: 160px;"><img src="../../css/img/bindFail.png" class="yui-hf-statusImg"><div class="yui-hf-height30">交易失败</div><div class="yui-hf-height30 yui-hf-color9" style="padding:0px 15px;">'+App.data.MSG+'</div></div>'
		}
		$("#result").html(html);
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
	},
	toSubmit:function(){
		Fw.redirect("1040900.html");
		
	},
	/**
	 * 返回工作首页
	 */
	toBack:function(){
		Fw.redirect("1040900.html");
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);