/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.flag = true;
		YT.showPageArea(App.pageA, [], true);
		App.type="0";
		App.initEvent();
		if (App.func("trsType")) {
			if (App.func("trsType")=="1") {
				App.initYCL();
			}else{
				App.initDCL();
			}
		}else{
			App.initDCL();
		}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 已处理按钮
		App.pageA.on("click", "#item", App.showDetail);
		App.pageA.on("click","#btnIconb",App.initDCL);
		App.pageA.on("click","#btnIconc",App.initYCL);
	},
	/**
	 * 待处理
	 */
	initDCL:function(){
		Fw.Client.openWaitPanel();
		$("#btnIconb").removeClass("yui-backgroud-iconbb").addClass("yui-backgroud-iconb");
		$("#colIconb").removeClass("yui-font-col2").addClass("yui-font-col1");
		$("#btnIconc").removeClass("yui-backgroud-iconc").addClass("yui-backgroud-iconcc");
		$("#colIconc").removeClass("yui-font-col1").addClass("yui-font-col2");
		App.type="0";
		$.get("10401_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 已处理
	 */
	initYCL:function(){
		Fw.Client.openWaitPanel();
		$("#btnIconb").removeClass("yui-backgroud-iconb").addClass("yui-backgroud-iconbb");
		$("#colIconb").removeClass("yui-font-col1").addClass("yui-font-col2");
		$("#btnIconc").removeClass("yui-backgroud-iconcc").addClass("yui-backgroud-iconc");
		$("#colIconc").removeClass("yui-font-col2").addClass("yui-font-col1");
		App.type="1";
		$.get("10401_LD.html?v=SID", {}, App.query);
	},
	/**
	 * 加载列表查询条件【事务类型 】【指令状态】【查询时间】
	 */
	query : function(tpl) {
		var json = {};
		var url = YT.dataUrl("private/queryHfOrderIds");
		if (App.type=="1") {
			url=YT.dataUrl("private/queryHfTrsConfirms");
		}
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "list",
			page : true,
			pageSize : 5,
			disclosure : true,
			ajax : {
				url : url,
				params : json
			},
			itemTpl : tpl,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(App.type);
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		var page = pageIndex || 1;
		Fw.Client.hideWaitPanel();
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 显示详情
	 */
	showDetail : function(itemData, itemIndex, itemElem) {
		if (App.type=="1") {
			itemData.detailFlag="1";
		}else{
			itemData.detailFlag="0";
		}
		Fw.redirect("1040901.html",itemData);
	},
	/**
	 * 返回工作首页
	 */
	gotoHomePage:function(){
		Fw.Client.gotoHomePage();
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);