/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.next="0";
		App.more=false;
		App.initEvent();
		App.initData();
		App.pushHistory();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		 App.pageA.on("click","#addAccount",App.toAddAccount);
		App.pageA.on("click","#searchMore",App.toSearchMore);
	
		 App.pageA.on("click","#cancelBtn",App.toCancle);
		 App.pageA.on("click","#black_b",App.toCancle);
		 App.pageA.on("click","#okBtn",App.okBtn);
		 
		 window.addEventListener("popstate",function(e){
			WeixinJSBridge.call('closeWindow');
			},false)
	},
	// 查询绑定列表
	initData : function() {
		var url = YT.dataUrlWeb("private/logisPayeeWXQuery");
		var params = {
			openId : App.func("openId")+'',
			NEXT_KEY:App.next+'',
    		PAGE_SIZE:10+"",
		}
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url, params,function(data) {
							if (data.STATUS == "1") {
								App.datas=data;
								App.loadList(data);
							} else {
								$.tips({
									content : data.MSG,
									stayTime : 2000,
									type : "fail",
								})
							}
							Fw.Layer.hideWaitPanel();
						}, function(data) {
							$.tips({
								content : data.MSG,
								stayTime : 2000,
								type : "fail",
							})
							Fw.Layer.hideWaitPanel();
						});
	},
	loadList:function(data){
		var html = "";
		if(data.list){
			for(var i=0;i<data.list.length;i++){
				html+='<div style="line-height:44px;padding:0 15px; border-bottom: 1px solid #E7E7EB;"><span>'+data.list[i].binderPhone+'</span>'
				html+='<span onClick="App.toUnBind('+data.list[i].binderPhone+')" style="display:inline-block;float:right;color:#417CDF;">解绑</span></div>';
			}
		}else{
			html+='<div style="line-height:44px;text-align:center;color:#999">暂无数据~</div>';
			
		}
		if(data.NEXT_PAGE){
			$("#searchMore").show();
			App.next=data.NEXT_KEY/1+10+"";
		}else{
			$("#searchMore").hide();
		}
		if(App.more==false){
			$("#list").html(html);
		}else{
			$("#list").append(html);
		}
		App.more=false;
		App.pageA.show();
		Fw.Layer.hideWaitPanel();
		
		var height=document.body.clientHeight;
		var scrollHeight=document.body.scrollHeight;
		var listHeight=document.getElementById("list").scrollHeight;
		if(height==scrollHeight && height-listHeight>250){
			$("#bottomTips").removeClass("yui-wxgzt-bottomTips-sp");
			$("#bottomTips").addClass("yui-wxgzt-bottomTips");
		}else{
			$("#bottomTips").removeClass("yui-wxgzt-bottomTips")
			$("#bottomTips").addClass("yui-wxgzt-bottomTips-sp")
		}
	},
	toUnBind : function(mobile) {
		App.mobile=mobile;
		$("#white_b").show();
		$("#black_b").show();
	},
	toCancle:function(){
		$("#white_b").hide();
		$("#black_b").hide();
	},
	okBtn:function(){
		$("#white_b").hide();
		$("#black_b").hide();
		var url = YT.dataUrlWeb("private/logisPayeeWXBind");
		var params = {
			openId : App.func("openId"),
			mobile:App.mobile+'',
			type:'1'
		}
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url, params,function(data) {
			if(data.STATUS=="1"){
				$.tips({
					content : "解绑成功",
					stayTime : 2000,
					type : "success",
				})
				App.next="0";
				App.more=false; 
//				App.pageA.hide();
//				Fw.Layer.openWaitPanel();
//				$("#list").html("");
				if(App.datas.list.length=="1"){
					Fw.redirect("1040805.html?openId="+App.func("openId"));
				}else{
					App.initData();
				}
			}else{
				$.tips({
					content : data.MSG,
					stayTime : 2000,
					type : "fail",
				})
				Fw.Layer.hideWaitPanel();
			}
			
		})
	},
	toSearchMore:function(){
		App.more=true;
		Fw.Layer.openWaitPanel();
		App.initData();
	},
	toAddAccount : function() {
		// 物流代码绑定 新增页面
		Fw.redirect("1040805.html?goBack=yes&openId=" + App.func("openId"));
	},
	pushHistory : function() {
		var state = {
			page : "1040806",
		}
		window.history.pushState(state, "title", "");
	}

};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);