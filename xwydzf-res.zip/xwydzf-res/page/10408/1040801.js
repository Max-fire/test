/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.pushHistory();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#addAccount", App.toAddAccount);
		App.initData();
	},
	toAddAccount : function(){
		Fw.redirect("1040800.html?goBack=yes&openId="+App.func("openId"));
	},
	toDelAccount : function(mobile){
		var json={
				name:App.list[mobile][0].userName,
				mobile:mobile,
				length:App.length
		}
		Fw.redirect("1040802.html?openId="+App.func("openId"),json);
	},
	//查询绑定列表
	initData:function(){
		var html="";
		App.length=0;
		 var url = YT.dataUrlWeb("private/weChatQuery");
			var params={
					openId:App.func("openId"),
			}
			Fw.Layer.openWaitPanel();
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					App.list=data.list;
					$.each(data.list,function(d,list){
						App.length++;
							html+='<div style="padding-left: 15px;font-size: 16px;background-color: #ffffff;margin-bottom: 15px;">';
							html+='<div class="yui-yqdz-height">';
							html+='<div style="float: left;"><span>'+list[0].userName+'</span>(<span>'+d+'</span>)</div>';
							html+='<div style="float: right;color: #417CDF ;vertical-align: middle;" onClick="App.toDelAccount('+d+')"><span style="padding: 0px 20px 0px 10px;">解绑</span></div>';
							html+='</div>';
							html+='<div style="clear: both;"></div>';
							for ( var i in list) {
							 	html+='<div class="yui-wxgzt-TopBorder">';
							 	html+='<div style="float: left;margin-right: 95px;">';
							 	html+='<div style="padding: 10px 0px;">'+list[i].firmName+'</div>';
						 			if(list[i].wechatSign=="0"){
						 				html+='<div class="yui-wxgzt-kgts" id="'+list[i].ncid+''+d+'0">已开启消息推送</div>';
						 				html+='<div class="yui-wxgzt-kgts hidden" id="'+list[i].ncid+''+d+'1">未开启消息推送</div>';
						 			}else{
						 				html+='<div class="yui-wxgzt-kgts hidden" id="'+list[i].ncid+''+d+'0">已开启消息推送</div>';
						 				html+='<div class="yui-wxgzt-kgts" id="'+list[i].ncid+''+d+'1">未开启消息推送</div>';
						 			}
						 			html+='</div>';
						 			html+='<div style="color: #417CDF ;vertical-align: middle;">';
						 			html+='<div class="ui-form-item yui-det-item">';
						 			html+='<label class="ui-switch" style="top:20px;">';
						 			if(list[i].wechatSign=="0"){
						 				html+='<input type="checkbox" id="'+list[i].ncid+''+d+'" value="1" onChange="App.toChangeMsg('+d+','+i+')"   checked="checked"/>';     
						 			}else{
						 				html+='<input type="checkbox" id="'+list[i].ncid+''+d+'" value="0" onChange="App.toChangeMsg('+d+','+i+')"/>';    
						 			}
						 			html+='</label>';
						 			html+='</div>';
						 			html+='</div>';
						 			html+='<div style="clear: both;"></div>';
						 			html+='</div>';
							}
							html+='</div>';
					})
					$("#list").html(html);
					App.pageA.removeClass("hidden");
					var height=document.body.clientHeight;
					var scrollHeight=document.getElementById("list").offsetHeight;
					if(height-255>scrollHeight){
						$("#bottomTips").removeClass("yui-wxgzt-bottomTips-sp");
						$("#bottomTips").addClass("yui-wxgzt-bottomTips");
					}else{
						$("#bottomTips").removeClass("yui-wxgzt-bottomTips")
						$("#bottomTips").addClass("yui-wxgzt-bottomTips-sp")
					}
					setTimeout(function(){
						//关闭微信右上角菜单
						WeixinJSBridge.call('hideOptionMenu');
					},1500);
					window.addEventListener("popstate",function(e){
						if(e.state.page=="1040801"){
							WeixinJSBridge.call('closeWindow');
						}
					},false)
					Fw.Layer.hideWaitPanel();
				}else{
					$.tips({
				        content:data.MSG,
				        stayTime:2000,
				        type:"fail",
				    })
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				$.tips({
			        content:data.MSG,
			        stayTime:2000,
			        type:"fail",
			    })
				Fw.Layer.hideWaitPanel();
				}
			);
	},
	toChangeMsg : function(d,i){
		var id=App.list[d][i].ncid+""+App.list[d][i].moblieNo;
		var openFlag=""
		if ($("#"+id).val()=="0") {
			openFlag="0";
			$("#"+id).val("1");
		}else{
			openFlag="1";
			$("#"+id).val("0");
		}
		//取消和接受消息接口
		 var url = YT.dataUrlWeb("private/weChatBindFirm");
			var params={
					openId:App.func("openId"),
					phone:App.list[d][i].moblieNo,
					ncid:App.list[d][i].ncid,
					cid:App.list[d][i].cid,
					type:openFlag
			}
			Fw.Layer.openWaitPanel();
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					if(openFlag=="1"){
						$("#"+id+"0").addClass("hidden");
						$("#"+id+"1").removeClass("hidden");
					}else{
						$("#"+id+"1").addClass("hidden");
						$("#"+id+"0").removeClass("hidden");
					}
						Fw.Layer.hideWaitPanel();
				}else{
					$.tips({
				        content:data.MSG,
				        stayTime:2000,
				        type:"fail",
				    });
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				$.tips({
			        content:data.MSG,
			        stayTime:2000,
			        type:"fail",
			    });
				Fw.Layer.hideWaitPanel();
				}
			);
	},
	pushHistory:function(){
		var state={
				page:"1040801",
		}
		window.history.pushState(state,"title","");
		window.history.pushState({page:"other"},"other","");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);