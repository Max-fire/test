/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#bind", App.toBind);
		App.pageA.on("click", "#noBind", App.toNoBind);
		App.pageA.on("input","#yzm",App.onYzm);
		App.pageA.on("porpertychanger","#yzm",App.onYzm);
		//发送短信
		sendUtil.openTimerListener("sendMsg",{type:"11"});
		var height=document.body.clientHeight;
		var scrollHeight=document.body.scrollHeight;
		window.onresize=function(){
			if(document.body.clientHeight<scrollHeight){
				$(".yui-wxgzt-bottomTips").hide();
			}else{
				$(".yui-wxgzt-bottomTips").show();
			}
		}
		if(height>540){
			$("#bottomTips").removeClass("yui-wxgzt-bottomTips-sp");
			$("#bottomTips").addClass("yui-wxgzt-bottomTips");
		}else{
			$("#bottomTips").removeClass("yui-wxgzt-bottomTips")
			$("#bottomTips").addClass("yui-wxgzt-bottomTips-sp")
		}
		$("#name").html(App.data.name);
		$("#phone").html("("+App.data.mobile+")");
		$("#mobile").val(App.data.mobile);
		App.pageA.removeClass("hidden");
		setTimeout(function(){
			//关闭微信右上角菜单
			WeixinJSBridge.call('hideOptionMenu');
		},1500);
	},
		onYzm:function(){
		if($("#yzm").val()){
			$("#bind").removeAttr("disabled");
		}else{
			$("#bind").attr("disabled","disabled");
		}
	},
	toBind:function(){
		 var num=/[0-9]{6}/;
		 if (!num.test($("#yzm").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		 var url = YT.dataUrlWeb("private/weChatSign");
			var params={
					openId:App.func("openId"),
					mobile:$("#mobile").val(),
					name:$("#name").html(),
					MSG:$("#yzm").val(),
					type:"1"
			}
			Fw.Layer.openWaitPanel();
			App.pageA.off("click", "#bind", App.toBind);
			App.pageA.off("click", "#noBind", App.toNoBind);
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					$.tips({
				        content:"账户已解绑",
				        stayTime:2000,
				        type:"success",
				    })
					Fw.Layer.hideWaitPanel();
					setTimeout(function(){
						if(App.data.length>1){
							Fw.redirect("1040801.html?openId="+App.func("openId"));
						}else{
							Fw.redirect("1040800.html?openId="+App.func("openId"));
						}
						App.pageA.on("click", "#bind", App.toBind);
						App.pageA.on("click", "#noBind", App.toNoBind);
					},1000)
				}else{
					$.tips({
				        content:data.MSG,
				        stayTime:2000,
				        type:"fail",
				    })
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					App.pageA.on("click", "#bind", App.toBind);
					App.pageA.on("click", "#noBind", App.toNoBind);
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				$.tips({
			        content:data.MSG,
			        stayTime:2000,
			        type:"fail",
			    })
				App.pageA.on("click", "#bind", App.toBind);
				App.pageA.on("click", "#noBind", App.toNoBind);
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Layer.hideWaitPanel();}
			);
		 
	},
	//弹窗
	toIknow:function(){
		App.pageA.unbind("touchmove");
	},
	toNoBind:function(){
		window.history.go(-1);
	},
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);