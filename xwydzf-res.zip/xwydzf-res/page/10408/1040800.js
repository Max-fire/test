/**
  * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		App.pushHistory();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#bind", App.toBind);
		App.pageA.on("click", "#noBind", App.toNoBind);
		App.pageA.on("input","#mobile",App.onMobile);
		App.pageA.on("porpertychanger","#mobile",App.onMobile);
		App.pageA.on("input","#yzm",App.onYzm);
		App.pageA.on("porpertychanger","#yzm",App.onYzm);
		App.pageA.on("input","#name",App.onName);
		App.pageA.on("porpertychanger","#name",App.onName);
		//发送短信
		sendUtil.openTimerListener("sendMsg",{type:"11"});
		var height=document.body.clientHeight;
		var scrollHeight=document.body.scrollHeight;
		window.onresize=function(){
			if(document.body.clientHeight<scrollHeight){
				$(".yui-wxgzt-bottomTips").hide();
			}else{
				$(".yui-wxgzt-bottomTips").show();
			}
		}
		if(height>540){
			$("#bottomTips").removeClass("yui-wxgzt-bottomTips-sp");
			$("#bottomTips").addClass("yui-wxgzt-bottomTips");
		}else{
			$("#bottomTips").removeClass("yui-wxgzt-bottomTips")
			$("#bottomTips").addClass("yui-wxgzt-bottomTips-sp")
		}
		App.pageA.removeClass("hidden");
		setTimeout(function(){
			//关闭微信右上角菜单
		WeixinJSBridge.call('hideOptionMenu');
		},1500);
		window.addEventListener("popstate",function(e){
			if(App.func("goBack")&&App.func("goBack")=="yes"){
				window.history.go(-1);
			}else{
				WeixinJSBridge.call('closeWindow');
			}
		},false)
	},
	onMobile:function(){
		if($("#mobile").val()&&$("#yzm").val()&&$("#name").val()){
			$("#bind").removeAttr("disabled");
		}else{
			$("#bind").attr("disabled","disabled");
		}
	},
	onName:function(){
		if($("#mobile").val()&&$("#yzm").val()&&$("#name").val()){
			$("#bind").removeAttr("disabled");
		}else{
			$("#bind").attr("disabled","disabled");
		}
	},
	onYzm:function(){
		if($("#mobile").val()&&$("#yzm").val()&&$("#name").val()){
			$("#bind").removeAttr("disabled");
		}else{
			$("#bind").attr("disabled","disabled");
		}
	},
	toBind:function(){
		var name =$("#name").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var tel =  /^(1)[0-9]{10}$/;
		var mobile =$("#mobile").val();
		 var num=/[0-9]{6}/;
		if (!tel.test(mobile)||mobile.length != '11') {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			return;
		}
		if (name == null || name == "") {
			Fw.Form.showPinLabel($(this), "请输入正确姓名", true);
			return;
		}
		 if (!num.test($("#yzm").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		 var url = YT.dataUrlWeb("private/weChatSign");
			var params={
					openId:App.func("openId"),
					mobile:mobile,
					name:name,
					MSG:$("#yzm").val(),
					type:"0"
			}
			Fw.Layer.openWaitPanel();
			App.pageA.off("click", "#bind", App.toBind);
			App.pageA.off("click", "#noBind", App.toNoBind);
			YT.ajaxDataWeb(url,params,function(data){
				console.log(data)
				if(data.STATUS=="1"){
					$.tips({
				        content:"绑定成功",
				        stayTime:2000,
				        type:"success",
				    })
					Fw.Layer.hideWaitPanel();
					setTimeout(function(){
						Fw.redirect("1040801.html?openId="+App.func("openId"));
						App.pageA.on("click", "#bind", App.toBind);
						App.pageA.on("click", "#noBind", App.toNoBind);
					},1000)
				}else{
					$.tips({
				        content:data.MSG,
				        stayTime:2000,
				        type:"fail",
				    })
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					App.pageA.on("click", "#bind", App.toBind);
					App.pageA.on("click", "#noBind", App.toNoBind);
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				$.tips({
			        content:data.MSG,
			        stayTime:2000,
			        type:"fail",
			    })
				App.pageA.on("click", "#bind", App.toBind);
				App.pageA.on("click", "#noBind", App.toNoBind);
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Layer.hideWaitPanel();}
			);
		 
	},
	//弹窗
	toIknow:function(){
		App.pageA.unbind("touchmove");
	},
	toNoBind:function(){
		if(App.func("goBack")&&App.func("goBack")=="yes"){
			window.history.go(-1);
		}else{
			WeixinJSBridge.call('closeWindow');
		}
	},
	pushHistory:function(){
		var state={
				page:"1040800",
		}
		window.history.pushState(state,"title","");
	}

};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);