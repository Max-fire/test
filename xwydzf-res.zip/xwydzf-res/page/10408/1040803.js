/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		App.pageA.on("blur", "#name", App.toBlur);
		App.pageA.on("focus", "#name", App.toFocus);
		var width=document.body.clientWidth;
		var height=$(window).height();
		$("#all").attr("style","height:"+height+"px;");
		App.pageA.removeClass("hidden");
		setTimeout(function(){
			//关闭微信右上角菜单
			WeixinJSBridge.call('hideOptionMenu');
		},1500);
	},
	
	toSubmit:function(){
		var name=$("#name").val();
		if(name==""){
			Fw.Form.showPinLabel($(this), "请输入您的姓名", true);
			return;
		}
		 var url= YT.dataUrlWeb("private/querySalaryMsg");
		 Fw.Layer.openWaitPanel();
			var params={
					name:name,
					id:App.func("id")
			}
			YT.ajaxDataWeb(url,params,function(data){
				if(data.STATUS=="1"){
					Fw.redirect("1040804.html?from=1040803",data);
					$("#name").val("");
					Fw.Layer.hideWaitPanel();
				}else{
					Fw.Form.showPinLabel($(this), data.MSG, true);
					Fw.Layer.hideWaitPanel();
				}
			},function(data){
				Fw.Form.showPinLabel($(this), data.MSG, true);
				Fw.Layer.hideWaitPanel();
				}
			);
	},
	//改变输入框样式
	toBlur:function(){
		$("#xm").removeClass("yui-gzt-yy");
	},
	toFocus:function(){
		$("#xm").addClass("yui-gzt-yy");
	},
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);