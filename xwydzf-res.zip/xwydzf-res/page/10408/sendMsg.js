sendUtil= {
		timer:60,
		intervalID: '',
		/**
		 * 获取短信验证码
		 */
		getSmsCode: function(param, id, callback){
			var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
			$("#yzm").val("");
			var me = this;
			var url = YT.dataUrlWeb('normal/tr3888.json');
			YT.ajaxDataWeb(url, param, function(rsp){
				if(rsp.STATUS == '1'){
				}else{
					me._closeTimerListener(id);
					Fw.Form.showPinLabel($(this), rsp.MSG, true);
				}
			},function(data){
				Fw.Form.showPinLabel($(this), data.MSG, true);
				
			});
		},
		openTimerListener: function(id,param, callback){
			param === undefined && (param = {});
			var tel =  /^(1)[0-9]{10}$/;
			var me = this;
			$('#' + id).on('click', function(){
				if ($("#mobile").val()) {
					param.mobile=$("#mobile").val();
					//param.type = "11";
				}
				 if (!tel.test(param.mobile)||param.mobile == "" || param.mobile.length != "11") {
					 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
					 param.mobile=null;
					 return;
				 }
				me.getSmsCode(param, id,callback)
				me._initTime = new Date().getTime()-1000;
				me._sumTime = 60;
				me._startTimerListener(id,param, callback);
			});
		},
		
		/**
		 * 打开短信验证码计时器
		 */
		_startTimerListener: function(id,param,callback){
			var me = this;
			if(me.timer > 0){
				var time = me._getTimer();
				me.timer = me._sumTime - time;
				if(me.timer>0){
					$("#" + id).text(me.timer + '秒后重发');
					$("#" + id).attr("disabled", true);
				}else{
					me._closeTimerListener(id);
					return;
				}
			}else{
				me._closeTimerListener(id);
				return;
			}
			me.intervalID = setTimeout("sendUtil._startTimerListener('" + id + "')", 1000);
		},
		_getTimer:function(){
			var me = this;
			var time = new Date().getTime();
			return Math.floor((time-me._initTime)/1000);
		},
		/**
		 * 清除计时器
		 * @param id
		 */
		_closeTimerListener: function(id){
			var me = this;
			if(me.intervalID){ // 当intervalID存在时，清空
				clearTimeout(me.intervalID);
				$("#" + id).removeAttr("disabled");//启用按钮
	            $("#" + id).text("重新获取");
	            me.timer = 60;
	            me.intervalID = null;
			}
			$('#' + id).on('click', function(){
				if(!me.intervalID){ // 当之前的intervalID已经清空时，打开
					me._initTime = new Date().getTime()-1000;
					me._sumTime = 60;
					me._startTimerListener(id);
				}
	        });
		},
};