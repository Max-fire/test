/**
 * 创建应用
 * @author wangjx
 */
var oprtType;
var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	init : function(require){
		App.func = window['_getParameter'];	
		App.func("trsId");
		Fw.Client.openWaitPanel();
		var urlTrs = YT.dataUrl("private/queryTrsStatus");
		YT.ajaxData(urlTrs,{trsNo:App.func("trsNo")},function(Data){
			if(Data.STATUS == "1"){
			}else{
				Fw.Client.alertinfo(Data.MSG,"消息提示");
				App.nextPage();
			}
		});
		var url = YT.dataUrl("private/getTaskDetail");
		var json = {
		    		trsNo: App.func("trsNo"),
		    		trsType:'4'
		    }
			YT.ajaxData(url,json,function(data){
			    oprtType = data.trsBiz[0].oprtType;
				sj= false;
				if(data.trsBiz[0].oprtType=="0"){
					sj=true;
				}
				if(sj){//如果变更手机号码
					$('#bgls').html('变更手机号码');
					$('#sjhm').removeClass('hidden');
					$('#yhm').html(data.trsBiz[0].oldPhoneNumber);
					$('#xhm').html(data.trsBiz[0].newPhoneNumber);	
				}else{//如果变更或修改必经人
					if(data.trsBiz[0].oprtType=="1"){
						$('#bgls').html('变更必经人权限');
					}else{
						$('#bgls').html('新增必经人');
					}
					var html = ''
					var tempData = data.approvalBizOp;
					$.each(tempData,function(i,n){
						if(!n.approvalAmount){
							n.approvalAmount = '';
						}
						var bizName = Fw.util.Format.fmtBizType(n.bizNo);
						html += '<div class="ui-form-item yui-det-item">'+
										'<div class="ui-border-b">'+
										'<span class="yui-icon-none" style="background-image:url(../../css/img/bizIcon_'+n.bizNo+'.png)" ></span>'+
										'&nbsp;&nbsp;&nbsp;'+bizName;
						if(n.approvalAmount){
							if(n.approvalAmount=='-1'){
								html +=	'&nbsp;&nbsp;&nbsp;<span class="yui-fs14 yui-c999">不限额</span>';
							}else{
								html +=	'&nbsp;&nbsp;&nbsp;<span class="yui-fs14 yui-c999">限额：'+Fw.util.Format.fmtAmt(n.approvalAmount.toString())+'</span>';
							}
						}
						html +='</div></div>';
					})
					$('#bjrqx').html(html).removeClass('hidden');
				}
				App.showChuli(data);
				App.initEvent();	
			});
		//pageA：主区域
		App.pageA = $("#pageA");
		//pageB：图片预览区域
		App.pageB = $("#pageB"); 
		//默认显示pageA
		App.showPageA();
	},
	/**
	 * 显示pageA
	 */
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	/**
	 * 显示pageB
	 */
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	/**
	 * 绑定事件
	 */
	initEvent:function(){
		$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  		$('#trsStatus').val( $(this).data('status') );
	  		$("#spr").removeClass('hidden');
			if($("#BJ").hasClass('active')){
				$("#spr").addClass('hidden');
			}else if($("#TH").hasClass('active')){
				$("#spr").addClass('hidden');
			}
			else{
				$("#spr").removeClass('hidden');
			}
	  	});
		App.pageA.on("click","#spr",App.initSPR);
		// 提交按钮事件
		App.pageA.on("click","#btnSubmit",App.submit);	
		// 图片预览返回按钮事件
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				$('.yui-det-title').addClass("ui-border-b");
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
		
	},
	/**
	 * 事务提交
	 */
	submit:function(){
		//办结
		if(!$("#BJ").hasClass('active') && !$("#ZB").hasClass('active') && !$("#TH").hasClass('active')){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return false;
		}
		if($("#BJ").hasClass('active')){
			var json = {
					func : "App.initComplete",
					funcAndroid:"App.initCompleteAndroid",
					type : "1"
				}
				Fw.Client.showBB(json);
		};
		   // 转办操作
		if($("#ZB").hasClass('active')){
			var url = YT.dataUrl("private/bizTask");
			var dealMsg = $("#dealMsg").val();
			var dealUserId = $("#dealUserId").val();
			var dealUserName = $("#dealUserName").val();
			if(dealUserId == ""){
				Fw.Form.showPinLabel($(this), "请选择下一个处理人", true);
				return;
			}
			if(Fw.util.proofTest.proolEmoji(dealMsg)){
				Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
				return;
			}
			var params = {
				type:"3",
				trsNo : App.func("trsNo"),   // 事务编号
				nextDealUserId : dealUserId ,              // 下一个处理人ID
			    nextDealUserName : dealUserName ,              // 下一个处理人名字
			    dealMsg : dealMsg ||"同意",     // 处理意见
			    oprtType : oprtType
			}
			YT.ajaxData(url, params, function(data){
				if( data.STATUS =="1"){
					  Fw.Client.alertinfo("已提交给下任处理人："+dealUserName,"提交成功","App.test()");
					  App.nextPage();	
				};
			});
		};
		// 退回操作
		if($("#TH").hasClass('active')){
			var url = YT.dataUrl("private/bizTask");
			var dealMsg = $("#dealMsg").val();
			if(dealMsg.trim() == ""){
				Fw.Form.showPinLabel($(this), "请输入审批意见", true);
				return;
			}
			var params = {
				type:"4",
				trsNo : App.func("trsNo"),	// 事务编号
			    dealMsg : dealMsg,  // 处理意见
			    oprtType : oprtType
			}
			YT.ajaxData(url, params, function(data){
				if(data.STATUS == "1"){
					  Fw.Client.alertinfo("已回退给发起人："+data.creUserName,"提交成功","App.test()");
				};
			});
		};	
	},
	/**
	 * 事务办结
	 */
	initComplete:function(){
		// 防止重复提交
		if(App.flag){
			Fw.Form.showPinLabel(null,"请勿重复提交",true);
			return false;
		}
		var url = YT.dataUrl("private/bizTask");
		var dealMsg = $("#dealMsg").val();
		var params = {
			type:"2",
			trsNo :  App.func("trsNo"),	// 事务编号
		    dealMsg : dealMsg || "同意",
		    trsType : "4",
		    oprtType : oprtType
		}
		YT.ajaxData(url, params, function(data){
			if(data.STATUS =="1"){
					Fw.Client.dealMessage("2",App.func("trsId"));	  
			}else{
				App.flag=false;
				Fw.Client.alertinfo(data.MSG,"消息提示") 
				Fw.Client.hideWaitPanel();
			}
		});
	},
	initCompleteAndroid:function(){
		// 防止重复提交
		if(App.flag){
			Fw.Form.showPinLabel(null,"请勿重复提交",true);
			return false;
		}
		var url = YT.dataUrl("private/bizTask");
		var dealMsg = $("#dealMsg").val();
		var params = {
			type:"2",
			trsNo :  App.func("trsNo"),	// 事务编号
		    dealMsg : dealMsg || "同意",
		    trsType : "4",
		    oprtType : oprtType
		}
		YT.ajaxData(url, params, function(data){
			if(data.STATUS =="1"){
					Fw.Client.dealMessage("2",App.func("trsId"));	  
			}else{
				App.flag=false;
				Fw.Client.alertinfo(data.MSG,"消息提示") 
				Fw.Client.hideWaitPanel();
			}
		});
	},
	/**
	 * 返回
	 */
	test:function(){
		Fw.Client.dealMessage("2",App.func("trsId"));
	},
	/**
	 * 加载处理意见
	 * 
	 */
  showChuli:function( d ){
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
	 			
			if(d.trsInfo[0].trsStatus == "0"){
				
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			
			//延迟 10ms 高亮第一个处理事件
			setTimeout( function(){				

				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			Fw.Client.hideWaitPanel();
			
  },	
	//选择审批人
	initSPR:function(){
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
	}
}
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);