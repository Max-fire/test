/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	datas:{},
	init : function(require){
		
		// pageA：主区域
		App.pageA = $("#pageA");
		
		// pageB：图片预览区域
		App.pageB = $("#pageB"); 
		App.func = window['_getParameter'];
		App.showPageA();
		Fw.Client.openWaitPanel();
		/* 获取上一个页面数据 并保存到 App.datas 变量中 */
		var trsNo = App.func("trsNo");
		if(trsNo){
			
			var url = YT.dataUrl("private/getTaskDetail");
			var json = {
					trsNo : trsNo,
					trsType : "3"
			}
			YT.ajaxData(url,json,function(data){
				$("#trsNo").html(Fw.util.Format.subTrsNo(data.trsInfo[0].trsNo));
				$('#jyls').html( data.trsInfo[0].trsNo);
				$('#qfzh').html( data.trsfrPwd[0].billAcctNo );
				$('#ywzl').html( Fw.util.Format.fmtBillType(data.trsfrPwd[0].billType) );
				$('#pzhm').html( data.trsfrPwd[0].billNo );
				$('#qfrq').html( Fw.util.Format.fmtSignDate(data.trsfrPwd[0].signDate) );
				$('#je').html( "\u00A5"+ Fw.util.Format.fmtAmt(data.trsfrPwd[0].amount.toString()) );
				$('#jedx').html( Fw.util.Format.fmtNumber2Chinese(data.trsfrPwd[0].amount.toString()) );
				$('#skzh').html( data.trsfrPwd[0].toAcctNo );
				App.showChuli( data );
				App.initEvent();	
			})
		}
	},
	// 显示pageA
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	// 显示pageB
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	// 绑定事件
	initEvent:function(){
		
		// 处理按钮事件
  	$('.ui-btn-list').off('click').on('click','button',function(){
  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
  		$('#trsStatus').val( $(this).data('status') );
  	});
  	
		// 提交按钮事件
  	$('#btnSubmit').off('click').on('click',function(){
  	});
  	
		// 图片预览返回按钮事件
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	// 显示数据
	showDatas:function( d ){
		
		$('#jyls').html( d.trsInfo[0].trsNo );
		$('#qfzh').html( d.detail[0].fromAcctNo );
		$('#ywzl').html( d.detail[0].billType );
		$('#pzhm').html( d.detail[0].billNo );
		$('#qfrq').html( Fw.util.Format.fmtTrsCreDate(d.detail[0].signDate) );
		
		$('#je').html( '￥'+ Fw.util.Format.fmtAmt(d.detail[0].amount.toString())+'元' );
		$('#jedx').html( Fw.util.Format.fmtNumber2Chinese(d.detail[0].amount.toString()) );
		$('#skzh').html( d.detail[0].toAcctNo );
		
	},
	// 加载处理意见
  showChuli:function( d ){
	  	App.data = d;
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'" /></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">办　结</div>',
				 						'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			
  },
	toBack:function(){
		Fw.Client.changePage("../10403/1040301.html?trsStatus="+App.func("trsStatus")+"","1");
	},
	
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);