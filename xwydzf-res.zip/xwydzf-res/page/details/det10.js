/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	datas:{},
	attach_url : "",
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require){
			Fw.Client.openWaitPanel();
			// 取成全局变量
			App.func = window['_getParameter'];
			App.func("trsId");
			// pageA：主区域
			App.flag=false;
			App.pageA = $("#pageA");
			App.attchList = new Array();
			App.attch = new Array();
			// pageB：图片预览区域
			App.pageB = $("#pageB"); 
			
			// 默认显示pageA
			App.showPageA();
			
			/* 获取上一个页面数据 并保存到 App.datas 变量中 */
			var url = YT.dataUrl("private/getTaskDetail");
			var params={
					trsNo : App.func("trsNo"),
					trsType : "2"
			}
			YT.ajaxData(url, params, function(d){
				App.data = d;
				App.showDatas(d);
				App.attach_url=d.attach_url;
				App.showFj( d.attach );
				App.showChuli( d );
			});
			App.initEvent();			
	},
	// 显示pageA
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	// 显示pageB
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	// 绑定事件
	initEvent:function(){
		$('#jyls').html(Fw.util.Format.subTrsNo(App.func("trsNo")));
		$("#trsNo").html(App.func("trsNo"));
		// 处理按钮事件
  	$('.ui-btn-list').off('click').on('click','button',function(){
  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
  		$('#trsStatus').val( $(this).data('status') );
  		$("#spr").removeClass('hidden');
		if($("#BJ").hasClass('active')){
			$("#spr").addClass('hidden');
		}else if($("#TH").hasClass('active')){
			$("#spr").addClass('hidden');
		}
		else{
			$("#spr").removeClass('hidden');
		}
  	});
	// 选择审批人
  		App.pageA.on("click","#spr",App.initSPR);
		App.pageA.on("click","#btnSubmit",App.submit);
		// 图片预览返回按钮事件
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	// 选择审批人
	initSPR : function() {
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople:function(name,id,co){
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	submit : function(){
		if(!$("#BJ").hasClass('active') && !$("#ZB").hasClass('active') && !$("#TH").hasClass('active')){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return false;
			
		}
		if(Fw.util.proofTest.proolEmoji($("#dealMsg").val())){
			Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
			return;
		}
		// 办结操作
		if($("#BJ").hasClass('active')){
			var url = YT.dataUrl("private/dailyTask");
			var dealMsg = $("#dealMsg").val();
			if($("#dealMsg").val()==""){
				dealMsg = "同意";
			}
			var params = {
					type:"2",
					trsNo : App.func("trsNo") ,	// 事务编号
					trsType : "2",                // 事务类型
				    dealMsg : dealMsg               // 处理意见
				}
			// 防止重复提交
			if(App.flag){
				Fw.Form.showPinLabel(null,"请勿重复提交",true);
				return false;
			}
			App.flag=true;
			Fw.Client.openWaitPanel();
			YT.ajaxData(url, params, function(data){
				Fw.Client.hideWaitPanel();
				if(data.STATUS =="1"){
					Fw.Client.alertinfo("已办结成功","消息提示","App.nextPage()")  
				}else{
					App.flag=false;
					Fw.Client.alertinfo(data.MSG,"消息提示") 
					return false;
				};
			});
		};
	   // 转办操作
		if($("#ZB").hasClass('active')){
			var url = YT.dataUrl("private/dailyTask");
			var dealMsg = $("#dealMsg").val();
			var dealUserId = $("#dealUserId").val();
			var dealUserName = $("#dealUserName").val();
			var communicateId= $("#communicateId").val();
			if(dealUserId == ""){
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return false;
			}
			if($("#dealMsg").val()==""){
				    dealMsg = "同意";        // 处理意见
			}
			var params = {
					type:"3",
					trsNo : App.func("trsNo"),   // 事务编号
					nextDealUserId : dealUserId ,              // 下一个处理人ID
				    communicateId : communicateId,
					nextDealUserName : dealUserName ,              // 下一个处理人名字
				    dealMsg : dealMsg                // 处理意见
				}
			// 防止重复提交
			if(App.flag){
				Fw.Form.showPinLabel(null,"请勿重复提交",true);
				return false;
			}
			App.flag=true;
			Fw.Client.openWaitPanel();
			YT.ajaxData(url, params, function(data){
				if( data.STATUS =="1"){
					var url = YT.dataUrl("private/addLinkUser");
					var params = {
						userId : dealUserId
					}
					YT.ajaxData(url, params,function(success) {
						Fw.Client.hideWaitPanel();
						if (success.STATUS == "1") {
						}else{
							App.flag=false;
							Fw.Form.showPinLabel($(this),success.MSG,true);
							Fw.Client.hideWaitPanel();
						}
					});
					Fw.Client.hideWaitPanel();
					Fw.Client.alertinfo("已提交给下一个处理人："+dealUserName,"提交成功" ,"App.nextPage()");
					}else{
						App.flag = false;
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG,"消息提示");
						return false;
					}
			});
		};
		// 退回操作
		if($("#TH").hasClass('active')){
			var dealUserName = $("#dealUserName").val();
			var url = YT.dataUrl("private/dailyTask");
			var dealMsg = $("#dealMsg").val();
			if(!$("#dealMsg").val().trim()){
				Fw.Form.showPinLabel(null, "请填写审批意见", true);
				return false;
			}
			var params = {
					type:"4",
					trsNo : App.func("trsNo"),	// 事务编号
				    dealMsg : dealMsg               // 处理意见
				}
			// 防止重复提交
			if(App.flag){
				Fw.Form.showPinLabel(null,"请勿重复提交",true);
				return false;
			}
			App.flag=true;
			Fw.Client.openWaitPanel();
			YT.ajaxData(url, params, function(data){
				Fw.Client.hideWaitPanel();
				if(data.STATUS == "1"){
					Fw.Client.alertinfo("已回退给发起人："+data.creUserName,"提交成功","App.nextPage()");
				}else{
					App.flag=false;
					Fw.Client.alertinfo(data.MSG,"消息提示");
					return false;
				}
			});
		};
	},
	// 返回上一个页面
	nextPage:function(){
		if(App.func("trsId")){
			Fw.Client.dealMessage("2",App.func("trsId"));
		}else{
			Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
			Fw.Client.changePage("../10402/1040201.html",true);
		}
	},
	// 显示数据
	showDatas:function( d){
	 	$('#sqsy').html( d.trsDaily[0].trsDetail );
		$('#sqlx').html( d.trsDaily[0].trsTitle );	
	},
	// 加载处理意见
  showChuli:function( d ){
	  // App.headUrl();
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			
			if(d.trsInfo[0].trsStatus == "0"){
				
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				
				if($("#DQCLR").html()==''&& $("#SQR").html()==''){
					$("#CLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );		
  },
	// 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},	
	// 返回前一页
	toBack:function(){
		if(App.func("trsId")){
			Fw.Client.dealMessage("1",App.func("trsId"));
		}else{
			Fw.Client.changePage("../10402/1040201.html?dealUser=2&trsStatus="+App.trsStatus+"", "1");
		}
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);