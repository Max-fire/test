/**
 * 创建应用
 * 
 * @author wangjx
 */

var App = {
	datas:{},
	attach_url:"",
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 应用入口
	 */
	init : function(require){
		// pageA：主区域
		App.pageA = $("#pageA");
		// pageB：图片预览区域
		App.pageB = $("#pageB"); 
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.attch = new Array();
		App.attchList = new Array();
		App.d = {};
		App.i=0;
		// 防止重复提交表示
		App.flag = false;
		
		App.zydh="";
		App.initEvent();
		// 默认显示pageA
		// 显示是否经过必经人
		/* 获取上一个页面数据 并保存到 App.datas 变量中 */
		Fw.Client.openWaitPanel();
		var json ={
				trsType:"1",
				trsNo:App.func("trsNo")
		}
		var path = YT.dataUrl("private/getTaskDetail");
		YT.ajaxData(path,json,App.showChuli,App.call);
	},
	// 显示pageA
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	// 图片预览区显示pangB
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	// 绑定事件
	initEvent:function(){
		//删除事务
		App.pageA.on("click","#deleTrsNo",App.showDeleteDiv);
		//确定  取消
		App.pageA.on("click","#IYES",App.initIYES);
		App.pageA.on("click","#INO",App.initINO);
		// 办结
		App.pageA.on("click","#BJ",App.initBJ);
		App.pageA.on("click","#BJ3",App.initBJ);
		// 转办
		App.pageA.on("click","#ZB",App.initZB);
		App.pageA.on("click","#ZB3",App.initZB);
		App.pageA.on("click","#ZB4",App.initZB);
		// 添加附件-事件
		App.pageA.on("click",".TJFJ",App.initTJFJ);
		// 退回
		App.pageA.on("click","#TH",App.initTH);
		// 转办2
		App.pageA.on("click","#ZB2",App.initZB2);
		// 退回2
		App.pageA.on("click","#TH2",App.initTH2);
		// 选择审批人
		App.pageA.on("click","#XZSPR",App.initSPR);
		// 提交
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		//明细
		App.pageA.on("click","#mx",App.changeMX);
		//屏蔽按钮
		App.pageA.on("click","#inputCheckbox",App.toInputCheckbox);
		// 处理按钮事件
  	$('.ui-btn-list').off('click').on('click','button',function(){
  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
  	});
  	
  	
		// 图片预览返回按钮事件
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	toInputCheckbox:function(){
		if ($("#inputCheckbox").is(":checked")) {
			$("#inputCheckboxText").html("是");
		}else{
			$("#inputCheckboxText").html("否");
		}
	},
	/**
	 * 确定 取消 点击事件
	 */
	showDeleteDiv:function(){
		$("#black_b").css("display","");
		$("#white_b").css("display","");
	},
	initIYES:function(){
		$("#black_b").css("display","none");
		$("#white_b").css("display","none");
		App.deleTrsNo();
	},
	initINO:function(){
		$("#black_b").css("display","none");
		$("#white_b").css("display","none");
	},
	// 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},
	/**
	 * 添加附件
	 */
	initTJFJ : function(){
		if(App.attch.length > 5){
			Fw.Form.showPinLabel($(this), "附件最多添加6个", true);
			return;
		}
		Fw.Client.openAttcchment("App.showAttcchment");
	},
	showAttcchment: function(name,url){
		Fw.util.attach.addAttach(name,url);
	},
	/**
	 * 删除事务
	 */
	deleTrsNo:function(){
			var path=YT.dataUrl("private/trsInfoInvalid");
			var params={
					trsNo:App.trsNo
			};
			YT.ajaxData(path, params, function(data) {
				if(data.STATUS=="1"){
					Fw.Client.dealMessage("2",App.func("trsId"));
					//Fw.Client.changePage("../10401/1040105.html?trsStatus="+App.trsStatus+"","");
				}
			})
	},
	/**
	 * 跳转明细页面
	 */
	changeMX:function(){
		
		try{
			
			App.d.no = "../details/det15";
			App.d.mx = "0";
			App.d.refuse="0";
			App.d.url=App.url;
			App.d.attch=App.attch;
			
			var amount = Fw.util.Format.replaceDouble("1",$("#HKJEA").html());
			Fw.redirect('../10406/1040608.html?trsNo='+App.func("trsNo")+'&trsStatus='+App.func("trsStatus")+
			'&allCount='+App.bs+'&amount='+amount+'&trsId='+App.func("trsId")+"",App.d);
		
		}catch(e){
			alert(e);
		}
		
	},
	// 判断是否经过必经人
	initBJRPD: function(d){ 
  		App.datas = d;
  		if(d.trsInfo[0].hasOwnProperty("effectiveUserId")){
			App.showJGBJR();
		}else{
			var path = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "3",
					amount : d.trsTrsfr[0].amount+"",
					bizNo: "3",
					flag:"2"
			}
			YT.ajaxData(path,params,function(data){
				if(data.isEffective == "YES"){
					App.showJGBJR();
				}else{
					App.showWJGBJR();
				}
			});
		}
  	},
  // 未经过有效必经人
  	showWJGBJR:function(){
  		if(App.trsStatus=="4"){
  			$("#WEBNONE").removeClass("hidden");
  		}else{
  			$("#WJGSPR").removeClass("hidden");
  		}
  		
  	},
  // 经过有效必经人
  	showJGBJR:function(){
  		if(App.trsStatus=="4"){
  			$("#WEBHAS").removeClass("hidden");
  		}else{
  			$("#JGSPR").removeClass("hidden");
  		}
  	},
	// 加载处理意见
  	showChuli:function( d ){
  		//判断是否有隐藏明细标志 
  		if(d.readFlag=="1"){
			$("#mx").addClass("hidden");
		}else{
			$("#mx").removeClass("hidden");
		}
  		App.trsStatus=d.trsStatus;
  		if(d.trsTrsfr[0].brief=='006'){
			$("#ZYType1").html("代发工资");
			App.zydh="006";
		}else if(d.trsTrsfr[0].brief=='022'){
			$("#ZYType1").html("奖金");
			App.zydh="022";
		}else if(d.trsTrsfr[0].brief=='023'){
			$("#ZYType1").html("津贴");
			App.zydh="023";
		}else if(d.trsTrsfr[0].brief=='047'){
			$("#ZYType1").html("福利");
			App.zydh="047";
		}else if(d.trsTrsfr[0].brief=='048'){
			$("#ZYType1").html("费用报销");
			App.zydh="048";
		}
	  	App.d = d;
	  	if((d.trsTrsfr[0].trsferType=="SALARY_TRANSFER")){
	  		App.pageA.attr("title","代发工资详情");
	  		Fw.Client.initPageTitle("#pageA");
			App.lx = "YGHK";
	  		var data = d;
	  		$("#xqTwo").removeClass("hidden");
	  		$("#cui-fj").removeClass("hidden");
	  		$("#xqOne").addClass("hidden");
	  		App.initBJRPD(data);
	  		App.dealUserId1 = data.trsInfo[0].dealUserId;
	  		App.trsNo = data.trsNo;
	  		$('#trsNoA').html(Fw.util.Format.subTrsNo(data.trsNo));
		  	var amount =0;
		  	App.bs = data.count;
		  	App.list=data.trsTrsfr;
		  	if (data.amount) {
		  		App.toAcctName=data.trsTrsfr[0].toAcctName+"等";
		  		App.toAcctNo=data.trsTrsfr[0].toAcctNo;
		  		amount=data.amount;
			}else{
				App.toAcctName=data.trsTrsfr[0].toAcctName;
		  		App.toAcctNo=data.trsTrsfr[0].toAcctNo;
		  		amount=data.trsTrsfr[0].amount;
			}
		  	$('#amountA').html(Fw.util.Format.fmtAmt(amount+"")+"元");
		  	$('#HKJEA').html(amount);
		  	$('#amount').html(amount);
		  	$('#bs').html(App.bs+"笔");
		  	$('#memo').html(data.trsTrsfr[0].memo);
		  	//屏蔽明细显示
		  	if(d.trsInfo[0].readFlag && d.trsInfo[0].readFlag=="1"){
	  			$('#hklxDF').html( "代发工资（屏蔽明细）");
	  		}else{
	  			$('#hklxDF').html( "代发工资");
	  		}
	  	}
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
					 					'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			App.attach_url = d.attach_url;
			App.trsStatus=d.trsStatus;
			if(d.trsStatus=="4"){
				$("#deleTrsNo").removeClass("hidden");
			}
			App.showFj(d.attach);
			
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			
		if(App.data &&　App.data.attch){
			//明细界面带回数据
	  		App.url=App.data.url;
			App.attch=App.data.attch;
			for ( var k = 0; k < App.attch.length; k++) {
				if(App.attch[k] != null){
					App.showAttcchment(App.attch[k].name,App.url);
				}
			}
		}
		Fw.Client.hideWaitPanel();
		App.showPageA();
  	},
	// 办结
	initBJ: function(){
		$("#SPR").attr("hidden","");
		$("#trsStatus").val("2");
		if(App.trsStatus=="4"){
			$("#showRemitDetails").addClass("hidden");
		}
	},
	// 转办
	initZB: function(){
		$("#SPR").removeAttr("hidden","");
		$("#trsStatus").val("1");
		if(App.trsStatus=="4"){
			$("#showRemitDetails").removeClass("hidden");
		}
	},
	// 退回
	initTH: function(){
		$("#SPR").attr("hidden","");
		$("#trsStatus").val("0");
	},
	// 转办2
	initZB2: function(){
		$("#SPR").removeAttr("hidden","");
		$("#trsStatus").val("1");
	},
	// 退回2
	initTH2: function(){
		$("#SPR").attr("hidden","");
		$("#trsStatus").val("0");
	},
	// 选择审批人
	initSPR : function() {
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id,co) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	// 提交
	toSubmit:function(){
		// 判断【办结】【转办】【退回】
		if($("#trsStatus").val() == ""){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		if($("#trsStatus").val() == "0"){
			if($("#dealMsg").val().trim() == ""){
				Fw.Form.showPinLabel($(this), "请输入审批意见", true);
				return;
			}
		}
		if(Fw.util.proofTest.proolEmoji($("#dealMsg").val())){
			Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
			return;
		}
		if($("#trsStatus").val() == "1"){
			if($("#dealUserId").val() == ""){
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
		}
		//是否对后续处理人隐藏
		if ($("#inputCheckbox").is(":checked")) {
			showRemitDetails='1';
		}else{
			showRemitDetails='0';
		}
		if(App.flag){
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag = true;
		Fw.Client.openWaitPanel("处理中...");
		if($("#trsStatus").val() == "0"){
			// 退回
			if(App.lx == "ZZHK"){
				path = YT.dataUrl("private/transferTask");
				App.params = {
					 type:"4",
					 trsNo : $("#trsNo").html(),
					 innerBank : App.innerBank,
					 amount : $("#amount").html(),
					 memo : $("#memo").html(),
					 nextDealUserName : $("#dealUserName").val(),
					 nextDealUserId : $("#dealUserId").val(),
					 toCommunicateId:$("#communicateId").val(),
					 trsStatus : $("#trsStatus").val(),
					 dealMsg:$("#dealMsg").val(),
					 trsType:"1"
				};
			}else{
				path = YT.dataUrl("private/traditionalTransfer");
				App.params =  {
						type:"4",
						trsNo:App.trsNo,
						dealMsg:$("#dealMsg").val()
				};
			}
			
			YT.ajaxData(path, App.params, App.callbackTrsStatus, App.callbackde);
		}
		if($("#trsStatus").val() == "1"){
			// 转办
			if($("#dealMsg").val() == ""){
				App.dealMsg = "同意";
			}else{
				App.dealMsg =$("#dealMsg").val();
			}
			if(App.lx == "ZZHK"){
				path = YT.dataUrl("private/transferTask");
				App.params = {
						 type:"3",
						 trsNo : $("#trsNo").html(),
						 innerBank : App.innerBank,
						 amount : $("#amount").html(),
						 memo : $("#memo").html(),
						 nextDealUserName : $("#dealUserName").val(),
						 nextDealUserId : $("#dealUserId").val(),
						 toCommunicateId:$("#communicateId").val(),
						 trsStatus : $("#trsStatus").val(),
						 amount : $("#amount").html(),
						 dealMsg:App.dealMsg,
						 trsType:"1"
				};
			}else{
				path = YT.dataUrl("private/traditionalTransfer");
				if(App.trsStatus=="4"){
					App.params =  {
						 	type:"3",
							trsNo:App.trsNo,
							nextDealUserName:$("#dealUserName").val(),
							nextDealUserId:$("#dealUserId").val(),
							dealMsg:App.dealMsg,
							dealUserId:App.dealUserId1,
							amount : $("#HKJEA").html(),
							readFlag:showRemitDetails
						};
				}else{
					App.params =  {
						 	type:"3",
							trsNo:App.trsNo,
							nextDealUserName:$("#dealUserName").val(),
							nextDealUserId:$("#dealUserId").val(),
							dealMsg:App.dealMsg,
							dealUserId:App.dealUserId1,
							amount : $("#HKJEA").html()
						};
				}
				
			}
			
			YT.ajaxData(path, App.params, App.callback, App.callbackde);
		}
		if($("#trsStatus").val() == "2"){
			App.flag = false;
			// 校验棒棒【1 PIN】【2 证书】【3 支付密码】
			if(App.d.trsInfo[0].hasOwnProperty("effectiveUserId") && App.d.trsInfo[0].effectiveUserId.trim() != ""){
				var path = YT.dataUrl("private/isEffective");
				var params = {
						trsType : "3",
						amount : $('#amount').html()+"",
						bizNo: "3",
						flag:"1" // 1.只查权限 2、是否是必经人
				}
				YT.ajaxData(path,params,function(data){
					if(data.isAmount == "YES"){
						if(data.isEffective == "YES"){
							var dealMsg = $("#dealMsg").val();
							if(dealMsg){
								App.dealMsg = dealMsg;
							}else{
								App.dealMsg="同意";
							}
							if(App.lx =="ZZHK"){
								App.initComplete();
								
							}else{
								App.onNext();
							}
						}else{
							Fw.Client.hideWaitPanel();
							Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
							return;
						}
					}else{
						Fw.Client.hideWaitPanel();
						Fw.Form.showPinLabel($(this), "汇款金额不得大于渠道限额("+data.listAmount.toFixed(2)+")", true);
						return;
					}
				});
			}else{
				var path = YT.dataUrl("private/isEffective");
				var params = {
						trsType : "3",
						amount : $('#amount').html()+"",
						bizNo: "3",
						flag:"2" // 1.只查权限 2、是否是必经人
				}
				YT.ajaxData(path,params,function(data){
					if(data.isAmount == "YES"){
						if(data.isEffective == "YES"){
							var dealMsg = $("#dealMsg").val();
							if(dealMsg){
								App.dealMsg = dealMsg;
							}else{
								App.dealMsg="同意";
							}
							if(App.lx == "ZZHK"){
								App.initComplete();
							}else{
								App.onNext();
							}
						}else{
							Fw.Client.hideWaitPanel();
							Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
							return;
						}
					}else{
						Fw.Client.hideWaitPanel();
						Fw.Form.showPinLabel($(this), "汇款金额不得大于渠道限额("+data.listAmount.toFixed(2)+")", true);
						return;
					}
				});
			}
//			
		}
	},
	callbackTrsStatus:function(data){
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已回退给发起人:"+data.creUserName,"提交成功","App.changPage()");
		}else{
			App.flag = false;
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
			return;
		}
	},
	// 成功回调函数
	callback:function(data){
		
		if(data.STATUS == "1"){
			 var path = YT.dataUrl("private/addLinkUser");
				YT.ajaxData(path,{userId:$("#dealUserId").val()},function(data){
				});
				Fw.Client.alertinfo("已提交下一个处理人:"+$("#dealUserName").val(),"提交成功","App.changPage()");
			return;
		}else{
			App.flag = false;
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
			return;
		}
	},
	changPage:function(){
		Fw.Client.hideWaitPanel();
		if(App.func("trsId")){
			Fw.Client.dealMessage("2",App.func("trsId"));
		}else{
			Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
			setTimeout(function() {
				Fw.Client.changePage("../10401/1040105.html",true);
			}, 500);
		}
	},
	
	// 权限通过可以办结
	initComplete:function(){
		var json={
				purpose:$("#bz").html(),
				toAcctName:$("#skhm").val()
				};
		var amount = Fw.util.Format.replaceDouble("1",$("#amount").html());
		var trsNos = $("#trsNo").html();
		Fw.Client.hideWaitPanel();
		if(App.func("trsId")){
			Fw.redirect("../10401/1040109.html?trsId="+App.func("trsId")+"&amount="+amount+"&trsNo="+trsNos+"&dealMsg="+App.dealMsg+"&trsStatus=1"+"&JYLS="+trsNos+"&toAcctNo="+$("#skzh").html()+"",json);
		}else{
			Fw.redirect("../10401/1040109.html?trsId="+""+"&amount="+amount+"&trsNo="+trsNos+"&dealMsg="+App.dealMsg+"&trsStatus=1"+"&JYLS="+trsNos+"&toAcctNo="+$("#skzh").html()+"",json);
		}
	},
	onNext:function(){
		var amount = Fw.util.Format.replaceDouble("1",$("#HKJEA").html());
		var count=App.bs;
		var purpose=$("#memo").html();
		var json = {
				"purpose":purpose,
				zydh:App.zydh,
				list:App.list,
				toAcctName:App.toAcctName
			};
		if(App.func("trsId")){
			Fw.redirect("../10406/1040609.html?trsNo="+App.trsNo+"&amount="+amount+"&trsId="+App.func("trsId")+
			"&toAcctNo="+App.toAcctNo+"&dealMsg="+App.dealMsg+"&count="+count+"",json);
		}else{
			Fw.redirect("../10406/1040609.html?trsNo="+App.trsNo+"&amount="+amount+"&trsId="+""+
			"&toAcctNo="+App.toAcctNo+"&dealMsg="+App.dealMsg+"&count="+count+"",json);
		}
		
	},
	// 判断汇款类型函数
	initHKLX: function( d ){
		if( d == "1"){
			return "行内汇款";
		}
		if( d == "2"){
			return "跨行汇款";
		}
	},
	toBack:function(){
		var json = {
				trsStatus:"0",
		}
		if(App.func("trsId")){
			Fw.Client.dealMessage("1",App.func("trsId"));
		}else{
			Fw.redirect("../10401/1040105.html",json);
		}
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);