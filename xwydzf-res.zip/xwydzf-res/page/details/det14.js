/**
 * 创建应用
 * 
 * @author cuijh
 */
var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	datas:{},
	init : function(require){
		App.func = window['_getParameter'];
		App.attch = new Array();
		App.attchList = new Array();
		App.i=0;
		App.pageA = $("#pageA");
		App.flag = false;
		var url = YT.dataUrl("private/getTaskDetail");
		var params = {
				trsNo:App.func("trsNo"),
				trsType:"5"
		};
		YT.ajaxData(url,params,function(data){
			if(data.STATUS == "1"){
				if (data.trsFinance[0].financeType!="3") {
					App.gm=true;
					App.pageA.attr("title","购买详情");
				}else{
					App.gm=false;
					App.pageA.attr("title","赎回详情");
				}
				App.attach_url = data.attach_url;
				App.initEvent();
				App.showDatas(data);
				App.showFj( data.attach );
				App.showChuli(data);
				App.initBJRPD(data);
			}
		});
	},
	/**
	 * 显示pageA
	 */ 
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	/**
	 * 显示pageB
	 */
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	onCpxys:function(){
		var html=protocol.productCode(App.cpdm);
		Fw.redirect("../10405/"+html+"?No=det14&trsNo="+App.func("trsNo")+"&trsStatus="+App.func("trsStatus")+"&trsId="+App.func("trsId")+"","");
	},
	// 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},	
	/**
	 * 绑定事件
	 */ 
	initEvent:function(){
		//产品协议书
		App.pageA.on("click","#cpxys",App.onCpxys);
		// 办结
		App.pageA.on("click","#BJ",App.initBJ);
		// 转办
		App.pageA.on("click","#ZB",App.initZB);
		// 退回
		App.pageA.on("click","#TH",App.initTH);
		// 转办2
		App.pageA.on("click","#ZB2",App.initZB2);
		// 退回2
		App.pageA.on("click","#TH2",App.initTH2);
		// 提交
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		// 选择审批人
		App.pageA.on("click","#SPR",App.initSPR);
		// 处理按钮事件
	  	$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  		$('#trsStatus').val( $(this).data('status') );
	  		if($("#BJ").hasClass('active')){
				$("#spr").addClass('hidden');
			}else if($("#TH").hasClass('active')){
				$("#spr").addClass('hidden');
			}
			else{
				$("#spr").removeClass('hidden');
			}
	  		
	  		if($("#TH2").hasClass('active')){
				$("#XZSPR").attr('hidden',"");
				$("#trsStatus").val("0");
			}
			if($("#ZB2").hasClass('active')){
				$("#XZSPR").removeAttr('hidden','');
				$("#trsStatus").val("1");
			}
	  	});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	/**
	 * 显示数据
	 */
	showDatas:function( data ){
		if (App.gm) {
			App.d  = data;
			App.data = data.product;
			App.dealUserId1 = data.trsInfo[0].dealUserId;
			App.cpdm = data.trsFinance[0].productCode;
			App.trsNo = data.trsFinance[0].trsNo;
			App.acctNo = data.trsFinance[0].fromAcctNo;
			App.acctName = data.trsFinance[0].fromAcctName;
			App.amount = data.trsFinance[0].amount;
			App.cpmc = data.trsFinance[0].shortName;
//			$("#sy").html(Fw.util.Format.fmtPercent(data.product.referYieldRate));
			
			$("#ZDAmount").html(Fw.util.Format.fmtAmt(data.product.purAmountMin+"")+"元");
			$("#ZGAmount").html(Fw.util.Format.fmtAmt(data.product.holdShareMax+"")+"元");
			$("#dz").html(Fw.util.Format.fmtAmt(data.product.purAmountInc+"")+"元");
			$("#MC").html(data.trsFinance[0].shortName);
			$("#bz").html(Fw.util.Format.fmtbz(data.product.salesCurrency)+"理财");
			$('#trsNo').html( Fw.util.Format.subTrsNo(data.trsFinance[0].trsNo));
			$("#zh").html(data.trsFinance[0].fromAcctNo);
			$('#je').html(Fw.util.Format.fmtAmt(data.trsFinance[0].amount+"")+"元");
			$("#HKJE").html(data.trsFinance[0].amount);
			$("#memo").html(data.trsFinance[0].memo);
		}else{
			$("#tou").addClass("hidden");
			$("#one").html("起赎份额:");
			$("#two").html("最低持有:");
			$("#three").html("交易时间:");
			$("#four").html("赎回份额");
			$("#five").html("入账账号");
			App.d = data;
			App.data = data;
			App.dealUserId1 = data.trsInfo[0].dealUserId;
			App.cpdm = data.trsFinance[0].productCode;
			App.fromAcctNo = data.trsFinance[0].fromAcctNo;
			App.fromAcctName = data.trsFinance[0].fromAcctName;
			App.amount = data.trsFinance[0].financeShare;
			App.trsNo = data.trsFinance[0].trsNo;
			App.cpmc = data.trsFinance[0].shortName;
			$("#MC").html(data.trsFinance[0].shortName);
			$("#sy").html(Fw.util.Format.fmtPercent(data.product.referYieldRate));
			//最低持有
			$("#ZDAmount").html(Fw.util.Format.fmtAmt(data.product.holdShareMin+""));
			//起赎份额
			if(data.product.redShareMin==0){
				$("#jyxq").removeClass("yui-lc-alltitle").addClass("yui-lc-alltitleA");
				$("#qsfeA").addClass("hidden");
			}else{
				$("#dz").html(Fw.util.Format.fmtAmt(data.product.redShareMin+""));
			}
			$("#ZGAmount").html(Fw.util.Format.fmtDate(data.product.transStartDate)+"-"+Fw.util.Format.fmtDate(data.product.transEndDate));
			$('#trsNo').html( Fw.util.Format.subTrsNo(data.trsFinance[0].trsNo) );
			$('#ywls').html( App.func("trsNo") );
			$("#zh").html(data.trsFinance[0].fromAcctNo);
			$('#je').html(Fw.util.Format.fmtAmt(data.trsFinance[0].financeShare+""));
			$("#memo").html(data.trsFinance[0].memo);
		}
		if(protocol.productCode(data.product.productCode)=='protocol4.html'){
			$("#sy").html(Fw.util.Format.fmtPercent(data.product.yieldRate));
		}else{
			$("#sy").html(Fw.util.Format.fmtPercent(data.product.referYieldRate));
		}
		if(protocol.productCode(data.product.productCode)=='protocol4.html'){
			$("#yieldRate").html("七日年化收益率");
		}
		App.showPageA();
	},
	/**
	 * 加载处理意见
	 */
  showChuli:function( d ){
 		var html='',html1='',html2='';
 		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else if item.dealType == 2}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
				 						'</div>',
				 						'{@else if item.dealType == 3}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">撤　销</div>',
				 						'</div>',
				 						'{@else if item.dealType == 4}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="../../css/img/XTtouxiang.png" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey ">拒　绝</div>',
				 						'</div>',	
					 				'{@/if}',
					 					'{@if item.dealType == 4}',
					 					'<div class="ui_01_div4">系统用户</div>',
					 					'{@else}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@/if}',
					 					'{@if item.dealMsg}',
					 						'{@if item.dealType == 4}',
							 				'<div class="ui-bg-ss2">',
							 					　'拒绝原因:&nbsp;&nbsp;${item.dealMsg}',
							 				'</div>',	 
							 				'{@else}',
							 				'<div class="ui-bg-ss2">',
						 					　	'${item.dealMsg}',
						 					 '</div>',	 
							 				'{@/if}',	 
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			Fw.Client.hideWaitPanel();
  },
  	/**
  	 * 判断是否经过必经人
  	 */ 
  	initBJRPD:function(d){
			if(d.trsInfo[0].hasOwnProperty("effectiveUserId")){
				App.showJGBJR();
			}else{
				var url = YT.dataUrl("private/isEffective");
				var params = {
						trsType : "5",
						amount : App.amount+"",
						bizNo: "5",
						flag:"2"
				};
				YT.ajaxData(url,params,function(data){
					if(data.isEffective == "YES"){
						App.showJGBJR();
					}else{
						App.showWJGBJR();
					}
				});
			}
			
			
  	},
	
  /**
   * 未经过有效必经人
   */ 
  	showWJGBJR:function(){
  		$("#JGYXBJR").addClass("hidden");
  		$("#WJGYXBJR").removeClass("hidden");
  	},
  /**
   * 经过有效必经人
   */ 
  	showJGBJR:function(){
  		$("#WJGYXBJR").addClass("hidden");
  		$("#JGYXBJR").removeClass("hidden");
  	},
	/**
	 * 办结
	 */ 
	initBJ:function(){
		$("#trsStatus").val("2");
		$("#XZSPR").attr("hidden","");
	},
	/**
	 * 转办
	 */ 
	initZB:function(){
		$("#trsStatus").val("1");
		$("#XZSPR").removeAttr("hidden","");
	},
	/**
	 * 退回
	 */ 
	initTH:function(){
		$("#trsStatus").val("0");
		$("#XZSPR").attr("hidden","");
	},
	// 转办2
	initZB2: function(){
		$("#SPR").removeAttr("hidden","");
		$("#trsStatus").val("1");
	},
	// 退回2
	initTH2: function(){
		$("#SPR").attr("hidden","");
		$("#trsStatus").val("0");
	},
	/**
	 * 选择审批人
	 */ 
	initSPR:function(){
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id,co) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 事务提交
	 */
	toSubmit:function(){
		if($("#trsStatus").val() == ""){
			Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji($("#dealMsg").val())){
			Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
			return;
		}
		if($("#trsStatus").val() == "0"){
			// 退回
			App.dealMsg = $("#dealMsg").val();
			if (App.dealMsg==null||App.dealMsg=="") {
				Fw.Form.showPinLabel($(this), "请输入审批意见", true);
				return;
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			var url = YT.dataUrl("private/financtTask");
			var params =  {
					type:"4",
					trsNo:App.func("trsNo"),
					dealMsg:App.dealMsg
			};
			YT.ajaxData(url, params, App.callbackTrsStatus, App.call);
			
		}
		
		if($("#trsStatus").val() == "1"){
			// 转办
			var dealMsg = $("#dealMsg").val();
			if(dealMsg){
				App.dealMsg = dealMsg;
			}else{
				App.dealMsg="同意";
			}
			if($("#dealUserId").val()==""||$("#dealUserId").val()==null){
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			var  url = YT.dataUrl("private/financtTask");
			if (App.gm) {
				var params =  {
						type:"3",
						trsNo:App.func("trsNo"),
						"financeType":"2",
						nextDealUserName:$("#dealUserName").val(),
						nextDealUserId:$("#dealUserId").val(),
						dealMsg:App.dealMsg,
						dealUserId:App.dealUserId1,
						amount : $("#HKJE").html()
				};
				YT.ajaxData(url, params, App.callback, App.call);
			}else{
				var params =  {
						type:"3",
						trsNo:App.func("trsNo"),
						"financeType":"3",
						nextDealUserName:$("#dealUserName").val(),
						nextDealUserId:$("#dealUserId").val(),
						dealMsg:App.dealMsg,
						dealUserId:App.dealUserId1,
						share : App.amount+"",
						amount:App.amount+""
				};
				YT.ajaxData(url, params, App.callback, App.call);
			}
		}
		
		Fw.Client.openWaitPanel();
		if($("#trsStatus").val() == "2"){
			//办结
			var url = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "5",
					amount : App.amount+"",
					bizNo: "5"
			};
			if(App.d.trsInfo[0].hasOwnProperty("effectiveUserId") && App.d.trsInfo[0].effectiveUserId.trim() != ""){
				
				params.flag = "1";   // 1.只查权限 2、是否是必经人
			}else{
				params.flag = "2";   // 1.只查权限 2、是否是必经人
			}
			YT.ajaxData(url,params,function(data){
					if(data.isEffective == "YES"){
						if (App.gm) {
							App.initComplete();
						}else{
							App.initBJs();
						}
					}else{
						Fw.Client.hideWaitPanel();
						Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
						return;
					}
			});
		}
	},
	
	/**
	 * 直接办结
	 */
	initBJs:function(){
		var dealMsg = $("#dealMsg").val();
		if(dealMsg){
			App.dealMsg = dealMsg;
		}else{
			App.dealMsg="同意";
		}
		var params = {
			type:"2",
			transCode:"REDEEN",
			trsNo : App.trsNo,
			"financeType":"3",
			cpdm:App.cpdm,
			fromAcctNo:App.fromAcctNo,
			fromAcctName:App.fromAcctName,
			zhdh:App.fromAcctNo,
			shfe:App.amount+"",
			yddh:"",
			dealMsg:App.dealMsg
		};
		var url = YT.dataUrl("private/financtTask");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,params,App.successs,App.failuri);
		
	},
	/**
	 * 赎回直接办结成功回调函数
	 */
	successs:function(data){
			if (data.STATUS == "1") {
				App.data.cpmc = App.cpmc;
				App.data.acctNo = App.fromAcctNo;
				App.data.trsNo = data.trsNo;
				App.data.shfe = data.shfe;
				App.data.ywslbh = data.ywslbh;
				App.data.transDate = data.transDate;
				App.data.trsId=App.func("trsId");
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.test1()");
			} else {
				App.flag = false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示","App.initFail()");
			}
	},
	/**
	 * 办结成功返回凭证类型
	 */
	test1:function(){
			Fw.Client.hideWaitPanel();
			Fw.redirect("../10405/1040505_shpz.html", App.data);
	},
	/**
	 * 转账失败回到待办列表
	 */
	initFail: function(){
		Fw.Client.changePage("../10405/1040507.html?trsStatus="+App.func("trsStatus")+"","1");
		
	},
	
	// 权限通过可以办结
	initComplete:function(){
		var dealMsg = $("#dealMsg").val();
		if(dealMsg){
			App.dealMsg = dealMsg;
		}else{
			App.dealMsg="同意";
		}
		App.onNext();
	},
	onNext:function(){
		Fw.Client.openWaitPanel("提交中...");
		var json = {
				func : "App.initComplete1",
				funcAndroid:"App.initCompleteAndroid",
				type : "2",
				toName:"兴业银行",
				toAcc:"",
				fromName:App.acctName,//付款名称
				fromAcc:App.acctNo,//付款账号
				xmlMoney:$("#HKJE").html().replace(/\s/g,""),//金额
				xmlNo:App.trsNo//流水账号
			};
		Fw.Client.hideWaitPanel();
		Fw.Client.showBB(json);
	},
	/**
	 * PIN 码验证通过iphon
	 */
	initComplete1:function(a,b){
		var fromAcctNo = App.acctNo;
		var fromAcctName = App.acctName;
		var purpose = "";
		Fw.Client.openWaitPanel();
		App.initBJ1(a,b,fromAcctNo,fromAcctName,purpose);
		
	},
	/**
	 * PIN 码验证通过Android
	 */
	initCompleteAndroid:function(a,b,fromAcctNo,fromAcctName,purpose){
		var fromAcctNo = App.acctNo;
		var fromAcctName = App.acctName;
		var purpose = "";
		App.initBJ1(a,b,fromAcctNo,fromAcctName,purpose);
	},
	/**
	 * 直接办结
	 */
	initBJ1:function(a,b,acctNo,acctName,purpos){
			var params = {
					type:"2",
					transCode:"PUR",
					"financeType":"2",
					trsNo : App.trsNo,
					cpdm:App.cpdm,
					fromAcctNo:App.acctNo,
					fromAcctName:App.acctName,
					zhdh:App.acctNo,
					jyje:$("#HKJE").html().replace(/\s/g,""),
					yddh:"",
					dealMsg:App.dealMsg,
					purpose : purpos,
					signData:a,
					signSrc:b
			};
			var url = "private/financtTask.json";
			Fw.Client.openWaitPanel();
			Fw.Client.post(url,params,"App.success1","App.failuri");
			
	},
	/**
	 * 直接办结成功回调函数
	 */
	success1:function(data){
			Fw.Client.hideWaitPanel();
			if (data.STATUS == "1") {
				App.data.trsNo = data.trsNo;
				App.data.ywslbh = data.ywslbh;
				App.data.acctNo =App.acctNo;
				App.data.amount =App.amount;
				App.data.cpmc = App.cpmc;
				App.data.transDate = data.transDate;
				App.data.trsType="5";
				App.data.trsId=App.func("trsId");
				Fw.Client.alertinfo(data.MSG,"消息提示","App.testC()");
			} else {
				App.flag = false;
				Fw.Client.alertinfo(data.MSG,"消息提示","App.test()");
			}
	},
	testC:function(){
			Fw.redirect("../10405/1040502_gmpz.html", App.data);
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(e,"消息提示");
	},
	
	callbackTrsStatus:function(data){
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已回退给发起人:"+data.creUserName,"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	// 成功后返回函数
	callback:function(data){
		 var url = YT.dataUrl("private/addLinkUser");
			YT.ajaxData(url,{userId:$("#dealUserId").val()},function(data){
			});
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人:"+$("#dealUserName").val(),"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			return;
		}
	},
	test:function(){
		Fw.Client.dealMessage("2",App.func("trsId"));
	},
	toBack:function(){
			Fw.Client.dealMessage("1",App.func("trsId"));	
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);