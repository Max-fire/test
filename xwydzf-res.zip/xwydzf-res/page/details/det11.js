/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	datas:{},
	init : function(require){
		App.pageA = $("#pageA");
		Fw.Client.openWaitPanel();
		App.pageB = $("#pageB"); 
		/* 获取上一个页面数据 并保存到 App.datas 变量中 */
		App.func = window['_getParameter'];
		var trsNo = App.func("trsNo");
		if(trsNo){
			if(App.func("trsStatus") == "2"){
				$("#pageA").attr("data-btnRight","true|修改|App.initXG()");
			}else{
				$("#pageA").attr("data-btnRight","false|修改|App.initXG()");
			}
			App.showPageA();
			
			var url = YT.dataUrl("private/getTaskDetail");
			var json = {
					trsNo:trsNo,
					trsType:"3"
			}
			YT.ajaxData(url,json,function(data){
				App.data = data;
				$('#skzh').html( data.trsfrPwd[0].toAcctNo );
				$('#qfrq').html( Fw.util.Format.fmtSignDate(data.trsfrPwd[0].signDate) );
				$('#trsNo').html( Fw.util.Format.subTrsNo(data.trsInfo[0].trsNo) );
				$('#jyls').html( App.func("trsNo") );
				App.trsNo =App.func("trsNo");
				$('#qfzh').html(data.trsfrPwd[0].billAcctNo );
				$('#fromAcctNo').html( data.trsfrPwd[0].billAcctNo );
				$('#ywzl').html( Fw.util.Format.fmtBillType(data.trsfrPwd[0].billType) );
				$('#je').html( "\u00A5"+ Fw.util.Format.fmtAmt(data.trsfrPwd[0].amount.toString()) );
				$('#jedx').html( Fw.util.Format.fmtNumber2Chinese(data.trsfrPwd[0].amount.toString()) );
				App.trsStatus = data.trsInfo[0].trsStatus;
				App.AcctNo = data.trsfrPwd[0].toAcctNo;
				App.billTypeId = data.trsfrPwd[0].billType;
				App.amounts = data.trsfrPwd[0].amount;
				App.toAcctNo = data.trsfrPwd[0].toAcctNo;
				$('#pzhm').html( data.trsfrPwd[0].billNo );
				var html='',html1='',html2='';
				var temp = [
			      			'{@each dealLog as item}',
			      			'{@if item.dealUserId != ""}',
					      			'<div class="yui_div_hm" >',
						 				'<div class="ui_01_div2">',
							 				'<div class="ui_01_div3 ui-list">',
							 					'<div class="ui_01_img1"></div>',
							 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
							 				'</div>',					 				
							 				'<div class="ui-bg-ss1">',
							 				'{@if item.dealType == 0}',
								 				'<div class="ui_01_phoneBack">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey">退　回</div>',
						 						'</div>',
						 					'{@else if item.dealType == 1}',
							 					'<div class="ui_01_phoneTongYi ui-list">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
						 						'</div>',
						 					'{@else}',
							 					'<div class="ui_01_phoneTongYi">',
							 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
							 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
						 						'</div>',
							 				'{@/if}',
							 					'<div class="ui_01_div4">${item.dealUserName}</div>',
							 					'<div class="ui_01_div5">(审批人)</div>',
							 					'{@if item.dealMsg}',
									 				'<div class="ui-bg-ss2">',
									 					　'${item.dealMsg}',
									 				'</div>',
							 					'{@/if}',
							 				'</div>',
						 				'</div>',
					 				'</div>',
				 				'{@/if}',
			      			'{@/each}',
		   			].join("");
		   			
					html = Fw.template(temp,data);
					html1 = 
							'<div class="yui_div_hm" >'+
			 				'<div class="ui_01_div2">'+
				 				'<div class="ui_01_div3 ui-list">'+
				 					'<div class="ui_01_img1"></div>'+
				 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].trsCreTime)+'</div>'+
				 				'</div>'+
				 				'<div class="ui-bg-ss1">'+
				 					'<div class="ui_01_phoneTongYi">'+
				 						'<div class="ui_01_phone1"><img src="'+data.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
				 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
				 					'</div>'+
				 					'<div class="ui_01_div4">'+data.trsInfo[0].creUserName+'</div>'+
				 					'<div class="ui_01_div5">(申请人)</div>'+
				 				'</div>'+
			 				'</div>'+
			 			'</div>';
					if(data.trsInfo[0].trsStatus == "0"){
						html2 = 
							'<div class="yui_div_hm" >'+
							'<div class="ui_01_div2">'+
			 				'<div class="ui_01_div3 ui-list">'+
			 					'<div class="ui_01_img1"></div>'+
			 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].sendTime)+'</div>'+
			 				'</div>'+
			 				
			 				'<div class="ui-bg-ss1">'+
			 					'<div class="ui_01_phoneTongYi">'+
			 						'<div class="ui_01_phone1"><img src="'+data.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
			 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
			 					'</div>'+
			 					'<div class="ui_01_div4">'+data.trsInfo[0].dealUserName+'</div>'+
			 					'<div class="ui_01_div5">(审批人)</div>'+
			 				'</div>'+
							'</div>'+
						'</div>';
						$("#DQCLR").html(html2);
					}
					$("#SQR").html(html1);
					$("#CLR").html(html);
					App.setTimeout();
					Fw.Client.hideWaitPanel();
			});
			App.initEvent();			
			console.log(App.datas);
		}
	},
	// 显示pageA
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	// 显示pageB
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	// 绑定事件
	initEvent:function(){
		
		// 处理按钮事件
  	$('.ui-btn-list').off('click').on('click','button',function(){
  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
  		$('#trsStatus').val( $(this).data('status') );
  	});
  	
  	
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	// 显示数据
	// 加载修改页面
	initXG:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/isApproval");
	    YT.ajaxData(url,{trsType:"3"},function(Data){
	    	if(Data.STATUS == "1"){
	    		if(Data.IsApproval=="YES"){
		    		Fw.Client.hideWaitPanel();
		    		var amount = Fw.util.Format.replaceDouble("1",App.amounts);
		    		Fw.Client.changePage("../10403/1040300_XGB.html?trsNo="+App.trsNo+"&trsStatus="+App.trsStatus
		    				+"&toAcctNo="+App.toAcctNo+"&acctNo="+$("#fromAcctNo").html()+"&billType="+App.billTypeId+"&billNo="+$("#pzhm").html()+"&signTime="+$("#qfrq").html()+"&amounts="+amount+"","0");
		    	}else{
		    		Fw.Client.hideWaitPanel();
		    		var amount = Fw.util.Format.replaceDouble("1",App.amounts);
		    		Fw.Client.changePage("../10403/1040300_XG.html?trsNo="+App.trsNo+"&trsStatus="+App.trsStatus
		    				+"&toAcctNo="+App.toAcctNo+"&acctNo="+$("#fromAcctNo").html()+"&billType="+App.billTypeId+"&billNo="+$("#pzhm").html()+"&signTime="+$("#qfrq").html()+"&amounts="+amount+"","0");
		    	}
	    	}else{
	    		Fw.Client.alertinfo(Data.MSG,"消息提示");
	    		Fw.Client.hideWaitPanel();
	    		return;
	    	}
	    })	
	},
	
	// 延迟 10ms 高亮第一个处理事件
	setTimeout: function(){
		if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
			if($('.ui_01_phoneBack').length>0){
				return false;
			}
			$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
			$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
		}
		if($("#DQCLR").html()!=''){
			$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
			$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
		}
		
	},
	
	// 返回前一页
	toBack:function(){
		Fw.Client.changePage("../10403/1040300.html?trsStatus="+App.trsStatus+"","1");
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);