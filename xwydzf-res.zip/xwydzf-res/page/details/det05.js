/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	datas:{},
	attach_url : "",
	requires : ['Fw.util.attach'],
	/**
	 * 应用入口
	 * @param require
	 */
	init : function(require){
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB"); 
		App.array = new Array();
		App.attch = new Array();
		App.attchList = new Array();
		Fw.Client.openWaitPanel();
		var data = App.func("trsNo");
		var trsStatus = App.func("trsStatus");
		if(data){
			if(trsStatus == "2"){
				$("#pageA").attr("data-btnRight","true|修改|App.initXG()");
			}
		var url = YT.dataUrl("private/getTaskDetail");
		var json = {
			trsNo:data,
			trsType:"1"
		}	
		App.initEvent();
		YT.ajaxData(url,json,function(data){
			App.data = data;
			if(data.STATUS=="1"){
				if (App.func("trsStatus") == "1") {
					if (data.canBack=="1") {
						$("#pageA").attr("data-btnRight","true|撤销|App.onTJ()");
					}
					App.data.trsDate=data.dealLog[0].dealTime;
					$("#sjz").removeClass("hidden");
					if (data.trsTrsfr[0].trsfrStatus!="1") {
						$("#ckpz").removeClass("hidden");
					}
					//判断是否是落地审核
					if (data.audite && data.audite=="YES") {
						//未审核
						if (data.auditeStatus=="1") {
							$("#clz").html("待银行审核");
							$("#wczt").html("处理中");
							$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
							$('#tjsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
						}else{
							//已审核
							$("#clz").html("银行已审核");
							if(data.trsTrsfr[0].trsfrStatus=="3"){
								$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
								$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
								$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf");
								$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc1");
								$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.trsTrsfr[0].recvTime,"MM-dd HH:mm:ss"));
							}else if (data.trsTrsfr[0].trsfrStatus=="1") {
								$("#sb").removeClass("hidden");
								$("#sbyy").html(data.trsTrsfr[0].msg);
								$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
								$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
								$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf").attr("style","color:#e61920;text-align: right;");
								$("#wczt").html("汇款失败");
								$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc3");
								if(data.dealLog[0].dealType=="4"){
									$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.auditeTime,"MM-dd HH:mm:ss"));
								}else if (data.dealLog[0].dealType=="3") {
									$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.dealLog[0].dealTime,"MM-dd HH:mm:ss"));
								}else{
									if (data.trsTrsfr[0].recvTime) {
										$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.trsTrsfr[0].recvTime,"MM-dd HH:mm:ss"));
									}else{
										$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.auditeTime,"MM-dd HH:mm:ss"));
									}
								}
							}
							$('#tjsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
							$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.auditeTime,"MM-dd HH:mm:ss"));
						}
						
					}else{
						$("#clz").html("待银行处理");
						$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
						$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
						if(data.trsTrsfr[0].trsfrStatus=="3"){
							$("#clz").html("银行已处理");
							$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
							$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf");
							$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc1");
							$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.trsTrsfr[0].recvTime,"MM-dd HH:mm:ss"));
							$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsTrsfr[0].recvTime,"MM-dd HH:mm:ss"));
						}else if (data.trsTrsfr[0].trsfrStatus=="1") {
							$("#clz").html("银行已处理");
							$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
							$("#sb").removeClass("hidden");
							$("#sbyy").html(data.trsTrsfr[0].msg);
							$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf").attr("style","text-align: right;color:#e61920;");
							$("#wczt").html("汇款失败");
							$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc3");
							if(data.dealLog[0].dealType=="4"){
								$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
								$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
							}else if (data.dealLog[0].dealType=="3") {
								$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.dealLog[0].dealTime,"MM-dd HH:mm:ss"));
								$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.dealLog[0].dealTime,"MM-dd HH:mm:ss"));
							}else{
								$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.trsTrsfr[0].recvTime,"MM-dd HH:mm:ss"));
								$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsTrsfr[0].recvTime,"MM-dd HH:mm:ss"));
							}
						}else{
							$("#wczt").html("处理中");
						}
						$('#tjsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
					}
					
				}
				$('#trsNo').html( Fw.util.Format.subTrsNo(data.trsInfo[0].trsNo) );
				$('#jyls').html( data.trsInfo[0].trsNo );
				if (data.trsTrsfr[0].expectedDate) {
					$('#hklx').html( App.initInnerbank(data.trsTrsfr[0].innerBank)+"（次日到账）");
				}else{
					$('#hklx').html( App.initInnerbank(data.trsTrsfr[0].innerBank));
				}
				$('#skzh').html( data.trsTrsfr[0].toAcctNo);
				$('#skdw').html( data.trsTrsfr[0].toAcctName );
				$('#skyh').html( data.trsTrsfr[0].toBrName||'兴业银行' );
				$('#je').html( "\u00A5"+ Fw.util.Format.fmtAmt(data.trsTrsfr[0].amount.toString()) );
				$('#jedx').html( Fw.util.Format.fmtNumber2Chinese(data.trsTrsfr[0].amount.toString()) );
				$('#bz').html( data.trsTrsfr[0].memo );
				App.showPageA();
				App.attach_url = data.attach_url;
				App.showFj(data.attach);
					var html='',html1='',html2='';
					var temp = [
				      			'{@each dealLog as item}',
				      			'{@if item.dealUserId != ""}',
						      			'<div class="yui_div_hm" >',
							 				'<div class="ui_01_div2">',
								 				'<div class="ui_01_div3 ui-list">',
								 					'<div class="ui_01_img1"></div>',
								 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
								 				'</div>',					 				
								 				'<div class="ui-bg-ss1">',
								 				'{@if item.dealType == 0}',
									 				'<div class="ui_01_phoneBack">',
								 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
								 						'<div class="ui_01_greey">退　回</div>',
							 						'</div>',
							 					'{@else if item.dealType == 1}',
								 					'<div class="ui_01_phoneTongYi ui-list">',
								 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
								 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
							 						'</div>',
							 					'{@else if item.dealType == 2}',
								 					'<div class="ui_01_phoneTongYi">',
								 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
								 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
							 						'</div>',
							 						'{@else if item.dealType == 3}',
								 					'<div class="ui_01_phoneBack">',
								 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
								 						'<div class="ui_01_greey">撤　销</div>',
							 						'</div>',
							 						'{@else if item.dealType == 4}',
								 					'<div class="ui_01_phoneBack">',
								 						'<div class="ui_01_phone1"><img src="../../css/img/XTtouxiang.png" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
								 						'<div class="ui_01_greey ">拒　绝</div>',
							 						'</div>',	
								 				'{@/if}',
								 					'{@if item.dealType == 4}',
								 					'<div class="ui_01_div4">系统用户</div>',
								 					'{@else}',
								 					'<div class="ui_01_div4">${item.dealUserName}</div>',
								 					'<div class="ui_01_div5">(审批人)</div>',
								 					'{@/if}',
								 					'{@if item.dealType == 3}',
								 					'<div class="ui-bg-ss2">',
								 					　'该笔汇款已撤销',
										 				'</div>',
								 					'{@/if}',
								 					'{@if item.dealMsg}',
								 						'{@if item.dealType == 4}',
										 				'<div class="ui-bg-ss2">',
										 					　'拒绝原因:&nbsp;&nbsp;${item.dealMsg}',
										 				'</div>',	 
										 				'{@else}',
										 				'<div class="ui-bg-ss2">',
									 					　	'${item.dealMsg}',
									 					 '</div>',	 
										 				'{@/if}',	 
								 					'{@/if}',
								 				'</div>',
							 				'</div>',
						 				'</div>',
					 				'{@/if}',
				      			'{@/each}',
			   			].join("");
						html = Fw.template(temp,data);
						html1 = 
								'<div class="yui_div_hm" >'+
				 				'<div class="ui_01_div2">'+
					 				'<div class="ui_01_div3 ui-list">'+
					 					'<div class="ui_01_img1"></div>'+
					 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].trsCreTime)+'</div>'+
					 				'</div>'+
					 				
					 				'<div class="ui-bg-ss1">'+
					 					'<div class="ui_01_phoneTongYi">'+
					 						'<div class="ui_01_phone1"><img src="'+data.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
					 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
					 					'</div>'+
					 					'<div class="ui_01_div4">'+data.trsInfo[0].creUserName+'</div>'+
					 					'<div class="ui_01_div5">(申请人)</div>'+
					 				'</div>'+
				 				'</div>'+
				 			'</div>';
						if(data.trsInfo[0].trsStatus == "0"){
							html2 = 
								'<div class="yui_div_hm" >'+
								'<div class="ui_01_div2">'+
				 				'<div class="ui_01_div3 ui-list">'+
				 					'<div class="ui_01_img1"></div>'+
				 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].sendTime)+'</div>'+
				 				'</div>'+
				 				
				 				'<div class="ui-bg-ss1">'+
				 					'<div class="ui_01_phoneTongYi">'+
				 						'<div class="ui_01_phone1"><img src="'+data.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
				 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
				 					'</div>'+
				 					'<div class="ui_01_div4">'+data.trsInfo[0].dealUserName+'</div>'+
				 					'<div class="ui_01_div5">(审批人)</div>'+
				 				'</div>'+
								'</div>'+
							'</div>';
							$("#DQCLR").html(html2);
						}
						$("#SQR").html(html1);
						$("#CLR").html(html);
						App.showChuli();
						Fw.Client.hideWaitPanel();
				 }
		},function(){
			alert("请求失败");
		});
	  }
	},
	
	array:{},
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	// 绑定事件
	initEvent:function(){
		var width=(document.body.clientWidth-144)/2;
		$("#gdx1").attr("style","width:"+width+"px;");
		$("#gdx").attr("style","width:"+width+"px;");
		// 处理按钮事件
	  	$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  		$('#trsStatus').val( $(this).data('status') );
	  	});
		//查看凭证
		App.pageA.on("click","#ckpz",App.toCKPZ);
		
			// 提交按钮事件
	  	$('#btnSubmit').off('click').on('click',function(){
	  	});
		// 图片预览返回按钮事件
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	goTask:function(){
		var json = {
				trsStatus:"1",
		}
		Fw.redirect("../10401/1040100.html?trsStatus=1",json);
	},
	//撤销操作
	onTJ:function(){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/transferCancel");
		var json = {
				trsNo:App.func("trsNo"),
				type:"1",
		};
		YT.ajaxData(url,json,function(data){
			if(data.STATUS == "1"){
				Fw.Client.alertinfo(data.MSG,"消息提示","App.goTask()");
				Fw.Client.hideWaitPanel();
	    	}else{
	    		Fw.Client.alertinfo(data.MSG,"消息提示","App.goTask()");
	    		Fw.Client.hideWaitPanel();
	    	}
		});
	},
	//查看凭证
	toCKPZ:function(){
		App.data.page="../details/det05.html?trsNo="+App.func("trsNo")+"&trsStatus=1";
		Fw.redirect("../10401/1040115.html", App.data);
	},
	// 加载处理意见
	showChuli:function( d ){
			// 延迟 10ms 高亮第一个处理事件
		setTimeout( function(){
			
			if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
				if($('.ui_01_phoneBack').length>0){
					return false;
				}
				$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
				$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
			}
			
			if($("#DQCLR").html()!=''){
				$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
				$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
			}
			
		},10 );
			
  },
	// 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
//		if(d.length > 0){ 
//			$("#FJLB").removeClass("hidden");
//		}
//		var html='';
//		$.each(d,function(i,n){
//			var attachType = n.attachName.substring(n.attachName.length-3,n.attachName.length);
//			if(attachType== "amr" || attachType=="m4a"){
//				html += '<div class="swiper-slide swiper-slide-active" style="width: 75px;">'+
//		              '<div class="ui-files audio" data-src="'+App.attach_url+n.attachUrl+'">'+
//		              '</div>'+
//	              '</div>';
//			}
//			if(attachType== "jpg"){
//				html += '<div class="swiper-slide swiper-slide-active" style="width: 75px;">'+
//		              '<div class="ui-files pic" style="background-image:url('+App.attach_url+n.attachUrl+'); background-size: 100% auto" data-url="'+App.attach_url+n.attachUrl+'">'+
//		              '</div>'+
//	              '</div>';      	
//			}
//		});
//		$('#fj').html(html);
//		App.fujian();
	},	
	// 判断是行内跨行
	initInnerbank: function( s ){
		if(s=="1"){
			return "行内汇款";
		}
		if(s=="2"){
			return "跨行汇款";
		}
	},
	//跳转修改页面
	initXG:function(){
		var json = App.data.trsInfo[0].trsNo;
		if(App.data.trsTrsfr[0].innerBank == "1"){
			Fw.Client.changePage("../10401/1040100_YTHXG.html?json="+json+"&status="+"0"+"","0");
		}
		if(App.data.trsTrsfr[0].innerBank == "2"){
			Fw.Client.changePage("../10401/1040100_XGKH.html?json="+json+"&status="+"0"+"","0");
		}
	},
	//返回列表页面
	toBack:function(){
		Fw.Client.changePage("../10401/1040100.html?trsStatus="+App.func("trsStatus")+"");
	},
	// 附件函数
	fujian : function(){		
		App.audio = document.getElementById("mainAudio");
		var swiper = new Swiper('.swiper-container', {
		    slidesPerView: 'auto',
		    freeMode: true,
		    freeModeMomentumBounce: false,
		    spaceBetween: 0
		});
		$('#fj').off('click').on("click", ".audio", function () {
		    if ($(this).hasClass('active')) {		
		        App.audioPause($(this));		
		    } else {		
		        App.audioPlay($(this));
		    }
		}).on("click", ".pic", function () {		
		    console.log('tap:图片预览');
		    App.picView($(this));		
		});
	},
	// 音频播放
	audioPlay:function(elem) {
//	      if (App.audioActive != elem.data('src')) {
//	          App.audioActive = elem.data('src');
//	          $("#mainAudio").attr("src", App.audioActive);
//	          console.log('set src');
//	      }
//	      $('.audio').removeClass('active');
//	      elem.addClass('active');
//	      console.log(App.audio);
//	      App.audio.pause();
//	      App.audio.play();
//	      App.audio.addEventListener('ended',function(){
//				elem.removeClass('active');
//			});
//	      console.log('正在播放，点击暂停');
		Fw.Client.openAudio(elem.data("src"));
	},
	// 音频暂停
	audioPause:function(elem) {
	      elem.removeClass('active');
	      console.log(App.audio);
	      App.audio.pause();
	      console.log('已暂停，点击继续播放');
	},
	// 图片预览
	picView:function(elem) {
			var url = elem.data('url');
//			$('#picView').attr('src',url);
//			App.showPageB();
			Fw.Client.openImage(url);
			console.log(App.pageB.height());
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);