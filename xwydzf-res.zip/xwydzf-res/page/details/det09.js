/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	datas:{},
	attach_url:"",
	requires : ['Fw.util.attach'],
	/**
	 * 应用入口
	 */
	init : function(require){
		Fw.Client.openWaitPanel();
		App.pageA = $("#pageA");
		App.pageB = $("#pageB"); 
		App.showPageA();
		App.attchList = new Array();
		App.attch = new Array();
		/* 获取上一个页面数据 并保存到 App.datas 变量中 */
		App.func = window['_getParameter'];
		var trsNo = App.func("trsNo");
		if(trsNo){
			$('#jyls').html(Fw.util.Format.subTrsNo(trsNo));
			$("#trsNo").html(trsNo);
			var url = YT.dataUrl("private/getTaskDetail");
			var params={
					trsNo:trsNo,
					trsType:"2"	
			}
			YT.ajaxData(url, params, function(d){
				App.data = d;
				App.showDatas(d);
				App.attach_url=d.attach_url;
				App.showFj( d.attach );
				App.showChuli( d );
			});		
			
			App.initEvent();			
		
		}
	},
	// 显示pageA
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	// 显示pageB
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	// 绑定事件
	initEvent:function(){
		// 图片预览返回按钮事件
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	// 显示数据
	showDatas:function(d){
		$('#sqsy').html( d.trsDaily[0].trsDetail );
		$('#sqlx').html( d.trsDaily[0].trsTitle );	
		
	},
	// 加载处理意见
  showChuli:function(d){
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else if item.dealType == 2}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
				 						'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
	 			
			if(d.trsInfo[0].trsStatus == "0"){
				
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			
  },
// 显示附件
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},	
	// 返回前一页
	toBack:function(){
		Fw.Client.changePage("../10402/1040201.html?dealUser=2&trsStatus=1", "1");
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);