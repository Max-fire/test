/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	datas:{},
	init : function(require){
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB"); 
		App.flag = false;
		App.showPageA();
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/getTaskDetail");
		var params = {
				trsNo:App.func("trsNo"),
				trsType:"3"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS == "1"){
				App.showDatas(data);
				App.showChuli(data);
				App.initBJRPD(data);
				App.initEvent();
			}
		});
	},
	/**
	 * 显示pageA
	 */ 
	showPageA:function(){
		YT.showPageArea(App.pageA,[App.pageB],true);
	},
	/**
	 * 显示pageB
	 */
	showPageB:function(){
		YT.showPageArea(App.pageB,[App.pageA],true);
	},
	/**
	 * 绑定事件
	 */ 
	initEvent:function(){
		// 办结
		App.pageA.on("click","#BJ",App.initBJ);
		// 转办
		App.pageA.on("click","#ZB",App.initZB);
		// 退回
		App.pageA.on("click","#TH",App.initTH);
		// 提交
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		// 选择审批人
		App.pageA.on("click","#SPR",App.initSPR);
		// 处理按钮事件
	  	$('.ui-btn-list').off('click').on('click','button',function(){
	  		$(this).addClass('active').parent().siblings().find('button').removeClass('active');
	  		$('#trsStatus').val( $(this).data('status') );
	  		if($("#BJ").hasClass('active')){
				$("#spr").addClass('hidden');
			}else if($("#TH").hasClass('active')){
				$("#spr").addClass('hidden');
			}
			else{
				$("#spr").removeClass('hidden');
			}
	  		
	  		if($("#TH2").hasClass('active')){
				$("#XZSPR").attr('hidden',"");
				$("#trsStatus").val("0");
			}
			if($("#ZB2").hasClass('active')){
				$("#XZSPR").removeAttr('hidden','');
				$("#trsStatus").val("1");
			}
	  	});
	  	$('#btnSubmit').off('click').on('click',function(){
	  	});
		$('#btnBackA').off('click').on('click',function(){
			App.showPageA();
		});
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	/**
	 * 显示数据
	 */
	showDatas:function( d ){
		$('#trsNo').html( Fw.util.Format.subTrsNo(d.trsInfo[0].trsNo) );
		$('#jyls').html( d.trsInfo[0].trsNo );
		$('#qfzh').html( d.trsfrPwd[0].billAcctNo );
		$('#ywzl').html( Fw.util.Format.fmtBillType(d.trsfrPwd[0].billType) );
		$('#je').html( "\u00A5"+ Fw.util.Format.fmtAmt(d.trsfrPwd[0].amount.toString()));
		$('#HKJE').html(d.trsfrPwd[0].amount);
		$('#jedx').html( Fw.util.Format.fmtNumber2Chinese(d.trsfrPwd[0].amount.toString()) );
	},
	/**
	 * 加载处理意见
	 */
  showChuli:function( d ){
	  App.data = d;
	  $('#pzhm').html( d.trsfrPwd[0].billNo);
	  $('#qfrq').html( Fw.util.Format.fmtSignDate(d.trsfrPwd[0].signDate) );
	  $('#skzh').html( d.trsfrPwd[0].toAcctNo );
	  App.fromAcctNo = d.trsfrPwd[0].fromAcctNo;
	  App.toAcctNo = d.trsfrPwd[0].toAcctNo;
	  App.billType = d.trsfrPwd[0].billType;
 		var html='',html1='',html2='';
		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
				 						'</div>',
					 				'{@/if}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@if item.dealMsg}',
							 				'<div class="ui-bg-ss2">',
							 					　'${item.dealMsg}',
							 				'</div>',
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			
			$("#SQR").html(html1);
			$("#CLR").html(html);
			Fw.Client.hideWaitPanel();
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
				
			},10 );
			
  },
  	/**
  	 * 判断是否经过必经人
  	 */ 
  	initBJRPD: function(d){ 
  		App.datas = d;
  		if(d.trsInfo[0].hasOwnProperty("effectiveUserId") && d.trsInfo[0].effectiveUserId.trim() != ""){
			App.showJGBJR();
		}else{
			var url = YT.dataUrl("private/isEffective");
			var params = {
					trsType : "4",
					amount : d.trsfrPwd[0].amount+"",
					bizNo: "4",
					flag:"2" // 1.只查权限 2、是否是必经人
			}
			YT.ajaxData(url,params,function(data){
				if(data.isEffective == "YES"){
					App.showJGBJR();
				}else{
					App.showWJGBJR();
				}
			});
		}
  	},
	
  /**
   * 未经过有效必经人
   */ 
  	showWJGBJR:function(){
  		$("#JGYXBJR").addClass("hidden");
  		$("#WJGYXBJR").removeClass("hidden");
  	},
  /**
   * 经过有效必经人
   */ 
  	showJGBJR:function(){
  		$("#WJGYXBJR").addClass("hidden");
  		$("#JGYXBJR").removeClass("hidden");
  	},
	/**
	 * 办结
	 */ 
	initBJ:function(){
		$("#trsStatus").val("2");
		$("#XZSPR").attr("hidden","");
	},
	/**
	 * 转办
	 */ 
	initZB:function(){
		$("#trsStatus").val("1");
		$("#XZSPR").removeAttr("hidden","");
	},
	/**
	 * 退回
	 */ 
	initTH:function(){
		$("#trsStatus").val("0");
		$("#XZSPR").attr("hidden","");
	},
	/**
	 * 选择审批人
	 */ 
	initSPR:function(){
		Fw.Client.openPersonnel("App.openPeople");
	},
	openPeople : function(name, id,co) {
		$("#dealUserName").val(name);
		$("#dealUserId").val(id);
		$("#communicateId").val(co);
	},
	/**
	 * 事务提交
	 */
	toSubmit:function(){
		App.dealMsg  = $("#dealMsg").val();
		if($("#trsStatus").val() == ""){
		Fw.Form.showPinLabel($(this), "请选择操作类型", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji($("#dealMsg").val())){
			Fw.Form.showPinLabel($(this), "审批意见包含特殊字符", true);
			return;
		}
		if($("#trsStatus").val() == "0"){
			// 退回
			if($("#dealMsg").val().trim() == ""){
				Fw.Form.showPinLabel($(this), "请填写审批意见", true);
				return;
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			var url = YT.dataUrl("private/trsPwdTask");
			var params =  {
					type:"4",
					trsNo:$("#jyls").html(),
					trsStatus:$("#trsStatus").val(),
					trsType:"3",
					nextDealUserName:$("#dealUserName").val(),
					nextDealUserId:$("#dealUserId").val(),
					toCommunicateId:$("#communicateId").val(),
					dealMsg:$("#dealMsg").val(),
			}
			YT.ajaxData(url, params, App.callbackTrsStatus, App.call);
		}
		
		if($("#trsStatus").val() == "1"){
			// 转办
			if($("#dealUserId").val() == ""){
				Fw.Form.showPinLabel($(this), "请选择审批人", true);
				return;
			}
			if(App.dealMsg){
			}else{
				App.dealMsg = "同意"
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			var  url = YT.dataUrl("private/trsPwdTask");
			 var params =  {
					 	type:"3",
						trsNo:$("#jyls").html(),
						trsStatus:$("#trsStatus").val(),
						trsType:"3",
						nextDealUserName:$("#dealUserName").val(),
						nextDealUserId:$("#dealUserId").val(),
						toCommunicateId:$("#communicateId").val(),
						dealMsg:$("#dealMsg").val(),
						amount : $("#HKJE").html(),
				}
				YT.ajaxData(url, params, App.callback, App.call);
		}
		Fw.Client.openWaitPanel();
		if($("#trsStatus").val() == "2"){
			// 办结
			if(App.dealMsg){
			}else{
				App.dealMsg = "同意"
			}
			if(App.flag){
				Fw.Form.showPinLabel($(this), "请勿重复提交", true);
				return;
			}
			App.flag = true;
			// 判断是否经过有效必经人
			if(App.datas.trsInfo[0].hasOwnProperty("effectiveUserId")){
				var url = YT.dataUrl("private/isEffective");
				var params = {
						trsType : "4",
						amount : $("#HKJE").html()+"",
						bizNo:"4",
						flag:"1" // 1.只查权限 2、是否是必经人
				}
				YT.ajaxData(url,params,function(data){
						if(data.isEffective == "YES"){
							App.initSQB();
						}else{
							Fw.Client.hideWaitPanel();
							Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
							App.flag = false;
							return;
						}
				});
			}else{
				var url = YT.dataUrl("private/isEffective");
				var params = {
						trsType : "4",
						amount : $("#HKJE").html()+"",
						bizNo:"4",
						flag:"2" // 1.只查权限 2、是否是必经人
				}
				YT.ajaxData(url,params,function(data){
						if(data.isEffective == "YES"){
							App.initSQB();
						}else{
							Fw.Client.hideWaitPanel();
							Fw.Form.showPinLabel($(this), "您的权限不够请选择其他操作", true);
							App.flag = false;
							return;
						}
				});
			}
		}
	},
	/**
	 * 调用授权棒
	 */
	initSQB:function(){
		App.flag = false;
		var json={
				func:"App.initComplete",
				funcAndroid:"App.initCompleteAndroid",
				fromAcctNo : $("#qfzh").html(),// 签发账号
				signTime : $("#qfrq").html(),// 签发时间
				billNo : $("#pzhm").html(),// 凭证号码
				billType : App.billType,// 凭证种类
				toAcctNo : "0",// 收款账号
				amount : $("#HKJE").html(),// 金额
				type:"3",
		}
		Fw.Client.hideWaitPanel();
		Fw.Client.showBB(json);
	},
	
	/**
	 * 棒棒验证成功后回调函数iphone
	 */
	initComplete:function(no){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/trsPwdTask");
		var jsons = {
			type:"2",
			trsNo:$('#jyls').html(),
			trsType:"3",
			payPwd:no,
			dealMsg:$("#dealMsg").val(),
			trsId:App.func("trsId")
		}
		YT.ajaxData(url, jsons, function(suc){
				if (suc.STATUS == "1") {
					Fw.Client.dealMessage("3",App.func("trsId"),$('#jyls').html());
					setTimeout(function() {
						Fw.Client.hideWaitPanel();
						Fw.redirect("../10403/1040304.html", jsons);
					}, 2000);
//					Fw.redirect("../10403/1040304.html", jsons);
				}else{
					App.flag = false;
					Fw.Client.alertinfo(suc.MSG,"消息提示");
				}
		}, App.call);
	},
	/**
	 * 棒棒验证成功后回调函数Android
	 */
	initCompleteAndroid:function(no,fromAcctNo,billType,billNo,signTime,amount,toAcctNo){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/trsPwdTask");
		var jsons = {
			type:"2",
			trsNo:$('#jyls').html(),
			trsType:"3",
			payPwd:no,
			dealMsg:$("#dealMsg").val(),
			trsId:App.func("trsId")
		}
		YT.ajaxData(url, jsons, function(suc){
				if (suc.STATUS == "1") {
					Fw.Client.dealMessage("3",App.func("trsId"),$('#jyls').html());
					setTimeout(function() {
						Fw.Client.hideWaitPanel();
						Fw.redirect("../10403/1040304.html", jsons);
					}, 2000);
//					Fw.redirect("../10403/1040304.html", jsons);
				}else{
					App.flag = false;
					Fw.Client.alertinfo(suc.MSG,"消息提示");
				}
		}, App.call);
	},
	callbackTrsStatus:function(data){
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已回退给发起人:"+data.creUserName,"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"提交成功");
			return;
		}
	},
	// 成功后返回函数
	callback:function(data){
		 var url = YT.dataUrl("private/addLinkUser");
			YT.ajaxData(url,{userId:$("#dealUserId").val()},function(data){
			});
		if(data.STATUS == "1"){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo("已提交下一个处理人:"+$("#dealUserName").val(),"提交成功","App.test()");
		}else{
			App.flag = false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"提交成功");
			return;
		}
	},
	test:function(){
		if(App.func("trsId")){
			Fw.Client.dealMessage("2",App.func("trsId"));// 跳到客户端待定
		}else{
			Fw.Client.dealMessage("3",App.func("trsId"),App.func("trsNo"));
			setTimeout(function() {
				Fw.Client.hideWaitPanel();
				Fw.Client.changePage("../10403/1040301.html",true);
			}, 2000);
//			Fw.Client.changePage("../10403/1040301.html",true);
		}
	},
	// 返回前一页
	toBack:function(){
		if(App.func("trsId")){
			Fw.Client.dealMessage("1",App.func("trsId"));	
		}else{
			Fw.Client.changePage("../10403/1040301.html?trsStatus="+App.func("trsStatus")+"","1");
		}
	}
};
/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);