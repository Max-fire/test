/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Layer.hideWaitPanel(); //关闭等待层
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#btnSubmit", App.toSubmit);
		App.pageA.on("click", "#yzm", App.toYZM);
		App.pageA.on("click","#gzhgg",App.togoGZ);
		App.pageA.on("focus", "#frxm", App.toFocus);
		App.pageA.on("blur", "#frxm", App.toBlur);
		App.pageA.on("focus", "#sjhm", App.toFocus);
		App.pageA.on("blur", "#sjhm", App.toBlur);
		App.pageA.on("focus", "#jgh", App.toFocus);
		App.pageA.on("blur", "#jgh", App.toBlur);
		App.pageA.on("blur", "#meg_code", App.toBlur);
		App.pageA.on("focus", "#meg_code", App.toFocus);
		App.pageA.on("click", "#iknow", App.toIknow);
		var width=document.body.clientWidth-60-30-10-100-2;
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black").attr("style","height:"+height+"px;");
		$("#meg_codef").attr("style","float: left;width:"+width+"px;margin-top: 0px;");
	},
	//改变输入框样式
	toBlur:function(){
		var id=this.getAttribute("id")+"f";
		$("#"+id).removeClass("yui-ldx-yy");
	},
	toFocus:function(){
		var id=this.getAttribute("id")+"f";
		$("#"+id).addClass("yui-ldx-yy");
	},
	//弹窗
	toIknow:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	toSubmit:function(){
		var artifName =$("#frxm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var tel =  /^(1)[0-9]{10}$/;
		var megCode = $("#meg_code").val();
		if (artifName == null || artifName == "") {
			Fw.Form.showPinLabel($(this), "请输入姓名", true);
			return;
		}
			if (!tel.test(mobile)||mobile.length != '11') {
				Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
				return;
			}
			if (megCode == "") {
				Fw.Form.showPinLabel($(this), "验证码不能为空!", true);
				return;
			}
			 var num=/[0-9]{6}/;
			 if (!num.test($("#meg_code").val())) {
				 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
				 return;
			}
			 var url = YT.dataUrlWeb("private/inviteeWebQuery");
				var params={
						name:artifName,
						mobile:mobile,
						org:$("#org").val(),
						MSG:megCode
				}
				Fw.Layer.openWaitPanel();
				YT.ajaxDataWeb(url,params,function(data){
					if(data.STATUS=="1"){
						$("#meg_code").val("");
						App._closeTimerListener();
						Fw.redirect("1061007.html",data);
						Fw.Layer.hideWaitPanel();
					}else{
						$("#content").html(data.MSG);
						$("#white_b").removeClass("hidden");
						$("#black").removeClass("hidden");
						//静止滑动
						App.pageA.bind("touchmove",function(e){
							e.preventDefault();
						});
						Fw.Layer.hideWaitPanel();
					}
				},function(data){
					$("#content").html(data.MSG);
					$("#white_b").removeClass("hidden");
					$("#black").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					Fw.Layer.hideWaitPanel();}
				);
	},
	
	toYZM:function(){
		App.timer=60;
		App._initTime = new Date().getTime()-1000;
		App._sumTime = 60;
		var tel =  /^(1)[0-9]{10}$/;
		 if (!tel.test( $("#sjhm").val())|| $("#sjhm").val() == "" ||  $("#sjhm").val().length != "11") {
			 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			 return;
		 }
		var param={
				mobile : $("#sjhm").val(),
				type : "10"
		}
		
		 var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
			var html="已向手机"+phone+"发送短信验证码，请注意查收";
			$("#yzm").val("");
			var url = YT.dataUrlWeb('normal/tr3888.json');
			YT.ajaxDataWeb(url, param, function(rsp){
				if(rsp.STATUS == '1'){
					App._startTimerListener();
				}else{
					$("#content").html(rsp.MSG);
					$("#white_b").removeClass("hidden");
					$("#black").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					return;
				}
			},function(data){
				$("#content").html(rsp.MSG);
				$("#white_b").removeClass("hidden");
				$("#black").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				return;
				
			});
	},
	/**
	 * 打开短信验证码计时器
	 */
	_startTimerListener: function(){
		if(App.timer > 0){
			var time = App._getTimer();
			App.timer = App._sumTime - time;
			if(App.timer>0){
				$("#yzm").text(App.timer + '秒后重发');
				$("#yzm").attr("disabled", true);
			}else{
				App._closeTimerListener();
				return;
			}
		}else{
			App._closeTimerListener();
			return;
		}
		App.intervalID = setTimeout("App._startTimerListener()", 1000);
	},
	_getTimer:function(){
		var time = new Date().getTime();
		return Math.floor((time-App._initTime)/1000);
	},
	
	/**
	 * 清除计时器
	 * @param id
	 */
	_closeTimerListener: function(){
		if(App.intervalID){ // 当intervalID存在时，清空
			clearTimeout(App.intervalID);
			$("#yzm").removeAttr("disabled");//启用按钮
            $("#yzm").text("重新获取");
            App.timer = 60;
            App.intervalID = null;
		}
	},
	togoGZ:function(){
		Fw.redirect("1061006.html");
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);