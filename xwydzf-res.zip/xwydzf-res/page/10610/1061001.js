/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 我知道了点击事件
		App.pageA.on("click", "#wyyq", App.gotoWYYQ);
		App.pageA.on("click", "#qyyh", App.gotoQYKH);
		App.pageA.on("click", "#shkh", App.gotoSHKH);
		App.pageA.on("click", "#ckgz", App.gotoCKGZ);
		$("#name").html(decodeURIComponent(App.func ("inviteName")));
		App.initwx();
		
	},
	gotoQYKH:function(){
		Fw.redirect("../10608/1060801.html?inviteCode="+App.func ("inviteCode"));
	},
	gotoSHKH:function(){
		Fw.redirect("1061003.html?inviteCode="+App.func ("inviteCode"));
	},
	gotoWYYQ:function(){
		Fw.redirect("1061002.html");
	},
	gotoCKGZ:function(){
		Fw.redirect("1061006.html");
	},
	//微信分享
	initwx:function(){
		 var params={
				 url : location.href.split('#')[0],
				 type:'2'
  			}
  		var url = YT.dataUrlWeb("private/dealApplyImg");
			YT.ajaxDataWeb(url, params, function(data) {
				if (data.STATUS == "1") {
					wx.config({ 
						   debug:false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。 
						   appId:data.wxMsg.appid , // 必填，公众号的唯一标识 
						   timestamp: data.wxMsg.timestamp, // 必填，生成签名的时间戳 
						   nonceStr: data.wxMsg.nonceStr, // 必填，生成签名的随机串 
						   signature: data.wxMsg.signature,// 必填，签名，见附录1 
						   jsApiList: [ 
						         'checkJsApi',
						         'onMenuShareTimeline', 
						         'onMenuShareAppMessage',
						         ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2 
						 }); 
					
				
						wx.ready(function(){
							wx.checkJsApi({
							    jsApiList: ['checkJsApi','onMenuShareTimeline','onMenuShareAppMessage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
							    success: function(res) {
							    }
							});
							
							wx.onMenuShareTimeline({
								title:'邀请有礼',
								desc:decodeURIComponent(App.func ("inviteName"))+" 邀请您签约兴业管家，好礼相送！",
								link:basePath+"/page/10610/1061001.html?inviteName="+App.func ("inviteName")+"&inviteCode="+App.func ("inviteCode"),
								imgUrl:basePath+"/css/img/xygj.png",
								fail :function(res){
									alert(JSON.stringify(res))
								}
							});
						    
							wx.onMenuShareAppMessage({
								title:'邀请有礼',
								desc:decodeURIComponent(App.func ("inviteName"))+" 邀请您签约兴业管家，好礼相送！",
								link:basePath+"/page/10610/1061001.html?inviteName="+App.func ("inviteName")+"&inviteCode="+App.func ("inviteCode"),
								imgUrl:basePath+"/css/img/xygj.png",
								fail :function(res){
									alert(JSON.stringify(res))
								}
							});
						}); 
					  	
						wx.error(function(res){
							Fw.Form.showPinLabel($(this), res.checkResult , true);
							return;
						});
				}else{
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
				}
			});
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);