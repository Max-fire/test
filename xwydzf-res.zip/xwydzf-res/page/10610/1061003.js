var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Layer.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click", "#yzm", App.toYZM);
		App.pageA.on("blur", "#shbh", App.toBlur);
		App.pageA.on("focus", "#shbh", App.toFocus);
		App.pageA.on("blur", "#sjhm", App.toBlur);
		App.pageA.on("focus", "#sjhm", App.toFocus);
		App.pageA.on("blur", "#meg_code", App.toBlur);
		App.pageA.on("focus", "#meg_code", App.toFocus);
		App.pageA.on("click", "#iknow", App.toIknow);
		var width=document.body.clientWidth-60-30-10-100-2;
		var height=document.body.clientHeight+500;
		var top=document.body.scrollTop+$(window).height()/4;
		$("#meg_codef").attr("style","float: left;width:"+width+"px;margin-top: 0px;");
		$("#white_b").attr("style","top:"+top+"px;");
		$("#black").attr("style","height:"+height+"px;");
		YT.showPageArea(App.pageA, [], true);
	},
	//改变输入框样式
	toBlur:function(){
		var id=$(this).attr("id")+"f";
		$("#"+id).removeClass("yui-ldx-yy");
	},
	toFocus:function(){
		var id=$(this).attr("id")+"f";
		$("#"+id).addClass("yui-ldx-yy");
	},
	//弹窗
	toIknow:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	/**
	 * 表单提交
	 */
	toSubmit:function(){
		var merchantNo =$("#shbh").val();
		var mobile =$("#sjhm").val();
		var tel =  /^(1)[0-9]{10}$/;
		var megCode = $("#meg_code").val();
		var te=/^[0-9a-zA-Z]*$/g;
		//商户编号
		if (merchantNo == null || merchantNo == "") {
			Fw.Form.showPinLabel($(this), "请输入商户编号", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji(merchantNo)){
			Fw.Form.showPinLabel($(this), "商户编号包含特殊字符", true);
			return;
		}
		if(!te.test(merchantNo)||merchantNo.length<10){
			Fw.Form.showPinLabel($(this), "请输入正确商户编号", true);
			return;
		}
		if (!tel.test(mobile)||mobile.length != 11) {
			Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			return;
		}
		if (megCode == "") {
			Fw.Form.showPinLabel($(this), "验证码不能为空!", true);
			$("#meg_code").focus();
			return;
		}
		if (megCode.length != '6') {
			Fw.Form.showPinLabel($(this), "验证码必须为6位!", true);
			$("#meg_code").focus();
			return;
		}
		 var num=/[0-9]{6}/;
		 if (!num.test($("#meg_code").val())) {
			 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
			 return;
		}
		 var url = YT.dataUrlWeb("private/inviteMerchant");
		var params={
				merchantNo:merchantNo,
				mobile:mobile,
				inviteCode:App.func("inviteCode"),
				MSG:megCode
		}
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url,params,function(data){
			if(data.STATUS=="1"){
				$("#meg_code").val("");
				App._closeTimerListener();
				Fw.Layer.hideWaitPanel();
				Fw.redirect("1061004.html");
			}else{
				$("#content").html(data.MSG);
				$("#white_b").removeClass("hidden");
				$("#black").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				Fw.Layer.hideWaitPanel();
			}
		},function(data){
			$("#content").html(data.MSG);
			$("#white_b").removeClass("hidden");
			$("#black").removeClass("hidden");
			//静止滑动
			App.pageA.bind("touchmove",function(e){
				e.preventDefault();
			});
			Fw.Layer.hideWaitPanel();}
		);
	},
	toYZM:function(){
		App.timer=60;
		App._initTime = new Date().getTime()-1000;
		App._sumTime = 60;
		var tel =  /^(1)[0-9]{10}$/;
		 if (!tel.test( $("#sjhm").val())|| $("#sjhm").val() == "" ||  $("#sjhm").val().length != "11") {
			 Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
			 return;
		 }
		var param={
				mobile : $("#sjhm").val(),
				type : "10"
		}
		 var phone=param.mobile.substring(0,3)+" ****"+param.mobile.substring(param.mobile.length-4,param.mobile.length);
			var html="已向手机"+phone+"发送短信验证码，请注意查收";
			$("#yzm").val("");
			var url = YT.dataUrlWeb('normal/tr3888.json');
			YT.ajaxDataWeb(url, param, function(rsp){
				if(rsp.STATUS == '1'){
					App._startTimerListener();
					callback && callback();
				}else{
					$("#content").html(rsp.MSG);
					$("#white_b").removeClass("hidden");
					$("#black").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					return;
				}
			},function(data){
				$("#content").html(rsp.MSG);
				$("#white_b").removeClass("hidden");
				$("#black").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				return;
				
			});
	},
	/**
	 * 打开短信验证码计时器
	 */
	_startTimerListener: function(){
		if(App.timer > 0){
			var time = App._getTimer();
			App.timer = App._sumTime - time;
			if(App.timer>0){
				$("#yzm").text(App.timer + '秒后重发');
				$("#yzm").attr("disabled", true);
			}else{
				App._closeTimerListener();
				return;
			}
		}else{
			App._closeTimerListener();
			return;
		}
		App.intervalID = setTimeout("App._startTimerListener()", 1000);
	},
	_getTimer:function(){
		var time = new Date().getTime();
		return Math.floor((time-App._initTime)/1000);
	},
	
	/**
	 * 清除计时器
	 * @param id
	 */
	_closeTimerListener: function(){
		if(App.intervalID){ // 当intervalID存在时，清空
			clearTimeout(App.intervalID);
			$("#yzm").removeAttr("disabled");//启用按钮
            $("#yzm").text("重新获取");
            App.timer = 60;
            App.intervalID = null;
		}
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		Fw.redirect("1061002.html");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);