/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#xz",App.toAppStore);
		App.pageA.on("click","#ys",App.toShow);
	},
	toAppStore:function(){
		window.location.href = "http://download.cib.com.cn/netbank/download/cn/DGYDZF/download.html";
	},
	toShow:function(){
		window.location.href = "http://mp.weixin.qq.com/s/GFrrhcBUah6cpXFoU8HZvQ";
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);