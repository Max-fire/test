/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		var height=document.body.clientHeight*0.75;
		$("#yqjl").attr("style","width: 100%;height: "+height+"px;");
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-ldx-close1').length>0){
				t.find('.yui-ldx-close1').removeClass().addClass('yui-ldx-close');
				t.next().removeClass('hidden');
			}else if(t.find('.yui-ldx-close').length>0){
				t.find('.yui-ldx-close').removeClass().addClass('yui-ldx-close1');
				t.next().addClass('hidden');
			}
		});
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);