/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.data = Fw.getParameters();
		App.initEvent();
		App.queryCount();
		YT.showPageArea(App.pageA, [App.pageB], true);
		Fw.Client.hideWaitPanel(); //关闭等待层
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		// 我知道了点击事件
		App.pageA.on("click", "#ljyq", App.toLJYQ);
		App.pageA.on("click", "#ckgd", App.toCKGD);
		App.pageA.on("click", "#sqgd", App.toSQGD);
		App.pageA.on("click", "#dj", App.toShowB);
		App.pageB.on("click", "#submit", App.toSubmit);
		var width=document.body.clientWidth-30-115-2;
		var splitWidth=width/3;
		var height=document.body.clientHeight*0.75;
		$("#yqjl").attr("style","width: 100%;height: "+height+"px;");
		$("#all").attr("style","width:"+width+";");
		$("#one").attr("style","width:"+splitWidth+";");
		$("#two").attr("style","width:"+splitWidth+";");
		$("#three").attr("style","width:"+splitWidth+";");
		
	},
	toShowB:function(){
		var url= YT.dataUrl("private/inviteCodePush");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{flag:"1"},function(data){
			if(data.STATUS=="1"){
				App.queryAddr();
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();}
		);
	},
	queryAddr:function(){
		var url= YT.dataUrl("private/inviteeManageMail");
		var params={
				mobile:App.mobile,
				queryFlag:"1"
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				$("#xm").val(data.addressName);
				$("#sfz").val(data.idNo);
				$("#lpdz").val(data.mailingAddr);
				$("#yb").val(data.zipCode);
				Fw.Client.hideWaitPanel();
				YT.showPageArea(App.pageB, [App.pageA], true);
			}else{
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();
	});
	},
	queryCount:function(){
		var url= YT.dataUrl("private/inviteeAPPQuery");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{flag:"1"},function(data){
			if(data.STATUS=="1"){
				App.mobile=data.mobile;
				$("#count").html(data.inviteCount);
				$("#primaryStandard").html(data.primaryNum);
				$("#intermediateStandard").html(data.intermediateNum);
				$("#advancedStandard").html(data.advancedNum);
				Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();}
		);
	},
	toLJYQ:function(){
		var url= YT.dataUrl("private/inviteCodePush");
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,{flag:"1"},function(data){
			if(data.STATUS=="1"){
				App.inviteName=data.inviteName;
				App.inviteCode=data.inviteCode;
				Fw.Client.hideWaitPanel();
				App.toShare();
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();}
		);
		
	},
	toShare:function(){
		var title="邀请有礼";
		var msg=App.inviteName+"邀请您签约兴业管家，好礼相送！";
		var url=basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.inviteName)+"&inviteCode="+App.inviteCode;
		var imgUrl=basePath+"/css/img/xygj.png";
		Fw.Client.shareTo(title,msg,url,imgUrl);
	},
	//保存收货地址
	toSubmit:function(){
		var name =$("#xm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var idNo=$("#sfz").val();
		var tel =  /^(1)[0-9]{10}$/;
		var yb = $("#yb").val();
		var addr=$("#lpdz").val();
		var name =$("#xm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var idNo=$("#sfz").val();
		var tel =  /^(1)[0-9]{10}$/;
		var yb = $("#yb").val();
		var addr=$("#lpdz").val();
		if (name == null || name == "") {
			Fw.Form.showPinLabel($(this), "请输入姓名", true);
			return;
			}
			if (yb == "") {
				Fw.Form.showPinLabel($(this), "请输入邮编", true);
				return;
			}
			if (idNo == "") {
				Fw.Form.showPinLabel($(this), "请输入身份证", true);
				return;
			}
			if (addr == "") {
				Fw.Form.showPinLabel($(this), "请输入礼品寄送地址", true);
				return;
			}
			 var num=/[0-9]/;
			 if (!num.test(yb)&&yb.length == 6) {
				 Fw.Form.showPinLabel($(this), "请输入正确邮编!", true);
				 return;
			}
			 if (!num.test(idNo)||idNo.length != 18) {
				 Fw.Form.showPinLabel($(this), "请输入正确身份证!", true);
				 return;
			}
			 var url= YT.dataUrl("private/inviteeManageMail");
				Fw.Client.openWaitPanel();
				var params={
						mobile:App.mobile,
						queryFlag:"2",
						addressName:name,
						mailingAddr:addr,
						zipCode:yb,
						idNo:idNo
				}
				YT.ajaxData(url,params,function(data){
					if(data.STATUS=="1"){
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo("保存成功","消息提示");
					}else{
						Fw.Client.alertinfo(data.MSG,"消息提示");
						Fw.Client.hideWaitPanel();
					}
				},function(data){
					Fw.Client.alertinfo(data.MSG,"消息提示");
					Fw.Client.hideWaitPanel();}
				);
	},
	toCKGD:function(){
		$("#gzmx").removeClass("hidden");
		$("#ckgd").addClass("hidden");
		$("#sqgd").removeClass("hidden");
	},
	toSQGD:function(){
		$("#gzmx").addClass("hidden");
		$("#ckgd").removeClass("hidden");
		$("#sqgd").addClass("hidden");
	},
	toBack:function(){
		YT.showPageArea(App.pageA, [App.pageB], true);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);