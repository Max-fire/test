/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#black_b",App.toshow);
		App.pageA.on("click", "#dj", App.toDG);
		App.pageA.on("click", "#ckgd", App.toCKGD);
		App.pageA.on("click", "#sqgd", App.toSQGD);
		App.pageA.on("click", "#ljyq", App.toLJYQ);
		var width=document.body.clientWidth-30-115-2;
		var splitWidth=width/3;
		var height=document.body.clientHeight*0.75;
		$("#yqjl").attr("style","width: 100%;height: "+height+"px;");
		$("#all").attr("style","width:"+width+";");
		$("#one").attr("style","width:"+splitWidth+";");
		$("#two").attr("style","width:"+splitWidth+";");
		$("#three").attr("style","width:"+splitWidth+";");
		$("#count").html(App.data.inviteCount);
		$("#primaryStandard").html(App.data.primaryNum);
		$("#intermediateStandard").html(App.data.intermediateNum);
		$("#advancedStandard").html(App.data.advancedNum);
		App.initwx();
	},
	//关闭提示
	toshow:function(){
		$("#black_b").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	//立即邀请
	toLJYQ:function(){
		$("#black_b").attr("style","height:"+window.screen.height+"px;position: absolute;"+"top:"+document.body.scrollTop+"px;");
		$("#black_b").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	initwx:function(){
		 var params={
				 url : location.href.split('#')[0],
				 type:'2'
 			}
 		var url = YT.dataUrlWeb("private/dealApplyImg");
			YT.ajaxDataWeb(url, params, function(data) {
				if (data.STATUS == "1") {
					try{
					wx.config({ 
						   debug:false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。 
						   appId:data.wxMsg.appid , // 必填，公众号的唯一标识 
						   timestamp: data.wxMsg.timestamp, // 必填，生成签名的时间戳 
						   nonceStr: data.wxMsg.nonceStr, // 必填，生成签名的随机串 
						   signature: data.wxMsg.signature,// 必填，签名，见附录1 
						   jsApiList: [ 
						         'checkJsApi',
						         'onMenuShareTimeline', 
						         'onMenuShareAppMessage',
						         ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2 
						 }); 
					
				
						wx.ready(function(){
							wx.checkJsApi({
							    jsApiList: ['checkJsApi','onMenuShareTimeline','onMenuShareAppMessage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
							    success: function(res) {
							    }
							});
							
							wx.onMenuShareTimeline({
								title:'邀请有礼',
								desc:App.data.inviteName+" 邀请您签约兴业管家，好礼相送！",
								link:basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.data.inviteName)+"&inviteCode="+App.data.inviteCode,
								imgUrl:basePath+"/css/img/xygj.png",
								fail :function(res){
									alert(JSON.stringify(res))
								}
							});
						    
							wx.onMenuShareAppMessage({
								title:'邀请有礼',
								desc:App.data.inviteName+" 邀请您签约兴业管家，好礼相送！",
								link:basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.data.inviteName)+"&inviteCode="+App.data.inviteCode,
								imgUrl:basePath+"/css/img/xygj.png",
								fail :function(res){
									alert(JSON.stringify(res))
								}
							});
						}); 
					  	
						wx.error(function(res){
							Fw.Form.showPinLabel($(this), res.checkResult , true);
							return;
						});
					}catch(e){
						alert(e);
					}
				}else{
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
				}
			});
	},
	//查看更多规则
	toCKGD:function(){
		$("#gzmx").removeClass("hidden");
		$("#ckgd").addClass("hidden");
		$("#sqgd").removeClass("hidden");
	},
	//收起更多规则
	toSQGD:function(){
		$("#gzmx").addClass("hidden");
		$("#ckgd").removeClass("hidden");
		$("#sqgd").addClass("hidden");
	},
	//去礼品信息登记界面
	toDG:function(){
		Fw.redirect("1061008.html",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);