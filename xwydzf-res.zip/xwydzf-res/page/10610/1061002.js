var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Layer.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#black_b",App.toshow);
		App.pageA.on("click","#black_w",App.toshow);
		App.pageA.on("click","#ckjl",App.toYQJL);
		App.pageA.on("click","#wc",App.toCheck);
		App.pageA.on("click", "#yzm", App.toYZM);
		App.pageA.on("click","#gzhgg",App.togoGZ);
		App.pageA.on("focus", "#frxm", App.toFocus);
		App.pageA.on("blur", "#frxm", App.toBlur);
		App.pageA.on("focus", "#sjhm", App.toFocus);
		App.pageA.on("blur", "#sjhm", App.toBlur);
		App.pageA.on("focus", "#jgh", App.toFocus);
		App.pageA.on("blur", "#jgh", App.toBlur);
		App.pageA.on("click", "#iknow", App.toIknow);
	},
	toshow:function(){
		$("#black_b").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	//改变输入框样式
	toBlur:function(){
		var id=$(this).attr("id")+"f";
		$("#"+id).removeClass("yui-ldx-yy");
	},
	toFocus:function(){
		var id=$(this).attr("id")+"f";
		$("#"+id).addClass("yui-ldx-yy");
	},
	//弹窗
	toIknow:function(){
		$("#white_b").addClass("hidden");
		$("#black").addClass("hidden");
		App.pageA.unbind("touchmove");
	},
	/**
	 * 表单提交
	 */
	toSubmit:function(){
		var artifName =$("#frxm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var tel =  /^(1)[0-9]{10}$/;
		if (artifName == null || artifName == "") {
			Fw.Form.showPinLabel($(this), "请输入姓名", true);
			return;
		}
			if (!tel.test(mobile)||mobile.length != '11') {
				Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
				return;
			}
		var url= YT.dataUrlWeb("private/inviteCodePush");
		var params={
				inviteName:artifName,
				org:$("#jgh").val(),
				mobile:mobile
		}
		Fw.Layer.openWaitPanel();
		YT.ajaxDataWeb(url,params,function(data){
			if(data.STATUS=="1"){
				App.inviteName=data.inviteName;
				App.inviteCode=data.inviteCode;
				var height=document.body.clientHeight+500;
				var top=document.body.scrollTop+$(window).height()/4;
				$("#black_b").attr("style","height:"+window.screen.height+"px;position: absolute;"+"top:"+document.body.scrollTop+"px;");
				$("#white_b").attr("style","top:"+top+"px;");
				$("#black").attr("style","height:"+height+"px;");
				$("#ts").attr("style","padding-top:"+top+"px;");
				$("#black_b").removeClass("hidden");
				//静止滑动
				App.pageA.bind("touchmove",function(e){
					e.preventDefault();
				});
				App.initwx();
				Fw.Layer.hideWaitPanel();
			}
		},function(data){
			$("#content").html(data.MSG);
			$("#white_b").removeClass("hidden");
			$("#black").removeClass("hidden");
			//静止滑动
			App.pageA.bind("touchmove",function(e){
				e.preventDefault();
			});
			Fw.Layer.hideWaitPanel();}
		);
	},
	toCheck:function(){
		var artifName =$("#frxm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var mobile =$("#sjhm").val();
		var tel =  /^(1)[0-9]{10}$/;
		var megCode = $("#meg_code").val();
		if (artifName == null || artifName == "") {
			Fw.Form.showPinLabel($(this), "请输入姓名", true);
			return;
		}
			if (!tel.test(mobile)||mobile.length != '11') {
				Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
				return;
			}
			if (megCode == "") {
				Fw.Form.showPinLabel($(this), "验证码不能为空!", true);
				$("#meg_code").focus();
				return;
			}
			if (megCode.length != '6') {
				Fw.Form.showPinLabel($(this), "验证码必须为6位!", true);
				$("#meg_code").focus();
				return;
			}
			 var num=/[0-9]{6}/;
			 if (!num.test($("#meg_code").val())) {
				 Fw.Form.showPinLabel($(this), "请输入正确验证码!", true);
				 return;
			}
			 var url = YT.dataUrlWeb("private/inviteeWebQuery");
				var params={
						name:artifName,
						mobile:mobile,
						org:$("#jgh").val(),
						MSG:megCode
				}
				Fw.Layer.openWaitPanel();
				YT.ajaxDataWeb(url,params,function(data){
					if(data.STATUS=="1"){
						Fw.Layer.hideWaitPanel();
						Fw.redirect("1061005.html",data);
					}else{
						$("#content").html(data.MSG);
						$("#white_b").removeClass("hidden");
						$("#black").removeClass("hidden");
						//静止滑动
						App.pageA.bind("touchmove",function(e){
							e.preventDefault();
						});
						Fw.Layer.hideWaitPanel();
					}
				},function(data){
					$("#content").html(data.MSG);
					$("#white_b").removeClass("hidden");
					$("#black").removeClass("hidden");
					//静止滑动
					App.pageA.bind("touchmove",function(e){
						e.preventDefault();
					});
					Fw.Layer.hideWaitPanel();}
				);
	},
	//微信分享
	initwx:function(){
		 var params={
				 url : location.href.split('#')[0],
				 type:'2'
  			}
  		var url = YT.dataUrlWeb("private/dealApplyImg");
			YT.ajaxDataWeb(url, params, function(data) {
				if (data.STATUS == "1") {
					wx.config({ 
						   debug:false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。 
						   appId:data.wxMsg.appid , // 必填，公众号的唯一标识 
						   timestamp: data.wxMsg.timestamp, // 必填，生成签名的时间戳 
						   nonceStr: data.wxMsg.nonceStr, // 必填，生成签名的随机串 
						   signature: data.wxMsg.signature,// 必填，签名，见附录1 
						   jsApiList: [ 
						         'checkJsApi',
						         'onMenuShareTimeline', 
						         'onMenuShareAppMessage',
						         ] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2 
						 }); 
					
				
						wx.ready(function(){
							wx.checkJsApi({
							    jsApiList: ['checkJsApi','onMenuShareTimeline','onMenuShareAppMessage'], // 需要检测的JS接口列表，所有JS接口列表见附录2,
							    success: function(res) {
							    }
							});
							
							wx.onMenuShareTimeline({
								title:'邀请有礼',
								desc:App.inviteName+" 邀请您签约兴业管家，好礼相送！",
								link:basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.inviteName)+"&inviteCode="+App.inviteCode,
								imgUrl:basePath+"/css/img/xygj.png",
								fail :function(res){
									alert(JSON.stringify(res))
								}
							});
						    
							wx.onMenuShareAppMessage({
								title:'邀请有礼',
								desc:App.inviteName+" 邀请您签约兴业管家，好礼相送！",
								link:basePath+"/page/10610/1061001.html?inviteName="+encodeURIComponent(App.inviteName)+"&inviteCode="+App.inviteCode,
								imgUrl:basePath+"/css/img/xygj.png",
								fail :function(res){
									alert(JSON.stringify(res))
								}
							});
						}); 
					  	
						wx.error(function(res){
							Fw.Form.showPinLabel($(this), res.checkResult , true);
							return;
						});
				}else{
					Fw.Form.showPinLabel($(this), data.MSG, true);
					return;
				}
			});
	},
	//立即邀请
	toYQJL:function(){
		var json={
				name:$("#frxm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,""),
				mobile:$("#sjhm").val(),
				org:$("#org").val()
		}
		Fw.redirect("1061005.html",json);
	},
	//活动规则
	togoGZ:function(){
		Fw.redirect("1061006.html");
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);