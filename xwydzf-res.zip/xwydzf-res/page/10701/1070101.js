var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		Fw.Client.hideWaitPanel();
		App.initEvent();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		//初始化时间插件
		App.pageA.on("click","#sjxz",App.toXZSJ);
		App.pageA.on("click","#qr",App.toQR);
		App.pageA.on("click","#black",App.toQX);
		App.pageB.on("click","#btnSubmit",App.gotoMsg);
		App.queryData("");
	},
	
	queryData:function(date){
		var html = "";
		html+='<div class="yui-gzt-histroy yui-gzt-topborder">';
		html+='<div style="font-size: 18px;">';
		html+='<div class="yui-yqdz-fl50">${item.yearMonth|fmtYearMonth}</div>';
		html+='<div class="yui-yqdz-fl50 yui-yqdz-r ">${item.salaryPurpose|fmtbiref}:  ${item.amount}元</div>';
		html+='</div>';
		html+='<div style="clear: both;"></div>';
		html+='<div>';
		html+='<div class="yui-yqdz-fl50 yui-cui-jymx-sj">${item.sendTime}</div>';
		html+='<div class="yui-yqdz-fl50 yui-yqdz-r yui-cui-jymx-sj">发送人:  ${item.name}</div>';
		html+='</div>';
		html+='<div style="clear: both;"></div>';
		html+='</div>';
		var json = {
				year:date+""
			};
			var url = YT.dataUrl("private/querySalaryMsgYear");
			var listView = App.listView = new Fw.ListView({
				contentEl : 'list',
				dataField : "list",
				page : true,
				pageSize : 5,
				disclosure : true,
				ajax : {
					url : url,
					params : json
				},
				itemTpl : html,
			});
			listView.custFunc4NextPage = App.hasNextPage;
			listView.on('itemtap', App.showDetail, this);
			listView.loadData(new Date());
			YT.showPageArea(App.pageA, [App.pageB], true);
		},
		/**
		 * 是否有下页 pageIndex：从1开始
		 */
		hasNextPage : function(rst, pageIndex) {
			if (!rst.list) {
				var height=window.screen.height-110;
				$("#noMessage").attr("style","text-align: center;position: absolute;top: 50px;z-index: 999;background-color: white;width: 100%;height:"+height+"px;")
				$("#noMessage").removeClass("hidden");
			}else{
				$("#noMessage").addClass("hidden");
			}
			var page = pageIndex || 1;
			Fw.Client.hideWaitPanel();
			return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
		},
		/**
		 * 显示详情
		 */
		showDetail : function(itemData, itemIndex, itemElem) {
			Fw.Client.openWaitPanel();
			var url = YT.dataUrl("private/querySalaryAppMsg");
			var params={salaryBatchNo:itemData.salaryBatchNo+""};
		    YT.ajaxData(url,params,function(data){
		    	if(data.STATUS=="1"){
		    		var html = "";
					if(data.title.length>0){
						html+='<div style="text-align: center;padding: 10px 0px;"><strong style="font-size: 16px;">实际发薪</strong><div>'+data.contents[2]+'</div></div>'
						for(var d in data.title){
							if(d==(data.title.length-1)){
								html+='<div class="yui-gzt-topborder yui-gzt-bottomborder yui-yqdz-height">';
							}else{
								html+='<div class="yui-gzt-topborder yui-yqdz-height">';
							}
							html+='<div class="yui-yqdz-fl50 yui-cui-jymx-sj yui-sdsh-overflow">'+data.title[d]+'</div>';
							html+='<div class="yui-yqdz-fl50 yui-yqdz-r yui-sdsh-overflow">'+data.contents[d]+'</div>';
							html+='</div>';
						}
						$("#mxlist").html(html);
					}else{
						$("#mxlist").html('<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:22px;font-style:oblique; color: gray;">您还未有工资条</div>');
					}
					$("#sendTime").html(Fw.util.Format.fmtTrsCreDate(data.sendTime)+"   发送人"+data.name);
					App.pageB.attr("title",Fw.util.Format.fmtYearMonth(data.month)+""+App.fmtSalary(data.salaryPurpose))
					YT.showPageArea(App.pageB, [App.pageA], true);
					Fw.Client.hideWaitPanel();
		    	}else{
		    		Fw.Client.alertinfo(data.MSG,"系统提示");
		    		Fw.Client.hideWaitPanel();
		    	}
		    },function(data){
		    	Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
		    });
		},
	
	toXZSJ:function(){
		$("#white").removeClass("hidden");
		$("#black").removeClass("hidden");
		//静止滑动
		App.pageA.bind("touchmove",function(e){
			e.preventDefault();
		});
	},
	
	/**
	 * 取消
	 */
	toQX:function(){
		$("#white").addClass("hidden");
		$("#black").addClass("hidden");
		//取消静止滑动
		App.pageA.unbind("touchmove");
		qdate.resetData();
	},
	/**
	 * 确认
	 */
	toQR:function(){
		$("#white").addClass("hidden");
		$("#black").addClass("hidden");
		//取消静止滑动
		App.pageA.unbind("touchmove");
		App.queryData(qdate.getDate())
	},
	fmtSalary:function(value){
		switch (value) {
		case '006':
			var trsStatus = "代发工资";
			return trsStatus;
		case '022':
			var trsStatus = "奖金"
			return trsStatus;
		case '023':
			var trsStatus = "津贴"
				return trsStatus;
		case '047':
			var trsStatus = "福利"
				return trsStatus;
		case '048':
			var trsStatus = "费用报销"
				return trsStatus;
		default:
			break;
		}
	},
	/**
	 * 返回时间查询
	 */
	gotoMsg:function(){
		YT.showPageArea(App.pageA, [App.pageB], true);
	},
	/**
	 * 返回
	 */
	gotoWork:function(){
		Fw.Client.gotoHomePage();
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);