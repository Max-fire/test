/**
 * 创建应用
 * 
 * @author zyq
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	requires : ['Fw.util.proofTest'],
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click", "#btnSubmit", App.gotoMsg);
		App.pageA.on("click", "#history", App.gotoHistory);
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/querySalaryAppMsg");
		var params={salaryBatchNo:App.func("trsNo")};
	    YT.ajaxData(url,params,App.success,App.fail);
	},
	success:function(data){
		if (data.STATUS == "1") {
			var html = "";
			if(data.title.length>0){
				html+='<div style="text-align: center;padding: 10px 0px;"><strong style="font-size: 16px;">实际发薪</strong><div>'+data.contents[2]+'</div></div>'
				for(var d in data.title){
					if(d==(data.title.length-1)){
						html+='<div class="yui-gzt-topborder yui-gzt-bottomborder yui-yqdz-height">';
					}else{
						html+='<div class="yui-gzt-topborder yui-yqdz-height">';
					}
					html+='<div class="yui-yqdz-fl50 yui-cui-jymx-sj yui-sdsh-overflow">'+data.title[d]+'</div>';
					html+='<div class="yui-yqdz-fl50 yui-yqdz-r yui-sdsh-overflow">'+data.contents[d]+'</div>';
					html+='</div>';
				}
				$("#list").html(html);
			}else{
				$("#list").html('<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:22px;font-style:oblique; color: gray;">您还未有工资条</div>');
			}
			$("#sendTime").html(Fw.util.Format.fmtTrsCreDate(data.sendTime)+"   发送人"+data.name);
			App.pageA.attr("title",data.month.substring(0, 4) + '年' +data.month.substring(4, 6) + '月'+App.fmtSalary(data.salaryPurpose))
			YT.showPageArea(App.pageA, [], true);
			Fw.Client.hideWaitPanel();
		} else {
			Fw.Client.alertinfo(data.MSG,"系统提示");
			Fw.Client.hideWaitPanel();
		}
	},
	fail:function(data){
		Fw.Client.alertinfo(data.MSG,"系统提示");
		Fw.Client.hideWaitPanel();
	},
	fmtSalary:function(value){
		switch (value) {
		case '006':
			var trsStatus = "代发工资";
			return trsStatus;
		case '022':
			var trsStatus = "奖金"
			return trsStatus;
		case '023':
			var trsStatus = "津贴"
				return trsStatus;
		case '047':
			var trsStatus = "福利"
				return trsStatus;
		case '048':
			var trsStatus = "费用报销"
				return trsStatus;
		default:
			break;
		}
	},
	//历史明细
	gotoHistory:function(){
		Fw.redirect("1070101.html");
	},
	//返回
	gotoMsg:function(){
		Fw.Client.dealMessage("2",App.func("trsId"),App.func("trsNo"));
	}
	
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);