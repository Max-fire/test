/**
 * 创建应用
 * 
 * @author cjh
 */
var App = {
		requires : ['Fw.util.attach','Fw.util.proofTest'],
		datas:{},
	/**
	 * 初始化 应用入口
	 */
	init : function() {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		Fw.Client.openWaitPanel();
		App.attch = new Array();
		App.attchList = new Array();
		App.i=0;
		App.initEvent();
	},
	initEvent:function(){
		var width=(document.body.clientWidth-144)/2;
		$("#gdx1").attr("style","width:"+width+"px;");
		$("#gdx").attr("style","width:"+width+"px;");
		var url = YT.dataUrl("private/getTaskDetail");
		var params = {
				trsNo:App.func("trsNo"),
				trsType:"8"
		};
		if(App.data && App.data.trsTrsfr){
			App.showDatas(App.data);
			App.showChuli(App.data);
		}else{
			YT.ajaxData(url,params,function(data){
				if(data.STATUS == "1"){
					App.data = data;
					App.showDatas(data);
					App.showChuli(data);
				}
			});
		}
		App.pageA.on("click","#zmx",App.changeMX);
		App.pageA.on("click","#cmx",App.changeMX);
		App.pageA.on("click","#smx",App.changeMX);
		//查看凭证
		App.pageA.on("click","#ckpz",App.toCKPZ);
		// 点击标题 收起或者展开内容 事件
		$('.yui-det-title').off('click').on('click',function(){
			var t = $(this);			
			if(t.find('.yui-icon-close2').length>0){
				t.find('.yui-icon-close2').removeClass().addClass('yui-icon-close3');
				t.next().addClass('hidden');
			}else if(t.find('.yui-icon-close3').length>0){
				t.find('.yui-icon-close3').removeClass().addClass('yui-icon-close2');
				t.next().removeClass('hidden');
			}
		});
	},
	//查看凭证
	toCKPZ:function(){
		App.data.trsDate=App.trsDate;
		App.data.topage="../10502/det15C.html?trsStatus="+App.func("trsStatus")+"&trsNo="+App.func("trsNo")+"";
		Fw.redirect("../10502/1050215.html", App.data);
	},
	/**
	 * 跳转明细页面
	 */
	changeMX:function(){
		App.data.no = "../10502/det15C";
		Fw.redirect('../10502/1050208.html?trsNo='+App.func("trsNo")+'&trsStatus='+App.func("trsStatus")+"",App.data);
	},

	showDatas:function(data){
		//判断是否有隐藏明细标志 
		if(data.readFlag=="1"){
			$("#zmx").addClass("hidden");
		}else{
			$("#zmx").removeClass("hidden");
		}
		if(data.trsTrsfr[0].brief=='006'){
			$("#ZYType").html("代发工资");
		}else if(data.trsTrsfr[0].brief=='022'){
			$("#ZYType").html("奖金");
		}else if(data.trsTrsfr[0].brief=='023'){
			$("#ZYType").html("津贴");
		}else if(data.trsTrsfr[0].brief=='047'){
			$("#ZYType").html("福利");
		}else if(data.trsTrsfr[0].brief=='021'){
			$("#ZYType").html("互助金");
		}else if(data.trsTrsfr[0].brief=='826'){
			$("#ZYType").html("补偿金");
		}else if(data.trsTrsfr[0].brief=='485'){
			$("#ZYType").html("交通补贴");
		}else if(data.trsTrsfr[0].brief=='814'){
			$("#ZYType").html("差旅费");
		}else if(data.trsTrsfr[0].brief=='813'){
			$("#ZYType").html("高温费");
		}else if(data.trsTrsfr[0].brief=='048'){
			$("#ZYType").html("费用报销");
		}else if(data.trsTrsfr[0].brief=='a23'){
			$("#ZYType").html("薪资理财");
		}
		if (App.func("page")) {
			App.data.page=App.func("page");
		}
		if(App.func("trsStatus") == "1"){
			App.trsDate=data.dealLog[0].dealTime;
			$(".yui-hide").removeClass("hidden");
			$("#sjz").removeClass("hidden");
			if (data.dealLog[0].dealType=="2") {
				$("#ckpz").removeClass("hidden");
			}
				$("#clz").html("待银行处理");
				$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
				$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
				//判断处理状态
				if(data.btStatus=="2"){
					$("#clz").html("银行已处理");
					$("#SB").removeClass("hidden");
					$("#CG").removeClass("hidden");
					$("#ccbs").removeClass("hidden");
					$("#cl").removeClass("yui-yghk-swcl").addClass("yui-yghk-swtj");
					$("#gdx").removeClass("yui-yghk-gdbx").addClass("yui-yghk-gdlx");
					$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf");
					$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc1");
					if(data.dealLog[0].dealType=="4"||data.dealLog[0].dealType=="3"||data.failCount==data.count){
						$("#wc").removeClass("yui-yghk-swwc").addClass("yui-yghk-swwc3");
						$("#wczt").removeClass("yui-yghk-jdtf1").addClass("yui-yghk-jdtf").attr("style","color:#e61920;text-align: right;");
						$("#wczt").html("汇款失败");
					}else if (data.succCount != data.count) {
						$("#wczt").html("部分成功");
					}
					$('#wcsj').html(Fw.util.Format.fmtTrsCreDate(data.btTime,"MM-dd HH:mm:ss"));
					$('#clzsj').html(Fw.util.Format.fmtTrsCreDate(data.btTime,"MM-dd HH:mm:ss"));
				}else{
					$("#wczt").html("处理中");
				}
			//}
			$('#hkzh').html(Fw.util.Format.account(data.trsTrsfr[0].fromAcctNo));
			$('#tjsj').html(Fw.util.Format.fmtTrsCreDate(data.trsInfo[0].finishTime,"MM-dd HH:mm:ss"));
			
			if(data.succCount==0){
				$("#cgbs").addClass("hidden");
				$("#dh").addClass("hidden");
				$("#CG").addClass("hidden");
			}
			if(data.failCount==0){
				$("#sbbs").addClass("hidden");
				$("#dh").addClass("hidden");
				$("#SB").addClass("hidden");
			}
			if(data.succCount==0&&data.failCount==0){
				$("#SB").addClass("hidden");
				$("#CG").addClass("hidden");
				$("#ccbs").addClass("hidden");
			}
		}
		//屏蔽明细显示
	  	if(data.trsInfo[0].readFlag && data.trsInfo[0].readFlag=="1"){
  			$('#hklx').html( "钱包代发（屏蔽明细）");
  		}else{
  			$('#hklx').html( "钱包代发");
  		}
		$('#trsNo').html(Fw.util.Format.subTrsNo(data.trsNo));
		$('#hkje').html(Fw.util.Format.fmtAmt(data.amount+'')+"元");
		$('#cgje').html(Fw.util.Format.fmtAmt(data.succAmount+'')+"元");
		$('#sbje').html(Fw.util.Format.fmtAmt(data.failAmount+'')+"元");
		$('#bs').html(data.count+"笔");
		$('#cgbs').html("成功"+data.succCount+"笔");
		$('#sbbs').html("失败"+data.failCount+"笔");
		
		App.attach_url = data.attach_url;
		App.showFj(data.attach);
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 显示附件
	 */
	showFj:function( d ){
		Fw.util.attach.showAttach( d );
	},
	/**
	 * 加载处理意见
	 */
	showChuli:function( d ){
 		var html='',html1='',html2='';
 		var temp = [
	      			'{@each dealLog as item}',
	      			'{@if item.dealUserId != ""}',
			      			'<div class="yui_div_hm" >',
				 				'<div class="ui_01_div2">',
					 				'<div class="ui_01_div3 ui-list">',
					 					'<div class="ui_01_img1"></div>',
					 					'<div class="ui_01_time1">${item.dealTime|fmtTrsCreDate}</div>',
					 				'</div>',					 				
					 				'<div class="ui-bg-ss1">',
					 				'{@if item.dealType == 0}',
						 				'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey">退　回</div>',
				 						'</div>',
				 					'{@else if item.dealType == 1}',
					 					'<div class="ui_01_phoneTongYi ui-list">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">同　意</div>',
				 						'</div>',
				 					'{@else if item.dealType == 2}',
					 					'<div class="ui_01_phoneTongYi">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey yui-font-color999">办　结</div>',
				 						'</div>',
				 						'{@else if item.dealType == 3}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="${item.photoUrl}" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey ">撤　销</div>',
				 						'</div>',
				 						'{@else if item.dealType == 4}',
					 					'<div class="ui_01_phoneBack">',
					 						'<div class="ui_01_phone1"><img src="../../css/img/XTtouxiang.png" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>',
					 						'<div class="ui_01_greey ">拒　绝</div>',
				 						'</div>',	
					 				'{@/if}',
					 					'{@if item.dealType == 4}',
					 					'<div class="ui_01_div4">系统用户</div>',
					 					'{@else}',
					 					'<div class="ui_01_div4">${item.dealUserName}</div>',
					 					'<div class="ui_01_div5">(审批人)</div>',
					 					'{@/if}',
					 					'{@if item.dealType == 3}',
					 					'<div class="ui-bg-ss2">',
					 					　'该笔汇款已撤销',
							 				'</div>',
					 					'{@/if}',
					 					'{@if item.dealMsg}',
					 						'{@if item.dealType == 4}',
							 				'<div class="ui-bg-ss2">',
							 					　'拒绝原因:&nbsp;&nbsp;${item.dealMsg}',
							 				'</div>',	 
							 				'{@else}',
							 				'<div class="ui-bg-ss2">',
						 					　	'${item.dealMsg}',
						 					 '</div>',	 
							 				'{@/if}',	 
					 					'{@/if}',
					 				'</div>',
				 				'</div>',
			 				'</div>',
		 				'{@/if}',
	      			'{@/each}',
   			].join("");
   			
			html = Fw.template(temp,d);
			html1 = 
					'<div class="yui_div_hm" >'+
	 				'<div class="ui_01_div2">'+
		 				'<div class="ui_01_div3 ui-list">'+
		 					'<div class="ui_01_img1"></div>'+
		 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].trsCreTime)+'</div>'+
		 				'</div>'+
		 				
		 				'<div class="ui-bg-ss1">'+
		 					'<div class="ui_01_phoneTongYi">'+
		 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlCre+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
		 						'<div class="ui_01_greey yui-font-color999">申　请</div>'+
		 					'</div>'+
		 					'<div class="ui_01_div4">'+d.trsInfo[0].creUserName+'</div>'+
		 					'<div class="ui_01_div5">(申请人)</div>'+
		 				'</div>'+
	 				'</div>'+
	 			'</div>';
			if(d.trsInfo[0].trsStatus == "0"){
				html2 = 
					'<div class="yui_div_hm" >'+
					'<div class="ui_01_div2">'+
	 				'<div class="ui_01_div3 ui-list">'+
	 					'<div class="ui_01_img1"></div>'+
	 					'<div class="ui_01_time1">'+Fw.util.Format.fmtTrsCreDate(d.trsInfo[0].sendTime)+'</div>'+
	 				'</div>'+
	 				
	 				'<div class="ui-bg-ss1">'+
	 					'<div class="ui_01_phoneTongYi">'+
	 						'<div class="ui_01_phone1"><img src="'+d.trsInfo[0].photoUrlDel+'" onerror="javascript:this.src=\'../../css/img/morentouxiang.png \'"/></div>'+
	 						'<div class="ui_01_greey yui-font-color999">处理中</div>'+
	 					'</div>'+
	 					'<div class="ui_01_div4">'+d.trsInfo[0].dealUserName+'</div>'+
	 					'<div class="ui_01_div5">(审批人)</div>'+
	 				'</div>'+
					'</div>'+
				'</div>';
				$("#DQCLR").html(html2);
			}
			$("#SQR").html(html1);
			$("#CLR").html(html);
			// 延迟 10ms 高亮第一个处理事件
			setTimeout( function(){
				if($("#DQCLR").html()==''&& $("#CLR").html()!=''){
					if($('.ui_01_phoneBack').length>0){
						return false;
					}
					$("#CLR").find('.ui_01_phoneTongYi').first().removeClass().addClass('ui_01_phone');
					$("#CLR").find('.ui_01_greey').first().removeClass('yui-font-color999')
				}
				if($("#DQCLR").html()!=''){
					$("#DQCLR").find('.ui_01_phoneTongYi').removeClass().addClass('ui_01_phone');
					$("#DQCLR").find('.ui_01_greey').removeClass('yui-font-color999');
				}
			},10 );
			Fw.Client.hideWaitPanel();
			
	},
	toBack:function(){
		if (App.data.page) {
			Fw.Client.changePage("../10502/"+App.data.page+".html?trsStatus="+App.func("trsStatus")+"","1");
		}else{
			Fw.Client.changePage("../10502/1050200.html?trsStatus="+App.func("trsStatus")+"","1");
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);