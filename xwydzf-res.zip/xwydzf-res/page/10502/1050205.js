/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.flag = true;
		App.initEvent();
		if(App.func("trsStatus")){
			if(App.func("trsStatus") == "1"){
				App.onYCL();
			}else{
				App.onDCL();
			}
		}else{
			App.onDCL();
		}
	},
	/**
	 * 初始化事件
	 */
	initEvent : function(){
		// 已处理按钮
		App.pageA.on("click","#liYCL",App.onYCL);
		// 待处理按钮
		App.pageA.on("click","#liDCL",App.onDCL);
		// 新建按钮
		//App.pageA.on("click", "#btn-show", App.onShow);
		//标题点击事件
		App.pageA.on("click","#icon-top",App.onTop);
		//我申请的点击事件
		App.pageA.on("click","#btnIconb",App.initWSQD);
	},
	/**
	 * 标题点击事件,收起展开
	 */
	onTop:function(){
		if(App.flag){
			$("#top-center").addClass("hidden");
			$("#top-bottom").removeClass("yui-background-top").addClass("yui-background-topB");
			$("#tab-navnew").removeClass("yui-ui-tab-navnew").addClass("yui-ui-tab-navnewB");
			$("#top-bg").removeClass("yui-height170").addClass("yui-height70");
			$("#icon-topA").removeClass("yui-background-top1").addClass("yui-background-top2");
			App.flag = false;
		}else{
			$("#top-bg").removeClass("yui-height70").addClass("yui-height170");
			$("#top-bottom").removeClass("yui-background-topB").addClass("yui-background-top");
			$("#tab-navnew").removeClass("yui-ui-tab-navnewB").addClass("yui-ui-tab-navnew");
			$("#top-center").removeClass("hidden");
			$("#icon-topA").removeClass("yui-background-top2").addClass("yui-background-top1");
			App.flag = true;
		};
	},
	/**
	 * 标题我申请的
	 * 点击样式变为蓝色，跳转到我处理的列表
	 */
	initWSQD:function(){
		$("#btnIconb").removeClass("yui-backgroud-iconbb").addClass("yui-backgroud-iconb");
		$("#colIconb").removeClass("yui-font-col2").addClass("yui-font-col1");
		$("#btnIconc").removeClass("yui-backgroud-iconc").addClass("yui-backgroud-iconcc");
		$("#colIconc").removeClass("yui-font-col1").addClass("yui-font-col2");
		Fw.Client.changePage("1050200.html","0");
	},
	
	
	/**
	 * 查询日期 1、签发 2、查询
	 */
	showSendTime : function() {
		var datas = {
			"func" : "App.opData",
			"flag" : "0",
			"date" : ""
		}
		Fw.Client.showDatePicker(Fw.JsonToStr(datas));
	},
	opData : function(begin,end) {
		App.beginTime =begin;
		App.endTime = end;
		switch (App.trsStatus) {
		case '0':
			url = YT.dataUrl("private/findTaskUnProc");
			$.get("10502_LB.html?v=SID", {}, App.query);
			break;
		case '1':
			url = YT.dataUrl("private/findTaskProced");
			$.get("10502_LB.html?v=SID", {}, App.query);
			break;
		default:
			break;
		}
	},
	/**
	 * 已处理
	 */
	onYCL : function(){
		App.pageA.off("click","#liYCL",App.onYCL);
		App.pageA.off("click","#liDCL",App.onDCL).on("click","#liDCL",App.onDCL);
		$("#d").attr("class","yui-background-2 yui-background");
		$("#liDCL").removeClass("current yui-current");
		$("#y").attr("class","yui-background-1 yui-background");
		$("#liYCL").addClass("current yui-current");
		App.trsStatus = "1";
		App.beginTime ="";
		App.endTime ="";
		App.url = YT.dataUrl("private/findTaskProced");
		$.get("10502_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 待处理
	 */
	onDCL : function(){
		App.pageA.off("click","#liYCL",App.onYCL).on("click","#liYCL",App.onYCL);
		App.pageA.off("click","#liDCL",App.onDCL);
		$("#y").attr("class","yui-background-4 yui-background");
		$("#liYCL").removeClass("current yui-current");
		$("#d").attr("class","yui-background-5 yui-background");
		$("#liDCL").addClass("current yui-current");
		App.trsStatus = "0";
		App.beginTime ="";
		App.endTime ="";
		App.url = YT.dataUrl("private/findTaskUnProc");
		$.get("10502_LB.html?v=SID", {}, App.query);
	},
	/**
	 * 加载列表
	 */
	query : function(tpl) { 
		Fw.Client.openWaitPanel();
		var json = {
				trsType:"8",
				trsStatus:App.trsStatus,
				timeBegin : App.beginTime,
				timeEnd :App.endTime,
				webTrsStatus:"4"
		};
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "datas",
			page : true,
			pageSize:5,
			disclosure : true,
			ajax : {
				url : App.url,
				params : json
			},
			itemTpl : tpl,
		});
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(App.trsStatus);
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		var page = pageIndex || 1;
		Fw.Client.hideWaitPanel();
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 显示详情
	 */
	showDetail : function(itemData, itemIndex, itemElem) {
		if(App.trsStatus == "0"){
			Fw.Client.changePage('../10502/det15D.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+'&page=1050205'+"","1")
		}else if(App.trsStatus == "1"){
			Fw.Client.changePage('../10502/det15C.html?trsNo='+itemData.trsNo+'&trsStatus='+itemData.trsStatus+'&page=1050205'+"","1")
		}
	},
	
	/**
	 * 返回工作首页
	 */
	gotoHomePage:function(){
		Fw.Client.gotoHomePage();
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);