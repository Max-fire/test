var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.type="";
		App.initEvent();
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		//初始化时间插件	
		App.pageA.on("click","#cz",App.toCZ);
		App.pageA.on("click","#qr",App.toQR);
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 类型：银联线下00,微信支付01,分期支付02,积分支付03,支付宝04,银联二维码05,超网二维码06,QQ钱包07,翼支付08
	 */
	toChange:function(i){
		App.type="0"+i;
		$("#0"+i).addClass("yui-sdsh-borderc").removeClass("yui-sdsh-border").siblings('.yui-yqdz-fl28').addClass("yui-sdsh-border").removeClass("yui-sdsh-borderc");
	},
	/**
	 * 重置
	 */
	toCZ:function(){
		App.type="";
		$("#00").parent().find(".yui-yqdz-fl28").addClass("yui-sdsh-border").removeClass("yui-sdsh-borderc");
		qdate.resetData();
	},
	/**
	 * 确认
	 */
	toQR:function(){
		if ($("#sxsj").val()=="") {
			Fw.Form.showPinLabel($(this), "请选择筛选时间", true);
			return;
		}
		var date=$("#sxsj").val();
			var json={
				pay_prod_type : App.type,
				startDate : date,
				endDate : date,
				mer_name_ch:App.data.mer_name_ch
		}
		Fw.redirect("1060304.html",json);
	},
	/**
	 * 返回
	 */
	toBackA:function(){
			Fw.redirect("1060304.html",App.data);
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);