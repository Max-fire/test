var App = {
	/**
	 * 初始化 应用入口
	 */
	init:function() {
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [], true);
		App.userInfo={};
		App.flag=false;
	},
	/**
	 * 初始化事件
	 */
	initEvent:function(){
		App.pageA.on("click","#dlmm",App.showTPwdPicker1);
		App.pageA.on("click","#qrdlmm",App.showTPwdPicker);
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		var width=(document.body.clientWidth-166)/3;
		$("#step12x").attr("style","width:"+width+"px;");
		$("#step23x").attr("style","width:"+width+"px;");
		$("#step34x").attr("style","width:"+width+"px;");
		App.queryInfo();
	},
	queryInfo:function(){
		var url = YT.dataUrl("public/findUserBasicInfo");
		var params={
				MOBILE:App.data.mobile,
		}
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				var json={
						idNo:data.idNo,
						userName:data.userName,
						userMobile:data.userMobile
					}
					Fw.Client.getVerify(json);
					Fw.Client.hideWaitPanel();
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		},function(data){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		);
	},
	/**
	 * 提交
	 */
	toSubmit:function(){
		var dlmm=$("#dlmm").val();
		var qrdlmm=$("#qrdlmm").val();
		if (dlmm=="") {
			Fw.Form.showPinLabel($(this), "请输入登录密码", true);
			return;
		}
		if (qrdlmm=="") {
			Fw.Form.showPinLabel($(this), "请输入确认密码", true);
			return;
		}
		if (dlmm.length<6) {
			Fw.Form.showPinLabel($(this), "密码长度不足6位", true);
			return;
		}
		if (qrdlmm.length<6) {
			Fw.Form.showPinLabel($(this), "确认密码长度不足6位", true);
			return;
		}
		if (App.flag) {
			Fw.Form.showPinLabel($(this), "请勿重复提交", true);
			return;
		}
		App.flag=true;
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/merchantRegistXYGJ");
		App.data.newPassWord=$("#dlmm").attr("data-value");
		App.data.newPassWord1=$("#qrdlmm").attr("data-value");
		//Fw.Client.setLockPassWord(data.ncid,"App.toZCCG()");
		YT.ajaxData(url,App.data,function(data){
			if(data.STATUS=="1"){
					App.flag=false;
					Fw.Client.hideWaitPanel();
					Fw.Client.setLockPassWord(data.ncid,"App.toZCCG()");
			}else{
				App.flag=false;
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		},function(data){
			App.flag=false;
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		);
	},
	/**
	 * 设置手势密码回调
	 */
	toZCCG:function(){
		Fw.redirect("1060303.html",App.data);
	},
	/**
	 * 登录密码键盘
	 */
	showTPwdPicker:function(){
		Fw.Client.showTPwdPicker($(this));
	},
	showTPwdPicker1:function(){
		Fw.Client.showTPwdPicker($(this),true);
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		Fw.redirect("1060301.html",App.data);
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);