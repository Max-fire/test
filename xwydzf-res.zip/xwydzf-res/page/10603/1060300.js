var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		var width=(document.body.clientWidth-166)/3;
		var width2=(document.body.clientWidth-148)/2;
		if (App.func("phone")) {
			$("#sj").addClass("hidden");
			$("#js").removeClass("ui-border-b");
			$("#step34x").addClass("hidden");
			$("#step4").addClass("hidden");
			$("#step12x").attr("style","width:"+width2+"px;");
			$("#step23x").attr("style","width:"+width2+"px;");
			$("#pageA").attr("data-btnLeft","true|返回|back()");
		}else{
			$("#step12x").attr("style","width:"+width+"px;");
			$("#step23x").attr("style","width:"+width+"px;");
			$("#step34x").attr("style","width:"+width+"px;");
		}
		if (App.data) {
			$("#shbh").val(App.data.merchantNo);
			$("#shmc").val(App.data.merchantName);
			$("#frxm").val(App.data.artifName);
			$("#zjhm").val(App.data.artifIdNo);
			$("#jskh").val(App.data.settleCard);
			$("#sjhm").val(App.data.mobile)
		}
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 表单提交
	 */
	toSubmit:function(){
		var merchantNo =$("#shbh").val();
		var artifName =$("#frxm").val().replace(/^(\s|\u00A0)+/,"").replace(/(\s|\u00A0)+$/,"");
		var artifIdNo =$("#zjhm").val();
		var settleCard =$("#jskh").val();
		var mobile =$("#sjhm").val();
		var tel =  /^(1)[0-9]{10}$/;
		var url ="";
		//商户编号
		if (merchantNo == null || merchantNo == "") {
			Fw.Form.showPinLabel($(this), "请输入商户编号", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji(merchantNo)){
			Fw.Form.showPinLabel($(this), "商户编号包含特殊字符", true);
			return;
		}
		//商户负责人姓名
		if (artifName == null || artifName == "") {
			Fw.Form.showPinLabel($(this), "请输入负责人姓名", true);
			return;
		}
		if(Fw.util.proofTest.proolEmoji(artifName)){
			Fw.Form.showPinLabel($(this), "负责人姓名包含特殊字符", true);
			return;
		}
		//证件号码
		if (artifIdNo == null || artifIdNo == "") {
			Fw.Form.showPinLabel($(this), "请输入证件号码", true);
			return;
		}
		//结算卡号
		if (settleCard == null || settleCard == "") {
			Fw.Form.showPinLabel($(this), "请输入结算卡号", true);
			return;
		}
		if (isNaN(settleCard)) {
			Fw.Form.showPinLabel($(this), "请输入正确结算卡号", true);
			return;
		}
		var params = {
				merchantNo : merchantNo,
				artifName : artifName,
				artifIdTpye : "01",
				artifIdNo : artifIdNo,
				settleCard : settleCard,
	
		}
		if (!App.func("phone")) {
			//手机号码
			if (mobile == null || mobile == "") {
				Fw.Form.showPinLabel($(this), "请输入手机号码", true);
				return;
			}
			if (!tel.test(mobile)||mobile.length != '11') {
				Fw.Form.showPinLabel($(this), "请输入正确手机号!", true);
				return;
			}
			params.mobile=mobile;
			params.regist="yes";
			url = YT.dataUrl("private/merchantAcceptCheck");
		}else{
			params.mobile=App.func("phone");
			params.regist="no";
			url = YT.dataUrl("private/linkMerchantAccpt");
		}
		Fw.Client.openWaitPanel();
		YT.ajaxData(url,params,function(data){
			if(data.STATUS=="1"){
				params.busi_lic_no=data.busi_lic_no;
				params.merchantName=data.merchantName;
				Fw.redirect("1060301.html",params);
			}else{
				Fw.Client.alertinfo(data.MSG,"消息提示");
				Fw.Client.hideWaitPanel();
			}
		},function(data){
			Fw.Client.alertinfo(data.MSG,"消息提示");
			Fw.Client.hideWaitPanel();}
		);
		
	},
	
	/**
	 * 返回
	 */
	toBackA:function(){
		Fw.Client.toLogin();
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);