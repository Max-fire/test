var App = {
	/**
	 * 初始化 应用入口
	 */
	init:function() {
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化事件
	 */
	initEvent:function(){
		App.pageA.on("click","#btnSubmit",App.toBackA);
		$("#shmc").html(App.data.merchantName);
		$("#shbh").html(App.data.merchantNo);
		$("#frxm").html(App.data.artifName);
		$("#dlm").html(App.data.mobile);
		if (App.data.regist=="no") {
			$("#pageA").attr("data-btnLeft","true|返回|back()");
			$("#ts").addClass("hidden");
			$("#zcts").html("恭喜您,关联成功!");
			if (App.data.strMsg) {
				$("#yhlx").html(App.data.strMsg);
			}
		}
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		if (App.data.regist=="no") {
			Fw.Client.gotoHomePage();
		}else{
			Fw.Client.toLogin();
		}
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);