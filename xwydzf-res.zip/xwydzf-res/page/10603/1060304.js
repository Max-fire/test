var App = {
	requires : ['Fw.util.attach','Fw.util.proofTest'],
	/**
	 * 初始化 应用入口
	 */
	init:function(require) {
		App.pageA = $("#pageA");
		App.pageB = $("#pageB");
		App.func = window['_getParameter'];
		App.data = Fw.getParameters();
		App.type="";
		
		Fw.Client.openWaitPanel();
		App.initEvent();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		App.pageA.on("click","#sx",App.toSX);
		if (App.data && App.data.mer_name_ch) {
			$("#shmc").html(App.data.mer_name_ch);
			App.merName=App.data.mer_name_ch;
			App.type=App.data.pay_prod_type;
			$("#rq").html(Fw.util.Format.fmtSignDate(new Date())==App.data.startDate?"今日":App.data.startDate);
		}
		App.query();
	},
	/**
	 * 查询今日账单
	 */
	query:function(){
		var temp = [
		        '<div style="padding: 10px 15px;background-color: white;" class="ui-border-b">',
		    		'<div class="yui-yqdz-fl65">',
		    		 '{@if item.zfcplx=="00"}',
		    		 '<div class="yui-sdsh-yl">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else if item.zfcplx=="01"}',
		    		 '<div class="yui-sdsh-wx">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else if item.zfcplx=="04"}',
		    		 '<div class="yui-sdsh-zfb">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
					'{@else if item.zfcplx=="02"}',
		    		 '<div class="yui-sdsh-fq">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
					 '{@else if item.zfcplx=="03"}',
		    		 '<div class="yui-sdsh-jf">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else if item.zfcplx=="05"|| item.zfcplx=="09"}',
		    		 '<div class="yui-sdsh-ylqb">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else if item.zfcplx=="06"}',
		    		 '<div class="yui-sdsh-cw">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else if item.zfcplx=="07"}',
		    		 '<div class="yui-sdsh-qqqb">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else if item.zfcplx=="08"}',
		    		 '<div class="yui-sdsh-yzf">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@else}',
		    		 '<div class="yui-sdsh-moren">',
		    		 '<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;color: #666666;"><span>订单后四位</span><span style="padding-left: 10px;">${item.shddh|subNo}</span></div>',
		    		 '{@/if}',
		    			'<div class="yui-sdsh-height yui-sdsh-overflow"><span>${item.zjyrq|fmtYear}</span><span style="padding-left: 10px;">${item.zjysj|fmtDate}</span></div>',
		    		'</div>',
		    		'</div>',
		    		'<div  class="yui-yqdz-fl35 yui-yqdz-r" style="overflow: hidden; text-overflow: ellipsis;">',
		    			'<div class="yui-sdsh-height yui-sdsh-overflow" style="color: black;font-size: 18px;">￥<span>${item.jyje}</span></div>',
		    			'<div class="yui-sdsh-height yui-sdsh-overflow" style="font-size: 16px;">${item.jylx_zh}</div>',
		    		'</div>',
		    		'<div style="clear: both;"></div>',
		    		'<div style="font-size: 16px;text-align: right;">${item.jyzt|fmtShStatus}</div>',
		    	'</div> ',
					].join("");
		var json={
				startDate : new Date(),
				endDate : new Date()
			}
		var url = YT.dataUrl("private/merIndex");
		if(App.data){
				json=App.data;
				url = YT.dataUrl("private/merHistoryFilter")
		}
		var listView = App.listView = new Fw.ListView({
			contentEl : 'list',
			dataField : "trades",
			page : true,
			pageSize:10,
			disclosure : true,
			ajax : {
				url : url,
				params : json
			},
			itemTpl : temp,
		});
		
		listView.custFunc4NextPage = App.hasNextPage;
		listView.on('itemtap', App.showDetail, this);
		listView.loadData(new Date());
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage : function(rst, pageIndex) {
		
		if (rst.shzwmc) {
			$("#shmc").html(rst.shzwmc);
			App.merName=rst.shzwmc;
		};
		if (rst.trades!=""&&rst.trades!=null) {
		}else{
			var html='<div class="yui-sdsh-hw yui-yqdz-c yui-sdsh-wsj">呜呜呜~~~今日无进账</div>';
			$("#list").html(html);
		}
		Fw.Client.hideWaitPanel();
		YT.showPageArea(App.pageA, [App.pageB], true);
		var page = pageIndex || 1;
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 显示详情
	 */
	showDetail : function(itemData, itemIndex, itemElem) {
		var lx="";
		$("#jyje").html(itemData.jyje);
//	 Fw.util.Format.qdtype(itemData.zfcplx);
		if (itemData.zfcplx=="00"){
			lx="银联线下"
		}else if (itemData.zfcplx=="01") {
			lx="微信支付"
		}else if (itemData.zfcplx=="04") {
			lx="支付宝"
		}else if(itemData.zfcplx=="02"){
			lx="分期支付"
		}else if(itemData.zfcplx=="03"){
			lx="积分支付"
		}else if(itemData.zfcplx=="05"||itemData.zfcplx=="09"){
			lx="银联二维码"
		}else if(itemData.zfcplx=="06"){
			lx="超网二维码"
		}else if(itemData.zfcplx=="07"){
			lx="QQ钱包"
		}else if(itemData.zfcplx=="08"){
			lx="翼支付"
	//	}else if(itemData.zfcplx=="09"){
	//		lx="京东钱包"
		}else{
			lx="其他"
		}
		$("#zffs").html(lx);
		$("#jyzt").html(Fw.util.Format.fmtShStatus(itemData.jyzt+""));
		$("#ddh").html(itemData.shddh);
		$("#jylx").html(itemData.jylx_zh);
		$("#jysj").html(Fw.util.Format.fmtYear(itemData.zjyrq+"")+" "+Fw.util.Format.fmtDate(itemData.zjysj+""));
		$("#zdbh").html(itemData.zdxh);
		YT.showPageArea(App.pageB, [App.pageA], true);
	},
	toSX : function(){
		var startDate=Fw.util.Format.fmtSignDate(new Date());
		var endDate=Fw.util.Format.fmtSignDate(new Date());
		if(App.data){
			startDate=App.data.startDate;
			endDate=App.data.endDate;
		}
		var json={
				type:App.type,
				mer_name_ch:App.merName,
				startDate:startDate,
				endDate:endDate,
				pay_prod_type:App.type
		}
		Fw.redirect("1060305.html",json);
	},
	/**：
	 * 查看详情返回
	 */
	toBankMain:function(){
		YT.showPageArea(App.pageA, [App.pageB], true);
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		Fw.Client.gotoHomePage();
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);