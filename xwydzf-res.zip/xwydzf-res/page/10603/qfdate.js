$(function() {
   qdate= new QfDatePicker();
   qdate.init();
});

function QfDatePicker() {
    var _this = this;
    var maxYear = new Date().getFullYear();
    var nowMonth= new Date().getMonth()+1;
    var nowday= new Date().getDate();
    var minYear = 2004;

    var curOpt = null;
    var rootDiv = null;
    var yearScroll, monthScroll, dayScroll;

    var yearList = [],
        monthList = [],
        dayList = [];
    this.init = function() {
        _this.initView();
        _this.initData();
        dayScroll.changeFunction=_this.updateDate;
        monthScroll.changeFunction=_this.updateMonth;
        yearScroll.changeFunction=_this.updateYear;
    };
    
    this.showDate=function(){
    	$(".dataBar").removeClass("yui-sdsh-sj");
    	$("#day"+dayScroll.getValue()).addClass("yui-sdsh-sj").addClass("day");
    	$("#month"+monthScroll.getValue()).addClass("yui-sdsh-sj").addClass("month");
    	$("#year"+yearScroll.getValue()).addClass("yui-sdsh-sj").addClass("year");
    	 $(".qfdate").val(this.getDate());
    };

    this.getDate = function() {
    	var month=monthScroll.getValue();
    	var day=dayScroll.getValue();
    	if (monthScroll.getValue()<10) {
    		month="0"+month;
		}
    	if (day<10) {
    		day="0"+day;
		}
        var date = yearScroll.getValue() + '-' + month + '-' + day;
        return date;
    };
    
    this.initData = function() {
        for (var i = minYear; i < maxYear + 1; i++) {
            yearList[i - minYear] = i;
        };
        for (var i = 0; i < nowMonth; i++) {
            monthList[i] = i + 1;
        };
        for (var i = 0; i < nowday; i++) {
            dayList[i] = i + 1;
        };
        yearScroll.setData(yearList,"year");
        monthScroll.setData(monthList,"month");
        dayScroll.setData(dayList,"day");
        $("#day"+nowday).addClass("yui-sdsh-sj").addClass("day");
        $("#month"+nowMonth).addClass("yui-sdsh-sj").addClass("day");
        $("#year"+maxYear).addClass("yui-sdsh-sj").addClass("day");
        _this.resetData();
        _this.showDate();
    };
    
    this.resetData = function() {
        yearScroll.selectIndex(yearList.length-1);
        monthScroll.selectIndex(nowMonth);
        dayScroll.selectIndex(nowday-1);
    };

    this.updateDate = function() {
        _this.showDate();
    };
    
    this.updateMonth = function(){
    	var y = yearScroll.getValue();
        var m = monthScroll.getValue();
        var curIndex = dayScroll.curIndex;
        var daycount = new Date(y, m, 0).getDate();
        if (y==maxYear && m==nowMonth) {
        	 dayList = [];
        	 for (var i = 0; i < nowday; i++) {
                 dayList[i] = i + 1;
             };
               dayScroll.setData(dayList,"day");
        	   dayScroll.selectIndex(nowday-1);
               $(".dataBar.day").removeClass("yui-sdsh-sj");
               $("#day"+dayScroll.getValue()).addClass("yui-sdsh-sj");
		}else{
				dayList = [];
				for (var i = 0; i < daycount; i++) {
					dayList[i] = i + 1;
				};
				dayScroll.setData(dayList,"day");
				dayScroll.selectIndex(curIndex);
				$(".dataBar.day").removeClass("yui-sdsh-sj");
	            $("#day"+dayScroll.getValue()).addClass("yui-sdsh-sj");
		}
        _this.showDate();
    };
    
    this.updateYear = function(){
    	var y = yearScroll.getValue();
    	var curIndexm = monthScroll.curIndex;
    	if (y!=maxYear) {
        	monthList = [];
        	for (var i = 0; i < 12; i++) {
                monthList[i] = i + 1;
            };
            monthScroll.setData(monthList,"month");
            monthScroll.selectIndex(curIndexm);
            $(".dataBar.month").removeClass("yui-sdsh-sj");
            $("#month"+monthScroll.getValue()).addClass("yui-sdsh-sj");
		}else{
			monthList = [];
        	for (var i = 0; i < nowMonth; i++) {
                monthList[i] = i + 1;
            };
            monthScroll.setData(monthList,"month");
            monthScroll.selectIndex(nowMonth);
            $(".dataBar.month").removeClass("yui-sdsh-sj");
            $("#month"+monthScroll.getValue()).addClass("yui-sdsh-sj");
		}
    	 _this.showDate();
    };

    this.initView = function() {
        $('.a').append(
            '<div class="qfDatepickerRoot">' +
            '<div class="yearScroll"></div>' +
            '<div class="monthScroll"></div>' +
            '<div class="dayScroll"></div>' +
            '<div class="datepickerBtnDiv">' +
            '</div>' +
            '</div>'
        );

        rootDiv = $('.qfDatepickerRoot');
        cancelBtn = rootDiv.find('.cancelBtn');
        okBtn = rootDiv.find('.okBtn');

        yearScroll = new QfScroll($('.yearScroll'));
        monthScroll = new QfScroll($('.monthScroll'));
        dayScroll = new QfScroll($('.dayScroll'));

        $('.qfDatepickerRoot').css({
            "background": "#fcfcfc",
            "height": "auto",
            "text-align": "center",
        });

        rootDiv.find('.datepickerBtnDiv').css({
            "text-align": "right",
            "margin": "10px"
        });

        rootDiv.find('.datepickerBtn').css({
            "display": "inline-block",
            "text-align": "center",
            "margin-right": "10px",
            "padding": "10px 20px",
            "color": "#333"
        });

    };
};

function QfScroll(divOpt) {
    var _this = this;

    var dataPanel = null;
    var selectedBar = null;
    var dataBar = null;
    var type=null;
    var touchEvents = null;
    var oneHeight = 0;
    var dataList = null;
    this.curIndex = 0;

    var mY = 0;
    var dY = 0;
    var isDown = false;

    this.getValue = function() {
        return dataList[_this.curIndex];
    };


    this.setData = function(data,type) {
        divOpt.empty();
        _this.initTouchEvents();
        _this.initView();
        _this.addEventListener(type);
        dataList = data;
        for (var i = 0; i < dataList.length; i++) {
            dataPanel.append('<div id="'+type+dataList[i]+'" class="dataBar '+type+'">' + dataList[i] + '</div>');
        };

        dataBar = divOpt.find('.dataBar');
        dataBar.height(divOpt.height() / 5);
        dataBar.css('line-height', divOpt.height() / 5 + 'px');
        _this.selectIndex(dataList.length - 1);

    };

    this.addEventListener = function(type) {
        dataPanel.bind(touchEvents.start, function(event) {
            event.preventDefault();
            mY = _this.getMousePos(event).y;
            dY = dataPanel.position().top;
            isDown = true;
        });
        dataPanel.bind(touchEvents.move, function(event) {
            event.preventDefault();
            var y = _this.getMousePos(event).y;
            if (isDown) {
                _this.setTop(y - mY + dY);
            };
        });
        dataPanel.bind(touchEvents.end, function(event) {
            event.preventDefault();
            isDown = false;
            _this.setRightTop();
        });
    };

    this.setRightTop = function() {
        var topValue = dataPanel.position().top;
        if (topValue >= 0) {
            if ((topValue % oneHeight) <= (oneHeight / 2)) {
                index = -parseInt(topValue / oneHeight) + 2;
            } else {
                index = -parseInt(topValue / oneHeight) + 1;
            };
            if (topValue >= oneHeight * 2) {
                index = 0;
            };
        } else {
            if ((-topValue % oneHeight) <= (oneHeight / 2)) {
                index = parseInt(-topValue / oneHeight) + 2;
            } else {
                index = parseInt(-topValue / oneHeight) + 3;
            };
            if (topValue <= -oneHeight * (dataList.length - 3)) {
                index = dataList.length - 1;
            };

        };
        _this.selectIndex(index);
    };


    this.changeFunction = function() {
    	
    };

    this.selectIndex = function(index) {
        if (index >= dataList.length) {
            _this.selectIndex(dataList.length - 1);
            return;
        };
        var val = oneHeight * 2 - index * oneHeight;
        _this.setTop(val);
        _this.curIndex = index;
        _this.changeFunction();
    };


    this.setTop = function(value) {
        dataPanel.css('top', value);
    };

    this.setWidth = function(value) {
        divOpt.css('width', value);
    };

    this.initView = function(event) {

        divOpt.addClass('qfScroll');
        divOpt.html(
            '<div class="dataPanel"></div>' +
            '<div class="selectedBar"></div>'
        );
        dataPanel = divOpt.find('.dataPanel');
        selectedBar = divOpt.find('.selectedBar');

        divOpt.css({
            "background": "#fcfcfc",
            "display": "inline-block",
            "height": "250px",
            "overflow": "hidden",
            "position": "relative",
            "float" : "left",
            "width" : "32%"
        });
        dataPanel.css({
            "text-align": "center",
            "position": "absolute",
            "width": "100%",
            "top": "0",
            "left": "0",
            "font-size": "18px",
            "color": "#999999",
            "z-index": "80"
        });

        selectedBar.css({
            "position": "absolute",
            "top": "40%",
            "left": "0",
            "width": "100%",
            "height": "20%",
            "border-top": "1px solid #e5e5e5",
            "border-bottom": "1px solid #e5e5e5",
            "z-index": "50"
        });
        oneHeight = divOpt.height() / 5;
    };

    this.initTouchEvents = function(event) {
        if (_this.isPC()) {
            touchEvents = {
                start: "mousedown",
                move: "mousemove",
                end: "mouseup",
                leave: "mouseleave"
            }
        } else {
            touchEvents = {
                start: "touchstart",
                move: "touchmove",
                end: "touchend",
                leave: "mouseleave"
            };
        }
    };


    this.isPC = function(event) {
        var userAgentInfo = navigator.userAgent;
        var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
        var flag = true;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) > 0) {
                flag = false;
                break;
            }
        }
        return flag;
    };

    this.getMousePos = function(event) {
        var e = event || window.event;
        var scrollX = document.documentElement.scrollLeft || document.body.scrollLeft;
        var scrollY = document.documentElement.scrollTop || document.body.scrollTop;
        var x = e.pageX || e.clientX + scrollX||e.originalEvent.changedTouches[0].pageX ;
        var y = e.pageY || e.clientY + scrollY||e.originalEvent.changedTouches[0].pageY;
        return {
            'x': x,
            'y': y
        };
    };
};
