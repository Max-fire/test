var App = {
	/**
	 * 初始化 应用入口
	 */
	init:function() {
		App.pageA = $("#pageA");
		App.data = Fw.getParameters();
		App.initEvent();
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 初始化点击事件
	 */
	initEvent:function(){
		/**
		 * 获取验证码
		 */
		var card=App.data.settleCard.substring(App.data.settleCard.length-4,App.data.settleCard.length);
		var params = {
				"type":"7",
				"mobile":App.data.mobile,
				"cardNo":card
		};
		Fw.util.Format.openTimerListener("yzm",params);
		App.pageA.on("click","#qkmm",App.showPwdPicker);
		App.pageA.on("click","#meg_code",App.showNumberPicker);
		App.pageA.on("click","#btnSubmit1",App.toSubmit1);
		App.pageA.on("click","#shxy",App.toSHXY);
		App.pageA.on("click","#zfxy",App.toZFXY);
		$("#qkmm").val(App.data.qkmm);
		$("#qkmm").attr("data-value",App.data.password);
		$("#meg_code").val(App.data.MSG);
		var width=(document.body.clientWidth-166)/3;
		var width2=(document.body.clientWidth-148)/2;
		if (App.data.regist=="no") {
			$("#step34x").addClass("hidden");
			$("#step4").addClass("hidden");
			$("#step12x").attr("style","width:"+width2+"px;");
			$("#step23x").attr("style","width:"+width2+"px;");
		}else{
			$("#step12x").attr("style","width:"+width+"px;");
			$("#step23x").attr("style","width:"+width+"px;");
			$("#step34x").attr("style","width:"+width+"px;");
		}
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 提交绑定
	 */
	toSubmit1:function(){
		if($("#qkmm").val()==""){
				Fw.Form.showPinLabel($(this), "取款密码不能为空", true);
			return;
		}
		if($("#qkmm").val().length!="6"){
			Fw.Form.showPinLabel($(this), "取款密码必须为6位", true);
			return;
		}
		if($("#meg_code").val()==""){
			Fw.Form.showPinLabel($(this), "验证码不能为空", true);
			return;
		}
		if($("#meg_code").val().length!="6"){
			Fw.Form.showPinLabel($(this), "验证码必须为6位", true);
			return;
		}
		if($("#ty:checked").val()==null){
			Fw.Form.showPinLabel($(this), "请勾选协议", true);
			return;
		}
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/merchantCoreCheck");
		App.data.MSG=$("#meg_code").val();
		App.data.password=$("#qkmm").attr("data-value");
		App.data.qkmm=$("#qkmm").val();
		YT.ajaxData(url,App.data,function(data){
			if(data.STATUS=="1"){
				if (App.data.regist=="no") {
					var url1 = YT.dataUrl("private/merchantLinkFirmInfo");
					YT.ajaxData(url1,App.data,function(data){
						if(data.STATUS=="1"){
							App.data.strMsg=data.strMsg;
							Fw.redirect("1060303.html",App.data);
						}
					},function(data){
						Fw.Client.hideWaitPanel();
						Fw.Client.alertinfo(data.MSG,"消息提示");
					});
				}else{
					if (data.setPwd=="2") {
						Fw.Client.hideWaitPanel();
						Fw.redirect("1060302.html",data);
					}else{
						var url1 = YT.dataUrl("private/merchantXYUserRegist");
						App.data.userid=data.userid;
						YT.ajaxData(url1,App.data,function(data){
							if(data.STATUS=="1"){
								Fw.redirect("1060303.html",App.data);
							}
						},function(data){
							Fw.Client.hideWaitPanel();
							Fw.Client.alertinfo(data.MSG,"消息提示");
						});
					}
				}
			}else{
				Fw.Client.hideWaitPanel();
				Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		},function(data){
			Fw.Client.hideWaitPanel();
			Fw.Client.alertinfo(data.MSG,"消息提示");
			}
		);
	},
	/**
	 * 数字键盘
	 */
	showNumberPicker:function(){
		Fw.Client.showNumberPicker($("#meg_code"))
	},
	/**
	 * 密码键盘
	 */
	showPwdPicker:function(){
		Fw.Client.showPwdPicker($("#qkmm"));
	},
	/**
	 * 兴业管家收单商户协议
	 */
	toSHXY:function(){
		App.data.MSG=$("#meg_code").val();
		App.data.password=$("#qkmm").attr("data-value");
		App.data.qkmm=$("#qkmm").val();
		Fw.redirect("shxy.html?No=1060301",App.data);
	},
	/**
	 *兴业管家移动支付协议
	 */
	toZFXY:function(){
		App.data.MSG=$("#meg_code").val();
		App.data.password=$("#qkmm").attr("data-value");
		App.data.qkmm=$("#qkmm").val();
		Fw.redirect("ydzfxy.html?No=1060301",App.data);
	},
	/**
	 * 返回
	 */
	toBackA:function(){
		if (App.data.regist=="no") {
			Fw.redirect("1060300.html?phone="+App.data.mobile+"",App.data);
		}else{
			Fw.redirect("1060300.html",App.data);
		}
	},
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);