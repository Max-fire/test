/**
 * 创建应用
 * 
 * @author yql
 */

var App = {
	/**
	 * 应用入口
	 */
	init : function(require) {
		App.pageA = $("#pageA");
		App.initEvent();
		App.data = Fw.getParameters();
		App.func = window['_getParameter'];
		App.mac="";
		Fw.Client.getMac("App.getMac");
		if (App.data.back) {
			App.acctNo=App.data.acctNo;
			App.loadData(App.data);
		}else{
			App.acctNo=App.data.acctNo;
			if (App.data.zjdzzq) {
				App.opData(App.data.zjdzzq);
			}else{
				App.opData("");
			}
		}
	},
    initEvent : function(){
    	App.pageA.on("click","#sj",App.toCX);
    },
	/**
	 * 明细查询回调函数
	 */
	opData : function(date) {
		var url = YT.dataUrl("private/queryBillDetail");
		Fw.Client.openWaitPanel();
		$("#zdsj").html(App.fmtYear(date+""));
		var params={
				dzzq:date+"",
				account:App.data.acctNo
		};
	    YT.ajaxData(url,params,App.success,App.failuri);
	},
	/**
	 * 成功回调函数
	 */
	success:function(data){
			if (data.STATUS == "1") {
	    		App.loadData(data);
			} else {
				var html="";
				$("#zq1").attr("style","display:block");
				$("#zq2").attr("style","display:none");
				html += '<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:22px;font-style:oblique; color: gray;">暂无账单！！！</div>';
				$("#list").html(html);
				YT.showPageArea(App.pageA, [], true);
				Fw.Client.alertinfo(data.MSG,"系统提示");
				Fw.Client.hideWaitPanel();
			}
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.hideWaitPanel();
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 * 加载数据
	 */
	loadData:function(data){
		App.data=data;
		App.data.acctNo=App.acctNo;
		var html="";
		if ( data.listMapResult==null) {
			$("#zq1").attr("style","display:block");
			$("#zq2").attr("style","display:none");
			html += '<div style="width: 100%; height: 88px; line-height: 88px; text-align:center; font-size:22px;font-style:oblique; color: gray;">暂无账单！！！</div>';
		}else{
			$("#bs").html(data.ddzsum);
			$("#zq2").show();
			$("#zq1").hide();
			for ( var d in data.listMapResult) {
				 
				html+='<div class="yui-yqdz-all">';
				html+='<div class="ui-border-b yui-yqdz-zh" style="font-size: 16px;">';
				html+='<div class="yui-yqdz-fl75">';
				html+='<div class="yui-yqdz-fl20">账号:</div>';
				html+='<div class="yui-yqdz-fl80 yui-bank-overf" style="padding:0px;">'+Fw.util.Format.fmtAcctNo(data.listMapResult[d].hxzh)+'</div>';
				html+='</div>';
				html+='<div class="ui-border-l yui-yqdz-hq" style="width: 23%">';
				html+='<div>'+Fw.util.Format.fmt(data.listMapResult[d].kmcc)+'</div>';
				html+='<div>'+data.listMapResult[d].hbzlmc+'</div>';
				html+='</div>';
				html+='</div>';
				html+='<div class="ui-border-b yui-yqdz-zqall">';
				html+='<div class="yui-yqdz-fl75 yui-yqdz-zql">';
				html+='<div>';
				html+='<div class="yui-yqdz-fl20 yui-cui-pf-font1" style="font-size: 14px;">账期:</div>';
				html+='<div class="yui-yqdz-fl80">'+App.fmtYear(data.listMapResult[d].dzdzq+"")+'</div>';
				html+='</div>';
				html+='<div>';
				html+='<div class="yui-yqdz-fl20 yui-cui-pf-font1">余额:</div>';
				html+='<div class="yui-yqdz-fl80">'+Fw.util.Format.fmtAmt(data.listMapResult[d].zhye)+'</div>';
				html+='</div>';
				html+='<div>';
				html+='<div class="yui-yqdz-fl20 yui-cui-pf-font1">状态:</div>';
				if (data.listMapResult[d].yejg=="0") {
					html+='<div class="yui-yqdz-fl80">待对账</div>';
				}
				if (data.listMapResult[d].yejg=="1") {
					html+='<div class="yui-yqdz-fl80">相符</div>';
				}
				if (data.listMapResult[d].yejg=="2") {
					html+='<div class="yui-yqdz-fl80 yui-cOrange">不相符</div>';
				}
				html+='</div>';
				html+='</div>';
				html+='<div class="yui-yqdz-fl25  yui-yqdz-r" style="margin-top: 20px;">';
				html+='<div  onclick="App.toMX('+d+')"><span class="yui-bqbj" style="border-radius: 3px;font-size: 14px;">明细查询</span></div>';
				html+='</div>';
				html+='</div>';
				html+='</div>';
				if (data.listMapResult[d].yejg=="0") {
					html+='<div class="yui-yqdz-height yui-yqdz-c yui-cc-border">';
					html+='<div class="yui-yqdz-fl50 yui-cOrange" onclick="App.toBXF('+d+')" ><div style="height: 10px;"></div><div class="ui-border-r" style="line-height: 22px;">不相符</div><div style="height: 10px;"></div></div>';
					html+='<div class="yui-yqdz-fl50 yui-color-b" onclick="App.toXF('+d+')">相符</div>';
					html+='</div>';
				}
				if (data.listMapResult[d].yejg=="2") {
					html+='<div class="yui-yqdz-height yui-yqdz-c yui-cc-border">';
					html+='<div class="yui-color-b" onclick="App.toXF('+d+')">改为相符</div>';
					html+='</div>';
				}
			}
		}
		if (data.zjdzzq) {
			$("#zdsj").html(App.fmtYear(data.zjdzzq+""));
		}
		$("#list").html(html);
		YT.showPageArea(App.pageA, [], true);
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 待对账不相符
	 */
	toBXF:function(i){
		var url="1040703.html?number="+i+"&trsId="+App.func("trsId")+"";
		App.data.acctNo=App.acctNo;
		Fw.redirect(url,App.data);
	},
	/**
	 * 相符
	 */
	toXF:function(i){
		var msg="账号（尾号"+App.data.listMapResult[i].hxzh.substring(App.data.listMapResult[i].hxzh.length-4,App.data.listMapResult[i].hxzh.length)+"）"+App.fmtYear(App.data.listMapResult[i].dzdzq)+"对账相符,请确认";
		Fw.Client.confirm(msg,"消息提示","App.goXF("+i+")");
	},
	/**
	 * 相符回执
	 */
	goXF:function(i){
		Fw.Client.openWaitPanel();
		var url = YT.dataUrl("private/checkReceipt");
		App.data.acctNo=App.acctNo;
		App.zq=App.data.listMapResult[i].dzdzq;
		var params={
				dzdbh : App.data.listMapResult[i].dzdbh,
				zhdh : App.data.listMapResult[i].hxzh,
				yehdjg : "1",
				hqzh :App.data.acctNo,
				macdz:App.mac
		};
	    YT.ajaxData(url,params,App.successxf,App.failuri);
	},
	/**
	 * 相符成功回调函数
	 */
	successxf:function(data){
		if (data.STATUS == "1") {
			App.opData(App.zq);
			} else {
				Fw.Client.alertinfo(data.MSG,"系统提示","App.opData("+App.zq+")");
			}
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 根据账期查询
	 */
	toCX:function(){
		Fw.Client.showPaymentDateDialog("App.opData")
	},
	/**
	 * 查看对账明细
	 */
	toMX:function(i){
		var url="1040702.html?number="+i+"&trsId="+App.func("trsId")+"";
		Fw.redirect(url,App.data);
	},
	fmtYear:function(s){
    	if(!s) return '';
        if(s=='null') return '';
    	return s.substring(0,4)+"年"+s.substring(4,6)+"月";
    },
    /**
     * 获取ip和mac
     */
    getMac:function(mac,ip){
    	App.mac=mac;
    },
    /**
	 * 返回前一页
	 */
    toBack:function(){
    	Fw.redirect("1040700.html?trsId="+App.func("trsId")+"");
    }
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);
