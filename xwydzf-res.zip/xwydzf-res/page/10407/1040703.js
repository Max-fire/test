/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		App.flag = true;
		App.data = Fw.getParameters();
		App.mac="";
		Fw.Client.getMac("App.getMac");
		App.i=0;
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#input1",App.showMoneyPicker);
		App.pageA.on("click","#input2",App.showMoneyPicker);
		App.pageA.on("click","#input3",App.showMoneyPicker);
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.pageA.on("click","#jia1",App.toJAH1);
		App.pageA.on("click","#jia2",App.toJAH2);
		App.pageA.on("click","#jian1",App.toJIH1);
		App.pageA.on("click","#jian2",App.toJIH2);
		App.pageA.on("click","#yh",App.toReplaceYh);
		var i=App.func("number");
		$("#lx").html(Fw.util.Format.fmt(App.data.listMapResult[i].kmcc));
		$("#bz").html(App.data.listMapResult[i].hbzlmc);
		$("#acctNo").html(Fw.util.Format.fmtAcctNo(App.data.listMapResult[i].hxzh));
		$("#yhye").html(Fw.util.Format.fmtAmt(App.data.listMapResult[i].zhye+""));
		$("#yhye").attr("data-value",App.data.listMapResult[i].zhye);
		YT.showPageArea(App.pageA, [], true);
		Fw.Client.hideWaitPanel();
		
	},
	/**
	 * 提交
	 */
	toSubmit:function(){
		var i=App.func("number");
		var yy=$("#yy").val();
		var dwye=$("#input1").attr("data-value");
		var dwtjye=$("#input2").attr("data-value");
		var yhtjye=$("#input3").attr("data-value");
		var jsye=$("#yy").html();
		if (dwye==undefined||dwye=="") {
			Fw.Form.showPinLabel($(this), "请输入单位余额", true);
			return;
		}
		if (yy==undefined||yy=="") {
				Fw.Form.showPinLabel($(this), "请输入不符原因", true);
				return;
		}
		if ($("#dwyex").html()!=$("#yhyex").html()) {
			Fw.Form.showPinLabel($(this), "调节后单位余额需与银行余额一致", true);
			return;
		}
		var url = YT.dataUrl("private/checkReceipt");
		Fw.Client.openWaitPanel();
		var params={
				dzdbh : App.data.listMapResult[i].dzdbh,
				zhdh : App.data.listMapResult[i].hxzh,
				yehdjg : "2",
				bfyy: yy,
				dwzmye: dwye,
				dwtjje: dwtjye,
				yhzmye: $("#yhye").attr("data-value"),
				yhtjje:yhtjye,
				hqzh :App.data.acctNo,
				macdz:App.mac
		};
	    YT.ajaxData(url,params,App.success,App.failuri);
	},
	/**
	 * 成功回调函数
	 */
	success:function(data){
		if (data.STATUS == "1") {
			Fw.redirect("1040701.html",App.data);
			} else {
				Fw.Client.alertinfo(data.MSG,"系统提示");
			}
		Fw.Client.hideWaitPanel();
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.openWaitPanel();
		Fw.Client.alertinfo(e,"消息提示");
	},
	sumMoney:function(){
		var jsye=($("#yhye").attr("data-value")*100-$("#input1").attr("data-value")*100)/100;
		var dwye1=($("#input1").attr("data-value")*100-$("#input2").attr("data-value")*100)/100;
		var dwye2=($("#input1").attr("data-value")*100+$("#input2").attr("data-value")*100)/100;
		var yhye1=($("#yhye").attr("data-value")*100+$("#input3").attr("data-value")*100)/100;
		var yhye2=($("#yhye").attr("data-value")*100-$("#input3").attr("data-value")*100)/100;
		$("#jsye").html(Fw.util.Format.fmtAmt(jsye+""));
		if ($("#jian1").hasClass("yui-yqdz-jj")){
			$("#dwyex").html(Fw.util.Format.fmtAmt(dwye1+""));
		}else{
			$("#dwyex").html(Fw.util.Format.fmtAmt(dwye2+""));
		}
		if ($("#jian2").hasClass("yui-yqdz-jj")) {
			$("#yhyex").html(Fw.util.Format.fmtAmt(yhye2+""));
		}else{
			$("#yhyex").html(Fw.util.Format.fmtAmt(yhye1+""));
		}
	},
	toJAH1:function(){
		$("#jia1").addClass("yui-yqdz-jj");
		$("#jian1").removeClass("yui-yqdz-jj");
		var dwye2=($("#input1").attr("data-value")*100+$("#input2").attr("data-value")*100)/100;
		$("#dwyex").html(Fw.util.Format.fmtAmt(dwye2+""));
	},
	toJIH1:function(){
		$("#jian1").addClass("yui-yqdz-jj");
		$("#jia1").removeClass("yui-yqdz-jj");
		var dwye1=($("#input1").attr("data-value")*100-$("#input2").attr("data-value")*100)/100;
		$("#dwyex").html(Fw.util.Format.fmtAmt(dwye1+""));
	},
	toJAH2:function(){
		$("#jia2").addClass("yui-yqdz-jj");
		$("#jian2").removeClass("yui-yqdz-jj");
		var yhye1=($("#yhye").attr("data-value")*100+$("#input3").attr("data-value")*100)/100;
		$("#yhyex").html(Fw.util.Format.fmtAmt(yhye1+""));
	},
	toJIH2:function(){
		$("#jian2").addClass("yui-yqdz-jj");
		$("#jia2").removeClass("yui-yqdz-jj");
		var yhye2=($("#yhye").attr("data-value")*100-$("#input3").attr("data-value")*100)/100;
		$("#yhyex").html(Fw.util.Format.fmtAmt(yhye2+""));
	},
	/**
	 * 调用金额键盘
	 */
	showMoneyPicker:function(){
		var Id=$(this).attr("id");
		App._preShowKeyBoard($(this));
		Fw.Client.showMoneyPicker($("#"+Id),true);
	},
	_preShowKeyBoard : function($ele) {
		if (Fw.isString($ele)) {
			$ele = $('#' + $ele);
		}

		var boardH = 255; // 自定义键盘高度
		var wHeight = $(window).height();
		var eh = $ele.height(); // 元素的高度
		var top = $ele.offset().top;
		var stop = $(window).scrollTop();// 滚动条高度
		var I = $ele.attr("data-boardI");// 偏移量，适用于页面没有导航条 推荐值55
		I = I ? I * 1 : 0;
		// 15为偏差量
		var newTop = wHeight - I + stop - top - eh - 20;
		if (newTop < boardH) {
			// Fw.log("--------newTop--------"+newTop);
			$(".page")
					.css(
							{
								'-webkit-transform' : 'translateY('
										+ (newTop - boardH) + 'px)',
								'transform' : 'translateY(' + (newTop - boardH)
										+ 'px)',
							});
		} else {
			$(".page").css({
				'-webkit-transform' : 'translateY(-2px)',
				'transform' : 'translateY(-2px)',
			});
		}
	},
	 /**
     * 获取ip和mac
     */
    getMac:function(mac,ip){
    	App.mac=mac;
    },
	gotoPage:function(){
		App.data.back="1040703";
		Fw.redirect("1040701.html?trsId="+App.func("trsId")+"",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);