/**
 * 创建应用
 * 
 * @author wangjx
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		Fw.Client.openWaitPanel();
		App.flag = true;
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		var url = YT.dataUrl("private/queryBillSignedInfo");
		var params={};
	    YT.ajaxData(url,params,App.success,App.failuri);
	},
	/**
	 * 成功回调函数
	 */
	success:function(data){
			if (data.STATUS == "1") {
	    		App.loadData(data);
			} else {
				Fw.Client.alertinfo(data.MSG,"系统提示","App.gotoHomePage()");
			}
			Fw.Client.hideWaitPanel();
	},
	/**
	 * 失败回调函数
	 */
	failuri:function(e){
		Fw.Client.alertinfo(e,"消息提示");
	},
	/**
	 * 加载数据
	 */
	loadData:function(data){
		App.data=data;
		var html="";
		if ( data.hqList==null) {
			Fw.Client.alertinfo(data.MSG,"消息提示","App.gotoHomePage()");
		}else{
			var i=0;
			for ( var d in data.hqList) {
				html+='<div class="yui-yqdz-bg yui-grk-lanbg" style="position: relative;" onclick="App.toXQ('+i+')">';
				html+='<div class="yui-yqdz-imgbj">';
				html+='<img src="../../css/bank_logo/309391000011.jpg" onerror="javascript:this.src=\'../../css/bank_logo/default.png \'"style="height: 35px; width: 35px;">';
				html+='</div>';
				html+='<div class="yui-yqdz-fl38 yui-yqdz-zh" style="padding-left:0px;opacity: 0.5;">兴业银行</div>';
				html+='<div class="yui-yqzh-rmb">'+Fw.util.Format.fmt(data.hqList[d].acctType)+'</div>';
				html+='<div style="clear: both;height: 0px;line-height: 0px;font-size: 0px;"></div>';
				html+='<div class="yui-grk-kh" style="font-size: 24px;"><span>'+Fw.util.Format.fmtAcctNo(data.hqList[d].acctNo)+'</span></div>';
				html+='<div style="float: right;">';
				html+='<div style="background: url("../../css/bank_logo/309391000011.jpg") no-repeat; background-size: 60%; background-position: 92% 47%;" class="yui-cui-tmtb"></div>';
				html+='</div>';
				html+='</div>';
				i++;
			}
		}
		$("#list").html(html);
		YT.showPageArea(App.pageA, [], true);
	},
	/**
	 * 查看账户对账详情
	 */
	toXQ:function(i){
		Fw.redirect("1040701.html?trsId="+App.func("trsId")+"",App.data.hqList[i]);
	},
	/**
	 * 返回工作首页
	 */
	gotoHomePage:function(){
		if(App.func("trsId")==""||App.func("trsId")==null||App.func("trsId")=="null"){
			Fw.Client.gotoHomePage();
		}else{
			Fw.Client.dealMessage("2",App.func("trsId"));
		}
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);