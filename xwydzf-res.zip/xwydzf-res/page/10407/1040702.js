/**
 * 创建应用
 * 
 * @author wangjx
 * 
 */
var App = {
	/**
	 * 初始化 应用入口
	 */
	init : function(require) {
		App.data = Fw.getParameters("_parameters");
		App.func = window['_getParameter'];
		App.pageA = $("#pageA");
		YT.showPageArea(App.pageA, [], true);
		App.i=App.func("number");
		App.initEvent();
	},
	/**
	 * 初始化事件
	 */
	initEvent : function() {
		App.pageA.on("click","#btnSubmit",App.toSubmit);
		App.query(App.data.listMapResult[App.i].dzdzq);
	},
	/**
	 *按时间查询明细
	 */
	toCXMX:function(){
		$("#btnSubmit").attr("style","display: none;");
		Fw.Client.showPaymentDate("App.opData",App.fmtYear(App.data.listMapResult[App.i].dzdzq));
	},
	/**
	 * 明细查询回调函数
	 */
	opData : function(begin,end) {
		App.data.beginTime=begin;
		App.data.endTime=end;
		App.query();
	},
	/**
	 * 加载数据
	 */
	query:function(zq){
		Fw.Client.openWaitPanel();
		var jdbj = "2";
		var tpl = '<div class="yui-yqdz-all yui-yqdz-mx">'+
				'<div class="yui-yqdz-fl90 yui-yqdz-zql"style="margin: 0px;">'+
					'<div>'+
						'<div class="yui-yqdz-fl50">{@if item.jdbj==0}支出{@else if item.jdbj==1}收入{@/if}</div>'+
						'<div class="yui-yqdz-fl50 yui-yqdz-r yui-lcxq-h1" style="color:#000;">{@if item.jdbj==0 && item.cbbz!=0}+${item.jyje.toString().substring(1,item.jyje.toString().length)|fmtAmt}{@else if item.jdbj==1 && item.cbbz!=0}${item.jyje.toString()|fmtAmt}{@else}${item.jdbj|fmtJDBJ}${item.jyje.toString()|fmtAmt}{@/if}</div>'+
					'</div>'+
					'<div>'+
						'<div class="yui-yqdz-fl50">余额</div>'+
						'<div class="yui-yqdz-fl50  yui-yqdz-r yui-lcxq-h1" style="color:#F26B00;">${item.zhye}</div>'+
					'</div>'+
					'<div>'+
						'<div class="yui-yqdz-fl50 yui-cui-pf-font1"><span class="yui-lcxq-jysj" style="padding-left: 18px;"></span><sapn>${item.jyrq|fmtYear} ${item.jysj|fmtDate}</sapn></div>'+
						'<div class="yui-yqdz-fl50 yui-cui-pf-font1 yui-yqdz-r zysm">${item.zysm}</div>'+
					'</div>'+
				'</div>'+
				'<div>'+
					'<input type="checkbox"  class="yui-yqdz-input"/>'+
				'</div>'+
			'</div>';
		var i=App.func("number");
		var json = {
				"zhdh":App.data.listMapResult[i].hxzh,
				"jdbj":"2",
				"qsrq":App.data.beginTime,
				"zzrq":App.data.endTime,
				"dqzq":zq
			};
		var url = YT.dataUrl("private/queryCheckBillInfo");
		var listView = new Fw.ListView({
				contentEl : 'list',
				dataField : "items",
				page : true,
				pageSize:10,
				disclosure : true,
				ajax : {
					url : url,
					params : json
				},
				itemTpl : tpl,
			});
			// 自定义分页识别
			listView.custFunc4NextPage = App.hasNextPage1;
			//判断是否有历史数据
			listView.lishi = App.lishishuju;
			// 加载数据
			listView.loadData();
			// 数据加载后触发
			listView.ajax.on('LoadTest', App.onLoad, this);
//			App.show();
	},
	/**
	 * 是否查询历史
	 * 
	 */
	lishishuju:function(res){
		return res;
	},
	/**
	 * 是否有下页 pageIndex：从1开始
	 */
	hasNextPage1 : function(rst, pageIndex) {
		Fw.Client.hideWaitPanel();
		var page = pageIndex || 1;
		if (rst.NEXT_PAGE!=""||rst.NEXT_KEY>0) {
			$("#btnSubmit").attr("style","display: block;");
		}else{
			$("#btnSubmit").attr("style","display: none;");
		}
		return rst && rst.NEXT_KEY && (rst.NEXT_PAGE * 1 > 0);
	},
	/**
	 * 完成
	 */
	toSubmit:function(){
		App.data.back="1040702";
		Fw.redirect("1040701.html",App.data);
	},
	fmtYear:function(s){
    	if(!s) return '';
        if(s=='null') return '';
    	return s.substring(0,4)+"-"+s.substring(4,6);
    },
	gotoPage:function(){
		App.data.back="1040702";
		 Fw.redirect("1040701.html?trsId="+App.func("trsId")+"",App.data);
	}
};

/**
 * 页面加载完毕后，初始化应用
 */
Fw.onReady(App);